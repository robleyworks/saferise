# Homepage copy · revision

**The homepage's job:** build recognition. Nothing else.

The visitor arrives carrying something unresolved. This page names it accurately enough that they think *that's me*, and shows them what it has cost. It does not explain the method — that belongs on the track pages. It does not price anything — that belongs on plans.

**Journey:** home → track page → plans. Or: track page → free Anxiety Reset → account → dashboard.

**Naming settled:** the session is the **Guided Meditation Experience**. Steps are **Recognise · Regulate · Release · Rise**. Seven more tracks in development.

---

## PART 1 · The sixteen wrong protocol names — fixed

Replace the three homepage carousels with these. They match the plans page and the built content.

### Track 01 · Personal Transformation
`01 Anxiety Reset · Agitated` · `02 Anger Alchemy · Agitated` · `03 Overwhelm Threshold · Agitated` · `04 Abandonment Wound · Agitated` · `05 Shame Dissolution · Unsteady` · `06 Grief Integration · Unsteady` · `07 Shutdown Recovery · Numb` · `08 Jealousy Release · Unsteady` · `09 Insecurity Anchor · Unsteady` · `10 Powerlessness & Despair · Numb`

### Track 02 · Relationship Healing
`01 Safe Conversation · Agitated` · `02 Rupture & Repair · Unsteady` · `03 Trust & Betrayal · Agitated` · `04 Resentment Release · Unsteady` · `05 Intimacy Barrier · Unsteady` · `06 Double Standard · Unsteady` · `07 Projection Clarity · Agitated` · `08 Appreciation & Support · Numb` · `09 Pursue & Withdraw · Unsteady` · `10 Conscious Separation · Numb`

### Track 03 · Professional Performance
`01 High-Stakes Presence · Agitated` · `02 Conflict Navigation · Agitated` · `03 Imposter Dissolution · Unsteady` · `04 Perfectionism Release · Agitated` · `05 Performance Anxiety · Agitated` · `06 Belonging Gap · Unsteady` · `07 Career Transition · Unsteady` · `08 Decision Fatigue · Numb` · `09 Burnout & Overload · Numb` · `10 Creative Flow · Unsteady`

**Removed because they do not exist:** Fear Transmutation · Conflict De-escalation · Boundary Setting · The Insecurity Anchor (Track 02) · Disconnection · Separation · The Invitation · Conflict at Work · Decision Pressure · Visibility.

**Derive from the same source the plans page uses.** A second hand-maintained list is how this happened.

---

## PART 2 · Hero

**Keep**
> Something takes over before you get a say.

**Replace the body**

> A state arrives, and it doesn't only decide what you do. It decides what you think happened.
>
> Whether they meant it. Whose fault it was. What it says about you. What you can expect next.
>
> And you don't hold that lightly. You act on it. You bring it to the next conversation, and the one after that, and within a year you're no longer responding to what happened — you're responding to something you assembled on a bad night and never went back to check.

**Keep**
> No course. No schedule. Nothing to install.

---

## PART 3 · New section — what it costs

**This is the section that has been missing.** Directly after the hero, before the router.

The visitor needs to see the damage before they'll accept there's a mechanism. Not a warning about the future — a description of what has already happened to them.

**Eyebrow**
WHY IT MATTERS MORE THAN IT LOOKS

**Headline**
It never stays where it started.

**Body**

> One evening you decided what somebody meant. You weren't in any state to be deciding it, but nobody's ever in a state to notice that at the time.
>
> So you kept it. And the next time they did something similar, it confirmed the first one. And by the third, you weren't reading them any more — you were reading the file.

**Section — the same thing, three ways**

> **What it did to that friendship.** It didn't end in an argument. It thinned. Fewer replies, longer gaps, and neither of you could say now what actually happened. Both of you have a version. Neither version is what occurred.
>
> **What it did to that job.** You didn't put yourself forward, because you'd already run how it would go. Somebody else did, and it went fine, and you took that as further evidence about yourself.
>
> **What it did to that relationship.** Two people, each responding to a version of the other that neither of them recognises, both certain they're responding to the real thing. Years of it. Nobody lying.

**Close**

> That's the actual cost, and it isn't the bad hour. It's the conclusions drawn during the bad hour, and everything built on top of them afterwards.
>
> Not one wrong read. Thousands of them, compounding, in the only direction they can go.

---

## PART 4 · Router — unchanged

*Where is this showing up?* · **On my own · With someone · At work**

Correct entry, correct phrasing, correct place.

---

## PART 5 · The three track sections

**Keep all three headlines.** They are the best writing on the site.

**Track 01** — one paragraph changed:

Currently: *Almost everything available to you works on the story. This works on the moment the story is running.*

> Almost everything available to you works on the story. This works on the state that wrote it.

**Track 02 and 03** — unchanged, including all three closing notes. *Nothing waits for you to fall behind it* · *They do not have to be doing this too* · *It fits inside a working day.* Each removes the objection that actually stops that visitor.

---

## PART 6 · Close — hand to the tracks, not to plans

The journey goes home → track page. **The homepage should not sell a plan.**

**Eyebrow**
WHERE TO START

**Headline**
Start with the one that's happening.

**Body**

> Not the deepest one, or the one you think is the root of it. The one that's live today.
>
> The Anxiety Reset is free and needs no account. If that's the one, start there. If it isn't, open the track that fits and read what's in it.

**Buttons**
> Try the Anxiety Reset — free → · See the three tracks →

---

## PART 7 · Images

Six placements. Three of them are doing real work; three are atmosphere.

**Hero.** Existing treatment, unchanged. It must not depict distress — a visitor arriving mid-state does not need to look at somebody else's difficult moment.

**The cost section — the strongest image opportunity on the site.** One image, not three. Something showing distance that was not chosen: two chairs at a table, one pushed back. A hallway with a closed door at the end. Something ordinary that went quiet.

⚠ **No faces, no depicted arguments, no crying.** The section is about accumulation and absence, not about a scene. And no before-and-after.

**Router — three small images**, one per door. Alone, with someone, at work. Interior, ordinary, unposed. **Same treatment across all three** — different atmosphere between them makes one track look like the serious one.

**Track sections — the existing covers.** Already provisioned, already correct, already the right register.

**Close.** Nothing. It's a decision point and an image competes with the two buttons.

### Rules for all of them

**The affluence drift test applies.** Does it invite someone in, or make them feel they are looking at somebody else's better life?

**Nobody demonstrating calm.** No lotus, no seated figure at sunrise, no serene face. The visitor is not calm and does not want to look at someone who is.

**No stock therapy imagery.** Two people on a sofa, one nodding.

**Ordinary interiors, ordinary light.** The one thing every image should have in common is that it looks like somewhere the visitor has actually been.

---

## PART 8 · Dashboard nav

**Add a plans entry.** Members on Personal need a route to Relationship and Professional, and there isn't one.

Label: **Plans** — nothing that implies they are on a lesser tier. Not *Upgrade*, not *Unlock more*.

Position: with the settings and account items, not in the primary protocol navigation. **A member arriving in distress should not meet a purchase prompt on the way to a protocol.**

---

## PART 9 · Consistency

| | |
|---|---|
| Session name | **Guided Meditation Experience** |
| Steps | **Recognise · Regulate · Release · Rise** |
| Tracks in development | **Seven** — correct as it stands |
| Protocol names | Part 1 above |
| Prices | Not on the homepage. One price list, on plans |
