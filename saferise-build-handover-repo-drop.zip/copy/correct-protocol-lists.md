# Correct protocol lists

As built. Matches the plans page. Replace the homepage carousels with these.

### Track 01 · Personal Transformation

| # | Protocol | State |
|---|---|---|
| 01 | Anxiety Reset | Agitated |
| 02 | Anger Alchemy | Agitated |
| 03 | Overwhelm Threshold | Agitated |
| 04 | Abandonment Wound | Agitated |
| 05 | Shame Dissolution | Unsteady |
| 06 | Grief Integration | Unsteady |
| 07 | Shutdown Recovery | Numb |
| 08 | Jealousy Release | Unsteady |
| 09 | Insecurity Anchor | Unsteady |
| 10 | Powerlessness & Despair | Numb |

### Track 02 · Relationship Healing

| # | Protocol | State |
|---|---|---|
| 01 | Safe Conversation | Agitated |
| 02 | Rupture & Repair | Unsteady |
| 03 | Trust & Betrayal | Agitated |
| 04 | Resentment Release | Unsteady |
| 05 | Intimacy Barrier | Unsteady |
| 06 | Double Standard | Unsteady |
| 07 | Projection Clarity | Agitated |
| 08 | Appreciation & Support | Numb |
| 09 | Pursue & Withdraw | Unsteady |
| 10 | Conscious Separation | Numb |

### Track 03 · Professional Performance

| # | Protocol | State |
|---|---|---|
| 01 | High-Stakes Presence | Agitated |
| 02 | Conflict Navigation | Agitated |
| 03 | Imposter Dissolution | Unsteady |
| 04 | Perfectionism Release | Agitated |
| 05 | Performance Anxiety | Agitated |
| 06 | Belonging Gap | Unsteady |
| 07 | Career Transition | Unsteady |
| 08 | Decision Fatigue | Numb |
| 09 | Burnout & Overload | Numb |
| 10 | Creative Flow | Unsteady |
