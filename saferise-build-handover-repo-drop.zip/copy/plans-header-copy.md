# Plans page · header and plan copy

Public surface — decorated language. Sits above the three plan cards.

**Organising logic:** Settled → attention you can place → you see what's actually there → what you do next is yours.

Four links. Every one of them in the platform's own words.

---

## Header

**Eyebrow**
BEFORE YOU CHOOSE

**Headline**
You get your judgement back.

**Lede**
Not your calm. Calm comes and goes. Your judgement — the read you make on what's happening, before you decide what to do about it.

**Body**

When a state is running you, most of what you'd normally have isn't reachable. You can't place your attention, so you can't see past what the state has already decided.

Settle it and that comes back. You can put your attention where you choose. You see what's actually in front of you, rather than what got matched to something older. And what you do next comes from you — rather than from something that happened to you a long time ago.

**Section break — the cost**

Think about what a year of that costs.

The job you didn't apply for, because you'd already decided what they'd think. The friendship that ended over something neither of you can reconstruct now. The thing you said at exactly the wrong moment. The opening that came up while you were too flat to notice it was one. The three years you stayed somewhere because leaving felt like more than you could face.

None of those were decisions about the situation. They were decisions about a version of it you put together while you weren't in any state to be putting versions together.

And you're making those calls all day. Who's on your side. What that message meant. Whether to say the thing. Whether it's worth it. Whether you're up to it.

Get a few wrong and you have a difficult week. Get them wrong consistently, for years, and you end up with a different life than the one that was available to you.

**Pull**
Everything you build, you build on those calls. This is about the quality of the calls.

**Close**
Three tracks. One skill, three places it costs you most.

---

## The three plans

Each card runs the same four beats: **what you can't reach · what comes back · what that changes · what's in it.**

---

### Personal Transformation · €9 a month

**Line**
See yourself straight.

**What a state takes**
In it, you can't tell the feeling from the fact. Something in you has already decided what this means about you, and it decided fast.

**What comes back**
The gap between the state and the person in it. Small, and it's the whole thing — you can look at something you're inside of.

**What that changes**
What you conclude about yourself on a bad day stops becoming what you believe about yourself in general.

**In it**
Ten protocols. Anxiety, anger, overwhelm, shame, grief, jealousy, insecurity and the rest. Every one with a guided session, a cue card for when there's no time to read, and eight further resources.

---

### Relationship Healing · €29 a month

**Line**
See them straight.

**What a state takes**
In it, you don't hear what they said. You hear what you braced for, and then you answer that.

**What comes back**
The ability to tell the event from your reading of it. What they did is one thing. What you decided it meant is another, and only one of the two is yours to check.

**What that changes**
You stop arguing with a version of someone you built on a bad night. Which is most of what long arguments are made of.

**In it**
Everything in Personal, plus ten more. Trust and betrayal, resentment, distance, pursue-and-withdraw, repair, separation. Includes what to say to someone close, and something you can actually send.

---

### Professional Performance · €49 a month

**Line**
See the room straight.

**What a state takes**
In it, a short reply is contempt, a decision is a manoeuvre, and a quiet room is a verdict on you.

**What comes back**
The read. Whether that's what happened, or what you brought with you.

**What that changes**
You act on the situation rather than on your account of it — in rooms where the account you're acting on tends to be expensive.

**In it**
Everything in Personal and Relationship, plus ten more. Conflict, imposter feeling, perfectionism, belonging, career decisions, decision fatigue, burnout, creative work. Includes how to raise something at work, and what to ask for.

---

**Note beneath the three**
Each one includes the ones before it. Not three subjects — one skill, applied wider.

---

## Rules this copy is written against

**Four links, not six.** Perception and judgement are the same event, not two stages. "Internal resource" is an abstraction sitting between two concrete things and it earns nothing.

**Vocabulary the resources actually use.** *Internal resource*, *resourced*, *command of* and *authentic* appear **zero times** across 126,000 words of authored content. A plans page organised around words the protocols never use hands the member a different product on arrival.

**"Triggered" is out.** It is the register of the content this platform is positioned against. The protocols say *state*, or name it — agitated, unsteady, numb.

**"Place" your attention, not "command" it.** Move B claims only that once you can see where your attention is sitting, you can put it somewhere else on purpose. Command is mastery, and it is a promise that fails on a bad day.

**No identity claims.** Move D: the decision is about what you'll do, never about what you are. Move F excludes purpose, calling, meant-to, your path. *Authenticity to who you truly are* sits in that family. What replaces it — *from you, rather than from something that happened to you a long time ago* — does the same work and names the alternative, which is the part that makes it land.

**Retrospective, never predictive.** Every cost is described as something already happening. The moment it becomes *if you don't fix this you'll lose everything*, it is a fear appeal and this platform does not use them.

**No outcome promised.** The calls get better. Not the job, the relationship or the year — those involve other people and are not ours to claim.
