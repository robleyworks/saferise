# SR-098 · Remove Dispenza, add Kross, write in twenty `extras` values

Single commit. `content/tracks.js` only — no other file references `dispenza` in the snapshot checked.

**This is larger than the ticket title suggests.** `kross` does not exist in the framework registry. `dispenza` occupies that slot and is registered as *interpretive*, so this is a **register-band correction** as well as a rename — six protocols currently cite an interpretive framework where the resource content cites a peer-reviewed one.

---

## 1 · The registry

### Remove

```js
  dispenza:  { name: 'Observer stance',       person: 'mechanism only', short: 'Dispenza',  register: 'interpretive',     step: 4, colour: 'var(--teal)' },
```

### Add, in its place

```js
  kross:     { name: 'Distance &amp; rehearsal', person: 'Kross &amp; Ayduk, with King', short: 'Kross', register: 'peer-reviewed', step: 4, colour: 'var(--gold)' },
```

Three things change and all three are deliberate:

| | was | now |
|---|---|---|
| `register` | interpretive | **peer-reviewed** |
| `colour` | `var(--teal)` | **`var(--gold)`** — the peer-reviewed band |
| `person` | mechanism only | **Kross & Ayduk, with King** — a real, citable attribution |

`step: 4` is unchanged. Kross supplies Rise, which is what the slot was always holding.

**Resulting registry — six frameworks, three bands:**

```
peer-reviewed      porges · heartmath · kross
clinical practice  mate
interpretive       jung · watts
```

That now matches the resource content on all thirty-one protocols and the six shared framework summary blocks.

---

## 2 · The six framework mappings

```js
't1-09': frameworks: ['jung','dispenza']            →  ['jung','kross']
't1-10': frameworks: ['porges','watts','dispenza']  →  ['porges','watts']
't2-08': frameworks: ['heartmath','dispenza']       →  ['heartmath','kross']
't3-03': frameworks: ['jung','dispenza']            →  ['jung','kross']
't3-08': frameworks: ['porges','dispenza']          →  ['porges','heartmath']
't3-10': frameworks: ['dispenza','watts']           →  ['kross','watts']
```

**t1-10 loses the key without replacement** — it authored against Porges and Watts and needs nothing further.

⚠ **t3-10 is the one to check.** `dispenza` was the **primary** key. Removing it without adding `kross` would leave Creative Flow resting on Watts alone: a single interpretive framework, no peer-reviewed support, and the weakest credibility position on the platform. Kross is not optional here.

**t3-08 takes `heartmath`, not `kross`** — decision fatigue is load with no single target, the same shape as t1-03 Overwhelm, which carries the same pair.

---

## 3 · Twenty `extras` values

All twenty Track 02 and Track 03 protocols currently read `extras: null`. **`null` is a documented sentinel meaning *not yet verified*, not *none*.** Do not tidy it to `[]` — write the resolved values in.

### Track 02

```js
't2-01': extras: ['invitation'],
't2-02': extras: ['invitation'],
't2-03': extras: ['advisory','invitation'],
't2-04': extras: ['advisory','invitation'],
't2-05': extras: ['invitation'],
't2-06': extras: ['invitation'],
't2-07': extras: [],
't2-08': extras: [],
't2-09': extras: ['advisory','invitation'],
't2-10': extras: ['advisory'],
```

### Track 03

```js
't3-01': extras: [],
't3-02': extras: ['advisory','invitation'],
't3-03': extras: [],
't3-04': extras: [],
't3-05': extras: [],
't3-06': extras: ['advisory'],
't3-07': extras: [],
't3-08': extras: ['advisory'],
't3-09': extras: ['advisory'],
't3-10': extras: [],
```

`[]` here means **verified as not applicable**, which is different from the `null` it replaces.

---

## 4 · Two other corrections in the same file

**t1-04's label is `Repair`, not `Anchor`.** `Anchor` belongs to t1-09. Check whichever field carries the label verb.

**t3-06 is no longer Ambition Recovery.** It is now:

```js
't3-06': { extras: ['advisory'], state: 'unsteady', frameworks: ['porges','jung'] },
```

Name **The Belonging Gap Protocol**, label **Stand**. Ambition Recovery is withdrawn from Track 03 and re-scoped for the Elevation Series under a different subject — see `t3-06-SWAP-SPEC.md`. Its state changes from `numb` to `unsteady`, so Track 03 now has two Numb protocols rather than three.

---

## 5 · After the data lands

**Strip the build notes from two content files.** t1-09 and t1-10 each carry a note at the top recording this mismatch:

> `META['t1-09'].frameworks` currently reads `['jung','dispenza']`. Authored here against Kross & Ayduk…

Delete both. They are not member-facing and they are the only place `dispenza` appears in 124,754 words of content.

---

## 6 · Verification

```
grep -ric "dispenza" .                    →  0, anywhere in the repo
grep -c "kross" content/tracks.js         →  5   (1 registry + 4 mappings)
grep -c "extras: null" content/tracks.js  →  0
node -e "new Function(require('fs').readFileSync('content/tracks.js','utf8'))"
                                          →  parses
```

**Five, not six.** Only four protocols take `kross` — t1-10 drops the key with no replacement, and t3-08 takes `heartmath`. A count of six means one of those two was patched wrongly.

A dry run of this patch against the current file has been done: it applies cleanly, parses, and produces exactly those counts. `tracks-SR098-patched.js` is attached as a reference diff — **read it, do not copy it wholesale**, since the working file may have moved since the snapshot.

Then confirm:

- Framework counts render as **peer-reviewed 3 · clinical practice 1 · interpretive 2**
- t3-10's framework block shows a peer-reviewed citation rather than Watts alone
- Resource counts still derive from `extras` and are not hardcoded anywhere
- Track 03 protocols show 9 to 11 resources; Track 02 shows 8 to 10; Track 01 shows 8 to 10

---

## 7 · Why this was left until now

The resource content was authored against the corrected mappings from the start, because a protocol citing a mechanism-only framework by name would have broken the register system on the page. The data was left alone so the fix could land as one commit rather than drifting across six.

Six protocols, one registry entry, twenty `extras` values, two label corrections, two build notes. One commit, message `fix: SR-098 remove dispenza, add kross, write in resolved extras`.
