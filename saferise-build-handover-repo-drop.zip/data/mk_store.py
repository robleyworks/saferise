import re, glob, json, html

def md2html(md):
    """Markdown resource body -> HTML for the reader's sr-body div."""
    out=[]; lines=md.split('\n'); i=0
    while i < len(lines):
        l=lines[i].strip()
        if not l or l=='---': i+=1; continue
        # production markers never reach the member
        if re.match(r'^> \*\*(TEAL|GOLD|PURPLE|RED|BLUE|VOICE)', l): i+=1; continue
        # shared-block reference marker
        if 'SHARED BLOCK' in l:
            out.append('<!-- SHARED BLOCK -->'); i+=1; continue
        # gate callout
        if l.startswith('⚠'):
            out.append(f'<p class="sr-gate">{inline(l.lstrip("⚠ "))}</p>'); i+=1; continue
        # blockquote (member-facing script lines)
        if l.startswith('>'):
            buf=[]
            while i<len(lines) and lines[i].strip().startswith('>'):
                t=lines[i].strip().lstrip('>').strip()
                if t and not re.match(r'^\*\*(TEAL|GOLD|PURPLE|RED|BLUE|VOICE)', t): buf.append(t)
                i+=1
            if buf: out.append('<blockquote>'+''.join(f'<p>{inline(b)}</p>' for b in buf)+'</blockquote>')
            continue
        # heading
        if l.startswith('### '):
            out.append(f'<h4>{inline(l[4:])}</h4>'); i+=1; continue
        # bold-only line = subhead
        m=re.match(r'^\*\*(.+?)\*\*$', l)
        if m: out.append(f'<h5>{inline(m.group(1))}</h5>'); i+=1; continue
        # bold lead-in followed by prose (cue card lines, R10 items)
        if l.startswith('**') and '**' in l[2:]:
            out.append(f'<p class="sr-lead">{inline(l)}</p>'); i+=1; continue
        # list
        if l.startswith('- '):
            items=[]
            while i<len(lines) and lines[i].strip().startswith('- '):
                items.append(inline(lines[i].strip()[2:])); i+=1
            out.append('<ul>'+''.join(f'<li>{x}</li>' for x in items)+'</ul>')
            continue
        # italic-only line = lede (must not swallow **bold** openers)
        m=re.match(r'^\*([^*].*?[^*])\*$', l)
        if m and not l.startswith('**'):
            out.append(f'<p class="sr-lede">{inline(m.group(1))}</p>'); i+=1; continue
        out.append(f'<p>{inline(l)}</p>'); i+=1
    return ''.join(out)

def inline(t):
    t=html.escape(t, quote=False)
    t=re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', t)
    t=re.sub(r'(?<!\*)\*([^*]+?)\*(?!\*)', r'<em>\1</em>', t)
    t=re.sub(r'`(.+?)`', r'<code>\1</code>', t)
    return t

GLYPH={'Guided Meditation':'◫','Cue Card':'▤','How This Works':'◑','Somatic Release Activities':'♡',
 'Safe Practice':'⚖','Proximity Guide':'◎','Disclosure & Support':'❏','Raising It':'▲',
 'Invitation to Repair':'✉','Your Record':'✎','Accountability & Empathy':'◍','The Decision':'◈'}
SUB={'Guided Meditation':'Do it with me.','Cue Card':'Do it yourself.','How This Works':'Why it works.',
 'Somatic Release Activities':'Between sessions.','Safe Practice':'When and how to proceed.',
 'Proximity Guide':'How close to stay.','Disclosure & Support':'A script for someone close.',
 'Raising It':'Who to tell, how much, and what to ask for.','Invitation to Repair':'Reopening it with them.',
 'Your Record':'What changed, in your words.','Accountability & Empathy':'What it does outside you.','The Decision':'What takes over.'}

store={}
for f in sorted(glob.glob('t?-*.md')):
    s=open(f).read(); key=f[:5]
    name=re.search(r'^# t\d-\d\d · (?:The )?(.+?)(?: Protocol)?$', s, re.M).group(1)
    recs=[]
    for n,(num,title) in enumerate(re.findall(r'\n## (\d+) · (.+)', s), start=1):
        title=title.strip()
        body=re.search(rf'\n## {num} · {re.escape(title)}\n(.*?)(?=\n## \d+ · |\Z)', s, re.S).group(1)
        recs.append({
            'n':n, 'id':f'{key}-{title.lower().replace(" & ","-").replace(" ","-")}',
            'title':title, 'sub':SUB.get(title,''), 'glyph':GLYPH.get(title,'·'),
            'audio':title!='Guided Meditation', 'pdf':title in ('Cue Card','Disclosure & Support','Raising It','Invitation to Repair'),
            'body':md2html(body)
        })
    store[key]={'name':name,'resources':recs}
json.dump(store, open('resource-content.json','w'), ensure_ascii=False, indent=0)
n=sum(len(v['resources']) for v in store.values())
kb=len(open('resource-content.json').read())/1024
print(f"{len(store)} protocols · {n} resources · {kb:.0f} KB")
