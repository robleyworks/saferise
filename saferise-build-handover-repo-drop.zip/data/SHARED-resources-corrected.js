  resources: [
    ['play', 'Guided Meditation', 'Do it with me.', 'The full session, voiced and paced. Audio, or follow-along video.'],
    ['warn', 'Cue Card', 'Do it yourself.', 'Two sides: the four lines for when it is happening, and the fuller version for when you have longer.'],
    ['gear', 'How This Works', 'Why it works.', 'What is happening in your body during this state, and why the four steps land in that order.'],
    ['heart', 'Somatic Release Activities', 'Between sessions.', 'Small physical things that hold the work on the days you will not sit down.'],
    ['comp', 'Safe Practice', 'When and how to proceed.', 'Pacing, what to expect, when to slow down, and when this is not the right tool today.'],
    ['pin', 'Proximity Guide', 'How close to stay.', 'Three tiers for what to stay engaged with, what to reduce, and what is past what self-regulation is for.'],
    ['shield', 'Disclosure &amp; Support', 'A script for someone close.', 'Words for telling one person outside the situation what is happening and what helps.'],
    ['up', 'Raising It', 'Who to tell, how much, and what to ask for.', 'The workplace version. Different audience, different consequences.'],
    ['mail', 'Invitation to Repair', 'Reopening it with them.', 'Something you can actually send, written for the far side of the protocol.'],
    ['pen', 'Your Record', 'What changed, in your words.', 'Prompts tied to this protocol. Written on your device and kept there.'],
    ['circle', 'Accountability &amp; Empathy', 'What it does outside you.', 'The half of the state that lands on other people, and what to do about it.']
  ],
