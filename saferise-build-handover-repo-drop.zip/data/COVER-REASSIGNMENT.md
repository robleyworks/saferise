# Cover Reassignment · t3-06 and t3-07

Small file operation, no code logic. Covers are referenced by protocol key, so nothing in `tracks.js` changes — only which image sits at which filename.

---

## What changes

| File | Was | Becomes |
|---|---|---|
| `assets/covers/t3-06.jpg` | Ambition Recovery — figure walking out at sunrise with a kit bag | **The Belonging Gap** — new cover, being sourced |
| `assets/covers/t3-07.jpg` | Career Transition — current image | **the kit-bag image**, moved from t3-06 |

The kit-bag image is **not discarded**. It moves to t3-07.

---

## Why

**t3-06 is no longer Ambition Recovery.** It is The Belonging Gap — see `SR-098-PATCH.md` §4. The kit-bag image is a departure composition, and Belonging Gap is a protocol about a room you are still in. A solitary figure walking away sets the wrong expectation before a word is read, and would suggest the protocol is about leaving — which Track 03 protocols must never imply.

**t3-07 Career Transition is literally about crossing a threshold.** The kit-bag image is a better fit there than it ever was for Ambition Recovery. This is an upgrade, not a salvage.

---

## Sequence

1. Copy the current `t3-06.jpg` aside — this is the kit-bag image and it is being kept.
2. Copy the current `t3-07.jpg` aside — it goes spare unless reassigned elsewhere.
3. Place the kit-bag image at `assets/covers/t3-07.jpg`.
4. Place the new Belonging Gap cover at `assets/covers/t3-06.jpg` when it arrives.

**Until step 4, `t3-06.jpg` should be absent rather than showing the kit-bag image.** A wrong cover is worse than a missing one — the page has a fallback, and a departure image on a belonging protocol miscommunicates before the member reads anything.

---

## Lockup

Both files must carry the current standard: **gold rule and SAFERISE wordmark only.** No top label word, no numeral. Shared centreline, wordmark right-aligned, colour sampled per image.

**Check the moved image.** t3-01 through t3-09 were flagged as still carrying burned-in numerals pending a removal pass. If the kit-bag image still has one, it needs the pass before it lands at t3-07 — moving a file does not fix what is printed into it.

---

## New cover brief, for the record

Sourcing is outside the build lane; this is here so the requirement is recorded in one place.

**A figure among others, not alone.** The state happens in the room, while staying. Someone present and slightly out of rhythm with a group. Not isolated, not walking away, not looking in from outside.

**No legible expression.** The protocol will not tell anyone whether they belong, and a cover showing someone visibly excluded does the interpreting the resource refuses to do — and gets it wrong for the members whose reading is accurate but whose room has not noticed.

**Standard spec:** 1086 × 1448, 3:4 portrait, JPEG q94 4:4:4, lockup as above.

---

## Verification

```
assets/covers/t3-07.jpg   → the kit-bag image, lockup correct, no numeral
assets/covers/t3-06.jpg   → new Belonging Gap cover, or absent
```

No `tracks.js` change. No reference update. Covers resolve by protocol key.
