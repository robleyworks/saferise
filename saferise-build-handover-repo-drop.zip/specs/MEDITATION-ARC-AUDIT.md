# Guided Meditation · Arc & Voice Audit

Assessment of all fourteen written meditations against the distress each one serves. Three systemic faults, then a per-protocol arc specification.

---

## Part 1 · What is wrong across the set

### Fault 1 · A new template, introduced by me two passes ago

Removing the posture assumptions replaced one uniform opening with another. Eight of fourteen now begin with a variant of *wherever you are / start from where you are / you don't have to move.*

The fix was correct. The execution made every protocol greet the listener identically, which is worse than the problem it solved — a member running three protocols now meets the same sentence three times in the first five seconds.

**An opening does not have to be about position at all.** It can open on the state, on the situation, on a fact, on a question, on silence. Position only needs handling where the script would otherwise assume it.

### Fault 2 · Almost all of them are somber

Fourteen scripts, and roughly two register variations between them. That is wrong on about half the set.

Grief, Shame, Shutdown, Powerlessness, Abandonment — quiet and slow is correct. These states need someone speaking gently and not hurrying.

**Anger, Jealousy, High-Stakes Presence, Performance Anxiety, Overwhelm, Creative Flow, Appreciation & Support** — a gentle voice is the wrong instrument. Someone about to walk into a room does not want tenderness. Someone furious does not want soothing, and will hear it as being managed. Someone with no time does not want a slow voice.

A somber register applied to an activated state reads as condescension, and it is the fastest way to lose a member in the first thirty seconds.

### Fault 3 · Defensive tics, and control

**Defensive constructions** — *that isn't a failing · that's not a sign of anything · nobody is asking you · anyone who tells you otherwise is lying.* Counted: Shame 10, Grief 8, Performance Anxiety 4.

Each one is defensible alone. Stacked, they make the script sound like it is arguing with an objection the listener has not made, and they crowd out the actual work. A reasonable ceiling is **two per script**, at the two moments where the misreading genuinely costs something.

**Imperative density** — Shame 15, High-Stakes 15, Overwhelm 12, Shutdown 12. Nearly every line begins *Find · Notice · Put · Let · Press · Say · Step.*

For an activated state, direct instruction is right and welcome. For a reduced or shamed state it becomes another set of demands from someone who already feels they are failing at demands. Those protocols should ask, offer and describe more than they instruct.

**Questions**, which are the opposite instrument, appear once per script on eleven of fourteen. Grief has one. Shutdown has one.

---

## Part 2 · Arc specification, protocol by protocol

Each entry: the shape of the distress, the journey the guide walks, the voice, and how it opens.

### t1-01 · Anxiety Reset · Agitated
**Distress:** fast, no object, the body ahead of the situation.
**Arc:** contact → slow the system → separate the state from the fight with it → one concrete thing that is available.
**Voice:** steady, unhurried, quietly competent. Someone who has seen this many times and is not alarmed. Not soothing — *unbothered*, which is more useful.
**Opens:** on the signal itself. *There's something running fast. It got here before you did.*
**Weight:** Regulation. This is the protocol where the breath does most of the work.
**Moves:** B, light D. No C.

### t1-02 · Anger Alchemy · Agitated
**Distress:** a line crossed. Force, heat, and a case already assembled.
**Arc:** meet the force → agree the line was crossed → separate the state from the case → show the rerun is rigged → decide conduct.
**Voice:** **direct, level, a bit dry.** Talks to them like an adult who is right about something. Never soothing — soothing reads as taking the other side. Some lines can land hard.
**Opens:** on the fact. *Something got crossed.* No preamble.
**Weight:** Release.
**Moves:** E1b is arguably strongest here — anger is experienced as the only thing preventing being walked over. D about conduct, never about the position.

### t1-03 · Overwhelm Threshold · Agitated
**Distress:** too much, no single target, and no time for this.
**Arc:** reduce input → name which kind → settle → drop the circling → the next single thing.
**Voice:** **brisk and efficient.** Short sentences, minimal warmth, no lingering. The member genuinely does not have time and a slow voice confirms their fear that this is a waste of it.
**Opens:** on the objection. *You don't have time for this.* Already correct.
**Weight:** Recognition, because the sorting question does real work.
**Moves:** B sized small. No C, no full D.

### t1-04 · Abandonment Wound · Agitated
**Distress:** an unanswered question the body has already answered.
**Arc:** name the state without naming them → contact and breath → stop the searching → stand in the not-knowing → one thing that is yours.
**Voice:** warm, close, steady. This is one of the few where reassurance in tone (never in content) is right — the state is about connection, so a voice that stays present is doing something the words are not.
**Opens:** on the silence. *There's a message you haven't had an answer to. Or a room that went quiet.*
**Weight:** Release.
**Moves:** A, C, E1, E1b.

### t1-05 · Shame Dissolution · Unsteady
**Distress:** a verdict, presenting as an observation.
**Arc:** name → separate the person from the verdict → settle → drop the case → find where it was installed → forgive both reluctances → choose one thing → acknowledge and put down.
**Voice:** quiet, plain, entirely without pity. Pity confirms the verdict. Speaks to them as an equal who happens to know something about how this works.
**Opens:** on the fact that it does not want to be looked at.
**Weight:** Release, heavily.
**Moves:** all six. **Currently 1,953 words — the outlier, and it needs trimming.** Ten defensive constructions and fifteen imperatives are both too many for this state specifically.

### t1-06 · Grief Integration · Unsteady
**Distress:** a loss that stays. Nothing to fix.
**Arc:** meet them → find where it is today → let the breath be uneven → separate the loss from the fight with it → an ordinary hour carried → something still here.
**Voice:** **slow, sparse, and unafraid of silence.** The most pauses of any protocol. Says less than it wants to. Does not comfort — sits alongside.
**Opens:** on the day. *Some days it's a long way off. Today it isn't.*
**Weight:** even, deliberately. No step should dominate.
**Moves:** E2 only, rewritten. No B, no C, no D. **Eight defensive constructions — cut to two.** Four imperatives is right; leave it.

### t1-07 · Shutdown Recovery · Numb
**Distress:** reduced. Starting anything is the obstacle.
**Arc:** acknowledge arrival → move one small thing → name in one word → contact then breath → drop the contempt → one very small thing.
**Voice:** **low, few words, generous pauses. Asks almost nothing.** Speaks as though there is no hurry and nothing at stake in getting it right.
**Opens:** on the arrival. *You got here. That took more than it looks like.* Already close.
**Weight:** Regulation.
**Moves:** E2 reduced. No B, C, or D. **Twelve imperatives — too many for this state.** Convert most to offers.

### t1-08 · Jealousy Release · Unsteady
**Distress:** comparison, and shame about the comparison.
**Arc:** name it without flinching → settle → stop the measuring → find what is actually wanted → do the thing that is yours.
**Voice:** **frank, unembarrassed, faintly wry.** This is the state people are most ashamed to admit to, so a matter-of-fact voice does more than a gentle one. Treating it as ordinary is the intervention.
**Opens:** on the admission, plainly. *This is the one nobody wants to say out loud.*
**Weight:** Release.
**Moves:** A, B, C, D.

### t1-09 · Insecurity Anchor · Unsteady
**Distress:** an opinion presenting as a fact you have finally noticed.
**Arc:** name → separate the person from the opinion → ground → stop the auditing → attention by choice → the one who does it anyway → decide.
**Voice:** plain, steady, matter-of-fact. No encouragement — encouragement gives the auditing something to take apart.
**Opens:** on the auditing already running.
**Weight:** Rise, at 393 words. Correct — this is where the work is.
**Moves:** A, B, C, D, E1b.

### t1-10 · Powerlessness & Despair · Numb
**Distress:** something that genuinely will not move.
**Arc:** acknowledge → move a finger → name → contact → separate the situation from the quarrel with it → one thing that is yours.
**Voice:** honest, level, no brightness whatsoever. Does not imply anything will improve. The respect is in refusing to pretend.
**Opens:** on the truth of it. *Nothing about this is going to be different when we finish.*
**Weight:** Release.
**Moves:** E2 reduced. No B, C, D, E1b. **The protocol where an offer of choice would be cruel.**

### t2-01 · Safe Conversation · Agitated
**Distress:** a conversation ahead, already had eleven times.
**Arc:** name the state not the prediction → open the throat → stop the drafting → the first sentence only.
**Voice:** practical, encouraging without promising. Slightly conspiratorial — someone helping you get ready.
**Opens:** on the thing itself. *There's a conversation you haven't had yet.*
**Weight:** Release.

### t2-02 · Rupture & Repair · Unsteady
**Distress:** something open with someone, and a ledger being built.
**Arc:** name → settle → drop the accounting → stand where they stood → one move that is yours.
**Voice:** even-handed, warm, careful not to take a side. The only protocol where the guide must audibly hold two people in mind.
**Opens:** on the state of things. *It's still open. That's why you're here.*
**Weight:** Release and Rise together.

### t3-01 · High-Stakes Presence · Agitated
**Distress:** minutes out, keyed up, needing to walk in.
**Arc:** name → open the throat → stop pre-playing → the first thirty seconds → go.
**Voice:** **brisk, almost brusque. Confident. Slightly clipped.** This is someone in a stairwell with very little time. Warmth here reads as delay. Ends on an instruction, not a settling.
**Opens:** on the clock. *You haven't got long, so we'll be quick.*
**Weight:** Regulation.
**Currently fifteen imperatives — right for this one. Leave it.**

### t3-05 · Performance Anxiety · Agitated
**Distress:** mid-performance, attention split.
**Arc:** name → one out-breath → attention outward → stop watching yourself → the next bit only.
**Voice:** quick, practical, low-key. Assumes competence throughout. No reassurance about ability — that would concede the point.
**Opens:** in the middle of it. *You're in it. That's fine, this works from in there.*
**Weight:** Regulation, because the outward-attention move lives there.

---

## Part 3 · What to change, in order

1. **Fourteen new openings.** No two alike, and none of them about posture unless the protocol needs it. Openings should come from the state.
2. **Voice pass per protocol** against the register column above. Roughly half the set gets faster, drier or more direct.
3. **Cut defensive constructions to two per script.** Shame from ten, Grief from eight.
4. **Rebalance imperatives.** Down on Shame, Shutdown, Powerlessness, Grief. Hold on High-Stakes, Overwhelm, Anger.
5. **Trim Shame to roughly 1,300.** It is the reference build carrying every move; no shipped protocol should run all six.
6. **Add questions where the guide should ask rather than instruct** — Grief, Shutdown, Powerlessness, Abandonment.

Length range across the set should end up roughly **700 to 1,300** rather than clustering at 800.
