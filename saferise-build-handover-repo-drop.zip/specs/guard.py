import re, sys
BAD=[r"\bwhat this is really about\b", r"\byour real fear is\b", r"\bthe real issue is\b",
     r"\byour part in\b", r"\bwhat you're really\b", r"\bit's not really about\b",
     r"\byou attracted\b", r"\bdeep down you\b"]
REFUSE=["i'm not answering","i'm not telling you","isn't mine to name","nobody outside your life","from outside your life nobody"]
ALONE=["not the only one","more common than it feels","most common there is","ordinary company","almost everyone who","almost every workplace","the ones others bring","nearly everyone doing","people who end up here","everyone has this","almost nobody says","almost everyone carrying","not the exception you feel","so many people are walking around","almost every arrangement","everyone does this","almost everyone who has been reasonable","almost every unrepaired","almost every room has","everyone who makes anything"]
BOTH=["two things can be true","what they did happened","their half is real","that's real, and none of what follows"]
for f in sys.argv[1:]:
    s=open(f).read(); t=s.lower()
    med=re.search(r'## 01 · Guided Meditation(.*?)## \d+ ·',s,re.S)
    has=lambda L: any(x in t for x in L)
    print(f"{f[:5]}  {len(med.group(1).split()):>5}w  "
          f"invalidating:{[p for p in BAD if re.search(p,t)] or '—'}  "
          f"refuses:{'Y' if has(REFUSE) else 'N'}  "
          f"not-alone:{'Y' if has(ALONE) else 'N'}  "
          f"exit:{'Y' if any(x in t for x in ['stop there','rather stop, stop','skip it','if you haven','stop and go back','go and do the next thing','go and have the conversation','if there is room','if there was room','one further, if']) else 'N'}  "
          f"protection:{'Y' if any(x in t for x in ['protecting','trying to protect','been protecting']) else 'N'}")
