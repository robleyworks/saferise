# Resource 12 · The Decision

**Universal. All 31 protocols.** Slot: last, after Accountability & Empathy.

Counts move to **9–12**. Track 01 and 02 gain one; Track 03 gains one on top of Raising It.

---

## 1 · What it is

Every protocol's Release step names an old pattern — the case, the auditing, the re-checking, the searching. Thirty-one of them, each described precisely.

**None of them has a successor.**

That is the gap this resource fills. The old pattern is not a fault; it is a job description, written a long time ago, still being carried out because nobody has given the post to anyone else.

The Decision writes the replacement. Not a feeling, not an affirmation, not a better self-image — **a stated instruction about where attention goes and what gets done with it.**

---

## 2 · Why it cannot live inside the meditation

**The moment you need it is the moment you cannot write it.** Mid-episode there is no room to author a pattern. You reach for one that already exists.

So: **defined once, when there is room. Invoked in the moment.**

The meditation's fourth step already invokes it — *put your attention on the one who does the work today.* That instruction assumes a described person. Without this resource, there isn't one, and the step reaches for someone the member has never met.

---

## 3 · The pairing

The resource opens by naming what is already running, in the protocol's own words, then asks what replaces it.

| | The old instruction | What the successor is instructed to do |
|---|---|---|
| t1-01 Anxiety | Scan everything. Find the exposure before it finds you | Attend to what leads somewhere worth going |
| t1-02 Anger | Build the case. Win it in advance | Say it once, at the time, without the case |
| t1-03 Overwhelm | Hold all of it at once. Drop nothing | Do the next one. Let the rest wait |
| t1-05 Shame | Go small. Be unfindable | Take up your actual amount of room |
| t1-08 Jealousy | Measure. Know where you stand | Attend to what's yours to make |
| t1-09 Insecurity | Audit. Find the fault before they do | Do it unsteady and let it be seen |
| t2-03 Trust | Re-read everything. Never be surprised again | Watch what they do from here, not what they did |
| t2-05 Intimacy | Manage the distance. Adjust continuously | Stay in it one exchange longer |
| t2-09 Pursue/Withdraw | Close the gap / protect the space | Say what's happening instead of moving |
| t3-03 Imposter | Check yourself against the room | Do the work and let it be assessed |
| t3-04 Perfectionism | Check again. Find permission to stop | Decide, and hand it over |
| t3-09 Burnout | Absorb it. Be the one who copes | Say what's at capacity, at the time |

Each protocol carries its own pair. The left column is lifted verbatim from that protocol's Release step so a member recognises it immediately.

---

## 4 · Structure

Five parts. The first three are the resource; the last two are what makes it usable.

**One · What's running now**
The old pattern, named in the protocol's own words, with its job stated plainly. Never as a fault. It has been protective, it has worked, and it is expensive.

**Two · What it costs**
Two or three lines, specific to the state. Not a warning — an account of what has already been happening.

**Three · The successor's instruction**
The member writes it. Prompted, not supplied. What does this version attend to instead? What does it do when the state arrives?

**Four · What that looks like in a day**
Three or four observable things. Behaviour, not disposition. *He says the thing in the first few minutes* rather than *he is confident.*

**Five · Who runs the next one**
The invocation line. This version is who operates **during** the next episode — not after it, not once it's fixed.

---

## 5 · The prompts

Written to be answerable. Nothing open-ended, nothing requiring insight the member may not have.

> **What has been running.** The protocol names it. Does it fit? Change the wording if it doesn't — it should sound like your own head.
>
> **What was it for?** It has been protecting something. Say what, in one line.
>
> **What has it cost?** Two things. Not a list.
>
> **What should attention be on instead?** Not the opposite of the old one. Something worth attending to. What are you actually moving toward.
>
> **What does that version do?** Three things, small enough to be visible. What they do when it arrives, and what they do on an ordinary day.
>
> **What do they do in the middle of it?** Not once it passes. During. Unsteady, and still.

---

## 6 · Rules

**Behaviour, never disposition.** *Says the thing early. Hands stay still. Says when he doesn't know.* Not *confident, calm, secure.* A disposition cannot be checked and cannot be done. The state dismantles it in seconds because there is nothing behind it.

**It runs during, not after.** The successor operates in the next episode, unsteady, while it is happening. Any framing that places them after recovery makes this a finish line, and there are none here.

**Never a replacement in the sense of deletion.** The old pattern is not removed. It gets given something to hand over to. Move E1b applies: nobody is asking you to stand it down.

**Revisable, never complete.** It gets rewritten. There is no version that is finished, no point at which the member has arrived.

**Nothing about worth.** No *deserve*, *worthy*, *enough*. This is about what a person does, not what they are owed.

**Device-only, like Your Record.** Same storage, same caveat, same export. On Track 03, the same work-device line.

---

## 7 · Excluded outright

Affirmations · *I am* statements of any kind · higher self · true self · best self · your potential · the person you were meant to be · manifesting anything · vision boards · *step into your power* · anything implying the new version arrives complete or that the old one disappears.

**And "Who am I choosing to become?" as the prompt.** *Becoming* points at someone who does not exist yet, which is what made the live version abstract. The question is what this version **does**, and it is answerable today.

---

## 8 · The live card must change

The card currently on the site:

> **INTEGRATION · WHEN YOU FEEL READY**
> Carry the shift into a choice. *"Who am I choosing to become?"*
> The Decision turns the space created by practice into a conscious direction. Meet the version of you who can feel what is present without handing it the final word.

Three faults.

**"INTEGRATION" is a fifth step.** Every script closes by naming four, and the standing rules forbid a fifth. This is a resource, not a step.

**The prompt asks about identity rather than conduct**, and points forward at someone who does not exist yet.

**The last sentence is unreadable.** *Meet the version of you who can feel what is present without handing it the final word* is not how anyone speaks.

**Replacement:**

> **THE DECISION**
> Something has been running this for a long time. It's had a job, and it's done it well, and it's cost you.
> This is where you write what takes over — not once you're better, but who runs the next one.

---

## 9 · Build

Slot 12, after Accountability & Empathy. Counts derive from `extras` and track, and now range **9 to 12** — anything hardcoded breaks on every protocol.

Storage identical to Your Record: local only, no sync, no analytics carrying entry content, real export.

Resource guidance audio needed — an eleventh recording. The others are 96–119 words; this one warrants the same.
