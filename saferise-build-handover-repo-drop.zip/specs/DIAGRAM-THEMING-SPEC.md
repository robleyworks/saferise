# SafeRise · Diagram Theming Spec

All 31 delivered SVGs inherit their colours from the page. No hex value is hardcoded. A diagram dropped onto any background the wireframe chooses will take that background's tokens.

**Applies to:** `img-090-two-parts.svg` and `img-067-release-t1-01.svg` … `t3-10.svg`.

---

## 1 · The six tokens

Every colour in every diagram resolves to one of these. Each carries a fallback, so a diagram opened on its own — in a browser tab, in a design tool, in an email — still renders correctly.

| Token | Used for | Fallback |
|---|---|---|
| `--sr-ink` | Primary lines, primary text, solid fills | `#1B2A4A` |
| `--sr-accent` | Secondary column — the loop, the second thing | `#2E7D6B` |
| `--sr-mark` | Lockup rule and wordmark | `#B08D57` |
| `--sr-muted` | Captions, sub-labels, italic notes | `#6d6a63` |
| `--sr-rule` | Hairlines, dividers, brackets | `#e4e2dc` |
| `--sr-surface` | Shape fills behind text | `transparent` |
| `--sr-bg` | Optional enclosure background | `transparent` |

Set them on any ancestor and the diagram follows:

```css
.protocol-page {
  --sr-ink: var(--rd-ink);
  --sr-accent: var(--rd-accent);
  --sr-mark: var(--rd-gold);
  --sr-muted: var(--rd-muted);
  --sr-rule: var(--rd-hairline);
  --sr-surface: transparent;
  --sr-bg: transparent;
}
```

---

## 2 · The enclosure background

Each SVG carries a full-bleed rect as its first drawn element, filled with `--sr-bg` and **transparent by default**.

```xml
<rect class="sr-bg" x="0" y="0" width="100%" height="100%" fill="var(--sr-bg, transparent)"/>
```

Transparent means the diagram sits directly on whatever the page provides — the usual case, and the one that always matches. Set `--sr-bg` only when a diagram needs to sit in a card or panel distinct from the page around it. It never needs setting to make a diagram legible; that's what the other tokens are for.

---

## 3 · Two things that must not change

**Fills use the same token as strokes.** The solid gate dot on the two-parts diagram is filled with `--sr-ink`, so it inverts with everything else — navy on paper, cream on midnight, legible in both. Giving fills their own token would break that on the first theme that isn't a straight inversion.

**`--sr-surface` defaults to transparent, not white.** A white fill behind box labels looks correct on paper and appears as a bright rectangle on a dark background. Transparent is right in both directions. Set it to a surface colour only where a shape must occlude something behind it.

---

## 4 · Verification

Both themes render clean across all 31. PNG previews are generated per theme:

```
diagrams/release/png/img-067-release-t1-01-light@2x.png
diagrams/release/png/img-067-release-t1-01-dark@2x.png
```

Dark preview values used for the check — indicative, not the platform's tokens:

```
--sr-ink #EDE9E1 · --sr-accent #6FBFA6 · --sr-mark #C9A227
--sr-muted #9a958b · --sr-rule #2a3245 · --sr-surface none · --sr-bg #0F1626
```

---

## 5 · One limitation to know about

**`var()` is not resolved by every SVG rasteriser.** Browsers handle it; several server-side converters — including cairosvg — do not, and will fail rather than fall back.

If a PNG or PDF has to be produced outside a browser, flatten the tokens first. A converter is included at `flatten.py`:

```python
from flatten import flatten, LIGHT, DARK
png = flatten(open('two-parts.svg').read(), DARK)
```

This affects export tooling only. Nothing in the live product needs it.

---

## 6 · Two typographic notes carried over

**The lockup uses a distinct typeface** — Cormorant Garamond Light at 10 units with 4.2 tracking, against Georgia for everything belonging to the diagram. If Cormorant isn't loaded, the lockup falls back to Georgia and stops reading as a mark. Confirm the face is available.

**Diagrams need a legibility floor on mobile.** Hold at `min-width: 600px` inside a horizontally scrolling container rather than letting them compress. A diagram squeezed to 340px is unreadable, not small.
