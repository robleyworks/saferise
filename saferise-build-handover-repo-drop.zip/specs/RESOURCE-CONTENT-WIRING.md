# Resource content · why the site is empty, and the fix

**The content was never missing. It was never wired.**

276 authored resources exist. Nothing has ever converted them into a store the site can read, so the reader has been serving placeholder bodies written before the real content existed.

---

## 1 · What is actually live

`saferise-resource-reader.html` holds hardcoded `body:` strings — two to four sentences per resource. Three problems with them, and the second is the serious one.

**They are placeholders.** Written as layout filler. None of it is the authored content.

**They break platform rules.**

| | |
|---|---|
| Durations | `read:'12 min'` · `read:'5 min read'` · `dur:'2:05'` · `railMeta:'15 min'` — on every record |
| Dispenza named | in the Source Insights body, in prose, by name |
| Retired step names | the Guided Meditation body still reads *identify and name… redirect attention to the heart… accept and release… close with gratitude and expansion* |

Those are not cosmetic. Each contradicts something stated in the authored content, and the third contradicts the cue cards on all 31 protocols.

**The resource list is wrong.** Twelve entries in `SHARED.resources`, including three that were cut — *Why I Built This One*, *Source Insights*, *Reference Case* — and missing two that exist: *Raising It* and *Accountability & Empathy*.

---

## 2 · What is delivered

**`resource-content.js`** — 805 KB, generated from the protocol markdown. Loads as a plain script and defines `RESOURCE_CONTENT`.

```js
RESOURCE_CONTENT['t1-01'] = {
  name: 'Anxiety Reset',
  resources: [
    { n: 1, id: 't1-01-guided-meditation', title: 'Guided Meditation',
      sub: 'Do it with me.', glyph: '◫',
      audio: false, pdf: false,
      body: '<p class="sr-lede">…</p><p>…</p>' },
    …
  ]
}
```

Drop-in for the reader's existing call:

```js
document.getElementById('rbody').innerHTML = r.body;
```

**`SHARED-resources-corrected.js`** — the eleven-entry registry to replace `SHARED.resources` in `content/tracks.js`.

---

## 3 · What the conversion does

**Strips every production marker.** `TEAL/BREATH`, `GOLD/PAUSE`, `PURPLE/MUSIC`, `RED/ACTION`, `BLUE/ILLUSTRATION` and `VOICE` are booth and edit cues. **Verified zero in output.** If any reach a member the meditation reads as a script rather than as speech.

**Carries no durations.** No `read`, no `dur`, no `railMeta` minutes. **Verified zero.** The reader's existing `dur:'2:00'` fallback must be removed rather than defaulted.

**Emits semantic classes** the stylesheet can target:

| | |
|---|---|
| `p.sr-lede` | the resource's own subtitle line |
| `p.sr-lead` | bold lead-in followed by prose — cue card lines, Resource 10 items |
| `blockquote` | member-facing script lines in Disclosure, Raising It, Invitation |
| `p.sr-gate` | the safety gates. **8 of these. They must be visually distinct** |
| `h4` / `h5` | section and subsection headings |

**Leaves `<!-- SHARED BLOCK -->` markers.** 16 of them. Each is where a shared block gets injected — the two-parts block on Track 02, *What this track works on* on Track 03. **The build must substitute these at render.** Left unhandled, sixteen How This Works resources have a hole in the middle.

---

## 4 · Wiring

1. Load `resource-content.js` before the reader initialises.
2. Replace `SHARED.resources` with the corrected eleven.
3. Resolve the 16 shared-block markers at render.
4. Delete every hardcoded `body:` string from the reader.
5. Remove `read`, `dur` and `railMeta` from the record shape and from the markup.
6. Derive the resource list per protocol from `RESOURCE_CONTENT[key].resources` — **never from a hardcoded count.** Lengths run 2 to 11.

---

## 5 · Verification

```
protocols            31
resources           278   (276 + The Clearing's 2)
markers               0   TEAL / GOLD / PURPLE / RED / BLUE / VOICE
durations             0
dispenza              0
unconverted markdown  0
unclosed tags         0
shared-block markers 16   must be resolved at render
safety gates          8   must render distinctly
```

Regenerate with `mk_store.py` whenever a protocol file changes. **Do not hand-edit `resource-content.js`** — the markdown is the source of truth and an edit here is lost on the next run.

---

## 6 · One thing to decide first

The authored content uses **Recognition / Regulation**; other material uses **Recognise / Regulate**. 248 occurrences across 34 files.

Settle it before this store lands, or the site ships one form and the diagrams and cue card modal ship the other. Regenerating after a decision costs one command; correcting it afterwards in three places does not.
