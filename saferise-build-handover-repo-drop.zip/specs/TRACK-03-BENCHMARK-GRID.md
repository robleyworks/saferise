# Track 03 · The Benchmark Grid

Ten professional situations the track has to serve. These are not protocols — they're the **situations the states show up in**, and mapping them is what makes the track legible as professional development without turning it into a manual.

Every one of the ten must be addressed somewhere in the track. Where a protocol owns a benchmark, that resource carries it explicitly.

---

## The grid

| Benchmark | Owned by | Also serves it |
|---|---|---|
| **1 · Communicating outward** — saying the thing, in the room, at the time | t3-03 Imposter | t3-01, t3-06 |
| **2 · Communicating inward** — what you tell yourself about how it went | t3-03 Imposter | t3-05, t3-04 |
| **3 · Taking feedback** | ⚠ **unowned** | t3-03, t3-04 partially |
| **4 · Giving feedback** | t3-02 Conflict | t3-06 |
| **5 · Problem-solving under load** | t3-08 Decision Fatigue | t3-09 |
| **6 · Conflict resolution** | t3-02 Conflict | — |
| **7 · Leading and delegating** | t3-04 Perfectionism | t3-09 |
| **8 · Producing and shipping** | t3-10 Creative Flow | t3-04 |
| **9 · Visibility and volunteering** | t3-06 Belonging Gap | t3-03 |
| **10 · Am I in the right place** | t3-07 Career Transition | t3-06, t3-09 |

---

## The gap

**Taking feedback is not owned by any protocol**, and it's the single most consequential professional moment for someone carrying imposter feeling, perfectionism or a belonging gap. A review, a piece of criticism in front of others, a note on work you've already checked eleven times.

Two options, and I'd take the second:

**A eleventh protocol.** Breaks ten-per-track again, and the track has just absorbed one swap.

**Fold it into t3-04 Perfectionism Release as a second entry point**, the way t1-03 handles three sources of overwhelm. The mechanism genuinely fits: perfectionism's loop is re-checking against a standard, and receiving criticism is that standard arriving from outside. The Release step is the same — the re-checking is the second thing, whether it's self-generated or triggered by a note.

t3-04's Recognition then forks: *is this your own standard, or somebody else's, arriving?*

---

## Where consequence lines go

One per resource, as an observation, never as a prediction. Default location is Accountability & Empathy.

**t3-01 High-Stakes Presence** — going in braced changes what the room decides before you've said anything. *Already present in Resource 10.*

**t3-02 Conflict Navigation** — a team quietly decides that working with either of you costs something. *Already present.*

**t3-03 Imposter Dissolution** — not saying the thing is why the argument gets attributed to whoever did say it, and why the work you did gets described as something you helped with. **Add.**

**t3-04 Perfectionism Release** — re-checking finished work is usually what stops you delegating, and not delegating is what keeps the work at your level. **Add.**

**t3-05 Performance Anxiety** — leaving straight afterwards means you never find out how it went, so the account you keep is the one the monitoring wrote. *Partially present; sharpen.*

**t3-06 Belonging Gap** — the edited version of you is the one being assessed, and it is consistently less interesting than the unedited one. **Write in.**

**t3-07 Career Transition** — staying while you decide has a cost that isn't visible until you add it up, and so does deciding in a state that can't tell the situation from the reading. **Write in.**

**t3-08 Decision Fatigue** — decisions that don't get made get made by default, by someone else, or by the deadline. **Write in.**

**t3-09 Burnout & Overload** — the reliable person gets given more, and absorbing it silently is what confirms the arrangement. **Write in.**

**t3-10 Creative Flow** — work that never leaves your hands is indistinguishable, from outside, from work that was never done. **Write in.**

---

## Two rules on the consequence lines

**Past or present tense only.** Describes what has been happening. Never *you will be overlooked*.

**No stacking.** One per resource. Two becomes a case for changing, which is leverage.

---

## What this grid is not

It is not a curriculum, a competency framework, or a set of skills to acquire. Nothing on the platform teaches negotiation, presentation or management technique, and nothing should — that content exists everywhere and is not what this is.

What the grid guarantees is that a member arriving with a real professional problem finds a protocol that recognises the situation they're actually in, rather than a state description that could apply anywhere.
