# Meditation Poster Handover · IMG-051 – 081

Thirty-one posters. **Every subject is already written** — they're production markers inside the guided meditation scripts, tagged `BLUE/ILLUSTRATION`, and they were authored alongside the protocol they belong to.

**Do not invent a subject.** If one appears to be missing, it isn't — it's in the script.

---

## 1 · What a poster is

The still behind the audio player on a protocol page, and the frame the meditation opens on.

**One per protocol.** Abstract, no figure, no face, no type. It sits beside the protocol's cover photograph and has to look like it came from the same product.

**A second cue appears in every script** — *figure at middle distance, room around it, unhurried.* That is **not** a poster. It's `IMG-065`, a shared diagram already built, used at the fourth step. Ignore it here.

---

## 2 · The subjects

Each is the exact `BLUE/ILLUSTRATION` line from that protocol's script. Treat the wording as the brief.

| ID | Protocol | State | Subject |
|---|---|---|---|
| IMG-051 | t0-00 The Clearing | Steady | Open ground. Nothing on it. Space rendered as space, not as emptiness |
| IMG-052 | t1-01 Anxiety Reset | Agitated | A single word settling onto a still surface. No ripple |
| IMG-053 | t1-02 Anger Alchemy | Agitated | A line, drawn firm. Something has passed over it |
| IMG-054 | t1-03 Overwhelm Threshold | Agitated | Many fine lines converging on one point, none resolving |
| IMG-055 | t1-04 Abandonment Wound | Agitated | A held breath rendered as a suspended shape, not falling |
| IMG-056 | t1-05 Shame Dissolution | Unsteady | A form turning inward, not crushed. Contained, not diminished |
| IMG-057 | t1-06 Grief Integration | Unsteady | A shape with a space in it. The space is part of the form, not damage to it |
| IMG-058 | t1-07 Shutdown Recovery | Numb | A still surface with movement beneath it. The surface is not the whole of it |
| IMG-059 | t1-08 Jealousy Release | Unsteady | Two shapes, one lit and one in shadow, the shadow slightly larger |
| IMG-060 | t1-09 Insecurity Anchor | Unsteady | A form on an uneven base. Upright. Not falling |
| IMG-061 | t1-10 Powerlessness & Despair | Numb | A wide flat horizon, one small fixed point on it. The point is not moving |
| IMG-062 | t2-01 Safe Conversation | Agitated | A closed door with light under it. Nothing behind it yet |
| IMG-063 | t2-02 Rupture & Repair | Unsteady | Two forms with a break between them. The break has an edge on both sides |
| IMG-064 | t2-03 Trust & Betrayal | Agitated | A surface with a fracture running through it. Both halves still present, still whole |
| IMG-065 | t2-04 Resentment Release | Unsteady | A stack of marks, evenly spaced, going back further than the frame |
| IMG-066 | t2-05 Intimacy Barrier | Unsteady | Two forms, near each other, not touching. The space between them even and deliberate |
| IMG-067 | t2-06 Double Standard | Unsteady | Two measures side by side, marked differently |
| IMG-068 | t2-07 Projection Clarity | Agitated | A small mark casting a much larger shadow |
| IMG-069 | t2-08 Appreciation & Support | Numb | Colour present in the frame, viewed through something. Not absent. Muted |
| IMG-070 | t2-09 Pursue & Withdraw | Unsteady | Two forms, one leaning in, one angled out. The distance between them constant |
| IMG-071 | t2-10 Conscious Separation | Numb | A door, open, with light on both sides of it |
| IMG-072 | t3-01 High-Stakes Presence | Agitated | A taut line, drawn straight. Held, not fraying |
| IMG-073 | t3-02 Conflict Navigation | Agitated | Two forms at a fixed distance, neither moving, both braced |
| IMG-074 | t3-03 Imposter Dissolution | Unsteady | A form on a foundation, with a gap drawn between the two. The form is not falling |
| IMG-075 | t3-04 Perfectionism Release | Agitated | A line drawn, then drawn again over itself. Same line, several times |
| IMG-076 | t3-05 Performance Anxiety | Agitated | An outline traced a second time, slightly offset. Watching itself |
| IMG-077 | t3-06 Belonging Gap | Unsteady | A set of forms, evenly spaced. One of them a slightly different weight |
| IMG-078 | t3-07 Career Transition | Unsteady | A threshold. Ground on both sides of it, drawn the same |
| IMG-079 | t3-08 Decision Fatigue | Numb | A set of open doors, all the same size. None of them marked |
| IMG-080 | t3-09 Burnout & Overload | Numb | A vessel, drawn empty, with the outline entirely intact |
| IMG-081 | t3-10 Creative Flow | Unsteady | A closed hand and an open one, drawn at the same size |

⚠ **The IDs above supersede any earlier numbering.** An earlier spec assigned IMG-051–060 to Track 01 posters and IMG-061–064 to body maps. **The body maps have moved and the Release diagrams collide too.** Reconcile before provisioning:

```
IMG-051 … 081   meditation posters              THIS DOCUMENT
IMG-090         two-parts diagram               built
IMG-101         regulation layer                built
IMG-110 … 113   body maps ×4                    built, renumber from 061–064
IMG-114         Rise figure                     built, renumber from 065
IMG-115         blind spot                      built, renumber from 066
IMG-116         proximity tiers                 built, renumber from 067
IMG-117         breath cycle                    unverified
img-release-t1-01 … t3-10                       built, drop the numeric prefix
```

---

## 3 · How to read a subject line

**They are descriptions of a relationship, not of an object.** *A shape with a space in it. The space is part of the form, not damage to it* is not asking for a shape with a hole. It's asking for an image where absence reads as belonging.

Every line carries a qualifier, and the qualifier is the whole instruction:

- *contained, not crushed*
- *not falling*
- *both halves still present, still whole*
- *not absent, muted*
- *the outline entirely intact*
- *space rendered as space, not as emptiness*

**If the qualifier isn't visible in the result, the poster is wrong regardless of how it looks.** These aren't hedges — each one is the protocol's position, and getting it backwards makes the image contradict the resource it sits above.

The three most easily reversed:

**IMG-080 Burnout** — *a vessel, drawn empty, with the outline entirely intact.* Empty, not broken. The person is depleted, not damaged.

**IMG-057 Grief** — the space is part of the form. Not a wound, not a missing piece.

**IMG-069 Appreciation** — colour is *present*, seen through something. Not drained, not grey. The good things are still there and arriving quietly.

---

## 4 · Register

**Abstract. No figures, no faces, no hands, no landscapes with meaning attached.** Where a subject says *form*, it means a shape, not a person.

**No type of any kind.** Titles are live text.

**Match the covers.** Same palette, saturation, contrast and grain as the thirty protocol covers at `assets/covers/`. Open three before generating anything — a poster that looks like it came from a different product is wrong however good it is.

**State affects treatment, not subject.** Agitated is higher contrast and more defined. Unsteady is softer. Numb is lower contrast, quieter, with less separation between elements. The subject line doesn't change; how it's rendered does.

### Absolutely not

Sunrises · mountains · silhouettes on horizons · lotus flowers · mandalas · light rays · water droplets · anything a stock meditation app would use. Generative models default to all of it, and it's the exact register the platform excludes.

No faces. No before-and-after. No progress, ascent, or light-at-the-end imagery. Nothing implying an outcome.

---

## 5 · Format

```
Aspect     16:9 · 1920 × 1080 minimum
Format     JPEG q94, or PNG where transparency helps
Naming     img-052-poster-t1-01-anxiety-reset.jpg
```

Lockup added afterwards as live overlay, not baked in — same as the cue card modal. **Do not burn in the wordmark.**

---

## 6 · Acceptance

1. Place beside that protocol's cover. Same product? If it needs explaining, no.
2. Is the qualifier visible? *Contained not crushed. Intact not broken. Muted not absent.*
3. Any face, figure, hand or human form? Reject.
4. Any type, including a signature or watermark? Reject.
5. Anything from the excluded list in §4? Reject.
6. Does the treatment match the state — Agitated defined, Unsteady soft, Numb quiet?
7. At thumbnail size, is it still distinguishable from the other thirty?

---

## 7 · Source of truth

Every subject line above is quoted verbatim from the `BLUE/ILLUSTRATION` marker in that protocol's Guided Meditation. If a subject and this table ever disagree, **the script wins** — it was written with the protocol and the poster was derived from it.
