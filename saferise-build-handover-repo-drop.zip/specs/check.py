import re, sys
BAN = [r'\bquantum\b', r'\bfrequenc\w*\b', r'\bmanifest\w*\b', r'\brewire\w*\b',
       r'\bstreak\w*\b', r'\bbadge\w*\b', r'\bgraduat\w*\b', r'\bdispenza\b',
       r'\bproductivity\b', r'\boptimis[ez]\w*\b', r'\bperformance target\b',
       r'\befficiency\b', r'\bhigh performer\b', r'\bpeak\b', r'\belite\b',
       r'\bearning potential\b', r'\bbest results\b', r'\bmaximis\w*\b',
       r'\bpurpose\b(?! ,)', r'\bcalling\b', r'\bdestiny\b', r'\byour path\b',
       r'\bthe universe\b', r'\bzone of genius\b',
       r"\byou don't have to decide today\b", r"\bthere's no rush\b"]
DUR = r'\b(one|two|three|four|five|six|seven|eight|nine|ten|\d+)\s+(minute|hour)s?\b'
ALLOW = ['on purpose', 'general optimism', 'your optimism']
def scan(path):
    s = open(path).read(); t = s.lower()
    hits = []
    for p in BAN:
        for m in re.finditer(p, t):
            ctx = t[max(0, m.start()-18):m.end()+18]
            if not any(a in ctx for a in ALLOW):
                hits.append(m.group(0))
    durs = [m.group(0) for m in re.finditer(DUR, t)]
    return hits, durs
if __name__ == '__main__':
    for f in sys.argv[1:]:
        h, d = scan(f)
        print(f"{f[:5]}  banned:{sorted(set(h)) or '-'}  dur:{sorted(set(d)) or '-'}")
