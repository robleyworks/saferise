# SafeRise · Shared Diagram Set

Eight shared assets, plus thirty Release diagrams and the Track 02 two-parts diagram delivered previously. **Every diagram on the platform is now built.**

All inherit colour from the page. See `DIAGRAM-THEMING-SPEC.md` — nothing is hardcoded, and a diagram dropped on any background takes that background's tokens. PNG previews included in both themes.

---

## The set

| ID | Asset | Appears on | Placement |
|---|---|---|---|
| IMG-061 | Body map — Agitated | 12 protocols | How This Works · *What the state is doing* |
| IMG-062 | Body map — Unsteady | 12 protocols | same |
| IMG-063 | Body map — Numb | 6 protocols | same |
| IMG-064 | Body map — where the practice puts attention | all 30 | same, paired with 061/062/063 |
| IMG-065 | Rise figure | all 30 | Guided Meditation poster · Rise step |
| IMG-066 | Blind spot | all 30 | Accountability & Empathy |
| IMG-067 | Proximity tiers | 14 protocols | Proximity Guide, above the tier copy |
| IMG-090 | Two parts | Track 02, all 10 | inside the shared block |
| IMG-101 | The regulation layer | Track 03, all 10 | inside *What this track works on* |

Release diagrams `img-067-release-t1-01` … `t3-10` ship separately. **Note the ID collision:** the Release set was numbered `img-067-release-*` before proximity tiers took IMG-067. Rename the Release set to `img-068-release-*` or drop the numeric prefix — they are already unambiguous by protocol key.

---

## Body maps — the axis, not a figure

**IMG-061 – 064 have no human figure.** Four earlier versions did, and none held: a seated silhouette read as a bell skirt, a standing one as a tunic, a contoured crop had no visible shoulders, a geometric pictogram read as a bin. Every version was a person constructed from curves, and it looked it.

What ships instead is **a vertical body axis** — a rounded column with the regions named alongside it. Same information, same family as the other diagrams, and it removes two problems the figure never solved:

**It cannot be anatomically wrong**, because it isn't an anatomy.

**It isn't a normative body.** A drawn figure is somebody's proportions, and a member whose body isn't those is being shown a map of someone else.

### The pairing rule

**Two passes, never one, and never with arrows between them.**

Left — *where it commonly shows*. Soft bands at the named regions. No hard edges, none dominant.
Right — IMG-064, *where the practice puts attention*. Open rings at jaw, shoulders and chest on the axis, hands and feet marked alongside. **Identical across all three states.**

A single map with lines running from a region to a point implies that point relieves that region. That's an efficacy claim nothing here supports, and one step from reading as acupressure.

### Built without filters or clip paths

Bands are stacked rounded rects at decreasing opacity — not gradients, not `feGaussianBlur`. Filters and clips get dropped silently by several server-side rasterisers, and a soft region rendering hard-edged looks like a mistake rather than a design.

**Do not sharpen IMG-063.** Two very large faint overlapping bands. The imprecision is the content.

### Captions — live text, not artwork

> **061 / 062** — Common, not required. Yours may sit somewhere else entirely — the protocol asks you to find it, not to match this.
> **063** — In this state the signal is often faint and hard to place. Not finding it is part of the state, not a failure to look.
> **064** — Jaw · shoulders · chest · hands · feet. The same five wherever the state sits.

**No lockup on these four.** They sit inline in prose and the wordmark would compete.

## IMG-065 · Rise figure

Middle distance, floor line, room edges implied. **Never brought closer** — the distance is the mechanism the fourth step teaches, and a closer crop teaches the opposite.

---

## IMG-066 · Blind spot

One figure. A mark in the chest, a line leaving the body and continuing past the frame edge into a region that fades out.

**One figure only.** Do not add an observer. The claim is about vantage, not about being watched — a second figure turns it into surveillance.

---

## IMG-067 · Proximity tiers

Nested bands rather than concentric circles: text needs horizontal room, and rings force labels across their own strokes.

**Two inner boundaries are dashed and soft. The outer one is solid and heavy.** That contrast is the whole diagram — tier three is a different kind of thing, not a further step outward. The annotation says so: *a hard line, not a further step out. Nothing inside it applies once you are past it.*

---

## IMG-101 · The regulation layer

Two stacked bands. Above: the plan, the training, the method, the system. Below and underneath all of it: the state, with an arrow running upward.

**No ladder, no ascent, no pyramid.** The lower band is not a foundation you graduate off — it is load-bearing and permanent. Any treatment implying progression breaks both the diagram and the platform's rules.

Carries the positioning line: *everyone sells the programme. This builds the system that can follow one.*

---

## Verification

```
8 shared SVGs · all tokenised · 16 PNG previews, light and dark
0 render failures
t3-06 Release diagram relabelled after the protocol swap
       → The room / The editing
```
