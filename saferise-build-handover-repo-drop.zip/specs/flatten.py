import re, cairosvg

LIGHT = dict(ink="#1B2A4A", accent="#2E7D6B", mark="#B08D57",
             muted="#6d6a63", rule="#e4e2dc", surface="#ffffff", bg="#faf9f6")
DARK  = dict(ink="#EDE9E1", accent="#6FBFA6", mark="#C9A227",
             muted="#9a958b", rule="#2a3245", surface="none",    bg="#0F1626")

def flatten(svg, theme):
    def sub(m):
        name, fallback = m.group(1), m.group(2).strip()
        return theme.get(name, fallback)
    return re.sub(r'var\(--sr-([a-z]+),\s*([^)]*)\)', sub, svg)

if __name__ == "__main__":
    s = open('two-parts.svg').read()
    for name, th in [("light", LIGHT), ("dark", DARK)]:
        out = flatten(s, th)
        cairosvg.svg2png(bytestring=out.encode(),
                         write_to=f'/tmp/{name}.png', output_width=1180)
        print(name, 'ok')
