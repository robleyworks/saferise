# SafeRise · Build Handover

**Supersedes every previous handover.** Where any of them disagrees with this, this wins.

Content is complete: **308 resources across 31 protocols, 151,772 words.**

---

## 1 · Do these five in order

Everything else assumes they have landed.

**1 · `data/SR-098-PATCH.md`** — one commit to `content/tracks.js`. Registry, six framework mappings, twenty `extras` values, two label corrections, the t3-06 swap.

**2 · Load `data/resource-content.js`** and delete every hardcoded `body:` string from the reader.

**3 · Replace `SHARED.resources`** with `data/SHARED-resources-corrected.js`. It is twelve entries, not the current twelve — three of those were cut and three are missing.

**4 · Resolve the 16 shared-block markers** at render.

**5 · Fix the homepage protocol lists.** Sixteen of thirty are wrong. `copy/correct-protocol-lists.md`.

---

## 2 · The site is currently serving placeholder content

Not missing content. **Placeholder prose written before the real resources existed**, and it breaks three rules.

| | |
|---|---|
| Durations | `read:'12 min'` · `dur:'2:05'` · `railMeta:'15 min'` — on every record |
| Dispenza | named in prose, in the Source Insights body |
| Retired step names | the meditation body still says *identify and name… redirect attention to the heart… accept and release… close with gratitude and expansion* |

That third one contradicts the cue cards on all 31 protocols. **These are worse than empty slots** — they look right and they are wrong.

Also live and also cut: *Why I Built This One*, *Source Insights*, *Reference Case*, and a card headed **INTEGRATION** offering *The Decision* with the prompt *"Who am I choosing to become?"*. Integration is a fifth step and there is no fifth step. Replacement copy for that card is in `specs/RESOURCE-12-THE-DECISION-SPEC.md` §8.

---

## 3 · The resource set — twelve, four conditional

| # | Resource | Appears |
|---|---|---|
| 01 | Guided Meditation Experience | always |
| 02 | Cue Card | always |
| 03 | How This Works | always |
| 04 | Somatic Release Activities | always |
| 05 | Safe Practice | always |
| 06 | Proximity Guide | `extras` includes `advisory` — 14 |
| 07 | Disclosure & Support | always |
| 08 | Raising It | **Track 03 only** — 10 |
| 09 | Invitation to Repair | `extras` includes `invitation` — 12 |
| 10 | Your Record | always |
| 11 | Accountability & Empathy | always |
| 12 | **The Decision** | always, except The Clearing |

**Counts run 2 to 12. Never hardcode — derive from `extras` and track.**

⚠ Three inventories in the codebase disagree with this. `SHARED.resources` holds twelve including three cut ones. `relationship-healing.html` lists nine by name in markup. `SafeRise-Anxiety-Reset-Resource-Reader.html` carries an eleven-item list matching nothing, plus a duration and two progress indicators. **Correct all three. Treat that reader file as void.**

---

## 4 · Build rules that make the copy true

Break any of these and shipped text becomes false.

**Your Record and The Decision are device-only.** Local storage, no sync, no server write, no analytics carrying entry content, real export producing a file the member holds. **60 resources state this.** If any part is untrue, that copy cannot ship.

**No durations anywhere.** None exist in 151,772 words. The interface must not add any — remove `read`, `dur` and `railMeta` from the record shape rather than defaulting them.

**No progress, scores, streaks, badges, completion or graduation.** No "Resource 7 of 12", no progress bars.

**The reader side panel shows opened state, not progress.** Small neutral mark against opened items, no count, no ticks, no emphasis difference between opened and unopened. Mockup: `copy/mock-reader-panel.html` if supplied, spec in this section. **If it ever counts, it has become the thing it replaced.**

**Cue cards are second person throughout.** Not stylistic — second-person self-address is the mechanism the fourth step rests on.

**No copy in markup.** Content lives in data files. Pages read; they never author.

**Every Safe Practice links to the support advisory page.** 30 resources point at it and it must exist before anything ships.

**Prohibited vocabulary:** quantum · frequency · manifest · rewire · streak · badge · graduate · Dispenza. Plus `ego` outside one quoted phrase on Track 02, and the Track 03 list — productivity · optimise · performance target · output · efficiency · high performer · peak · elite · earning potential · best results · maximise.

A register checker is at `specs/check.py`. Run it against any file you touch.

---

## 5 · Naming, settled

| | |
|---|---|
| Session | **Guided Meditation Experience** |
| Steps | **Recognise · Regulate · Release · Rise** — verbs, not nouns |
| Tracks in development | **Seven** |
| State labels | Agitated · Unsteady · Numb, plus **Steady** for The Clearing |

⚠ **The authored markdown still uses `Recognition` / `Regulation`** — 248 occurrences across 34 files. The plans page uses the verb forms and they are canonical. **This migration has not been run.** Do not run it in the codebase; it happens in the content lane and the store is regenerated. Flag it and wait, or the store and the diagrams ship different forms.

---

## 6 · Shared blocks — one source, referenced

Three blocks appear on every protocol in their track. They are **referenced, not pasted**. Each protocol file carries a marker; the build substitutes at render.

| Block | Appears | Source |
|---|---|---|
| Framework summaries ×6 | all 31, in *What we rest on* | `content/shared/SHARED-framework-summaries.md` |
| The part that's on your side… | Track 02, all 10 | `SHARED-t2-two-instruments.md` |
| What this track works on | Track 03, all 10 | `SHARED-t3-what-this-track-works-on.md` |

**16 `<!-- SHARED BLOCK -->` markers in the store.** Unresolved, sixteen How This Works resources have a hole in the middle.

⚠ **t2-01 and t2-02 still hold the two-parts block inline.** Convert both to the reference form.

**The `ego` constraint rides on this.** The Track 02 block contains the single permitted use, inside the quoted phrase *"that's just your ego talking"* — the thing the member is told **not** to say. One record makes that structural rather than checked.

---

## 7 · Safety gates — 8 in the store, class `sr-gate`

Inline warnings on t2-03, t2-09, t3-02 and t3-06 telling a member when the resource is not for their situation. On t2-09 the same gate appears **three times, deliberately** — the danger there is that a coercive dynamic reads as a two-sided pattern.

**Render them visually distinct. Do not shorten, merge, or move any of them behind a disclosure.** They sit inline, where the member is reading.

---

## 8 · Diagrams — 39 SVGs, all built

**Read `specs/DIAGRAM-THEMING-SPEC.md` before placing any.**

Every diagram inherits colour through CSS custom properties. Nothing hardcoded, each with a fallback, all rendering in light and dark.

```
--sr-ink · --sr-accent · --sr-mark · --sr-muted · --sr-rule · --sr-surface · --sr-bg
```

`--sr-bg` is a full-bleed enclosure rect, transparent by default. Set only where a diagram sits in a card distinct from the page.

| Asset | Count | Placement |
|---|---|---|
| Release diagram | 30 | How This Works · *Why Release goes after…* |
| Body maps | 4 | How This Works · *What the state is doing*, **in pairs** |
| Rise figure | 1 | poster · Rise step |
| Blind spot | 1 | Accountability & Empathy |
| Proximity tiers | 1 | Proximity Guide |
| Two parts | 1 | Track 02 shared block |
| Regulation layer | 1 | Track 03 shared block |

**Body maps pair, always.** A state map beside `img-064`. Never alone, never combined, **never with arrows between them** — a line from a region to a point is an efficacy claim the platform does not make.

**Mobile floor:** hold at `min-width: 600px` in a horizontally scrolling container.

**Known limitation:** `var()` is not resolved by every server-side rasteriser. Browsers handle it; cairosvg fails outright. For PNG or PDF generated outside a browser, flatten with `specs/flatten.py`.

⚠ **ID collision.** The Release set is named `img-067-release-*` and proximity tiers took IMG-067. Rename the Release set or drop the numeric prefix.

**Breath cycle is unverified.** Assumed to exist on the method pages, never confirmed. Grep before commissioning a duplicate.

---

## 9 · Structural facts

**Six protocols take a different meditation entry** — t1-07, t1-10, t2-08, t2-10, t3-08, t3-09 are Numb. Movement before attention, contact before the count, one-word Recognise. Their cue card fronts carry **four numbered lines plus an unnumbered *Before you start —* line above.** Same on t1-03. This keeps "Four lines. Always here." literally true on all 31.

**Track 03 carries a work-device line** in every Your Record and every Decision.

**The Clearing is the fourth router door.** State `Steady`, free, no account, **two resources only**. Giving a boundary resource to someone who is fine manufactures a problem.

**Journey:** home → track page → plans. Or track page → free Anxiety Reset → account → dashboard.

**Dashboard nav needs a Plans entry.** Label it **Plans**, not *Upgrade*. Position it with account and settings, **not in the protocol navigation** — a member arriving in distress should not meet a purchase prompt on the way to a protocol.

---

## 10 · Copy deliverables

`copy/home-copy-revision.md` — homepage revision. New cost section after the hero, corrected protocol lists, image direction, close handing to the tracks rather than to plans.

`copy/plans-header-copy.md` — superseded by the finalised plans page. Retained for the rules section only.

`copy/correct-protocol-lists.md` — the thirty, as built.

---

## 11 · Verification

```
Content     308 resources · 31 protocols · 151,772 words
            banned vocabulary: none   ·   durations: none
            cue card fronts: four lines everywhere
            suggestion line on the six Numb protocols and t1-03

Store       node -e "const R=require('./resource-content.js');
              console.log(Object.keys(R).length, Object.values(R)
              .reduce((a,v)=>a+v.resources.length,0))"
            → 31 308
            markers: 0   durations: 0   dispenza: 0   unclosed tags: 0
            shared-block markers: 16   safety gates: 8

Data        grep -ric "dispenza" .                    → 0
            grep -c "kross" content/tracks.js         → 5
            grep -c "extras: null" content/tracks.js  → 0

Diagrams    39 SVGs · all tokenised · light and dark clean

Build       counts derived, never hardcoded
            Your Record and The Decision local-only, real export
            support advisory page reachable without an account
```

**Regenerate the store with `data/mk_store.py` whenever a protocol file changes. Do not hand-edit `resource-content.js`** — the markdown is the source of truth and an edit there is lost on the next run.

---

## 12 · Still open, not for this pass

Meditation posters ×31 — separate chat, brief at `specs/POSTER-HANDOVER.md`. Body maps are built but were rebuilt as an axis rather than a figure; see `specs/DIAGRAM-SET.md`. Cue card print layouts ×10, OG share images ×31, the breath cycle, the ID remap, the t3-06 cover, the recordings and music bed, the Track 03 introduction.
