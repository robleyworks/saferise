# t0-00 · The Clearing

**Label:** Steady · **State:** Steady · **Frameworks:** HeartMath, Kross · **extras:** `[]`
**Free. No account.** The fourth door on the router — for the visitor who arrives from intention rather than duress.

> **Not a distress asset.** Agitated, Unsteady and Numb are duress states. This is the fourth door, and it is a different kind of thing rather than a fourth flavour of the same thing. Nothing is being put out here.
>
> **Deliberately the shortest thing on the platform.** It is the first experience for someone who is not in trouble. If it asks more of them than the Anxiety Reset asks of someone having a bad day, the ask is backwards.
>
> **Resources:** meditation and cue card only. It carries no Safe Practice, no Proximity Guide, no Disclosure, no Record — a person who is fine does not need a boundary resource, and giving them one manufactures a problem.

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in from the first word. Lighter than the protocols. Turn at four seconds.
> **VOICE** — unhurried, warm, and entirely unworried. Nothing is wrong and the voice knows it. Closest register to a conversation.

Nothing's wrong today.

> **GOLD/PAUSE**

That's not a small thing, and it's usually the reason people don't do this. There's no fire, so there's no reason to sit down.

> **GOLD/PAUSE** — long

Which is exactly why today is the useful one. What gets built here is what's available on the day something *is* wrong.

> **GOLD/PAUSE**

Same four moves as everything else on this platform. You're just running them without a problem attached.

---

### Recognition

So — nothing's wrong. What's actually here?

> **GOLD/PAUSE** — very long

Not a problem to find. Just what your body is doing while nothing in particular is happening to it.

Somewhere there'll be a bit of held-ness. Jaw, maybe. Shoulders. Something in the stomach that hasn't fully sat down.

> **BLUE/ILLUSTRATION** — open ground. Nothing on it. Space rendered as space, not as emptiness.

> **GOLD/PAUSE** — long

That's readiness. It's on standby, and it's been on standby a while.

> **GOLD/PAUSE**

One word for where you are. **Steady.**

> **GOLD/PAUSE** — long

Notice something. You just found a state without being driven to look for it. That's the skill, and it's much easier to learn today than on the day you'll need it.

---

### Regulation

Four counts in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six out. Longer out than in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Same count you'd use in the worst hour of a bad week. Nothing about it changes.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention to the middle of your chest.

> **RED/ACTION** — hand to sternum, flat, light. Offered, not instructed.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And here's the difference. On a bad day this is work. Today it's just breathing.

> **GOLD/PAUSE** — long

Your body is learning the pattern in easy conditions. That's the whole reason to be here.

> **GOLD/PAUSE** — extended

---

### Release

Nothing to put down today. So we'll do something else with this step.

> **GOLD/PAUSE** — long

That readiness you found a minute ago — the jaw, the shoulders, whatever hasn't quite sat down.

> **GOLD/PAUSE**

It isn't responding to anything. There's nothing in the room. It's on, because it's usually on.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

That's what it costs to be permanently a bit prepared. You've been paying it in the background and it doesn't send a bill.

> **GOLD/PAUSE** — long

So — let some of it go. Not all of it, and not permanently. Just notice you can take some of it off while nothing is coming at you.

> **GOLD/PAUSE** — very long

And a question, and this one's better on a good day than a bad one.

**What's running that you didn't choose?**

> **GOLD/PAUSE** — very long

Not a fault. Something doing its job on old instructions — a way of reading a room, a thing you always check, an assumption that's never had a quiet moment to be looked at in.

> **GOLD/PAUSE** — very long

I'm not telling you what yours is. I don't know, and it isn't mine to say.

> **GOLD/PAUSE** — very long

---

And while it's quiet, one thing worth practising here rather than in the middle of something.

> **GOLD/PAUSE** — long

A thought turns up. You notice it. Those are two separate events, and today you can feel the gap between them.

> **GOLD/PAUSE** — very long

A feeling arrives. You notice that too. It's happening in you, and it isn't the whole of you — and on an ordinary afternoon that's easy to see.

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — open ground, and one small figure standing on it with room on every side.

Something in your body wants attention. You notice, and nothing has to happen next.

> **GOLD/PAUSE** — very long

That's the whole skill. Not stopping any of it — noticing that you're the one it's arriving to.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

On a bad day that gap closes and there's no space in it at all. Which is precisely why it's worth finding today, while there's nothing at stake in it.

> **GOLD/PAUSE** — very long

Nothing to work out. Just three things to notice — a thought, a feeling, something in the body — and each time, the fact that you're the one noticing.

> **GOLD/PAUSE**

If something surfaced, leave it there. If nothing did, that's ordinary — this one answers slowly, and it answers better on days like today.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

---

### Rise

Step outside it, the same way you would on any other day.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Someone over there. Not in trouble. Breathing four and six on an ordinary afternoon.

> **GOLD/PAUSE**

Speak to them as *you*.

*Nothing's wrong. You're doing this anyway.*

> **GOLD/PAUSE** — long

Most people only ever do this in an emergency, which is the hardest place there is to learn anything.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now — you can see where your attention is sitting. On a good day it's the easiest it will ever be to move it somewhere on purpose.

> **GOLD/PAUSE**

So: put it on something you're actually building.

Not a wish, and not the finished version — that one does nothing for you. The work itself. Today or tomorrow.

> **GOLD/PAUSE** — long

Where are you when you're doing it. What's in your hands. What's the first move.

> **GOLD/PAUSE** — very long

That's what this is for. Not feeling better — you already feel fine. Being the one who decides where the attention goes, on the easy days and the other ones.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing already here, before you finish. Not something to be grateful about in general. Something specific, in the room, now.

> **GOLD/PAUSE** — long

Now put it down. All of it. You don't have to carry any of this out of here.

> **GOLD/PAUSE**

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back whenever you're ready.

You'll have noticed there wasn't much to it. That's the point — this is the version of the practice that fits into an ordinary day, and it's the one that makes the other ten usable when you need them.

Recognition. Regulation. Release. Rise.

Same four. No fire required.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Find what's here** — *You are steady.* Not a problem. What your body's doing anyway.
**Breathe it** — Four in, six out. Same count as the worst day.
**Take some readiness off** — Nothing's coming. Ask *what's running that you didn't choose?*
**Put attention somewhere on purpose** — The work itself. Not the finished version.

### Back

**Recognition** — Nothing's wrong, so there's nothing to hunt for. Find what your body's doing while nothing in particular is happening to it — jaw, shoulders, something in the stomach that hasn't sat down. That's readiness on standby. Naming a state without being driven to is the skill, and today is the easy day to learn it.

**Regulation** — Four in, six out. Exactly the count you'd use in the worst hour of a bad week. On a bad day this is work; today it's just breathing, and your body is learning the pattern in easy conditions.

**Release** — Nothing to put down, so use the step differently. That readiness isn't responding to anything — it's on because it's usually on, and being permanently a bit prepared has a running cost. Take some of it off. Then ask *what's running that you didn't choose?* and leave it open. This question answers better on good days than hard ones.

**Rise** — See yourself from a distance. *Nothing's wrong. You're doing this anyway.* Then put your attention somewhere on purpose — the work you're actually building, not the finished version of it. Where you are, what's in your hands, the first move. Then one thing already here.

---

## Notes for the build

**Router placement.** Fourth door, rendered visually distinct — dashed border, teal, `nothing's wrong` label. The difference in treatment is the difference in kind.

**Door promise:** *The practice for an ordinary day. Not a rescue — the thing you build when there's nothing to put out.*

**Length.** Shortest meditation on the platform, and it must stay that way. If it ever runs longer than the Anxiety Reset, the intentional visitor is being asked for more than the distressed one, which is backwards.

**Two resources only.** Meditation and cue card. Adding Safe Practice, a Proximity Guide or a Record to a protocol for people who are fine manufactures a problem in order to solve it.

**Free, no account**, on the same basis as the Anxiety Reset.
