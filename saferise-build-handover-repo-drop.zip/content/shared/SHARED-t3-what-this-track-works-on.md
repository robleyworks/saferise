# SHARED · Track 03 — What this track works on

Appears once in **How This Works** on all ten Track 03 protocols, immediately before *What we rest on*. Written once, used everywhere. Roughly 320 words.

No framework is cited. This is the platform's own position and is presented as such.

---

## What this track works on

**You are being graded. This platform isn't the one doing it.**

Someone is forming a view of how you show up — in meetings, in writing, under pressure, when something goes wrong. That view affects what you're offered, what you're paid, whose problems you get handed, and which rooms you end up in. Pretending otherwise would make this track useless.

So there's already a scoreboard. What this platform won't do is add a second one on top of it.

Nothing here sets you a target, measures what you produced, or tells you that you should be getting more done. There's no version of a bad week here, and nothing will ever ask you how much you got through.

**Two kinds of pressure, and only one of them is yours**

There's the pressure applied to you. The deadline, the review, the client, the person who decides. Real, largely imposed, and often not yours to change.

And there's the pressure you generate on top of it. The rehearsal before the meeting. The re-checking of work that's already finished. The case you're building about a colleague. The audit you run on yourself afterwards.

The second one is invisible from outside, it doubles the load, and it's the only one of the two you can put down. That's what the third step does on every protocol here.

**Why settling the state changes what you're able to bring**

This isn't modesty about what regulation does — it's the actual mechanism. A narrowed system makes worse calls, hears less in a room, takes longer to start things, and finds it harder to ask for what it needs. Settling it doesn't make you more productive. It makes the person doing the work available.

**And one thing this track is honestly for**

Working out whether you're in the right place. Some of what these protocols surface is a state to be worked with. Some of it is an accurate reading of an environment. Nothing here will tell you which — from outside, nobody can. But the difference matters more than anything else on this track, and a settled system is much better at telling them apart than a narrowed one.

---

## Why this block exists

The track is called Professional Performance and the platform forbids performance targets. Without the position stated once, on every protocol, the track fails in one of two directions: it reads as productivity tooling, or it reads as a wellness product written by someone who has never been in an office.

The reconciliation is the first line. **Work is evaluative; this platform declines to be a second evaluator.** That's a different claim from pretending the evaluation isn't happening.

## Track-specific prohibited vocabulary

In addition to the standing list: **productivity · optimise · performance target · output · efficiency · high performer · peak · elite · edge · unlock your potential · earning potential · best results · maximise.**

*Perform* survives only as t3-05's label.

**Permitted, and preferred, where consequence is named:** what you're offered · what gets noticed · what you're paid · whose problems you get handed · which rooms you end up in · what you're trusted with.

Plainer, factual, and not a promise.

## The line on consequence

Naming that a state costs you materially is honest and it is motivating. Taken further it becomes leverage — *fix this or you'll be passed over* — which is a fear appeal, and this platform does not use them.

**The rule:** consequence is stated **once per resource**, as an observation, in the past or present tense. Never as a prediction, never as a warning, never as a reason to act.

Right: *"Not saying the thing in meetings is why the argument gets attributed to someone else."*
Wrong: *"If you don't start speaking up, you'll be overlooked."*

The consequence line belongs in **Accountability & Empathy** by default, since that resource is already about the exterior. Where it belongs elsewhere — usually How This Works — it replaces rather than supplements.
