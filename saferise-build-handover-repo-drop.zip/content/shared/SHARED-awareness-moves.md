# SHARED · The two awareness moves

Two additions to the meditation scripts. Neither is universal — placing them where they don't belong does real harm, and the table below is the decision.

Sources: philosophy §8 (*the difference between consciousness and the contents of consciousness*) and move 3 (*presence — attention placed on now, the only place that contains your actual resources*). Framework support for the second move is Kross & Ayduk with King, already in the set.

---

## Move A · Stepping out of the state's grip

**Where:** Recognition, immediately after the naming. Never before it — there has to be something named before you can be the one who named it.

**What it does:** separates the person from the state while they are still inside it. On the protocols where the state arrives claiming to *be* you, this is the only move that works, because argument fails — the state produced the evidence and will produce more.

**The language, plain:**

> You just described a state. And something in you did the describing.
>
> Those aren't the same thing.
>
> The state is in the room. You're the one who noticed it was in the room. That's a different position, and you're already standing in it.

**What it must never become:** a claim that the person is separate from their feelings in some permanent or spiritual sense, or an instruction to detach. It is a noticing that lasts a second, and the platform says so.

**Vocabulary excluded:** higher self, true self, witness, observer consciousness, ego death. All of these are in the philosophy document and none belong on a page.

---

## Move B · Putting attention somewhere by choice

**Where:** Rise, replacing or preceding the forward scene.

**What it does:** names what awareness is actually for. Not stopping the state — the member has already watched that fail. Once you can see where your attention is sitting, you can move it deliberately.

**The language, plain:**

> Not making it stop. You've watched it not stop on request. It's that once you can see where your attention is sitting, you can put it somewhere else on purpose.
>
> And look at where it's been sitting. A room you were in last week. One you haven't walked into yet. Neither of those has anything in it you can use. Everything you actually have is here.
>
> So put it somewhere by choice. Not on the version of you who feels confident — that one isn't available on demand. Not on the version who's already got the thing, either. That one does nothing for you.
>
> On the one who does the work today. Where are they. What's in their hands. What's the first move.
>
> That's not a reward waiting at the end of something. That person is the thing being built.

### The line this move must not cross

**Rehearsing yourself doing the work is supported. Rehearsing having the thing is not.**

The finding is that concrete future rehearsal lifts outlook in the person rehearsing. It says nothing about the world, and it makes no claim that attention produces outcomes. Cross that line and the platform is doing manifestation with the vocabulary changed — which is precisely what the four prohibited words exist to prevent.

**Excluded, absolutely:** attract, draw in, create your reality, call it in, align with, abundance, deserve it, the universe. And no promise about what the rehearsal will produce.

The closing sentence carries the safe version of the whole idea: *that person is the thing being built.* The person is the output. Nothing else is claimed.

---

## Where each move goes

| | Move A · out of the grip | Move B · attention by choice |
|---|---|---|
| t1-01 Anxiety | light | **yes** |
| t1-02 Anger | no — the state doesn't claim to be you | light |
| t1-03 Overwhelm | no | **yes**, sized small |
| t1-04 Abandonment | **yes** | light |
| t1-05 Shame | **yes — the primary move** | light |
| t1-06 Grief | light | **no** |
| t1-07 Shutdown | light | **no** |
| t1-08 Jealousy | **yes** | **yes** |
| t1-09 Insecurity | **yes — the primary move** | **yes** — worked example, built |
| t1-10 Powerlessness | **yes** | **no** |

### Why the three refusals matter more than the eleven placements

**Grief.** There is no forward version of you to move attention toward, and offering one says the loss should be got past. The fourth step here stays where it is: an ordinary hour, carried out while carrying this.

**Shutdown.** The capacity to place attention deliberately is the faculty that has reduced. Asking for it produces a member who fails at the last step of a protocol built for their worst day.

**Powerlessness.** Telling someone whose situation genuinely cannot be moved that attention is a choice is the cruellest available version of this idea. The protocol's forward move stays what it is — one small thing that is actually theirs, returning to the fingers moving at the start.

On Tracks 02 and 03, Move B carries a further risk on the professional protocols specifically: it is one step from productivity framing. On t3-10 Creative Flow and t3-06 Ambition Recovery it must stay on *the person doing the work* and never touch what the work produces.

---

## Move C · The layered descent

**Where:** Release, after *what was this for* and never before it. The deepest move on the platform.

**Source:** philosophy §7 — observe the feelings, look beneath them, find the beliefs, ask where they came from. §8 turns that into layers: thought, emotion, belief, identity.

### It is a descent, not a question

An earlier version of this move asked one question. That was wrong. One question gets one layer, and the layer that matters is usually the third.

**Three layers, with room between them:**

**1 · What you'd say it's about.** Usually accurate, rarely the whole of it.

**2 · What's underneath that.** What the surface fear is actually protecting or grieving.

**3 · What makes it unbearable rather than just unwelcome.** Almost always some version of *it isn't fair* or *there's nothing I can do about it.*

That third layer is where the weight is, and no amount of working on the first one reaches it.

### The worked example

A member cannot be told what their layers are. But they can be shown the *shape* of the move using somebody else's, and without that the instruction is too abstract to follow.

> Someone frightened of flying will tell you it's the plane. And it is, partly.
>
> But go underneath and it's usually not the crash. It's everything on the other side of the crash. The people who'd be left. The things they'd never get round to. The ordinary Tuesday afternoons they'd miss.
>
> And under that there's usually one more thing. It wouldn't be fair. And there'd be nothing they could do about it.
>
> That isn't fear of flying. That's grief, arriving early, with nowhere to put itself.

**Then, and only then, the member's own:**

> What's underneath the thing you'd say it's about?
>
> And under that — what makes it unbearable, rather than just unwelcome?

Each protocol carries its own example, drawn from that state. The example is always somebody else's and always in the third person.

### Pacing is the move

**Very long pauses between layers.** A descent read at conversational pace is a list of questions. The silences are where the layers actually get reached, and the marker density on this move is higher than anywhere else in the script.

### Three constraints

**1 · After Regulation, never before.** Opening this on an unregulated system is how people get hurt.

**2 · Poses and refuses to answer.** *I'm not answering either of those. I don't know, and anyone telling you from outside your own life is guessing.* No candidates — not a parent, a school, a partner, or childhood.

**3 · Nothing arriving is legitimate, stated outright.** *These arrive in their own time, and often not while you're looking.*

### The exits — before and after

Opens with one, before the question is asked:

> If today is a day for getting steady and stopping there, stop there. Come back to the count, finish, and go. That's a complete use of this.

Closes with another:

> If it opened something bigger than today, come back to the count now and end here. Going further on your own isn't the brave version. It's just the unaccompanied one.

---

## Move C-close · The three beats that follow a descent

These are not optional. A descent that ends on the third layer leaves someone holding the heaviest thing they've found today with nothing after it.

**1 · Forgiveness for struggling.** The reflex arriving behind a discovery is *I should be able to handle this.*

> Whatever you just found — it would be strange not to struggle with it. Struggling is the appropriate response to it. You've been doing that already, without knowing what it was you were up against.

**2 · Acknowledgement of the faculty that surfaced it.** Directed at what looked, never at what happened.

> Something in you brought that up. Not the part that's frightened — the part that was willing to look underneath it while it was still happening.
>
> That took something. It's yours, it was yours before today, and it's the thing this whole practice runs on.

**3 · Not the only one.** Framed as fact rather than as comfort, which is what stops it being a platitude.

> One more, and it's simply true rather than comforting. Whatever you found under there — you're not the only one. Not close to it. It's one of the most ordinary things there is, and almost nobody says it out loud.

**The prefacing matters.** *Simply true rather than comforting* is what lets a member accept it. Offered as reassurance, the same sentence gets discarded.

**Excluded:** we're all in this together · you're not alone in this journey · millions of people · a community of · everyone feels this way (which is frequently false and always dismissive).

### Two failure modes

**Parts language.** *Who is speaking* is one step from naming internal characters and holding dialogue with them. Different modality, own training. The questions are asked once and left open.

**Weaponising it on Track 02.** *What's really underneath that for you* asked about the other person is the case-builder wearing depth. The descent is always about yourself.

### Where the descent goes

| | Move C |
|---|---|
| t1-01 Anxiety | **yes, as an optional deeper pass.** Built — reference. The state's surface subject is almost never its content |
| t1-05 Shame · t1-09 Insecurity | **yes — the primary work** |
| t1-04 Abandonment · t1-08 Jealousy | **yes** |
| t1-02 Anger | the proportion layer only — what was crossed, and why that one |
| t1-03 Overwhelm | **no** — acute, and the member came to get steady |
| t1-06 Grief | **no.** Nothing is buried, and implying there is says the grief needs explaining |
| t1-07 Shutdown · t1-10 Powerlessness | **no** — capacity reduced, situation real |
| t2-04 · t2-05 · t2-06 · t2-07 | **yes** |
| t2-03 · t2-09 | **no** — the member may be the person being harmed |
| t3-03 · t3-04 · t3-06 | **yes** |
| t3-01 · t3-02 · t3-05 · t3-08 · t3-09 | **no** — acute, situational, or reduced |

**Anxiety moving to yes is a change from the earlier table.** It was excluded as acute. The flying example shows why that was wrong: this is the state whose stated subject is least often its actual content, and the descent is where it becomes workable. It is gated as optional with an exit before and after, which is what makes it safe on an acute protocol.

---

### E1b · The second reluctance — not wanting to put it down

**Where:** immediately after E1, in the same breath.

**What it does.** E1 answers *how did I not see this.* E1b answers the harder one — **I don't want to give it up.** That reluctance is more common, more shaming to admit, and almost never named anywhere.

The resolution is not that the protection was wrong. It is that it is **out of date** — working off the last information it received.

> You might not want to put it down.
>
> That isn't a failing and it isn't stubbornness. That thing worked. It got you through something, and whatever it has cost you since, some part of you knows exactly what would have happened without it.
>
> So of course there's a reluctance. You're being asked to set down the thing that kept you standing.
>
> It was built with what you had at the time. What you had then and what you have now aren't the same thing. You've got more room than you did, and more steadiness, and you can see a state while you're inside it — you did that a few minutes ago, at the start of this.
>
> That part of you doesn't know any of that. Nobody told it. It's still working off the last information it got, and that information is old.
>
> You don't have to make it stand down. You're not being asked to, and you'd be right to refuse.
>
> You're only being asked to notice that the person it's guarding isn't the one it started guarding.

### Three constraints on E1b

**1 · Never assert that the member is safe now.** The platform does not know their situation and some of them are not. The claim is about the protection being uninformed, never about the life being safe. *You are safe now* is prohibited on every protocol without exception.

**2 · The evidence offered must be something they just did.** Not a promise about their capacity — a demonstration of it, from earlier in the same session: *you can see a state while you're inside it — you did that a few minutes ago.* Verifiable, present, and theirs.

**3 · Releasing is never required.** The pangolin anchor already says nobody is taking the armour off them. E1b must agree with it: *you don't have to make it stand down, and you'd be right to refuse.* The ask is a noticing, not a surrender.

**Excluded:** you are safe now · it's not needed any more · that part of you can go · thank it and release it · you've outgrown it · it served its purpose (past tense verdict).

### Where E1b goes

Strongest where the protective pattern is most obviously still working for the member:

| | E1b |
|---|---|
| t1-05 Shame | **yes.** Built — reference |
| t1-02 Anger | **yes — arguably its strongest home.** Anger is experienced as the thing keeping them from being walked over |
| t1-04 Abandonment | **yes.** The vigilance feels like the only thing preventing the loss |
| t1-09 Insecurity | **yes.** The auditing is experienced as what stops them being caught out |
| t1-08 Jealousy · t2-03 Trust & Betrayal | **yes**, and on t2-03 with the safety gate adjacent |
| t3-03 Imposter · t3-04 Perfectionism | **yes.** Both are widely believed to be the source of the person's standard |
| t1-06 Grief | **no.** There is no protection to relinquish |
| t1-07 Shutdown · t1-10 Powerlessness | **no.** Capacity is reduced, and on t1-10 the protection may still be entirely correct |
| Acute protocols | **no** |

---

**The framing constraint.** Never *forgive yourself for* — that construction presupposes an offence, which reintroduces the charge in the act of dropping it. The move drops a charge that was never valid rather than pardoning one that was.

**Excluded:** forgive yourself, let yourself off, you did your best, be kind to yourself, self-compassion as a named practice.

### E2 · Gratitude and release — closes Rise

**Where:** the final beat of the session, after Move D. It is the last thing the member hears.

**What it does.** Directs acknowledgement at the faculty that got them here — the part that noticed and stayed — rather than at anything that happened to them. That distinction is the whole safety of the move and it is stated out loud.

> Something in you brought you here today. Not the part that was hurting — the part that noticed the hurting and sat down with it anyway.
>
> That was there the whole time, underneath all of it. Nobody taught you that. It's yours, and it was yours before today.
>
> So just acknowledge it. Not gratitude for what happened to you — nobody is asking you for that, and anyone who does is wrong.
>
> Gratitude for the thing in you that kept looking anyway.

Then the release, which is what stops the session becoming something to carry:

> Now put all of it down. The state. The question. The decision. You don't have to carry any of it out of here. It happened, and it stays happened, whether or not you keep hold of it.

**Why the release beat is not optional.** Without it, a session that reached Move C and Move D hands the member a pile of new material at the exact moment they stand up. The last instruction has to be to set it down, or the protocol becomes another thing being carried.

### Where Move E goes

**E1 travels with Move C.** Wherever Move C runs, E1 runs — it is not separable, because C reliably produces the charge E1 answers. A protocol carrying C without E1 is unfinished.

**E2 is close to universal**, with the wording changing by protocol:

| | E2 |
|---|---|
| Most protocols | **yes** — gratitude for the faculty that noticed |
| t1-06 Grief | **yes, and rewritten.** Already handled: *not something to be grateful for about the loss — something that's still here.* Never extend it beyond that |
| t1-07 Shutdown | **yes, reduced.** *You did this. That's the whole of it.* Nothing more is available and nothing more should be asked |
| t1-10 Powerlessness | **yes, reduced.** Acknowledgement of having got through the day, and nothing about the situation |
| t3 protocols | **yes**, and never about the work or what it produced |

**The release beat is universal, with no exceptions.** Every session ends by putting it down.

---

## Move F · What this is telling you

**Where:** the close of Rise, after Move D. Only on protocols where a real decision is live — stay, go, ask, wait.

**Source:** philosophy §4, the survival metronome — a present event gets compared against stored experience, and the response answers the comparison rather than the event. Move F is that mechanism turned into a reason for regulating before deciding.

### The claim, and why it holds

A narrowed system doesn't decide from the situation in front of it. It decides by matching the present against everything that came before, and answering the old one.

That isn't a fault — it's fast, and speed was the point. But it means a decision made from inside the state is substantially about a situation you were in previously.

Settled, you get the present one, roughly as it is.

**This is the platform's own mechanism, not a claim about clarity or intuition.** It gives regulation a place in a life decision without the platform having any view on the decision.

### The language

> There's one more thing here, and it's bigger than today.
>
> You're going to have to decide something. Stay, go, ask for something, wait it out.
>
> Here's what's worth knowing about how that decision gets made. A system in this state doesn't decide from the situation in front of it. It decides by comparison — matching what's happening now against everything that's happened before, and answering the old one.
>
> That's not a fault. It's fast, and it was built to be fast. It does mean the decision you'd make right now is largely about a situation you were in previously.
>
> Settled, you get something else. The one actually in front of you.
>
> So — a few questions while you're here. None of them to answer today.
>
> **How did you get here?** Not whose fault. What the sequence was.
>
> **What is it in you that keeps arriving at this?** Something has kept choosing this shape of situation, or kept staying in it. That's information, not a fault.
>
> **What would you do differently, if you were placing yourself again?**
>
> **And what has the whole run of it — including the parts that went badly — actually left you able to do?**
>
> That last one is the useful one. Not what you'd like to do. What all of it has equipped you for, which you may not have noticed because you were inside it.
>
> None of that decides anything today. It means that when the decision comes, it gets made from here rather than from a comparison.

### Four constraints

**1 · It never answers the question.** Not stay, not go, not ask. The platform has no view and no information. Move F changes what the decision is made from, and nothing else.

**2 · Nothing about purpose, calling, destiny or alignment.** *What the run of it has equipped you to do* is a plain observation about accumulated capability. *What you're meant for* is a claim about the universe, and this philosophy asserts nothing about the universe.

**Excluded:** purpose · calling · destiny · meant to · aligned with · your path · the universe · everything happens for a reason · your zone of genius.

**3 · The questions are posed and left open.** Same rule as Move C — the script asks and refuses to answer, and nothing arriving is a legitimate outcome.

**4 · No inventory of failures.** *How did you get here* is a sequence, not an audit. If the member starts listing what they got wrong, the move has become self-prosecution and the script should say so and stop.

**5 · Never assume there is time.** Members arrive with offers expiring, consultation periods running, visa dates and review meetings. *You don't have to decide today* is false for them and useless at the moment they most need the protocol.

Under a deadline the move compresses rather than being skipped: take the fourth question only — *what has the whole run of it left you able to do* — and drop the other three. A short deadline is a reason to regulate first, because there is no time left to correct a decision made from a comparison.

**Excluded:** you don't have to decide today · there's no rush · take all the time you need · sit with it for a while.

### Where Move F goes

Requires a live decision. Never on acute protocols — someone getting steady is not in a position to review their working life, and asking them to is a category error.

| | Move F |
|---|---|
| t3-07 Career Transition | **yes — the protocol is built around it** |
| t3-06 Belonging Gap | **yes.** Whether to stay in the room is the live question |
| t3-09 Burnout & Overload | **yes**, sized small. Capacity is reduced |
| t3-10 Creative Flow | **light** — about the work rather than the position |
| t2-10 Conscious Separation | **yes**, and it is about you rather than about them |
| t1-08 Jealousy · t1-09 Insecurity | **light.** What the state points at, not a life review |
| t3-01 · t3-02 · t3-04 · t3-05 · t3-08 | **no** — acute, situational, or no decision live |
| t1-01 · t1-03 · t1-07 · t1-10 · t2-03 · t2-09 | **no.** Acute, reduced, or gated for safety |

### The failure mode to hold against

**Move F becoming a career-planning exercise.** The moment it produces a plan, a direction or a recommendation, the platform has started advising on someone's life from a position of no information. It asks four questions and then hands the decision back, unanswered.
