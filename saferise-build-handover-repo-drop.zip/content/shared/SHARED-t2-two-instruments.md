# SHARED · Track 02 — Two parts of you

Appears once in **How This Works** on all ten Track 02 protocols, immediately before *What we rest on*. Written once, used everywhere. Roughly 450 words.

**Frameworks:** Jung (interpretive band — the material you decline to look at runs unattended and is met as other people's faults). Nothing else is cited here; the rest is the platform's own account, and it is presented as such.

---

## The part that's on your side, and the part that can hear them

Almost everyone in a conflict is doing the same thing: assembling the case that supports their view. It does not feel like assembling. It feels like thinking clearly, or finally being honest with yourself about what happened.

The part worth knowing is what is doing the assembling.

**The first instrument is built for survival, not for fairness.** It is the part of you that keeps you intact, and it is necessary — nothing here says otherwise. But it operates on a few fixed rules, and they are structural rather than moral:

- **You are the primary concern.** Not from selfishness. From function.
- **There is no true equal.** Another account cannot be simply as valid as yours; it has to be measured against yours.
- **Its filters decide what is real.** Whether something is reasonable, credible, or true is settled by whether it passes through them.

Run a conflict through an instrument with those rules and the answer comes back in your favour. Every time. Not because you are dishonest — because that is what the instrument is for. This is the single most useful thing to know about your own case: the verdict was determined by the tool, before the evidence was in.

**The second instrument works differently.** It can hold that another person's account is complete on its own terms rather than as a version of yours. It does not require agreement, and it is not the same as being nice. It is a way of receiving information the first instrument is not built to accept.

Both are needed. The first one keeps you from being erased in a conflict. The second is the only one that can end one.

**One rule, and it is not optional.**

You can audit your own instrument. You cannot audit theirs.

You can hold that theirs is also running, and that it is doing the same job for them — that is the part that produces symmetry rather than superiority. What you cannot do is tell them what theirs is doing. From where you stand there is no access to it, and the naming is the first instrument working: *that's just your ego talking* invalidates their account while sounding like insight. It is the best case-builder available, and it is still a case.

If you find yourself explaining someone else's psychology to them mid-conflict, that is the instrument, not the insight.

**Why this sits underneath every step here.** Recognition separates the state from the account. Regulation settles the system that is producing the case. Release puts down the assembly. And the fourth step asks you to stand somewhere that is not your own vantage — which is the second instrument, used deliberately, for as long as you can hold it.

---

## Related: where Track 01 comes in

Sits at the foot of the block, one short paragraph. Recommendation, never a gate — access is cumulative, so every Track 02 member already has Track 01.

> This work goes more easily when you can already see your own state while you are inside it. That is what Track 01 builds, and it is why it comes first. Nothing here requires it, and nothing here assesses whether you are ready — but the second instrument is difficult to reach for while the first one is running unobserved.

---

## Vocabulary decisions

**"Ego" appears once, in the member-facing quotation** *(that's just your ego talking)*, as the thing not to say. Everywhere else it is **"the part that's on your side"** and **"the part that can hear them"**.

Two reasons. "Ego" arrives pre-loaded — half of members read it as an insult, the other half as a licence to diagnose whoever they are arguing with. And an invented label like "the first instrument" is worse than the word it replaces, because nobody knows what it means. Describing the part beats naming it.

**"Energy" is not used.** Not prohibited, but adjacent to the four words that are, and it is the term that would let a sceptical reader dismiss the page. The faculty is described directly instead.

**No aetiology.** The block says what the instrument does, never where it came from or what yours says about you.

---

## Safety floor — required wherever mutual disclosure is encouraged

Full disclosure between two people is the right target and it is unsafe in some situations. Wherever a Track 02 resource encourages divulgence, this gate applies — written fresh per protocol, not pasted:

> This assumes both of you can move, and that what you say will be received rather than used. Where one person is being controlled, monitored, or made afraid, telling them more is not the move and this is not the resource for it. The Proximity Guide's third tier is, and your safety is a separate question from your regulation.

Gate is mandatory on **t2-03 Trust & Betrayal** and **t2-09 Pursue & Withdraw**, where the member may plausibly be the person being harmed.
