# Resource 10 · Accountability & Empathy
*What it does outside you.*

**Universal.** Appears on every protocol. Not conditional — every state exits.

**Frameworks:** Kross (the perspective mechanism), Maté (the register that keeps it from becoming self-attack).

---

## What this resource is for

Governance of a state means having all of the information about it. Most people have half.

The protocol trains the interior half. You can now find where it sits in your body, name it while you're inside it, bring the physical side down, and see it from a distance. That is a real faculty and most people never get it.

But the state does not stay in there. It exits — into a room, into a tone, into a silence, into what you did or didn't do — and it lands somewhere. That half happens outside your body and you have no direct access to it. You cannot feel your own volume. You cannot see your own face. You do not know what your going-quiet looks like from the other side of the table.

So there is a part of your own state you have never observed. Not because you are avoiding it — because you are standing in the wrong place to see it.

This resource is how you get the missing half.

**Empathy, here, is not kindness.** It is the only instrument available for observing the exterior of your own state. Another person's reaction is data you cannot generate on your own.

**Accountability, here, is not guilt.** It is authorship applied to conduct. What you do while in a state is either yours or it is the algorithm's. Owning it is the move that makes it yours.

---

## The blind spot, precisely

Three things you have no line of sight to:

**Your volume and your face.** Both feel neutral from inside. Neither is.

**The onset.** You experience the state as arriving somewhere in the middle, after it has been building. Other people frequently see it before you feel it — the shortening replies, the pace change, the set of the jaw. They have earlier information about your state than you do.

**The gap between what you meant and what arrived.** You have the whole context. They have the last thirty seconds. You are working from the loop you have been running silently; they are working from what came out of your mouth. These are different events and only one of them was witnessed.

None of that is a character finding. It is a matter of vantage. You are inside the thing, which is the one place from which it cannot be seen.

---

## Getting the missing half

**Turn the fourth step outward.** You already do this on yourself — see the scene from across the room rather than from inside it. Same move, one change: stand where they were standing. Same room, same evening, their vantage. What arrived, from there. What they had no access to. What had already happened to them that day, which you may not know.

**Describe what was observable, and ask about the rest.** You do not know their interior. Asserting it — *"I made you feel unsafe"* — puts words in their mouth and hands them something to correct rather than something to answer.

> "You went quiet and left the room. I'm not going to tell you what that was like. I'd rather you told me."

The asking is not manners. It is how the data arrives.

**Turn the third-step question outward too.** *What was this for* is the register you have been using on your own responses. Applied to theirs, it returns the same kind of answer — function rather than defect. Their reaction was also doing a job.

Understanding what a response was doing is not endorsement. That holds in both directions, including toward yourself.

---

## Owning it without attacking yourself

Three moves. Each is a move, not a feeling.

**Name the act, not the character.** *"I raised my voice at you in the kitchen on Sunday"* is ownership. *"I've been a nightmare lately"* is not — it is vaguer, it names nothing, and it quietly asks the other person to disagree with it. Specificity is what makes it real.

**End the sentence where the act ends.** Every *because* after it converts an account into a defence, however true the because is. The reason exists. It may be worth saying, later, if they ask. Attached here, it cancels what came before it.

**Leave yourself out of the aftermath.** *"I'm so sorry, I'm awful, I don't know why you put up with me"* moves the burden across the table — now they are managing your distress about the thing you did to them. Remorse that requires reassurance is a second demand arriving disguised as an apology.

That third one matters beyond manners. Self-attack is the same defect-register question — *what is wrong with me* — wearing the clothes of accountability. It returns nothing usable, and it is the register this platform declines everywhere else. Ownership is a statement about an act. It is not a verdict on you.

---

## Change is what makes it land

A statement is a statement. A change in conduct is something another person can observe over time.

Say the smaller true thing you will actually do rather than the larger one that sounds better. *"I'm going to go outside when it starts, before it gets loud"* is checkable. *"I'll never do that again"* is not.

This is also how you get the next round of information. Conduct that changes produces a different reaction, and a different reaction is a further reading of a state you still cannot see directly.

---

## Where the boundary of this work sits

**This is governance of your own conduct, not a share of what happened.** If you look and cannot find your part, that is a legitimate finding. Manufacturing one to make an exchange go smoothly is a false account, and it comes apart later.

**A reaction is information, not a verdict.** Another person's response tells you something about the exterior of your state. It does not tell you what you are, and someone else's account of you is not automatically more accurate than your own. This resource gives you the missing half of the picture. It does not hand anyone else the whole of it.

**If someone is controlling or hurting you, this is not the resource for that situation.** Looking hard at your own conduct is the right work when both people can move. Where one person is being harmed, it becomes the mechanism that keeps them there. The Proximity Guide's third tier is the resource for that, and your safety is a separate question from your regulation.

**What you find here is yours to read.** This explains where the blind spot is and how to get line of sight into it. What you see when you look — what it means about you, your history, or what you should do next — is not something this platform will tell you.

---

## Instance · t1-02 Anger Alchemy

**The specific blind spot** — anger's exterior is the one people misjudge by the widest margin. Volume feels normal from inside. The face feels neutral. And the loop you have been running is silent, so what arrives on the other side has no build-up attached to it at all. From where you stand it was the sixth round of an argument. From where they stand it was the first, and it was sudden.

**Their earlier information** — people close to you can usually see it coming before you feel it. That makes them a genuine early-warning instrument, and worth asking directly: *what do you see, before I know?*

**Named acts, for practice** — volume, words chosen for where they would land, timing, the leaving. Pick the one they would name if asked.

> "I raised my voice at you on Sunday, in front of the kids."
> "I said the thing about your job. I knew where it would land and I said it anyway."
> "I walked out mid-conversation and didn't come back."

**The hardest omission** — anger arrives with an unusually complete case attached, and the case is what wants to go in the sentence. You may be entirely right about the underlying thing. It still has no place here. Two conversations, not one.

**The checkable change** — anger repairs by leaving earlier, not by leaving better.

---

## Placement

Sits after Your Record. The sequence is: do the protocol, write your account of the interior, then go and get the exterior. The record is the half you can write. This is the half you have to ask for.
