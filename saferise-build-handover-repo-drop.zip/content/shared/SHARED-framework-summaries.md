# SHARED · framework summaries

Six blocks. Written once, used in the **What we rest on** section that closes every *How This Works*.

Each protocol renders only the frameworks in its own `META[key].frameworks`, in mapping order, followed by one line of per-protocol application. The band label (peer-reviewed / clinical practice / interpretive) is not decoration — it is the claim being made about how much weight the finding carries, and it appears on every instance.

---

## porges — Polyvagal Theory · Stephen Porges
**Peer-reviewed** · supplies **Recognition** and the three state labels

Threat detection runs ahead of thought. The body reads a situation and moves before deliberation catches up, which is what makes the response fast and also what makes it non-negotiable in the moment. Porges describes three broad conditions: settled and socially available, mobilised for action, and shut down. Agitated, Unsteady and Numb are the member-facing names for those three.

*The anatomical premises are contested — a 2026 evaluation in* Clinical Neuropsychiatry *challenged them, with Porges replying in the same issue. The state distinctions are what this platform uses and they hold independently of that dispute.*

---

## heartmath — Cardiac coherence · HeartMath Institute
**Peer-reviewed** · supplies **Regulation** and the count

At roughly six breath cycles a minute, heart rhythm and breath settle into a single smooth wave rather than two competing ones, close to a rhythm the body's blood-pressure regulation already runs at. Four counts in, six counts out lands near that rate. The uneven ratio is the mechanism: lengthening the out-breath relative to the in-breath is the part that shifts the system toward settled.

*The finding is used here. The wider programme is not — there is no measurement of coherence anywhere on this platform and no score attached to any breath.*

---

## kross — Distance & rehearsal · Kross & Ayduk, with King
**Peer-reviewed** · supplies **Rise**

Observing an experience from outside it — rather than from inside looking out — lowers distress at the time and reactivity afterwards. Distraction does neither. Addressing yourself in the second person is one of the reliable ways to produce that shift, which is why every cue card on this platform says *you*.

Rehearsing a specific future scene in concrete detail lifts outlook. General optimism does not.

*The effect is on the person rehearsing. It acts on your own steadiness and makes no claim to act on anyone else, or on how anything turns out.*

---

## mate — Compassionate Inquiry · Gabor Maté
**Clinical practice** · supplies **Release** and the way the question is asked

A response is treated as an adaptation rather than a defect: something that was doing a job, whether or not it is still the right job. The register of the question decides the answer. *What is wrong with me* asks about defect and returns answers about defect. *What was this for* asks about function and returns something workable.

Understanding what a response was doing is not endorsement — of the response, or of anyone's behaviour.

*This is a clinical practice, not a controlled research programme. It is used here for the way the question is asked, and nothing wider.*

---

## jung — Shadow & individuation · C. G. Jung
**Interpretive** · informs **Release**

What you decline to look at keeps running unattended, and you tend to meet it as other people's faults. The usable test is proportion: when a reaction outruns the event that occasioned it, the surplus is carrying information about something other than the event.

There is no finish line here and nothing to complete.

*Offered as a lens rather than a finding. It is a way of looking, and it has no controlled evidence behind it. What it shows you, if anything, is yours to read — this platform will not tell you what your surplus means.*

---

## watts — Non-resistance · Alan Watts
**Interpretive** · informs why **Release** says *accept*

The state is one thing. The fight with the state is a second thing. The fight usually costs more, and it is the only one of the two you can put down. Setting the fight down is not passivity, not approval, and not agreement that the situation is acceptable.

*Watts is an interpreter rather than an originator; the older sources are Laozi and, for the framing used here, D. T. Suzuki. Offered as a lens rather than a finding.*

---

## Per-protocol application lines

One sentence per framework, protocol-specific, appended to its block. Examples from the three authored so far:

**t1-01** · porges — *Here it names the fast state without attaching a verdict to it.*
**t1-01** · heartmath — *Here it is the whole of the second step, and the reason a small breath beats a large one.*

**t1-02** · porges — *Here it distinguishes anger from fear: both are mobilised, but anger moves toward rather than away.*
**t1-02** · mate — *Here it is what lets you understand what the anger was protecting without dropping the charge.*

**t1-03** · porges — *Here it names mobilisation with no single target, which is why the preparation runs without discharging.*
**t1-03** · heartmath — *Here the feet into the floor do a related job: a definite signal for a system that cannot find one.*
