# SafeRise · Support Advisory & Record Copy

Two deliverables. Both are member-facing copy, authored to the same register rules as the protocol resources.

---

# Part 1 · Getting Help — support advisory

**Purpose.** Every Safe Practice resource on the platform points to "a helpline in your country" — ten references across Track 01 alone. This is what those references resolve to.

**What it is not.** Not a directory. Services, numbers and eligibility differ by country, change without notice, and a stale number is worse than no number. This page tells a member how to find the right thing where they are, and says plainly that finding it is worth doing.

**Placement.** Linked from every Safe Practice resource, from the cue card modal footer, and from the site footer. Reachable without an account.

---

## Getting help where you are

**If you are in immediate danger, contact your local emergency service now.** That is the number you would call for an ambulance or the police, and it is the right one to use for a mental health emergency as well.

### Finding support in your country

SafeRise does not list helplines. Services differ from country to country, they change, and an out-of-date number is worse than none at all. What we can tell you is that support exists almost everywhere, that it is usually free, and that finding it takes less effort than the state you are in will suggest.

**Start with your doctor.** A GP or family doctor is the most direct route into everything else — assessment, talking therapy, medication if it is appropriate, and referral onward. You do not need to have your situation worked out before you go. "I have not been right for a while" is a complete reason for an appointment.

**Search for a crisis line in your country.** Searching your country's name with *"mental health helpline"* or *"crisis line"* will find the national service. Most operate around the clock. Many offer text or online chat as well as phone, which matters if speaking is difficult.

**International directories.** Organisations including the International Association for Suicide Prevention and Befrienders Worldwide maintain lists of services by country. They are a reliable starting point when you are not sure what exists where you live.

**If you are outside your home country,** your embassy or consulate can point you to local services, and international insurers usually run a helpline of their own.

### If making contact feels beyond you

That is common, and it is a feature of some of the states this platform works with rather than a lack of resolve.

**Ask someone else to do it.** Sending one person a message — *"I need to see someone and I cannot face arranging it, can you help me do that this week"* — is a legitimate way to start, and often the only one available on a bad day.

**Use text rather than voice.** Many services take messages or online chat. If speaking is the obstacle, it is a removable one.

**Bring someone with you.** To the appointment, or just to the waiting room.

### What SafeRise is, and where it stops

SafeRise is self-guided education and training in nervous-system regulation. It is a resource you can reach for on your own, at the moment you need it, without an appointment or a referral. For a lot of people that is the thing that was missing.

It is not a clinic, not an emergency service, and not a substitute for either. Nobody here is monitoring your use of it and nobody reads what you write.

What this platform gives you works alongside professional support rather than instead of it. If you are already seeing a doctor, therapist or counsellor, tell them you are using this — most will want to know, and some will have views worth hearing.

Some states need another person in the room. When one of the resources says so, it is not a formality.

---

# Part 2 · Your Record — device-only copy

**The claim.** Every Your Record resource states that entries are written on the member's device, that nobody else sees them, and that nothing is measured. That claim must be true in the build and visible in the interface, not only in the resource text.

**Dependency for the build:** local storage only, no sync, no server write, no analytics event carrying entry content, and an export that produces a file the member holds. If any of those is not true, the copy below cannot ship.

## Interface strings

**Above the entry field, always visible**

> Kept on this device. Not sent anywhere, not read by anyone, not scored.

**Placeholder in an empty field**

> Write as much or as little as you want. One line is a complete entry.

**Beside the export control**

> Export a copy
> Your entries live on this device only. Export them to keep a copy somewhere you choose.

**First time a member opens Your Record**

> This is yours.
>
> What you write here stays on this device. It is not sent to us, it is not part of your account, and nobody reads it.
>
> That has one consequence worth knowing: clearing your browser data, or changing device, will remove it. Export a copy whenever you want one that outlasts this browser.

**Before an action that would clear entries**

> This removes your entries from this device. There is no copy on our side, so this cannot be undone. Export first if you want to keep them.

**If storage is unavailable or blocked**

> This browser is not letting us save to the device, so entries will not persist. Private browsing is the usual cause. Nothing has been sent anywhere.

## Resource text — addition

Append to the opening paragraph of every Your Record resource, all thirty protocols:

> Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it is never measured against anything you wrote before. **Because it is only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.**

**Why the caveat is in the resource rather than only in the interface.** A member who loses months of entries to a browser clear has lost the material the fourth step depends on. The privacy guarantee and its cost are the same fact, and stating one without the other is a partial account.

---

# Part 3 · Notes

**Safe Practice mandate — brief amendment.** `RESOURCE-CONTENT-HANDOVER.md` §6, resource 05, currently reads:

> *Constraints:* states the limit without disclaiming the practice. Leads with contribution, not negation. Where a state needs a person in the room, says so plainly. **Reviewed by the clinical collaborator.**

Strike the final sentence. Replacement:

> *Constraints:* states the limit without disclaiming the practice. Leads with contribution, not negation. Where a state needs a person in the room, says so plainly. Best-practice recommendations within an education and training platform — no clinical review is claimed anywhere, and no copy should imply one.

No authored resource claims review, so nothing in the ninety needs changing. This corrects the record only.

**Print stays.** Members can print any resource. Scope kept deliberately small: a light print stylesheet covering the cue card at A6 and a clean text print of any other resource. Not a print system.

What the printed cue card carries: the verb, the protocol title, the four lines, the suggestion line where one exists, and the lockup. Not carried: navigation, the modal chrome, the "I have got it" control, or the emergency line — the printed card is the thing in a pocket, and a member holding one has already read the page it came from.

**One wording note.** "Alternative resource" is right as intent and wrong as copy — on the page it reads as an alternative *to* clinical care, which is the one framing the platform's standing rules exclude. The section above says the same thing without that risk: something you can reach for on your own, without an appointment or referral, working alongside professional support rather than instead of it.
