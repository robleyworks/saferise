# t3-05 · The Performance Anxiety Protocol

**Label:** Perform · **State:** Agitated · **Frameworks:** HeartMath, Porges · **extras:** `[]`
**Resources: 9**

> **Distinct from t3-01 High-Stakes Presence.** That one works on the state before you go in. This one works on what happens *during* — when you're already performing and part of your attention has turned around to watch you do it.

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Five-bar phrase. Turn at four seconds.

Start from exactly where you are. This one was built to run in the middle of something — at a break, between one part and the next, in the seconds before you go back.

> **GOLD/PAUSE**

This works on the state, and it doesn't touch your ability. Whatever you can do, you can still do.

---

### Recognition

Find where it is in your body, before any of the words.

> **GOLD/PAUSE**

Hands, often — shaking, or gone cold. The voice, unreliable. Chest high and tight. A blankness where the next thing was supposed to be. Heat in the face.

> **BLUE/ILLUSTRATION** — a figure's own outline traced a second time, slightly offset. Watching itself.

Now name the state. One word. **Agitated.**

> **GOLD/PAUSE**

Notice what that word doesn't include. It doesn't include how it's going. It doesn't include what they're thinking.

> **GOLD/PAUSE**

Here's the thing that makes this one different. Part of your attention has turned around and is watching you perform. That's not a character flaw and it isn't vanity. It's the state doing something protective, and it's the thing costing you most.

---

### Regulation

Four counts in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six counts out. Longer out than in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

If you're mid-thing, one long out-breath is a complete use of this step. That's not a lesser version.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the centre of your chest.

> **RED/ACTION** — feet flat, pressed into the floor. Offered, not instructed.

Press your feet into the floor.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now something specific to this one. Put your attention on one thing outside you. The material. The instrument. The person you're actually talking to. Anything that isn't you.

> **GOLD/PAUSE** — long

Outward. That's the whole move.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

If you've got a moment, there's one question. If you haven't, skip it and go back in.

> **GOLD/PAUSE** — long

Still here.

> **GOLD/PAUSE**

Then — what does it feel like would happen if it goes badly?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — an outline traced twice, and beneath both a single earlier one.

Not the real consequence. The real one is usually mild, and knowing that has never once helped.

> **GOLD/PAUSE** — long

Underneath, for most people, it isn't the performance. It's being seen falling short in front of people whose opinion has weight — and something in you learned, somewhere, that being seen falling short costs more than falling short does.

> **GOLD/PAUSE** — very long

That's why the watching is the problem rather than the ability. You're not checking whether you can do it. You're checking how it looks while you do it.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

I'm not telling you where that came from. From outside your life nobody knows.

> **GOLD/PAUSE** — long

And the monitoring — that's not sabotage. It's a system trying to catch the fault before the room does, so you're never the last to know.

> **GOLD/PAUSE** — very long

It's on your side. It's just standing in the worst possible place to be useful.

> **GOLD/PAUSE** — long

If something surfaced, put it down before you go back. Whatever it is, it will still be true afterwards, and it's not the thing to carry in.

> **GOLD/PAUSE**

And this, quickly. Nearly everyone doing what you're doing has some version of this running. The ones who look easy are mostly just further from the beginning.

---

### Release

Two things are running.

> **GOLD/PAUSE**

There's the state — hands, voice, chest, the blankness. That turned up on its own.

And there's the monitoring. Watching yourself while you go, checking how it's landing, listening to your own voice, noticing your hands. Running a commentary on a performance while giving it.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

That's the expensive one, and here's why. Attention is finite. Every bit of it pointed at yourself is a bit that isn't on the thing you're doing — so the monitoring makes the performance worse, which gives the monitoring more to report, which takes more attention.

That's the loop. It doesn't end on its own.

> **GOLD/PAUSE** — long

Let the state be here. Shaking hands are not a verdict, and nobody can hear your heart.

Put down the monitoring. Give the attention back to the thing.

> **GOLD/PAUSE** — long

And the question. Not *what's wrong with me that I fall apart* — you're not falling apart, and plenty of people who are extremely good at this feel exactly this.

**What was this for?**

> **GOLD/PAUSE** — long

Watching yourself closely in front of others is a skill, and it was learned somewhere. Knowing exactly how you were landing was useful information once.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

It's still running. It hasn't been told the situation changed.

---

### Rise

Step outside it.

See yourself from across the room — properly outside, not the half-turned watching from a moment ago. Someone in the middle of doing a hard thing, breathing four and six.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Speak to them as *you*.

*You are shaking, and you are doing it anyway.*

> **GOLD/PAUSE**

Both. The second half doesn't wait for the first to stop.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now forward, and small. Not the version where you're relaxed and brilliant — that isn't available on demand and building it would be a lie.

The next bit. Just the next bit. Where your attention goes when you turn back to it, and the first thing you do with it.

> **GOLD/PAUSE** — long

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing already true. Something in the room, not about you.

> **GOLD/PAUSE**

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back. Feet on the floor.

Your hands may still be going. That's allowed, and it was never the target — the target was where your attention was pointed.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are agitated.* Not how it's going.
**One long out-breath** — Feet down. Then attention on one thing outside you.
**Stop watching yourself** — Give the attention back to the thing.
**Next bit only** — *You are shaking, and you are doing it anyway.*

### Back

**Recognition** — Find it in your body first: hands shaking or cold, the voice unreliable, chest high and tight, a blankness where the next thing was. Name the state in one word. Part of your attention has turned around to watch you perform — that isn't vanity, it's the state, and it's what's costing you most.

**Regulation** — Four in, six out. Mid-thing, one long out-breath is a complete use. Feet into the floor. Then put your attention on one thing outside you — the material, the instrument, the person you're talking to. Anything that isn't you. Outward is the whole move.

**Release** — Two things are running. The state, which turned up on its own. And the monitoring — watching yourself while you go, running a commentary on a performance while giving it. Attention is finite, so every bit pointed at you is a bit off the thing, which makes it worse, which gives the monitoring more to report. Put down the monitoring. Give the attention back.

**Rise** — See yourself from a distance — properly outside, not the half-turned watching. *You are shaking, and you are doing it anyway.* Then the next bit only: where your attention goes when you turn back, and the first thing you do with it.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

Performing in front of others produces a mobilised state, and it produces some specific effects: fine motor tremor in the hands, changes to the voice, dry mouth, heat in the face, and disruption to working memory — which is what the blankness is.

That last one matters, because it's the effect people take most personally. Losing your place is not a sign you didn't know the material. It's what happens to short-term recall under mobilisation, and it reverses when the state does.

**Why this protocol is different from the one before it**

t3-01 works on the state before you go in. This one works on what happens during, and the distinguishing feature is the split.

Under this state part of your attention turns around and watches you perform. You hear your own voice. You notice your hands. You track how it's landing, in real time, while continuing.

**Why the split is the actual problem**

Attention is finite. Whatever is pointed at yourself is not pointed at the thing you're doing.

So the monitoring degrades the performance, which gives the monitoring more to report, which pulls more attention across. It's self-feeding, and it doesn't resolve on its own — which is the tell that it's a loop rather than useful vigilance.

That's why the second step here includes something the other protocols don't: attention deliberately placed on one object outside you. Not as a distraction. As the direct reversal of the split.

**Why the exhale is longer than the inhale**

You can't decide your heart rate down. You can decide your breathing, and it's the one reachable control on a system you otherwise can't get at. Lengthening the out-breath relative to the in-breath is what shifts things toward settled.

Mid-performance, a single long out-breath is a real intervention rather than a token one, which is why the protocol says so plainly. A member who believes they need a full session will do nothing at all.

**Why the fourth step distinguishes two kinds of watching**

The monitoring is a half-turn — still inside, looking at yourself with the room's eyes. The fourth step is a full step outside, and the difference is the point. One splits your attention; the other settles you and hands it back.

The forward move is deliberately the next small piece rather than the rest of it. Rehearsing being relaxed and brilliant is rehearsing something you can't produce on demand, and your body won't take it.


---

### What this track works on

Everything here works on you, not on your output.

That isn't modesty about what it can do. It's the actual mechanism. A narrowed system makes worse calls, hears less in a room, and takes longer to start things — so settling it changes what you're able to bring. What it won't do is set you a target, measure what you produced, or tell you that you should be getting more done.

Nothing on this platform will ask you how productive you were. There's no version of a bad week here.

The reason is simple enough. A tool that measures your output becomes one more thing to fail at, and the people who most need this arrive on the days they're already failing at everything else.

---

### What we rest on

**Cardiac coherence — HeartMath** · *peer-reviewed* · supplies Regulation and the count

At roughly six breath cycles a minute, heart rhythm and breath settle into a single smooth wave rather than two competing ones, close to a rhythm the body's blood-pressure regulation already runs at. Four in, six out lands near that rate. The uneven ratio is the mechanism. *Here it's what one long out-breath between two parts is doing, and why that counts as a complete use.*

*The finding is used here; the wider programme is not. There is no measurement of coherence anywhere on this platform and no score attached to any breath.*

**Polyvagal Theory — Stephen Porges** · *peer-reviewed* · supplies Recognition and the three state labels

Threat detection runs ahead of thought. The body reads a situation and moves before your thinking catches up. Porges describes three broad conditions: settled and socially available, mobilised for action, and shut down. Agitated, Unsteady and Numb are the member-facing names for those three. *Here it accounts for the tremor, the voice and the blankness — all effects of mobilisation rather than signs about your ability.*

*The anatomical premises are contested: a 2026 evaluation in* Clinical Neuropsychiatry *challenged them, with Porges replying in the same issue. The state distinctions are what this platform uses, and they hold independently of that dispute.*

**Where the reading is yours** — this explains the machinery. How it went, whether you're suited to this, and what any of it means about you are readings that belong to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**One long out-breath.** In four, out six, once. The only item here that works mid-performance, and it works.

**Attention on one object.** Pick something outside you and rest attention there for a few seconds. The direct reversal of the split, and it takes no time at all.

**Warm the hands.** Under a tap, around a cup, in pockets. Cold hands are part of the state and they make the tremor more noticeable.

**Feet into the floor.** Press down, feel it push back. Invisible while seated.

**Hum, or speak one sentence aloud.** Somewhere private, before. A voice already in use arrives steadier.

**Shake the hands out.** Deliberately, for a few seconds, before you go on. Giving the tremor somewhere to go beats holding it still.

**Jaw apart, shoulders down.** Both hold here and both creep back.

*If you can practise the thing itself in front of one person first, do that. The state is smaller the second time it meets a room.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with the state that arrives while you're performing, using breath, attention and observation. It doesn't touch your ability, and it isn't a substitute for knowing the material.

**Pacing**

Once through is a complete use. Mid-performance, one long out-breath and one outward point of attention is also a complete use. If four and six is a stretch, shorten both and keep the ratio uneven.

**What people commonly notice**

The tremor continuing after the state settles. That's ordinary and it lags.

The monitoring restarting immediately, sometimes about the protocol itself — whether you're doing it right. That's the loop finding a new subject. Note it and go back to the outward object.

Feeling steadier without feeling confident. That's the expected result.

**When to slow down**

If focusing on your breathing makes things worse — and mid-performance it can, because it points attention inward — drop the breath and use only the outward object. That's the more important half of this step anyway.

**When something else is going on**

If the tremor, the voice or the blankness are severe enough that you're avoiding things you want to do, if the state is arriving well in advance and staying, if you're using something to get through performances, or if you're being affected in ways that could put your work or licence at risk, that's worth taking to a doctor. Some of this responds to treatment, and finding out is not an admission of anything.

**A note on managing it with something**

Using alcohol or medication not prescribed to you to get through performances is common and it's worth being honest with yourself about. It works, briefly, and it builds a dependency on being managed rather than being able. If that's where you are, a doctor is the right conversation and it's a very ordinary one for them.

**Alongside other support**

If you're with a therapist, doctor, counsellor or coach, this sits alongside that and replaces nothing.

---

## 06 · Disclosure & Support
*A script for someone close.*

> **This one is for outside work.** A friend, a partner, someone who isn't in the building. The workplace conversation is a different act with different consequences — that's **Raising It**, the next resource.

Take these exactly, or change every word.

**Saying it**
> "I get a thing when I'm performing where my body goes and part of my head turns round to watch me do it. It isn't nerves exactly. I'd rather you knew than thought I was underprepared."

**Describing what it's actually like**

> "Hands go, voice goes unreliable, and sometimes I blank — the next thing just isn't there. That last one isn't me not knowing it. It's what happens to memory when the body is like that."

> "The hardest part to explain is being split. I'm doing it and watching myself do it at the same time, and the watching makes the doing worse."

**How to tell it's coming**

> "I go quiet and stop making eye contact. I check things repeatedly. My hands get cold."

**What helps**

> "Afterwards, tell me one specific thing that actually happened. 'The bit about the numbers landed' works. 'You were great' doesn't — it goes straight into the loop and gets picked apart."

> "Before, treat it as a normal day. Encouragement raises the stakes."

**What doesn't**

> "Watching me to see how I'm doing. I can feel it, and it feeds the exact thing I'm trying to stop."

> "Telling me nobody noticed. Sometimes they did, and then I can't trust the next thing you say."

**If they ask what you're doing about it**

> "There's a method I run. I name it as a state rather than as a verdict on how it's going, take one long out-breath, and put my attention on something outside me — because the problem is that half of it has turned round to watch me. Then I stop the watching and give the attention back to the thing. Then just the next bit."

> "It doesn't stop my hands. It stops me spending the performance on myself."

*Tell one person. This is one of the states people hide hardest, because the hiding is part of performing.*

---

## 07 · Raising It
*Who to tell, how much, and what to ask for.*

Telling a friend costs you nothing. Telling someone at work may go on a record, may change what you're trusted with, and can't be taken back. Different audience, different calculus, different words.

**First: you may not have to say anything.**

Not disclosing is a legitimate choice and often the right one. Nothing here pushes you toward telling anyone. What follows is for if you've decided to, or if something needs to change and saying nothing is what's costing you.

**Who you tell changes what happens**

These are not interchangeable, and most people don't know the difference.

**Your manager** — can change the work. Cannot usually keep it confidential, and shouldn't be expected to.

**HR** — exists to protect the organisation. That doesn't make them hostile, and it does mean they are not neutral and are not your representative. Useful for process; not the place to think out loud.

**Occupational health** — assesses fitness for work and recommends adjustments. Reports to the employer but usually only on what you consent to release. Frequently the most useful route available and almost nobody uses it.

**A union rep** — represents you specifically. If you have access, use it before HR rather than after.

**A colleague** — no power to change anything, and the only one who can be told without it becoming a process.

**Your GP** — outside the building entirely, and the only one who can put something in writing that an employer has to take seriously.

**How much to say**

*I'm dealing with something and it's affecting my sleep* is a different act from naming a condition. Both are honest. The first is almost always enough for a workplace conversation, and it's the version you can't be held to later.

Say what's affecting the work. You are not obliged to explain why.

**Make it a request, not a confession**

This is the move that works at work, and it's the one most people miss.

A specific ask travels. It's actionable, it's answerable, and it puts the conversation on ground the other person knows how to stand on.

An explanation of a state invites a response nobody has been trained to give, and it frequently ends in sympathy and no change.

> **The ask, on this protocol:** *"Could I have the questions in advance? I'm better with the material than I am on my feet, and you'll get more out of me."*

> Or: *"Can we do this seated rather than presenting? Same content."*

Neither discloses anything. Both are framed around what the other person gets, which is what makes them easy to grant.

**One further note.** If the physical side — a tremor, a voice, a blank — is affecting work you can't avoid, occupational health is the right route rather than your manager. Some of it responds to treatment, and that conversation belongs with a doctor.

**Put it in writing afterwards**

Verbal is deniable in both directions. If you've asked for something and it matters, follow the conversation with a short email — *thanks for the chat, just confirming we agreed X.* No tone, no argument, no explanation.

That isn't building a case. It's a record of what was agreed, and it protects both of you.

**Two things this resource can't do**

It isn't legal advice. Employment rights differ enormously by country and by contract, and where something might be unlawful, that's a conversation with a union or an employment lawyer rather than with a platform.

And it makes no promise about how it will be received. That varies more than anything else on this track, which is why nothing here tells you to disclose.

---

## 08 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it is never measured against anything you wrote before. Because it is only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

If this is a work device, remember it is stored on the device — and a work device is not always yours.

Keep anything you may need factually — dates, what was said, who was present — somewhere separate from this. This is for your state. That is for the record, and it belongs off a work device.

Any of these, or none.

- Where did it sit in your body?
- What did the monitoring say while you were going? Write the actual commentary.
- How much of your attention was on you, and how much on the thing?
- Did anyone mention any of it afterwards?
- *What was this for* — what turned up, without needing to answer it?
- What did you say to yourself from across the room?
- What was the outward object you used? Did it hold?
- What actually happened, plainly, without the verdict attached?
- What did you write here last time? Read it back.

That fourth prompt earns its place here. The monitoring produces a confident account of how visible it all was, and your own record of what anyone actually said is the only evidence you have that isn't generated by the state.

---

## 09 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half exits into a room full of people, and this is one of the few protocols where the exterior is mostly *not* what the member fears.

**The specific blind spot here, and it runs the other way** — most people watching notice far less than the monitoring reports. A tremor that feels enormous from inside is frequently invisible from six feet away. A pause that felt like a collapse read as a pause. This is the one place on the platform where the blind spot works in your favour, and it's worth checking rather than assuming.

**What does land** — the withdrawal afterwards. Leaving quickly, not staying for the conversation, deflecting when someone says something. From inside that's not wanting to discuss it. From outside it's someone who won't be thanked, and people stop offering.

**The second one** — the deflection itself. *"It was a disaster, sorry about the middle bit."* From inside it's honesty. From outside it asks them to talk you out of your own account before they can say what they thought, which means you never find out what they thought.

**Their earlier information** — the people who've watched you do this more than once have a record you don't. Worth asking directly: *what did you actually see?* And then not arguing with the answer.

**Naming the act, not the character** — *"I left straight after and didn't speak to anyone who came"* is ownership. *"I'm hopeless at this"* is not; it names nothing, it's the monitoring again, and it asks them to argue with it.

**No because.** The state is a real reason and it doesn't belong in the sentence.

**No self-attack.** On this protocol self-attack is the state's own material, said out loud. An apology built from it hands the other person the job of reassuring you — which is the loop, running through someone else.

**Describe what was observable, ask about the rest.** *"I got out fast afterwards and didn't talk to you. I'm not going to tell you how it looked — I'd rather you told me."* Then let them answer without correcting it.

**The checkable change** — this repairs by staying rather than by performing better. *"I'm going to stay afterwards and let people say whatever they're going to say"* is small, specific and observable.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. And here specifically: if someone tells you it went better than it felt, that is data. It is not them being kind.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Watch yourself while you do it. Catch the fault first.

Half the attention turns around and monitors the performance while it's happening. How's the voice, how are the hands, how is this landing. Get to the problem before the room does.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Being seen falling short in front of people whose opinion has weight.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the performances I got through and can't remember*, or *the things I stopped doing because of how the watching felt.*

---

**What it should be attending to instead**

It isn't feeling relaxed. That's not available mid-performance and never was.

What's available is a different instruction about **which way attention faces**.

The old one points it inward, which takes it off the thing you're doing and makes the performance worse, which gives the monitoring more to report. The successor points it out — at the material, the instrument, the person actually in front of them.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *attention on the thing, not on how the thing is going.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *looks at the material rather than the room. Answers the question rather than assessing the answer. Doesn't leave straight afterwards.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*One long out-breath. Attention onto one thing outside them. Back to the next bit only.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*

*If this is a work device, remember it is stored on the device — and a work device is not always yours.*
