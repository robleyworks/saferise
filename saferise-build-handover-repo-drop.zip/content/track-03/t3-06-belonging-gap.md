# t3-06 · The Belonging Gap Protocol

**Label:** Stand · **State:** Unsteady · **Frameworks:** Porges, Jung · **extras:** `['advisory']`
**Resources: 10**

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Turn at four seconds.
> **VOICE** — plain, even, matter-of-fact. Never warm about belonging. Warmth here would be the thing the state is watching for and would read as pity.

Everyone else seems to know how this works.

> **GOLD/PAUSE** — long

The references, the shorthand, what's funny, how much to say. There's a way of being in that room and you're doing a version of it.

> **GOLD/PAUSE**

Nothing here is going to tell you that you belong. I don't know whether you do, and neither does anyone who'd say it.

---

### Recognition

Where does it sit?

> **GOLD/PAUSE** — long

Chest, unsteady rather than tight. A watchfulness behind the eyes. Something in the throat just before you say something in a group.

> **BLUE/ILLUSTRATION** — a set of forms, evenly spaced. One of them a slightly different weight.

One word. **Unsteady.**

> **GOLD/PAUSE**

That's about how you're standing. It isn't a verdict on whether you fit, and it isn't a verdict on the room either.

> **GOLD/PAUSE** — long

Because there are two things here and they've been welded together. There's a reading — *I'm not one of them.* And there's a state, running in your chest.

> **GOLD/PAUSE**

The reading might be right. Some rooms are closed and some are worse than closed. We're not touching that today. The state is the half that answers to anything.

---

### Regulation

Four counts in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six out. Longer out than in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the middle of your chest.

> **RED/ACTION** — feet flat, pressed into the floor. Offered, not instructed.

Press your feet into the floor. Whatever the room is, the floor is holding you the same as everyone else's.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Let the throat open. Jaw apart, tongue down.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

### Release

Two things.

> **GOLD/PAUSE**

There's the gap, which may be entirely real.

And there's the editing.

> **GOLD/PAUSE** — long

Adjusting how you speak before you speak. Holding back the reference nobody in this room will get. Deciding which version of yourself is admissible here, in the half-second before it goes out.

> **GOLD/PAUSE** — very long

That's running constantly. It's been running so long you'd struggle to say what the unedited version sounds like.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And here's the cost, and it's the one nobody mentions. The edited version is the one they're forming a view of. It's careful, it's appropriate, and it's less interesting than you are.

> **GOLD/PAUSE** — long

Keep the reading. Put down the editing — for the next few minutes, in a room with nobody in it.

> **GOLD/PAUSE** — very long

And the question. Not *what's wrong with me that I can't just relax around people* —

**What was this for?**

> **GOLD/PAUSE** — long

Assembling a version of yourself that fits a room is a skill. It was learned somewhere, and it was learned because somewhere, being the unedited version had a cost.

> **GOLD/PAUSE** — long

So — what's underneath it? What did you learn about what happens when you're the odd one?

> **GOLD/PAUSE** — very long

Not mine to answer. If something came, it's yours. If nothing did, that's ordinary.

> **GOLD/PAUSE** — long

And the harder one. You might not want to put it down.

> **GOLD/PAUSE** — very long

That's fair. It works. It has kept you employed, and it has kept you comfortable in rooms where the unedited version might not have been.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Nobody's asking you to stop. You'd be right to refuse, and there are rooms where it's the correct move. Only to notice what it costs to run it all day, and that the version being assessed isn't the whole of you.

> **GOLD/PAUSE** — very long

---

One further, if there's room.

> **GOLD/PAUSE**

One thing first. If you're being excluded, talked over, or treated differently because of who you are — that's real, it's theirs, and nothing here hands you a share of it. That needs people with authority, not this.

> **GOLD/PAUSE** — long

Assuming the room is indifferent rather than closed: what does it feel like would happen if the unedited version turned up?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — evenly spaced forms with one of different weight, and beneath it an older mark of the same shape.

Not being disliked. Something more specific than that.

> **GOLD/PAUSE** — long

For a lot of people it's being placed. Filed as the one who doesn't quite fit, permanently, by people who won't ever say it out loud.

> **GOLD/PAUSE** — very long

And under that, often: *I've been somewhere like this before, and I know how it goes.*

> **GOLD/PAUSE** — very long

I'm not telling you that's yours. From outside your life nobody knows.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

And the editing — what's it protecting?

> **GOLD/PAUSE** — very long

Your place in the room. It has kept you employed, and it has kept you comfortable in rooms where the unedited version might not have been.

> **GOLD/PAUSE**

It works. That's exactly why it's expensive.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before we move.

> **GOLD/PAUSE**

Something will arrive behind that — usually *everyone else manages to just be themselves.*

> **GOLD/PAUSE** — very long

Put it down. If what's underneath is being placed as the one who doesn't fit, then editing is a reasonable response to it, and struggling is the right size.

> **GOLD/PAUSE** — long

And something in you looked at the thing you've been arranging not to look at.

> **GOLD/PAUSE** — very long

One more, simply true rather than comforting. Almost every room has someone in it doing exactly this, and none of them are telling each other.

---

### Rise

Step outside it.

Someone at a desk, feet on the floor, breathing four and six.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Speak to them as *you*.

*You might not fit here. You're still the one doing the work.*

> **GOLD/PAUSE** — long

Both of those can be true at once, and one of them is entirely within your hands.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now — one thing, and make it small.

Not being yourself, whatever that means. One specific unedited thing. The actual opinion rather than the acceptable version of it. The reference you'd normally swallow. Saying you don't know what something means.

> **GOLD/PAUSE** — very long

Small enough that you'll do it tomorrow, in exactly the room you're in.

> **GOLD/PAUSE**

The editing was installed. This one you picked.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing already yours. Something the room has no view on.

> **GOLD/PAUSE**

Now put it down. All of it.

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back. Feet on the floor.

Nothing about the room has changed and you may still not fit it.

What's changed is that you've had a few minutes not maintaining a version, and you know what that costs now.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are unsteady.* Not a verdict on you or the room.
**Breathe it** — Four in, six out. Feet down, throat open.
**Stop editing** — Just for now. Nobody's in the room.
**One unedited thing** — The actual opinion. The reference. *I don't know.*

### Back

**Recognition** — Find it in your body: chest unsteady, a watchfulness behind the eyes, the throat tightening before you speak in a group. Name the state in one word. Two things are welded together — a reading, *I'm not one of them*, and a state in your chest. The reading might be right. The state is the half that answers to anything.

**Regulation** — Four in, six out. Attention in the centre of your chest. Feet into the floor — whatever the room is, the floor holds you the same as everyone else's. Jaw apart, throat open.

**Release** — Two things. The gap, which may be entirely real. And the editing — adjusting how you speak before you speak, holding back the reference nobody here will get, deciding which version of you is admissible. It runs constantly. And the edited version is the one they're forming a view of: careful, appropriate, less interesting than you are. Keep the reading. Put down the editing.

**Rise** — See yourself from a distance. *You might not fit here. You're still the one doing the work.* Then one specific unedited thing — the actual opinion, the reference you'd swallow, saying you don't know what something means. Small enough to do tomorrow, in exactly the room you're in.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

The first of the three conditions Porges describes is *safe and socially available* — a body settled enough to be in company without guarding. Belonging is that system reading a room and returning a verdict, continuously, below the level of decision.

In the body: unsteadiness through the chest, a raised watchfulness, tension in the throat before speaking in a group, and a scanning quality to attention in rooms where the norms aren't yours.

**Why it isn't imposter feeling**

They're routinely confused and they are different states.

Imposter is a verdict about **competence** — *I'm not good enough to be here* — and its loop is retrospective: replaying what you already said, evaluating what it revealed.

This is a verdict about **kind** — *I'm not one of you* — and its loop is prospective: filtering what you're about to say, before it goes out.

People are frequently confident in their work and eat lunch alone. People are frequently well-liked and privately certain they're a fraud. Different mechanisms, and the protocols don't substitute.

**Why the state and the reading come apart**

The reading may be accurate. Rooms can be closed, and some are worse than closed.

But an accurate reading and a settled body are separate objects, and while they're fused, settling feels like accepting the exclusion. Splitting them concedes nothing — the reading is exactly as intact afterwards, and it's easier to assess from a system that isn't scanning.

**Why the exhale is longer, and why the feet**

You can't decide a state down. You can decide your breathing, and it's the one reachable control. Lengthening the out-breath relative to the in-breath shifts things toward settled.

The feet do something specific. This state's signature is unsteadiness in a room, and the floor is the one thing in that room that's holding you on identical terms to everyone else in it.

**Why Release goes after the editing**

There's the gap, and there's the maintenance of a version.

Two different costs. The gap is a condition. The editing is continuous work: adjusting register, filtering references, deciding in the half-second before speaking which version is admissible here. It runs all day, in every exchange, and after long enough people can't say what the unedited version sounds like.

**The cost that nobody names.** The edited version is the one being assessed. It's careful, appropriate, and less interesting than the person producing it — and views are being formed of it, in rooms where being memorable is most of what gets you offered things.

**Why the persona is the Jung reference**

The version assembled to be acceptable in a given room is precisely what Jung called the persona. It isn't a fault and it isn't dispensable — everyone has one, and a person with none would be unemployable. What's interpretive here is the observation that the more it costs to maintain, the less of you is available to the room. Offered as a lens rather than a finding.

**Why nothing here tells you that you belong**

It would be reassurance, it would be an outcome claim, and on this subject it's frequently false. The platform doesn't know your situation and can't see your room.

What it can say is that maintaining an edited self is expensive whether or not the reading is accurate — which is true either way, and workable either way.

---

> **SHARED BLOCK** — insert *What this track works on* here, verbatim from `SHARED-t3-what-this-track-works-on.md`. Identical on all ten Track 03 protocols. Do not paraphrase or re-cut per protocol.

---

### What we rest on

**Polyvagal Theory — Stephen Porges** · *peer-reviewed* · supplies Recognition and the three state labels

Threat detection runs ahead of thought. The body reads a situation and moves before your thinking catches up. Porges describes three broad conditions: settled and socially available, mobilised for action, and shut down. Agitated, Unsteady and Numb are the member-facing names for those three. *This is the one protocol where the first of those conditions is the subject rather than the background — belonging is that system reading a room and returning a verdict.*

*The anatomical premises are contested: a 2026 evaluation in* Clinical Neuropsychiatry *challenged them, with Porges replying in the same issue. The state distinctions are what this platform uses, and they hold independently of that dispute.*

**Shadow & individuation — C. G. Jung** · *interpretive* · informs Release

The persona is the version of yourself assembled to be acceptable in a given setting. Everyone has one; it isn't a fault. What Jung observed is that the further it sits from the rest of you, the more it costs to hold — and the material that isn't admissible doesn't disappear, it goes unattended. *Here it's the editing, and the cost of running it all day.*

*Offered as a lens rather than a finding, with no controlled evidence behind it. What it shows you is yours to read.*

**Where the reading is yours** — this explains the machinery. Whether you fit, whether the room is closed, and whether to stay are readings that belong entirely to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Feet into the floor.** Press down, feel it push back. Invisible in any meeting, and the floor is holding you the same as it's holding everyone else in the room.

**Long exhale, no ceremony.** Four in, six out, three or four cycles.

**Jaw apart, throat open.** Both hold here, and both are what the editing runs through.

**Take up your actual amount of room.** Not expanding — just stopping the small contraction. Back against the chair, elbows off your sides.

**Say one thing early.** In any group, contribute in the first few minutes. The editing gets heavier the longer you go without speaking.

**Ask what something means.** Once, out loud, when you don't know a reference or an acronym. This is the single highest-value item on the list and the hardest, and the response is almost never what the state predicts.

*Have one exchange a day with someone outside the room — a friend, a former colleague — where nothing is edited. It's a reference point for what the unedited version sounds like.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with the state that arrives in a room where you're not sure you belong, using breath, attention and observation. It doesn't tell you whether you fit, doesn't assess the room, and doesn't ask you to be more yourself.

**Pacing**

Once through is a complete use. Before an occasion, or after one, both work.

**What people commonly notice**

Difficulty finding the unedited version. That isn't a failure — it's how long the editing has been running.

Grief, sometimes, which surprises people. Noticing what it has cost to be a version of yourself for years can arrive as a loss.

Resistance at Release, because putting the editing down feels professionally reckless. That's addressed in the third step and it's worth reading rather than pushing through.

**When to slow down**

If Release opens something much larger — an earlier room, a family, a school — you can stop there and come back to the breath. This protocol surfaces older material more often than its surface suggests.

If the session turns into an inventory of every room you've never fitted, stop. That's the state, running inside the step designed to interrupt it.

**Where the reading is accurate, and this is the wrong tool**

Sometimes *I don't fit here* is not a state to be managed. It's an accurate report of how you're being treated.

If you're excluded from things you need to do your job, talked over consistently, having your work attributed elsewhere, or treated differently because of who you are — that is not a belonging state and no amount of regulation addresses it. That's exclusion, and where it tracks a protected characteristic it may be discrimination.

That needs bodies with authority: HR, a union, a regulator, an employment lawyer. Get advice earlier than feels necessary, and keep your own records — dated, factual, and stored somewhere that isn't a work device.

Nothing on this platform can tell you which of the two you're in. What it can do is settle a system that's better at telling them apart when it isn't scanning.

**When a person in the room is the right tool**

Contact someone — a doctor, a helpline in your country, or a person you trust — if you're dreading work in a way you can't shake, if this is costing you sleep across weeks, if you're using something to get through the day, if you've become isolated outside work as well, or if you're having thoughts of harming yourself.

**Alongside other support**

If you're with a therapist, doctor, counsellor or coach, this sits alongside that and replaces nothing.

---

## 06 · Proximity Guide
*How close to stay.*

A team is exactly the kind of ongoing source this resource exists for — and unlike most, you can't leave the room for the working day.

Three tiers. Which one yours belongs in is your read, on information nobody here has.

**Worth staying engaged with**

Where the difference is real but nothing is being done with it. Where people are indifferent rather than exclusionary — busy, established, and not thinking about it. Where one or two individuals respond when you engage them directly.

Distance isn't the tool here; it's what the state is asking for and it would cost you the room. Regulation, plus a smaller amount of editing, is.

**Worth reducing the surface area of**

Where the setting reliably produces the state and nothing has shifted over a long period. Where you've noticed you're a smaller version of yourself in that building than anywhere else.

Reduction is specific and professional: occasions you decline, a channel you use less, lunch taken elsewhere, one relationship you invest in rather than the whole group, and — importantly — sources of belonging outside that room. A person whose only social context is a team they don't fit is carrying something no protocol will move.

There's also the surplus worth attending to. Where your reaction to an ordinary exclusion is much larger than the exclusion, the excess is carrying something. A lens rather than a finding.

**Past what self-regulation is for**

Where you're being excluded from what you need to do your job. Where you're talked over as a matter of routine. Where your work is attributed to others. Where you're treated differently because of your race, sex, disability, age, religion, sexuality, class or background.

That is not a belonging gap. It's exclusion, and it may be unlawful. Treating it as a state to be regulated converts a situation needing institutions into a private failure of fit — which is the reading that keeps people in these rooms for years.

What it needs is HR, a union, a regulator, or an employment lawyer, and it needs them earlier than most people ask.

**Using this**

Notice the tier. Then notice whether it's the tier you'd assign if someone else described the same room to you.

---

## 07 · Disclosure & Support
*A script for someone close.*

> **This one is for outside work.** A friend, a partner, someone who isn't in the building. The workplace conversation is a different act with different consequences — that's **Raising It**, the next resource.

Best said to someone outside the room. Take these exactly, or change every word.

**Saying it**
> "I've been in that job a while and I still feel like a visitor in it. It isn't about the work. I'd rather say it out loud to one person than keep managing it."

**Describing what it's actually like**

> "It's physical. Chest unsteady, watchful, and my throat tightens just before I say anything in a group."

> "The part that's hard to explain is the editing. I'm adjusting how I talk before I talk — what I reference, how much I say, which version of me is allowed in that room. All day. It's exhausting and it's invisible."

**How to tell it's coming**

> "I go quiet in groups but I'm fine one-to-one. I laugh slightly late. I stop mentioning anything about my life outside work."

**What helps**

> "Don't tell me they probably all feel like that. Maybe they do. It doesn't touch it, and it makes the specific thing generic."

> "Let me be the unedited version with you. That's genuinely the thing — having somewhere it isn't running is worth more than any advice."

**What doesn't**

> "Telling me to just be myself. That's the whole difficulty compressed into three words."

> "Asking why I don't leave. I might. It's a bigger question than a bad week and I'd rather answer it slowly."

**If you're saying it to someone in the room**
> "Can I say something slightly awkward? I've never quite worked out how things run here and I've been guessing. If there's stuff I should know, I'd rather ask than keep approximating."

**If they ask what you're doing about it**

> "There's a method I run. I name it as a state rather than as a verdict about whether I fit, do a breathing pattern with my feet pressed into the floor, and stop the editing for a few minutes — which is when I notice how much work it's been. Then one small unedited thing for the next day."

*Tell one person outside the building. A person whose only social context is a team they don't fit is carrying something no practice will move.*

---

## 08 · Raising It
*Who to tell, how much, and what to ask for.*

Telling a friend costs you nothing. Telling someone at work may go on a record, may change what you're trusted with, and can't be taken back. Different audience, different calculus, different words.

**First: you may not have to say anything.**

Not disclosing is a legitimate choice and often the right one. Nothing here pushes you toward telling anyone. What follows is for if you've decided to, or if something needs to change and saying nothing is what's costing you.

**Who you tell changes what happens**

These are not interchangeable, and most people don't know the difference.

**Your manager** — can change the work. Cannot usually keep it confidential, and shouldn't be expected to.

**HR** — exists to protect the organisation. That doesn't make them hostile, and it does mean they are not neutral and are not your representative. Useful for process; not the place to think out loud.

**Occupational health** — assesses fitness for work and recommends adjustments. Reports to the employer but usually only on what you consent to release. Frequently the most useful route available and almost nobody uses it.

**A union rep** — represents you specifically. If you have access, use it before HR rather than after.

**A colleague** — no power to change anything, and the only one who can be told without it becoming a process.

**Your GP** — outside the building entirely, and the only one who can put something in writing that an employer has to take seriously.

**One addition on this protocol.** If you're being excluded from what you need to do your job, or treated differently because of who you are, this stops being a disclosure question. Union or an employment lawyer first, and keep a dated factual record from the start. Raising it with the people doing it rarely helps and sometimes escalates.

**How much to say**

*I'm dealing with something and it's affecting my sleep* is a different act from naming a condition. Both are honest. The first is almost always enough for a workplace conversation, and it's the version you can't be held to later.

Say what's affecting the work. You are not obliged to explain why.

**Make it a request, not a confession**

This is the move that works at work, and it's the one most people miss.

A specific ask travels. It's actionable, it's answerable, and it puts the conversation on ground the other person knows how to stand on.

An explanation of a state invites a response nobody has been trained to give, and it frequently ends in sympathy and no change.

> **The ask, on this protocol:** *"I've come from a different background to most people here and I've been guessing at how things run. Is there anything I should know that nobody's got round to telling me?"*

> Or: *"Could I get an intro to whoever handles X? I've not built up the network that most people here arrived with."*

Both are askable without disclosing a state, and both name the actual gap — information and access — rather than the feeling about it.

**Put it in writing afterwards**

Verbal is deniable in both directions. If you've asked for something and it matters, follow the conversation with a short email — *thanks for the chat, just confirming we agreed X.* No tone, no argument, no explanation.

That isn't building a case. It's a record of what was agreed, and it protects both of you.

**Two things this resource can't do**

It isn't legal advice. Employment rights differ enormously by country and by contract, and where something might be unlawful, that's a conversation with a union or an employment lawyer rather than with a platform.

And it makes no promise about how it will be received. That varies more than anything else on this track, which is why nothing here tells you to disclose.

---

## 09 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

If this is a work device, remember it is stored on the device — and a work device is not always yours.

Keep anything you may need factually — dates, what was said, who was present — somewhere separate from this. This is for your state. That is for the record, and it belongs off a work device.

Any of these, or none.

- Where did it sit in your body?
- What did you edit today? Write the thing you didn't say.
- What would the unedited version have been?
- What actually happened in the room? Write it as events, not as a reading.
- *What was this for* — what turned up, without needing to answer it?
- What did you say to yourself from across the room?
- What was the one unedited thing? Did you do it? What happened?
- Where else in your life is this running? Where isn't it?
- What did you write here last time? Read it back.

That last-but-one is the useful one here. A room where the editing doesn't run is evidence about the room rather than about you.

---

## 10 · Accountability & Empathy
*What it does outside you.*

⚠ **Read this first.** This resource asks you to look at your own conduct. That's the right work where the room is indifferent rather than exclusionary. If you're being excluded, talked over, or treated differently because of who you are, looking harder at yourself is the mechanism that keeps people in those rooms — the Proximity Guide's third tier is the resource for that.

Assuming that isn't where you are:

The protocol trains the interior half of the state. The other half is happening in a room full of people, all day.

**The specific blind spot here, and it's the consequential one** — **the edited version is the one being assessed.** Careful, appropriate, and consistently less interesting than you are. Views are being formed of it in a setting where being memorable is most of what gets you offered things.

**The second one** — withdrawal reads as disinterest. Not going to the thing, leaving early, not asking about anyone's weekend. From inside it's conserving yourself. From outside it's someone who doesn't want to be there, and people stop including those they've concluded don't want including.

**The third one** — the watchfulness is visible. Scanning a room registers as reserve, and reserve in a group registers as judgement. People frequently conclude that the person who feels excluded is the one holding themselves apart, and from where they stand there's no evidence against it.

**Their earlier information** — worth asking someone in the room you half-trust: *what was I like when I started?* The answer is often *hard to read*, which is not what the state predicts.

**Naming the act, not the character** — *"I've turned down every social thing for six months"* is ownership. *"I don't fit in"* is not; it's the reading, it names no act, and it invites them to reassure you.

**No because.** The gap is a real reason and it doesn't belong in the sentence.

**No self-attack.** *"I'm hard work, I know I'm not really one of you"* asks the room to argue you in, which is more editing with the direction reversed.

**Describe what was observable, ask about the rest.** *"I've been quiet and I've said no to most things. I'm not going to tell you how that's come across — I'd rather hear it."*

**The checkable change** — this repairs by turning up rather than by feeling included. *"I'm going to come to the thing and stay for the first half"* is small, specific and observable, and doesn't require you to feel any different.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. And if the room is genuinely closed, none of this applies. You are not responsible for making yourself acceptable to people who have decided you aren't.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Edit. Decide what's admissible before it goes out.

Adjust the register. Hold back the reference nobody here will get. Work out which version of you is allowed in this room, in the half-second before you speak. Every time.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Being placed. Filed as the one who doesn't quite fit, permanently, by people who'll never say it.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *how tired I am after an ordinary day*, or *the fact that they've never met the version of me my friends know.*

---

**What it should be attending to instead**

It isn't being yourself, whatever that means, and it isn't stopping the editing. There are rooms where editing is the correct move.

What's available is a different instruction about **how much**.

The old one edits everything, at every turn. The successor lets one unedited thing through a day and watches what actually happens.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *one unedited thing a day.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *says the actual opinion rather than the acceptable version. Asks what a reference means. Mentions something from their own life.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Feet on the floor. Says the thing before the edit finishes. Doesn't watch how it landed for the rest of the meeting.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*

*If this is a work device, remember it is stored on the device — and a work device is not always yours.*
