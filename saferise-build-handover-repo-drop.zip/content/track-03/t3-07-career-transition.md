# t3-07 · The Career Transition Protocol

**Label:** Cross · **State:** Unsteady · **Frameworks:** Jung, Watts · **extras:** `[]`
**Resources: 9**

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Turn at four seconds.
> **VOICE** — level, unhurried, entirely without opinion. Someone who has watched a lot of people decide things and has no stake in this one.

You don't know whether to stay.

> **GOLD/PAUSE** — long

Or you've decided and you're not sure, which is the same thing in a different coat.

> **GOLD/PAUSE**

I'm not going to tell you. I don't know your situation, I can't see your position, and anyone offering you an answer from outside it is guessing.

> **GOLD/PAUSE**

What we can do is get you into a state that decides differently.

---

### Recognition

Where is it sitting?

> **GOLD/PAUSE** — long

Chest, unsteady rather than tight. Stomach. Something that arrives on a Sunday evening and again on Monday morning. Sleep that goes light rather than short.

> **BLUE/ILLUSTRATION** — a threshold. Ground on both sides of it, drawn the same.

One word. **Unsteady.**

> **GOLD/PAUSE**

And notice what that word doesn't include. It doesn't include the decision. It doesn't say the job is wrong, or that you should have gone last year.

> **GOLD/PAUSE** — long

You described a state, and something in you did the describing. Those are two different things — and the second one is what makes any of the rest of this possible.

---

### Regulation

Four counts in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six out. Longer out than in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the middle of your chest.

> **RED/ACTION** — feet flat, pressed into the floor. Offered, not instructed.

Press your feet into the floor. You're standing somewhere, whatever else is unresolved.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

### Release

Two things are running.

> **GOLD/PAUSE**

There's the situation. Real, with real constraints — money, people, timing, whatever is genuinely fixed about it.

And there's the running of versions.

> **GOLD/PAUSE** — long

The one where you go and it works. The one where you go and it doesn't. The one where you stay and it gets better. The one where you stay and you're still here in three years.

> **GOLD/PAUSE**

You've run all four this week. Some of them several times.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

None of them resolve, because none of them can. They're all forecasts, and no amount of running one produces information you didn't have when you started.

> **GOLD/PAUSE** — long

The situation stays. Put down the running.

> **GOLD/PAUSE** — long

And the question — not *why can't I just make a decision.* You're not indecisive. You're holding something that genuinely has no obvious answer, which is a different problem.

**What was this for?**

> **GOLD/PAUSE** — long

Something in you keeps checking whether this is right. That's a system that has decided the stakes are high and that being wrong about placement has a cost.

> **GOLD/PAUSE**

It's not malfunctioning. It's just been left running on a question that can't be settled by more checking.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

---

### Rise

Step outside it.

Someone at a desk, feet on the floor, holding something unresolved.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Speak to them as *you*.

*You might have until Friday. You might have a year. Either way, this is the state you'd be deciding from.*

> **GOLD/PAUSE** — long

And if there's no deadline on it — notice that not deciding is a decision too, taken daily, by default.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

---

Now something bigger than today, and it's the reason this protocol exists.

> **GOLD/PAUSE**

Here's what's worth knowing about how a decision like this gets made.

A system in this state doesn't decide from the situation in front of it. It decides by comparison — matching what's happening now against everything that's happened before, and answering the old one.

> **GOLD/PAUSE** — long

That isn't a fault. It's fast, and fast was the point.

It does mean that the decision you'd make right now is substantially about a situation you were in previously. Possibly a long time ago. Possibly one that isn't much like this.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Settled, you get something else. The one actually in front of you.

> **GOLD/PAUSE** — long

So — four questions.

> **GOLD/PAUSE**

If you've got months, sit with them over months. If you've got until Friday, take the last one and leave the other three — it's the one that does the most work under pressure.

> **GOLD/PAUSE**

**How did you get here?** Not whose fault. Just what the sequence was.

> **GOLD/PAUSE** — very long

**What is it in you that keeps arriving at this?** Something has kept choosing this shape of situation, or kept staying in it past the point you'd have advised someone else to.

> **GOLD/PAUSE** — very long

That's information. It isn't a fault, and if you've started listing what you got wrong, you've slipped into a different exercise. Come back.

> **GOLD/PAUSE**

**What would you do differently, if you were placing yourself again?**

> **GOLD/PAUSE** — very long

**And what has the whole run of it — including the parts that went badly, especially those — actually left you able to do?**

> **GOLD/PAUSE** — very long

And one more, underneath all of them.

> **GOLD/PAUSE** — long

If you left — what does it feel like you'd be losing? And if you stay — what does it feel like you'd be giving up?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — a threshold, and beneath the ground on both sides a shared layer running under it.

Those two answers are usually not about the job at all. For a lot of people what's actually on the table is who they've been, and whether they're allowed to be someone else now.

> **GOLD/PAUSE** — very long

Or it's plainer than that. Security. Being able to say what you do without explaining it. Not having to start again in front of people who knew you before.

> **GOLD/PAUSE** — very long

I'm not telling you which is yours. I don't know, and from outside your life nobody does.

> **GOLD/PAUSE** — long

And the checking — the part that keeps asking whether this is right — what has that been protecting?

> **GOLD/PAUSE** — very long

Being wrong about where you stand has cost something before. So something in you decided it would never be caught out by that again, and it's been on duty ever since.

> **GOLD/PAUSE**

Expensive. Also on your side.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

If something arrived just now, there'll be a second thing behind it. Usually *most people just get on with it.*

> **GOLD/PAUSE** — very long

Put that down. If what's on the table is who you've been, then of course this is hard, and struggling with it is the appropriate response rather than a failure to be decisive.

> **GOLD/PAUSE** — long

And something in you was willing to look at that while it's still unresolved. That's harder than deciding, and it was yours before today.

> **GOLD/PAUSE** — very long

One more, and it's simply true rather than comforting. Almost everyone who has changed direction stood exactly here first, for longer than they admit to afterwards. You're in very ordinary company.

> **GOLD/PAUSE** — very long

That last one is the useful one. Not what you'd like to do. What all of it has equipped you for, which you may not have noticed because you've been inside it the whole time.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

I'm not answering any of those. I don't know, and nobody outside your life does.

> **GOLD/PAUSE** — long

None of that decides anything for you. What it does is mean the decision gets made from here — rather than from a comparison with something that happened years ago.

> **GOLD/PAUSE**

And if it has to be made this week, that matters more rather than less. A short deadline doesn't leave time to correct a decision made from the wrong state.

---

> **GOLD/PAUSE** — long

One last thing. Not the decision itself.

Something that would give you information you don't currently have. A conversation. A question you've been not asking. One fact, found out.

> **GOLD/PAUSE** — long

If you've got time, make it small enough to do this week. If you haven't, make it the single thing that would most change the answer — and go and get it today.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing already true, wherever this goes.

> **GOLD/PAUSE**

Now put it down. The versions, the questions, all of it. You don't have to carry any of this out of here.

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back. Feet on the floor.

Nothing's decided here. That was never the offer, and on your timeline rather than mine.

What's different is what the decision gets made from.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are unsteady.* Not a verdict on the job.
**Breathe it** — Four in, six out. Feet into the floor.
**Stop running versions** — None of them resolve. They're forecasts.
**One thing that gets you information** — Not the decision. A fact you don't have.

### Back

**Recognition** — Find it in your body: chest unsteady, stomach, something that arrives on a Sunday evening. Name the state in one word. It doesn't include the decision and it doesn't say the job is wrong. You described a state, and something in you did the describing.

**Regulation** — Four in, six out. Attention in the centre of your chest. Feet into the floor — you're standing somewhere, whatever else is unresolved.

**Release** — Two things. The situation, with its real constraints. And the running of versions — go and it works, go and it doesn't, stay and it improves, stay and you're still here in three years. You've run all four this week. None resolve, because they're forecasts and running one produces no information you didn't already have. Put down the running.

**Rise** — *Whatever your timeline, this is the state you'd be deciding from.* A system in this state decides by comparison, matching now against what came before and answering the old one. Settled, you get the one in front of you. Four questions — how did you get here, what in you keeps arriving at this, what would you do differently, and what has the whole run of it left you able to do. Under a deadline, take the last one only. Then one thing that gets you information you don't have.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

An unresolved decision with real stakes produces a maintained unsettled state rather than episodes. In the body: unsteadiness through the chest, disturbance in the stomach, light sleep, and a characteristic timing — Sunday evenings, Monday mornings, the moment a calendar invitation arrives.

The distinguishing feature is that it has no discharge point. Ordinary states resolve when the situation does. This one is generated by the absence of a resolution, so it persists exactly as long as the question does.

**Why the state and the decision come apart**

Naming the state without naming the decision separates a physiological condition from an open question.

The question stays open — nothing here closes it, and closing it isn't available today. The state is running in you now and answers to different tools. While they're fused, settling feels like accepting the situation, so people stay lit for months and conclude they're indecisive.

**Why the exhale is longer, and why the feet**

You can't decide a state down. You can decide your breathing, and it's the one reachable control. Lengthening the out-breath relative to the in-breath shifts things toward settled.

Feet into the floor does something specific here: the state's whole content is not knowing where you'll be, and the floor is the one thing in the room that's settled.

**Why Release goes after the running of versions**

There's the situation, with genuine constraints. And there's the running — go and it works, go and it doesn't, stay and it improves, stay and nothing changes.

Two different costs. The versions feel like weighing it up. They aren't: each one is a forecast, and running a forecast repeatedly produces no information that wasn't available on the first pass. What it does produce is the state, renewed each time.

The tell is familiar by now — it doesn't terminate. A process that were genuinely weighing something would eventually arrive somewhere.

**Why the question isn't about indecision**

*Why can't I just decide* assumes the difficulty is in you. Frequently it isn't — some situations genuinely have no obvious answer, and treating an unanswerable question as a character flaw adds a second problem to the first.

*What was this for* asks about function, and what it surfaces is a system that has decided being wrong about placement carries a cost, and has been left running on a question more checking can't settle.

**Why the fourth step is longer here than anywhere else on the platform**

Because this is the protocol where the decision actually matters, and the platform has something specific and defensible to say about how decisions get made under load.

A system in this state doesn't assess the situation in front of it. It matches the present against stored experience and answers the comparison — which is fast, which was the point, and which means a decision made from inside the state is substantially about a previous situation.

Settled, the present one is available. **That's the entire argument for regulating before deciding**, and it's a mechanism claim rather than a claim about clarity or intuition.

The four questions that follow are posed and left open. The platform has no information about your life and no view on your decision, and anything else would be advice from a position of ignorance.

**Why the forward move is information rather than a decision**

A fact you don't currently have is available in a way a resolution usually isn't — a conversation, a question you've been not asking, one thing found out. That moves the situation rather than the state, and it's the only move that changes what there is to decide about.

**And where there is a deadline**

Some members arrive here with an offer expiring, a consultation period running, a visa date, or a probation review. Nothing on this protocol assumes otherwise, and a practice that told them the decision could wait would be both false and useless.

Under a deadline the sequence compresses rather than changing: settle the state, put down the running of versions, take the fourth question, and go after the single fact most likely to change the answer.

A short deadline is a reason to regulate first rather than a reason to skip it. There's no time to correct a decision made from a comparison with a situation from years ago.

---

> **SHARED BLOCK** — insert *What this track works on* here, verbatim from `SHARED-t3-what-this-track-works-on.md`. Identical on all ten Track 03 protocols. Do not paraphrase or re-cut per protocol.

---

### What we rest on

**Shadow & individuation — C. G. Jung** · *interpretive* · informs Release

What you decline to look at keeps running unattended. The usable test is proportion: when a reaction outruns the event that occasioned it, the surplus is carrying information about something other than the event. There's no finish line and nothing to complete. *Here it informs the second of the four questions — what keeps arriving at this — which is offered as something to notice rather than a fault to correct.*

*Offered as a lens rather than a finding, with no controlled evidence behind it. What it shows you is yours to read.*

**Non-resistance — Alan Watts** · *interpretive* · informs why the third step says *put down* rather than *resolve*

The state is one thing. The fight with the state is a second thing. The fight usually costs more, and it's the only one of the two you can put down. Setting it down isn't passivity and isn't agreement that the situation is fine. *Here it's the distinction the protocol turns on — the question stays open, and the running of versions doesn't have to.*

*Watts is an interpreter rather than an originator; the older sources are Laozi and, for the framing used here, D. T. Suzuki. Offered as a lens rather than a finding.*

**Where the reading is yours** — this explains the machinery. Whether to stay, whether to go, and what any of it means about your working life are readings that belong entirely to you. Nothing on this platform has a view, and nothing on it has the information to form one.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Feet into the floor.** Press down, feel it push back. You're standing somewhere, whatever else is open.

**Long exhale, no ceremony.** Four in, six out, three or four cycles.

**One horizon.** Look at the furthest thing you can see. This state pulls focus to a middle distance that doesn't exist yet.

**Write the constraint down.** One line: the thing that's actually fixed — money, notice period, a person, a date. Then stop. Naming the real constraint once is worth more than circling it.

**Ask one factual question.** Of anyone. What something pays, what a role involves, whether something's possible. Facts move the situation; versions don't.

**Do one thing this week that isn't about it.** This state colonises evenings and weekends, and the colonisation produces no decisions.

*When you notice a version running, name which one — go-and-it-works, stay-and-nothing-changes. Naming it is usually enough to stop that pass.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with the state that comes from an unresolved decision, using breath, attention and observation. **It does not tell you whether to stay or go, and nothing on this platform will.** It changes the state the decision gets made from.

**Pacing**

Once through is a complete use. Sunday evening is when most people want it, and that's a legitimate time.

**What people commonly notice**

The versions restarting immediately after the session. That's the state doing what it does.

A clearer sense of the actual constraint, sometimes uncomfortably — people often discover the thing holding them is smaller or larger than they'd been treating it as.

Grief, occasionally, at the fourth step. Looking at how you got somewhere can surface what it cost.

**When to slow down**

If the four questions turn into an inventory of everything you've got wrong, stop. That's self-prosecution wearing the protocol's clothes, and the questions say so — come back to the breath and end there.

If Release opens something much larger than this decision, you can stop and come back to the breath.

**When there's a deadline**

Some people arrive here with an offer expiring, a consultation period running, a visa date, or a review scheduled. If that's you, nothing on this protocol assumes you have time you don't.

Run it anyway, and run it short. The state settles in a few minutes and the decision doesn't get better for being made from inside it — a short deadline is a reason to regulate first rather than a reason to skip it, because there's no time left to correct a decision made from the wrong state.

Take the fourth question and leave the other three. Then go after the one fact most likely to change the answer, today.

And if the deadline is being used as pressure — an offer that expires unreasonably fast, a decision demanded before you can get advice — that's worth naming to yourself as a tactic rather than a timeline.

**When the situation is the thing**

If you can't afford to leave, if a visa or a contract holds you, if there are dependants involved — those are real constraints and no regulation practice moves them. What it can do is stop you spending the constrained period in a state that makes the constraint heavier.

Where money, contracts, immigration status or notice periods are involved, get advice from someone qualified in that thing. Early.

**Where staying is doing you harm**

If the situation involves bullying, harassment, discrimination, or an environment making you unwell, this isn't a decision protocol — it's a matter for occupational health, a union, HR or an employment lawyer. Treating harm as a career question keeps people in place while it continues.

**When a person in the room is the right tool**

Contact someone — a doctor, a helpline in your country, or a person you trust — if the state is affecting your sleep or health across weeks, if you're dreading Mondays in a way you can't shake, if you're using something to get through the week, or if you're having thoughts of harming yourself.

**Alongside other support**

If you're with a therapist, doctor, counsellor or coach, this sits alongside that and replaces nothing. A coach in particular is built for the decision itself, which this deliberately isn't.

---

## 06 · Disclosure & Support
*A script for someone close.*

> **This one is for outside work.** A friend, a partner, someone who isn't in the building. The workplace conversation is a different act with different consequences — that's **Raising It**, the next resource.

Take these exactly, or change every word.

**Saying it**
> "I don't know whether to stay in this job and I've been going round it for months. I'm not asking you what you'd do. I'd rather one person knew where I actually am with it."

**Describing what it's actually like**

> "It's physical. Chest unsteady, stomach, and it arrives on a Sunday evening like clockwork."

> "The part I can't switch off is running versions. Go and it works, go and it doesn't, stay and it changes, stay and I'm still here in three years. I've run all four this week and none of them ever finish."

**How to tell it's coming**

> "I go quiet on Sundays. I get short about something unrelated. I start looking at job sites and closing them again."

**What helps**

> "Ask me what I'd actually need to know to decide. Usually it's one fact and I've been avoiding finding it out."

> "Talk about something else. This has taken over more of my week than it deserves."

**What doesn't**

> "Telling me what you'd do. You're not in it, you don't have the numbers, and then I've got your version to carry as well."

> "Asking every time we speak. I'll tell you when there's something to tell."

**If they're affected by it — a partner, family**
> "This affects you too and I've been treating it as mine to work out alone. I'd rather do it with you than present you with a conclusion. Can we talk about what we'd both need?"

**If they ask what you're doing about it**

> "There's a method I run. I name it as a state rather than as the decision, do a breathing pattern, and stop running versions — which never resolve, because they're forecasts. Then I look at how I got here and what the whole of it has left me able to do."

> "It doesn't decide anything. It changes what I'd be deciding from."

*Tell one person, and pick someone who won't ask for a conclusion. The pressure to have decided is the part most people can't carry alongside the deciding.*

---

## 07 · Raising It
*Who to tell, how much, and what to ask for.*

Telling a friend costs you nothing. Telling someone at work may go on a record, may change what you're trusted with, and can't be taken back. Different audience, different calculus, different words.

**On this protocol especially: you may not have to say anything.**

Signalling that you're considering leaving changes how you're treated, and not always in the direction people expect. Nothing here pushes you toward disclosing. What follows is for if you've decided to, or if something could change and saying nothing is what's costing you.

**Who you tell changes what happens**

**Your manager** — can change the work, and will also start planning for your absence. Both, from the same conversation.

**HR** — exists to protect the organisation. Not hostile, and not neutral, and not your representative.

**A colleague** — no power to change anything, and no obligation to keep it to themselves.

**A mentor or someone senior elsewhere** — frequently the most useful conversation available, and the one with the least consequence.

**Someone in the role or the field you're considering** — the only person who can give you the fact you're missing.

**How much to say**

*I've been thinking about what's next for me* is a different act from *I'm looking.* The first opens a conversation. The second starts a clock.

**Make it a request, not an announcement**

The move that works is asking for something specific rather than declaring a state of mind. A specific ask is actionable and answerable. An announcement invites a response you can't control.

> **The ask, on this protocol:** *"I'd like to talk about what the next eighteen months could look like for me here. Not because anything's wrong — I'd just rather know than assume."*

> Or: *"Is there scope for me to do more of X? It's the part of this I'd want more of."*

Both are entirely ordinary requests, both produce real information, and neither commits you to anything.

**Put it in writing afterwards**

If something is agreed — a change of scope, a review, a conversation in three months — follow it with a short email confirming it. No tone, no argument. It's a record of what was agreed and it protects both of you.

**Two things this resource can't do**

It isn't legal advice. Notice periods, restrictive covenants and immigration status differ enormously and are a conversation with a lawyer.

And it makes no promise about how it will be received, which is why nothing here tells you to disclose.

---

## 08 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

If this is a work device, remember it is stored on the device — and a work device is not always yours.

Keep anything you may need factually — dates, what was said, who was present — somewhere separate from this. This is for your state. That is for the record, and it belongs off a work device.

Any of these, or none.

- Where did it sit in your body?
- Which version were you running today?
- What's the actual constraint? One line, the thing that's genuinely fixed.
- Is there a date on this? Write it down rather than carrying it.
- Is that constraint as fixed as you've been treating it? Including yes.
- *What was this for* — what turned up, without needing to answer it?
- What did you say to yourself from across the room?
- **How did you get here?** The sequence, not the fault.
- **What keeps arriving at this?**
- **What would you do differently, placing yourself again?**
- **What has the whole run of it left you able to do?**
- What's the one fact you don't have? Did you go and get it?
- What did you write here last time? Read it back.

Those four in bold are the ones worth writing rather than thinking. They answer slowly, and reading your own answers from a month ago is the closest thing to an outside view you'll get on your own working life.

---

## 09 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half lands on colleagues who don't know, and on people at home who do.

**The specific blind spot here** — half-present reads as disengaged. From inside you're weighing something enormous. From outside, someone has stopped putting themselves forward, stopped taking on anything long-term, and stopped saying much in meetings. **Being visibly on the way out is often what makes the leaving decision for you**, and it happens months before anyone says anything.

**The second one** — the people at home. From inside, working it out alone is protecting them from an unresolved thing. From outside it's a decision that affects them being made without them, and then presented. Most people would rather have the uncertainty than the conclusion.

**The third one** — the Sunday. It arrives in the house every week, and the people in it have learned to work around it without ever having been told what it is.

**Their earlier information** — worth asking someone at home: *how long has it been like this?* Expect longer than you'd say.

**Naming the act, not the character** — *"I've been somewhere else on Sundays for six months and never said what it was"* is ownership. *"I'm in a bad place with work"* is not; it names nothing and asks them to be understanding about an unspecified thing.

**No because.** The situation is a real reason and doesn't belong in the sentence.

**No self-attack.** *"I'm sorry, I'm useless at this, I should have sorted it by now"* moves the burden across to someone who has been living with it patiently.

**Describe what was observable, ask about the rest.** *"I've been half-here for months. I'm not going to tell you what that's been like — I'd rather you told me."*

**The checkable change** — this repairs by including rather than by deciding. *"I'll tell you what I'm actually weighing rather than presenting you with an answer"* is small, specific and observable, and doesn't require you to have decided anything.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. And nobody is owed a decision on their timetable. If someone is pressing you for one, that's a conversation about the pressure rather than about the decision.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Keep checking whether this is right.

Run the versions. Go and it works, go and it doesn't, stay and it improves, stay and you're here in three years. Check again. Being wrong about where you stand has a cost, so it never stops checking.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Being wrong about placement. Ending up somewhere I didn't choose because I didn't decide in time.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the Sundays*, or *the months I've spent on this without getting one fact closer to an answer.*

---

**What it should be attending to instead**

It isn't deciding today. You may not be able to, and there may be nothing to decide with yet.

What's available is a different instruction about **what closes the gap**.

The old one runs forecasts, which produce nothing that wasn't there at the start. The successor goes and gets a fact — a conversation, a number, an answer to a question that's been left unasked.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *get one fact rather than run one more version.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *asks the awkward question. Finds out what something actually pays. Talks to someone doing the thing rather than imagining it.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Names the version they're running. Stops it. Writes down the one fact that would change the answer.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*

*If this is a work device, remember it is stored on the device — and a work device is not always yours.*
