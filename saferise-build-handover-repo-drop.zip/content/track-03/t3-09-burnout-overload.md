# t3-09 · The Burnout & Overload Protocol

**Label:** Refill · **State:** Numb · **Frameworks:** Porges, Watts · **extras:** `['advisory']`
**Resources: 10**

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in very late, very low. No turn until the close.
> **VOICE** — quiet, slow, asks almost nothing. Never encouraging. Long pauses. Sounds like someone who has seen this and isn't going to make it worse by being bright about it.

You're still going.

> **GOLD/PAUSE** — very long

That's most of what there is to say about it, and it's not a compliment. It's just where you are.

> **GOLD/PAUSE** — long

This one asks very little. If you stop after the first part, that's a complete use of it.

---

### Before we start

> **RED/ACTION** — small deliberate movement. Offered, never insisted on.

Move your fingers, if they'll go.

> **GOLD/PAUSE** — very long

And your feet, into whatever's underneath.

> **GOLD/PAUSE** — very long

That's the whole of the first step. Nothing bigger than that for a while.

---

### Recognition

One word. We're not going looking.

> **GOLD/PAUSE**

**Numb.**

> **GOLD/PAUSE** — very long

You don't need to find where it sits. That's often hard here and not finding it is part of what this is.

> **BLUE/ILLUSTRATION** — a vessel, drawn empty, with the outline entirely intact.

> **GOLD/PAUSE** — long

And one thing worth knowing. This isn't tiredness. Tiredness lifts after a weekend.

> **GOLD/PAUSE**

This is what a system does after a long time of putting out more than came in. The flatness is what's left when there's nothing spare, and it doesn't respond to being pushed through — you'll have tested that already.

---

### Regulation

Contact first. Counting can wait.

> **RED/ACTION** — hand to sternum, or hold the opposite arm. Offered, not instructed.

A hand on your chest. Or hold your own arm — whichever is nearer.

> **GOLD/PAUSE** — very long

Let it stay there.

> **GOLD/PAUSE** — long

Now the breath, and it doesn't have to be four and six today.

> **TEAL/BREATH** — in, slow
> **TEAL/BREATH** — out, longer

Longer out than in. That's all this step needs.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

Nothing to achieve here. Nobody's checking.

---

### Release

Two things are going on, and only one of them is the load.

> **GOLD/PAUSE** — long

There's what's actually being asked of you. Real, probably unreasonable, and largely not yours to change from a chair.

And there's the pushing through.

> **GOLD/PAUSE** — very long

Carrying on as though the tank weren't empty. Adding the effort of appearing fine to the effort of the work. Getting up tomorrow and doing it again on the assumption that stopping isn't available.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

That costs more than the work does. And it's the only one of the two you can put down.

> **GOLD/PAUSE** — long

Which isn't the same as stopping. Nobody here is telling you to stop — I don't know what that would cost you and neither does anyone else outside your life.

> **GOLD/PAUSE**

Only that pretending is a second job, and it's the one that isn't paid.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

And the question. Not *what's wrong with me that I can't cope with this* — the load may be genuinely beyond what one person carries, and that question puts the fault in the wrong place entirely.

**What was this for?**

> **GOLD/PAUSE** — very long

Something in you kept absorbing. Every time there was more, it went to you, and each time you found somewhere to put it.

> **GOLD/PAUSE** — long

That's a capability, and it's why the volume kept arriving. Reliable people get given more. That's not a moral failing on anyone's part — it's just what happens.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Nothing needs answering today.

> **GOLD/PAUSE** — very long

---

There's a bit more here, and it asks almost nothing.

> **GOLD/PAUSE**

If you'd rather stop, stop. Come back to the breath and end there. That's complete.

> **GOLD/PAUSE** — very long

Still here.

> **GOLD/PAUSE**

Then one question, and take it slowly.

> **GOLD/PAUSE** — long

What would it mean, to stop carrying it?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — a vessel, empty, and beneath it the shape of what it has been holding.

Not practically. Practically you know — things would slip, people would notice, something would go wrong.

> **GOLD/PAUSE** — long

Underneath that, for a lot of people, it's simpler and harder.

> **GOLD/PAUSE**

Being the one who carries it is how they know what they're for.

> **GOLD/PAUSE** — very long

Take that away and there's a question they'd rather not be left alone with.

> **GOLD/PAUSE** — very long

I'm not telling you that's yours. I don't know. If it landed, it landed. If it didn't, that's a real answer.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

---

And the absorbing — what has that been protecting?

> **GOLD/PAUSE** — very long

Being needed is safe. Being the one who copes is safe. Somewhere, that was true and probably necessary.

> **GOLD/PAUSE**

So every time there was more, it came to you, and you found somewhere to put it. That's a capability, not a failing.

> **GOLD/PAUSE** — long

It's also the arithmetic. Reliable people get given more.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before you come back.

> **GOLD/PAUSE**

Something will be arriving behind that. Usually *other people manage this.*

> **GOLD/PAUSE** — very long

Put it down. If being the one who carries it is tied to what you're for, then of course this is hard to set down. That isn't weakness. It's the size of the thing.

> **GOLD/PAUSE** — long

And this. Something in you sat down and looked at it, on a day when you've got nothing spare.

> **GOLD/PAUSE**

That's the part that got you here, and it was yours before today.

> **GOLD/PAUSE** — very long

One more, and it's simply true rather than comforting. The people who end up here are almost always the ones who were good at carrying things. You're in very ordinary company, and almost none of them have said so out loud either.

> **GOLD/PAUSE** — very long

None of that changes the load. What it changes is whether you're also carrying a question about yourself on top of it.

---

### Rise

Step back, if you can.

Someone sitting there with a hand on their chest, still going.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Speak to them as *you*.

*You're not failing at this. You're out.*

> **GOLD/PAUSE** — very long

Those are different things, and almost everyone in this state has the first one.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now — one thing, and make it smaller than you think it should be.

> **GOLD/PAUSE**

Not a plan. Not a conversation with anyone. Not a change to the work.

Something that puts a small amount back. Eating properly today. Leaving at the time you're supposed to. Not opening it after dinner. Going to bed.

> **GOLD/PAUSE** — very long

I know how that sounds against the size of what you're carrying.

> **GOLD/PAUSE**

It's still the only thing on offer today, and nothing else works until some of it comes back.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And before you come back — something in you got you here today. Not the part that's exhausted. The part that noticed and sat down with it anyway.

> **GOLD/PAUSE** — long

That was yours before today and it's still there.

> **GOLD/PAUSE**

Now put it all down. You don't have to carry any of this out of here.

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back slowly.

Nothing about the load has changed. You knew that going in.

What you've got is a few minutes where you weren't also pretending, and one small thing that puts something back.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

*Before you start — move something. Fingers, feet into the floor.*

**Name it** — *You are numb.* Not tired. Out.
**Contact, then breath** — Hand on your chest. Longer out than in.
**Stop pushing through** — Pretending is a second job. It isn't paid.
**One thing that puts something back** — Eat. Leave on time. Go to bed.

### Back

**Move first** — Before anything else, move something small. Movement comes before attention here, because attention is the part that's reduced.

**Recognition** — One word. *Numb.* Don't search for where it sits. This isn't tiredness — tiredness lifts after a weekend. It's what a system does after a long time of putting out more than came in, and it doesn't respond to being pushed through. You'll have tested that.

**Regulation** — Contact before counting. Hand on your chest, or hold your own arm. Then longer out than in. Count if you can, don't if you can't. Nothing to achieve.

**Release** — Two things. What's actually being asked of you, which is real and largely not yours to change from a chair. And the pushing through — carrying on as though the tank weren't empty, adding the effort of appearing fine to the effort of the work. That costs more than the work, and it's the only one you can put down. Not the same as stopping.

**Rise** — *You're not failing at this. You're out.* Then one thing smaller than you think it should be — eating properly, leaving on time, not opening it after dinner, going to bed. It sounds trivial against the size of it. It's still the only thing on offer, and nothing else works until some of it comes back.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

Sustained output without adequate recovery produces a reduced state — not tiredness, which lifts, but a flattening that persists through rest and shows up as an absence rather than a symptom.

In the body: heaviness, distance from your own limbs, slowed thought, disrupted sleep that doesn't restore, and a marked drop in the capacity to begin anything. Attention is unreliable. Feeling is muted across the range, including the parts you'd want.

There's usually a cognitive signature too — worse recall, more errors, more re-reading. People take that personally. It's a feature of the state and it reverses when the state does.

**Why it's a reduced state rather than a mobilised one**

Mobilisation needs something to push against and a prospect of resolution. Where the demand is continuous and the end isn't visible, the system doesn't stay activated. It comes down. That's protective, it's expensive, and it isn't a decision.

**Why movement comes before attention**

Every other protocol opens by asking you to find where the state sits and hold attention there. In a reduced state that's the least available capacity, and opening that way produces someone who has failed at step one.

Small deliberate movement asks nothing of attention and returns an immediate physical signal.

**Why contact comes before the count**

Warmth and pressure at the sternum requires nothing of you and registers when finer inputs don't. The breath follows: lengthening the out-breath relative to the in-breath shifts things toward settled. The count is offered rather than required, because in this state a count is one more demand.

**Why Release goes after the pushing through**

There's the load, which is real and often genuinely unreasonable. And there's the pushing through — continuing as though the reserve weren't empty, and adding the work of appearing fine to the work itself.

Two different costs. The first isn't optional in the short term. The second is generated continuously, produces nothing, and is frequently larger than the work — maintaining an appearance under depletion is expensive in a way that doesn't show up on anyone's list.

**Putting it down is not the same as stopping.** Nothing here tells anyone to stop, because the platform doesn't know what stopping would cost you. What it can say is that pretending is a second job and it isn't paid.

**Why the question isn't about coping**

*What's wrong with me that I can't cope* assumes the load is reasonable and the failure is yours. Frequently the load isn't reasonable, and that question adds a second problem to the first.

*What was this for* asks about function — and what surfaces is usually a capability rather than a fault. Something in you kept absorbing, so the volume kept arriving. Reliable people get given more; that's not a moral failure on anyone's part and it explains the arithmetic.

**Why the forward move is deliberately trivial**

Rehearsing the load reducing is rehearsing something outside your control. Rehearsing a conversation, a boundary or a plan asks for a resource that is currently depleted — and a plan made from here gets abandoned, which becomes further evidence of failing.

Eating properly, leaving on time, not opening it after dinner. These are the only moves available today, they put a small amount back, and **nothing else in the protocol works until some of it returns.** The disproportion between their size and the size of the problem is named in the script, because a member who notices it unaided will conclude the protocol hasn't understood them.

---

> **SHARED BLOCK** — insert *What this track works on* here, verbatim from `SHARED-t3-what-this-track-works-on.md`. Identical on all ten Track 03 protocols. Do not paraphrase or re-cut per protocol.

---

### What we rest on

**Polyvagal Theory — Stephen Porges** · *peer-reviewed* · supplies Recognition and the three state labels

Threat detection runs ahead of thought. The body reads a situation and moves before your thinking catches up. Porges describes three broad conditions: settled and socially available, mobilised for action, and shut down. Agitated, Unsteady and Numb are the member-facing names for those three. *Here it accounts for why continuous demand with no visible end produces reduction rather than mobilisation — there is nothing to push against.*

*The anatomical premises are contested: a 2026 evaluation in* Clinical Neuropsychiatry *challenged them, with Porges replying in the same issue. The state distinctions are what this platform uses, and they hold independently of that dispute.*

**Non-resistance — Alan Watts** · *interpretive* · informs why the third step separates the load from the pushing through

The state is one thing. The fight with the state is a second thing. The fight usually costs more, and it is the only one of the two you can put down. Setting it down isn't passivity and isn't agreement that the situation is acceptable. *Here it is the distinction the protocol turns on — the load stays, and pretending it isn't there doesn't have to.*

*Watts is an interpreter rather than an originator; the older sources are Laozi and, for the framing used here, D. T. Suzuki. Offered as a lens rather than a finding.*

**Where the reading is yours** — this explains the machinery. Whether the load is reasonable, whether to stay, and what any of it means about your working life are readings that belong entirely to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

Smaller than on any other protocol. Any one on its own is a complete use.

**Move one small thing.** Fingers, feet into the floor.

**Hand to sternum, or hold your own arm.** The input this state takes when it takes little else.

**Longer out than in.** Three or four breaths. No counting.

**Eat something at a normal time.** Not a nutrition instruction. A time instruction. This state loses the shape of a day first.

**Leave at the time you're meant to.** Once this week.

**Go outside the door and come back.** Air and light on skin.

**Put it down after dinner.** One evening. Not every evening — one.

*Sleep is the thing that puts most back and the thing this state damages first. If it's gone, that's worth a doctor rather than a technique.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with a reduced state, using movement, contact, breath and observation. **It does not restore capacity — only rest and reduced demand do that — and it doesn't change your workload.**

**Pacing**

Any single part is a complete use. Moving your fingers and stopping there counts.

**What people commonly notice**

Feeling nothing during or after. Common here, and it doesn't mean nothing happened.

Emotion arriving suddenly when the state eases, sometimes as anger rather than sadness, and often disproportionate.

Considerable tiredness. And a resistance to the fourth step, because the small things sound insulting against the size of the problem.

**When to slow down**

If the practice feels like one more demand, do a single somatic item and leave the session.

If Release opens something much larger, you can stop and come back to the breath.

**Where this needs a doctor rather than a practice**

Burnout overlaps with conditions that respond to treatment, and it can be confused with several of them.

**See a doctor** if this has gone on for months, if sleep has gone, if you've lost or gained weight without meaning to, if you're getting ill repeatedly, if your heart or your chest is doing something that worries you, if you can't function rather than functioning badly, or if you're using alcohol or anything else to get through the week.

That isn't a formality. Depression, thyroid problems, anaemia and several other things present exactly like this, and a practice will not touch any of them. A blood test and a conversation cost you an hour.

**Where the load is the thing**

If the volume is structurally impossible and has been for a long time, this settles you and changes nothing. The useful next moves are outside this platform: occupational health, a union, HR, or a manager with the authority to change the input. Occupational health in particular is designed for exactly this and is under-used.

**When a person in the room is the right tool**

Contact someone today — a doctor, a helpline in your country, or a person you trust — if you're having thoughts of harming yourself or of not being here, if you feel there's no point continuing, if you can't get up, or if you're frightened by how you feel.

**Alongside other support**

If you're with a therapist, doctor, counsellor or coach, this sits alongside that and replaces nothing. This is one of the protocols where having a person matters most.

---

## 06 · Proximity Guide
*How close to stay.*

Burnout has a source, and it's usually continuous demand from a specific arrangement. How much of it continues is a real variable, and it's the one most people treat as fixed when it isn't entirely.

Three tiers. Which one yours belongs in is your read, on information nobody here has.

**Worth staying engaged with**

Where the volume is high but finite, and responds when it's named. Where there's a version of the conversation about scope you haven't had. Where the demand moves when you ask for it to move.

Distance isn't the tool here. Regulation plus one specific request is — and the request has to be specific, because *I'm overloaded* produces sympathy and *if this comes to me, what comes off* produces a decision.

**Worth reducing the surface area of**

Where the conversation has been had, more than once, and nothing changed. Where your capacity is treated as the thing that flexes. Where things arrive addressed to you because you've historically absorbed them.

Reduction is specific: hours you stop being available in, a channel you leave, a standing commitment you let end, work you hand back, an ask you answer with a date rather than a yes.

**Delegating belongs here**, and it's frequently blocked by a different protocol — re-checking other people's work keeps the work on your desk. Where that's what's happening, Perfectionism Release is the nearer tool.

**Past what self-regulation is for**

Where the volume is structurally impossible and no arrangement of your own state will meet it. Where you're held responsible for outcomes you have no authority over. Where you're being made unwell, and it has been going on for a long time.

That isn't a regulation problem, and treating it as one has a real cost: it converts a situation needing institutions into a private failure of resilience. What it needs is occupational health, a union, HR, a manager with actual authority, or a doctor.

**Using this**

Notice the tier. Then notice whether it's the tier you'd assign if a colleague described the same load. People place their own one tier lower than they'd place someone else's, and on this protocol more reliably than on any other.

---

## 07 · Disclosure & Support
*A script for someone close.*

> **This one is for outside work.** A friend, a partner, someone who isn't in the building. The workplace conversation is a different act with different consequences — that's **Raising It**, the next resource.

Any of these can be sent as a message rather than said.

**Saying it**
> "I'm running on empty and I have been for a while. I'm not asking you to fix it. I'd rather say it than keep doing the version where everything's fine."

**Describing what it's actually like**

> "It isn't tiredness. Tiredness goes after a weekend. This is flat, and it's been flat for months, and sleeping doesn't touch it."

> "The part I can't explain well is that I've got worse at things, not just slower. I'm making mistakes I wouldn't normally make. That isn't carelessness — it's what happens when there's nothing spare."

**How to tell it's coming**

> "I go quiet and efficient. I stop suggesting anything. I say I'm fine in a flat voice. I stop making plans for anything that isn't work."

**What helps**

> "Take one actual thing off me. Not offer — take. Anything, however small."

> "Do the thing rather than asking what I want. Decisions are expensive right now."

> "Be around without needing me to be good company."

**What doesn't**

> "Suggestions. It isn't that they're wrong — another thing I could be doing lands as another thing on the list."

> "Telling me to look after myself. I know. Knowing isn't the bit that's missing."

**If it's affecting the household**
> "I know I've been absent even when I've been here, and that's landed on you. I'm not going to fix it this week. I'd rather say I've seen it than keep letting it be unmentioned."

**If they ask what you're doing about it**

> "There's a method I run. It starts small — move something, name it, hand on my chest before any breathing. Then I stop pushing through, which is a separate job from the work and it's the one that isn't paid. Then one small thing that puts something back."

**If you need someone to act**
> "I need to see a doctor about this and I can't face arranging it. Could you help me do that this week?"

*Tell one person. This state removes the impulse to ask for anything, and it's the one where that costs most.*

---

## 08 · Raising It
*Who to tell, how much, and what to ask for.*

Telling a friend costs you nothing. Telling someone at work may go on a record, may change what you're trusted with, and can't be taken back. Different audience, different calculus, different words.

**You may not have to say anything. But on this protocol, saying nothing has a cost.**

Nothing here pushes you toward disclosing. It is worth knowing that a load nobody has been told about is a load nobody adjusts, and that most people carrying this have never made a specific request.

**Who you tell changes what happens**

**Your manager** — the only person who can change what arrives. Cannot usually keep it confidential.

**Occupational health** — assesses fitness for work and recommends adjustments, reporting only what you consent to release. **The most useful route available for this specifically, and almost nobody uses it.**

**A union rep** — represents you. If you have access, use it before HR.

**HR** — exists to protect the organisation. Not hostile, not neutral, not your representative.

**Your GP** — outside the building, and the only one who can put something in writing an employer has to take seriously.

**How much to say**

*I'm at capacity and something needs to come off* is a different act from describing how you feel. The first is a workload conversation and entirely ordinary. The second invites a response nobody has been trained to give.

**Make it a request, not a confession**

> **The ask, on this protocol:** *"I'm at capacity. If this new piece comes to me, I need to know what comes off. I'm not saying no — I'm asking which."*

That sentence is the most useful on this track. It doesn't disclose a state, it can't be waved away, and it moves the decision to the person who owns it.

> Or: *"Could we look at what's on my list together? I don't think the shape of it is right any more."*

> Or, to occupational health: *"I'd like an assessment. I've been running at this level for a long time and I want it looked at properly."*

**Put it in writing afterwards**

If something is agreed, confirm it in one line the same day. Verbal workload agreements evaporate.

**Two things this resource can't do**

It isn't legal advice, and where you may be too unwell to work, that's a conversation with a doctor and possibly a union rather than a platform.

And it makes no promise about how it will be received.

---

## 09 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

If this is a work device, remember it is stored on the device — and a work device is not always yours.

There's no arc here and nothing accumulating toward a good end. One line is a complete entry.

- What did you manage today? Anything at all.
- Could you find where it sat, or not? Either is fine.
- What did the pushing through cost today — the appearing fine, separate from the work?
- *What was this for* — anything, or nothing? Nothing is a real answer.
- What did you say to yourself from across the room?
- What was the small thing that put something back? Did you do it?
- Has anything come off your list this month? Including no.
- What did you write here last time? Read it back — without comparing today to it.

---

## 10 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half lands on colleagues and on people at home, and most of them have concluded something about it already.

**The specific blind spot here, and it's the consequential one** — **the reliable person gets given more, and absorbing it silently is what confirms the arrangement.** From inside, taking it on is coping. From outside it's evidence that the volume is fine, and next quarter's is set accordingly.

**The second one** — the appearing fine. It works, which is the problem. Nobody adjusts anything for a load they can't see, and the effort of concealing it is the part that isn't visible on anyone's list.

**The third one** — at home, being present and absent at once. From inside it's having nothing left. From outside it's someone who is there and unreachable, week after week, and the people in the house have quietly stopped expecting anything.

**The fourth one** — the errors. Depleted people make more of them, and colleagues who don't know experience that as carelessness about them specifically.

**Their earlier information** — worth asking someone at home: *how long has it been like this?* And a colleague you trust: *have I been different?* Expect both answers to be longer and more specific than yours.

**Naming the act, not the character** — *"I've been unreachable in the evenings for four months"* is ownership. *"I've been so busy"* is not; it's an explanation offered as an account, and it invites them to say it's understandable, which lets both of you skip it.

**No because.** The load is a real reason and it doesn't belong in the sentence, though on this protocol it can be said shortly afterwards, because the explanation genuinely changes what happened for them.

**No self-attack.** *"I'm useless, I don't know why you put up with me"* asks them to reassure you while they're still carrying what you couldn't.

**Describe what was observable, ask about the rest.** *"I've been here and not here for months. I'm not going to tell you what that's been like — I'd rather you told me."*

**The checkable change** — this repairs by naming the load rather than by carrying it better. *"I'll tell you when I'm at capacity instead of absorbing it"* is small, specific, observable, and doesn't require the load to change first.

**Where this stops** — this isn't an instruction to be less depleted for anyone's convenience, and you don't owe anyone a better performance. If the load is genuinely beyond what one person carries, none of this is about your conduct and the Proximity Guide's third tier is the resource.

---

## 12 · The Decision
*What takes over.*

Short version today. This one asks very little.

---

**What's running now**

Absorb it. Be the one who copes.

More arrives, and you find somewhere to put it. And you keep the face on while doing it, which is the second job — the one that isn't paid.

It isn't a fault. It's been doing a job.

---

**What takes over**

It isn't doing less. That may not be available, and telling you to would be useless.

What's available is stopping the pretending, which costs more than the work.

> **One line. What should it be doing instead?**

Something like: *say what's at capacity, at the time.*

Yours, if you've got one. If you haven't, leave it and come back — this one keeps.

---

**Who runs the next one**

Not who you are once this lifts. Who's in it while it's happening.

> **One thing they do, in the middle of one.**

*Says one true thing about the load. Leaves at the time once. Doesn't open it after dinner.*

---

**Come back to it**

This gets rewritten and nobody arrives at it. On a day like today, having written one line is the whole of it.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*

*If this is a work device, remember it is stored on the device — and a work device is not always yours.*
