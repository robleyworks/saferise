# t3-03 · The Imposter Dissolution Protocol

**Label:** Dissolve · **State:** Unsteady · **Frameworks:** Jung, Kross · **extras:** `[]`
**Resources: 9**

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Turn at four seconds.
> **VOICE** — plain, matter-of-fact, no encouragement whatsoever. Encouragement is the thing this state metabolises.

You're waiting to be found out.

> **GOLD/PAUSE** — long

Not vaguely. There's a specific moment you can picture, and a specific person, and a specific thing they'd say.

> **GOLD/PAUSE**

Nothing here is going to tell you you're good at your job. You'd have taken that apart before I finished the sentence.

---

### Recognition

Where does it sit?

> **GOLD/PAUSE** — long

Chest, unsteady rather than tight. Stomach. A tightness in the throat just before you speak in a room where it matters.

> **BLUE/ILLUSTRATION** — a form on a foundation, with a gap drawn between the two. The form is not falling.

One word. **Unsteady.**

> **GOLD/PAUSE**

That word describes how you're standing, not what you're worth. It's precise and it isn't a compliment.

> **GOLD/PAUSE** — long

Because this arrives with an opinion attached, and the opinion presents itself as something you've finally noticed rather than something you're feeling.

> **GOLD/PAUSE**

Notice what just happened, though. You described a state — and something in you did the describing.

> **GOLD/PAUSE** — long

Those are two different things. The opinion is in the room. You're the one who noticed it was in the room.

---

### Regulation

Four counts in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six out.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the middle of your chest.

> **RED/ACTION** — feet flat, pressed into the floor. Offered, not instructed.

Press your feet into the floor. Feel it push back. The state is unsteady. The floor isn't.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Nothing to be good at here. Nobody's marking it.

> **GOLD/PAUSE** — extended

---

### Release

Two things.

> **GOLD/PAUSE**

There's the state, which turned up on its own.

And there's the auditing. Checking yourself against the room. Replaying what you said. Working out what it revealed.

> **GOLD/PAUSE** — long

It feels like being conscientious. And it runs whether or not anything happened, finds something every time, and has never once returned a verdict of *fine*.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Put down the auditing.

> **GOLD/PAUSE** — long

And the question — not *what's wrong with me.* That's what the auditing has been asking all day. Asking it again in here would just be running the loop with better lighting.

**What was this for?**

> **GOLD/PAUSE** — long

Watching yourself closely in a room is a skill. It was learned somewhere, and it was learned because knowing exactly how you were landing was once useful information.

> **GOLD/PAUSE** — long

So — what's underneath it? What did you decide it would cost to be seen not knowing something?

> **GOLD/PAUSE** — very long

I'm not answering that. I don't know, and it isn't mine.

> **GOLD/PAUSE**

If something surfaced, it's yours. If nothing did, that's ordinary.

> **GOLD/PAUSE** — long

And there's a second one, harder to admit. You might not want to put it down.

> **GOLD/PAUSE** — very long

Fair enough. It works. Some part of you is convinced the auditing is the only reason you haven't been caught out yet, and that if you stopped, the standard would go with it.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

It was built with what you had then. What you had then and what you've got now aren't the same — you can watch a state while you're inside it, and you did that at the top of this.

> **GOLD/PAUSE**

That part doesn't know. Nobody told it. Nobody's asking you to stand it down, either.

> **GOLD/PAUSE** — very long

---

There's more here if you want it.

> **GOLD/PAUSE**

If today is a day for getting some ground under you and stopping there, stop there. That's complete.

> **GOLD/PAUSE** — very long

Still here.

> **GOLD/PAUSE**

Then — the opinion. Not whether it's true. What it seems to say.

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — a form on a foundation, and beneath the foundation a second one, older and deeper.

On the surface it's about the work. Whether you can do it, whether you've been found out yet.

> **GOLD/PAUSE** — long

Go under that and it's usually not about the work at all.

> **GOLD/PAUSE** — very long

Somewhere, at some point, being good at something got attached to being allowed to stay. To being wanted in the room. To being worth the space.

> **GOLD/PAUSE** — very long

That's a different thing from competence, and it's why competence never settles it. You can be demonstrably good at your job and the question doesn't close, because the question was never really about the job.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

So — what does it feel like would go, if you were found out?

> **GOLD/PAUSE** — very long

I'm not answering that. I don't know, and from outside your life nobody does.

> **GOLD/PAUSE**

If something surfaced, let it have been said. If nothing did, that's ordinary and it often comes later.

> **GOLD/PAUSE** — long

---

And what has the auditing been protecting?

> **GOLD/PAUSE** — very long

Getting there first. Finding the fault before anyone else can, so that whatever happens next, at least you saw it coming.

> **GOLD/PAUSE**

That's not vanity and it isn't weakness. It's a system trying to make sure you're never caught unprepared in the one room that mattered.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before we move.

> **GOLD/PAUSE**

Something will be arriving behind that. Usually *other people manage this without all of it.*

> **GOLD/PAUSE** — very long

Put that down. What you found under there is heavy, and struggling with it is the appropriate response. You've been carrying it while working, which is not nothing.

> **GOLD/PAUSE** — long

And this. Something in you was willing to look under the opinion rather than argue with it. Arguing is what you've done for years.

> **GOLD/PAUSE**

Looking is different, and it's the part that was yours before today.

> **GOLD/PAUSE** — very long

One more, and it's simply true rather than comforting. Whatever you found under there — you're not the only one, not close to it. Most rooms you've been in have had somebody else in them carrying the same thing, silently, at the same time.

> **GOLD/PAUSE** — very long

And none of it decides anything about you. The signal has given you information. Information isn't a verdict.

---

### Rise

Step outside it.

Someone at a desk, feet on the floor, breathing four and six.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Speak to them as *you*.

*You're unsteady today. That's a state, and you've worked in it before.*

> **GOLD/PAUSE** — long

From out here there's a person, and there's an opinion about the person. Two objects. From inside they were one.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now — once you can see where your attention is sitting, you can move it on purpose. That's the useful part of all of this.

> **GOLD/PAUSE**

And look where it's been. On a version of yourself constructed by a room. There's nothing in that you can use.

> **GOLD/PAUSE** — long

So put it on the one who does the work today. Not the one who feels qualified — that one isn't available on demand. Not the one who's already been recognised, either; that one does nothing for you.

> **GOLD/PAUSE**

Where are they. What are they about to do. What's the first move.

> **GOLD/PAUSE** — long

That's not a reward at the end of something. That person is the thing being built.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing you did. Not something you are. Small and factual.

> **GOLD/PAUSE**

Now put it all down. You don't have to carry any of this out of here.

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back. Feet on the floor.

The opinion may well still be here. It doesn't get overturned in one go and nothing here pretended otherwise.

What's changed is that there's ground under you, and a bit of space between you and it.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic. On this protocol it carries most of the work: *you* is what puts space between the person and the opinion.

### Front

**Name it** — *You are unsteady.* How you're standing, not what you're worth.
**Breathe it** — Four in, six out. Feet into the floor.
**Stop auditing** — It runs all day and never clears you.
**The one who does the work** — Not the one who feels qualified.

### Back

**Recognition** — Find it in your body: chest unsteady, stomach, the throat tightening before you speak. Name the state in one word. It arrives with an opinion attached that presents itself as something you've finally noticed. Don't argue with it — you described a state, and something in you did the describing. Those are two different things.

**Regulation** — Four in, six out. Attention in the centre of your chest. Press your feet into the floor — the state is unsteady and the floor isn't. Nothing here to be good at.

**Release** — Two things. The state, and the auditing — checking yourself against the room, replaying what you said, working out what it revealed. It feels conscientious. It runs whether or not anything happened and it never returns a verdict of fine. Put down the auditing. Ask *what was this for* and leave it open.

**Rise** — See yourself from a distance. From out there the person and the opinion are two objects; from inside they were one. Then put your attention on the one who does the work today — not the one who feels qualified. Then one thing you did, not something you are.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

This is an unsettled state rather than a mobilised one. In the body: unsteadiness through the chest, the stomach, tightness in the throat immediately before speaking, and a raised sensitivity to how a room is responding.

That last part is the distinguishing feature. Attention runs outward, monitoring, and inward, evaluating the returns — both at once, continuously, in every professional setting.

**Why the opinion presents as an observation**

This state doesn't describe a situation. It describes you, and it presents that description as something you've finally been honest enough to see rather than something you're currently feeling.

That's why counter-evidence fails. Every promotion becomes luck, every piece of praise becomes politeness, every success becomes the thing that raises the stakes for next time. The state generated the framework and it will process anything you put into it.

Recognition doesn't dispute the content. It changes the content's status — from fact to symptom. A symptom can be worked on.

**Why the exhale is longer, and why the feet**

You can't decide a state down. You can decide your breathing, and it's the one reachable control. Lengthening the out-breath relative to the in-breath shifts things toward settled.

The feet do something specific. This state's whole signature is unsteadiness, and pressure against a fixed surface is the most direct contradiction available — not as a metaphor, but because the body registers support and stops registering it unless attention is sent there.

**Why Release goes after the auditing**

There's the state, and there's the auditing — checking yourself against the room, replaying, evaluating.

Two different costs. The auditing presents as conscientiousness, which is why it's so hard to give up in a professional setting. But it runs whether or not anything happened, finds material every time, and never returns a verdict of adequate. It doesn't terminate, which is the tell.

**Why the question isn't the one it's been asking**

*What is wrong with me* is precisely what the auditing asks, all day. Asking it inside a protocol is the loop with better lighting.

*What was this for* asks about function — and what surfaces is that close self-monitoring in a room is a learned skill, learned because knowing exactly how you were landing once mattered a great deal.

**Why the reluctance gets named**

Most people running this believe the auditing is the reason they haven't been caught out, and that stopping it would take the standard with it. That belief is worth saying out loud, because unexamined it makes the third step impossible.

Nothing here asks you to stand it down. What's on offer is noticing that it was built with what you had at the time and hasn't been told anything since.

**Why Rise rehearses the work rather than the qualification**

Rehearsing feeling qualified is rehearsing something you can't produce on demand, and your body doesn't accept it. Rehearsing having been recognised is worse — it's an outcome you don't control.

The one who does the work today is available. That person is the thing being built, and the rehearsal acts on your own steadiness rather than on how anything turns out.

---

> **SHARED BLOCK** — insert *What this track works on* here, verbatim from `SHARED-t3-what-this-track-works-on.md`. Identical on all ten Track 03 protocols. Do not paraphrase or re-cut per protocol.

---

### What we rest on

**Shadow & individuation — C. G. Jung** · *interpretive* · informs Release

What you decline to look at keeps running unattended. The usable test is proportion: when a reaction outruns the event that occasioned it, the surplus is carrying information about something other than the event. There's no finish line and nothing to complete. *Here it accounts for why an ordinary question in a meeting can produce a disproportionate day.*

*Offered as a lens rather than a finding, with no controlled evidence behind it. What it shows you is yours to read.*

**Distance & rehearsal — Kross & Ayduk, with King** · *peer-reviewed* · supplies Rise

Observing an experience from outside it, rather than from inside looking out, lowers distress and later reactivity. Distraction does neither. Second-person self-address is one of the reliable ways to produce that shift. Rehearsing a specific future scene in concrete detail lifts outlook; general optimism does not. *Here it's what separates you from the opinion about you — two objects from outside, one from inside.*

*The effect is on the person rehearsing. It acts on your own steadiness and makes no claim to act on anyone else, or on how anything turns out.*

**Where the reading is yours** — this explains the machinery. What the opinion is about, where it was learned, and whether any part of it is warranted are readings that belong to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Feet into the floor.** Press both down, feel it push back, hold for a slow five. The most direct thing available for a state whose signature is unsteadiness. Works in any meeting, invisibly.

**Long exhale, no ceremony.** Four in, six out, three or four cycles.

**Both forearms on the table.** Weight through them. This state holds the arms slightly lifted and ready.

**Take up your actual amount of room.** Not expanding — just stopping the small contraction. Feet apart rather than tucked, elbows off your sides, back against the chair.

**Say one thing early.** In any meeting, contribute in the first few minutes — a question, an agreement, anything. The auditing gets heavier the longer you go without speaking, and the first contribution is expensive whenever you make it.

**One horizon.** Look at the furthest thing you can see. This state pulls focus to the nearest faces.

*Write down one thing you did, factually, at the end of the day. Not an assessment. A record. The auditing keeps no record of anything that went well.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with a state that arrives with an opinion attached, using breath, attention and observation. It doesn't dispute the opinion, doesn't confirm it, and doesn't assess your competence.

**Pacing**

Once through is a complete use. Before a specific occasion is a legitimate use.

**What people commonly notice**

The auditing starting up about the protocol itself — whether you're doing it correctly, whether you're feeling the right things. That's the loop finding a new subject. Note it and come back to the count.

Resistance at the fourth step, because looking at yourself from outside is uncomfortable when you expect the view to be unkind.

Relief smaller than hoped for. This state doesn't clear in one session and nothing here suggests it should.

**When to slow down**

If the fourth step turns into an inventory of everything you've got wrong, stop. That's the auditing restarting inside the step built to interrupt it. Come back to the breath and end there. Three steps is a complete use.

If Release opens something much larger — something old, something outside work — you can stop and come back to the breath.

**When a person in the room is the right tool**

Contact someone — a doctor, a helpline in your country, or a person you trust — if you're having thoughts of harming yourself or punishing yourself, if you've started declining things you want because of it, if you're using something to get through occasions, or if the opinion is now constant rather than episodic.

**Where the environment is the thing**

If you're being undermined, excluded, or consistently told you're not good enough by someone with power over you, this settles you and doesn't change it. Some of what people call imposter feeling is an accurate reading of an environment. That's a matter for HR, a union, or an employment lawyer rather than a regulation practice.

**Alongside other support**

If you're with a therapist, doctor, counsellor or coach, this sits alongside that and replaces nothing.

---

## 06 · Disclosure & Support
*A script for someone close.*

> **This one is for outside work.** A friend, a partner, someone who isn't in the building. The workplace conversation is a different act with different consequences — that's **Raising It**, the next resource.

The obvious response is reassurance, which doesn't work and which everyone offers. Telling someone what does work spares you both.

**Saying it**
> "I get a thing at work where I'm convinced I'm about to be found out. It isn't connected to how things are actually going. I'd rather you knew than wondered why I go strange before things."

**Describing what it's actually like**

> "It's physical. Chest goes unsteady, throat tightens just before I speak in anything that matters."

> "The part that's hardest to explain is the auditing. I'm watching how I'm landing the whole time I'm in a room, and then replaying it afterwards. It's exhausting and it isn't a choice."

**How to tell it's coming**

> "I go quiet in groups. Or I talk too fast. I start deferring to everyone. I turn things down with a reason attached."

**What helps**

> "Facts about what happened, not opinions about who I am. 'The thing you did on Tuesday worked' lands. 'You're brilliant' gets taken apart in about ten seconds."

> "In a meeting, bringing me in by name once. That's usually all it takes."

**What doesn't**

> "Reassurance. I know you mean it. It gives the loop something new to argue with, and the loop always wins."

> "Telling me everyone feels like this. Maybe. It doesn't touch the specific certainty that I'm the exception."

**If they ask what you're doing about it**

> "There's a method I run. I name it as a state — this one arrives disguised as something I've finally noticed about myself, and calling it a state puts it in a category rather than making it true. Then breathing, with my feet pressed into the floor. Then I stop the auditing, which never clears me. Then I look at myself from across the room, and from out there, me and the opinion about me are two different things."

> "It doesn't make me confident. It gets me into the room anyway."

*Tell one person. This state's instruction is to keep the doubt hidden in case anyone agrees with it, and telling someone contradicts that directly.*

---

## 07 · Raising It
*Who to tell, how much, and what to ask for.*

Telling a friend costs you nothing. Telling someone at work may go on a record, may change what you're trusted with, and can't be taken back. Different audience, different calculus, different words.

**First: you may not have to say anything.**

Not disclosing is a legitimate choice and often the right one. Nothing here pushes you toward telling anyone. What follows is for if you've decided to, or if something needs to change and saying nothing is what's costing you.

**Who you tell changes what happens**

These are not interchangeable, and most people don't know the difference.

**Your manager** — can change the work. Cannot usually keep it confidential, and shouldn't be expected to.

**HR** — exists to protect the organisation. That doesn't make them hostile, and it does mean they are not neutral and are not your representative. Useful for process; not the place to think out loud.

**Occupational health** — assesses fitness for work and recommends adjustments. Reports to the employer but usually only on what you consent to release. Frequently the most useful route available and almost nobody uses it.

**A union rep** — represents you specifically. If you have access, use it before HR rather than after.

**A colleague** — no power to change anything, and the only one who can be told without it becoming a process.

**Your GP** — outside the building entirely, and the only one who can put something in writing that an employer has to take seriously.

**How much to say**

*I'm dealing with something and it's affecting my sleep* is a different act from naming a condition. Both are honest. The first is almost always enough for a workplace conversation, and it's the version you can't be held to later.

Say what's affecting the work. You are not obliged to explain why.

**Make it a request, not a confession**

This is the move that works at work, and it's the one most people miss.

A specific ask travels. It's actionable, it's answerable, and it puts the conversation on ground the other person knows how to stand on.

An explanation of a state invites a response nobody has been trained to give, and it frequently ends in sympathy and no change.

> **The ask, on this protocol:** *"Could you bring me in by name in the Monday meeting if I haven't spoken? I contribute more once I've said something and I tend not to start."*

> Or: *"I'd find it useful to know what you thought of the thing I did last month. Not reassurance — specifics."*

The second one is uncomfortable and it's the single most useful request available on this protocol. The auditing keeps no record of anything that went well, and asking is the only way to get one that it didn't write.

**Put it in writing afterwards**

Verbal is deniable in both directions. If you've asked for something and it matters, follow the conversation with a short email — *thanks for the chat, just confirming we agreed X.* No tone, no argument, no explanation.

That isn't building a case. It's a record of what was agreed, and it protects both of you.

**Two things this resource can't do**

It isn't legal advice. Employment rights differ enormously by country and by contract, and where something might be unlawful, that's a conversation with a union or an employment lawyer rather than with a platform.

And it makes no promise about how it will be received. That varies more than anything else on this track, which is why nothing here tells you to disclose.

---

## 08 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

If this is a work device, remember it is stored on the device — and a work device is not always yours.

Keep anything you may need factually — dates, what was said, who was present — somewhere separate from this. This is for your state. That is for the record, and it belongs off a work device.

Any of these, or none.

- Where did it sit in your body?
- What was the occasion? Write what actually happened, without the reading.
- What did the auditing find? Write the sentence it used.
- Had anything actually gone wrong, or only possibly gone wrong?
- *What was this for* — what turned up, without needing to answer it?
- What did you say to yourself from across the room?
- What did you do today? A fact, not an assessment.
- What did you write here last time? Read it back — as if someone else wrote it.

That last instruction is deliberate. Reading your own account as though it were somebody else's is the same distancing move as the fourth step, and it's usually where people first hear how they talk to themselves.

---

## 09 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half exits in ways that look like modesty from inside and like something else from outside.

**The specific blind spot here** — it exits as absence. Not putting yourself forward, not saying the thing, not taking the place. From inside that's staying out of the way. From outside it's someone capable who didn't show up, and colleagues had to cover it. They rarely say so, because complaining about someone's self-doubt feels unkind.

**The second one** — the pre-emptive undercut. *This is probably rubbish, don't expect much, I'm not really the right person.* From inside it's managing expectations. From outside it hands them the job of talking you up before they can respond to the actual work, every time. It's the version people tire of quietly.

**The third one** — deferring. Agreeing with the room, not raising the objection, going along. From inside it's not being difficult. From outside it's the loss of your actual view, and the people who wanted it are the ones who notice.

**Their earlier information** — people who work with you often see it before you feel it. Worth asking one you trust: *what do you see me do?*

**Naming the act, not the character** — *"I didn't say what I thought in that meeting, and you ended up making the argument alone"* is ownership. *"I'm useless in meetings"* is not; it's the opinion again, it names nothing, and it asks them to argue with it.

If your account of yourself is a verdict rather than an act, you haven't done accountability. You've done the state, out loud, at somebody.

**No because.** The state is a real reason and it doesn't belong in the sentence.

**No self-attack.** On this protocol that isn't a matter of manners. Self-attack is the state's native mode, and an apology built from it hands the other person the job of reassuring you — which is the whole pattern, repeating inside the apology for the pattern.

**Describe what was observable, ask about the rest.** *"I've been quiet in things where I'd normally have said something. I'm not going to tell you what that's been like — I'd rather you told me."* Then let them answer without correcting it or apologising for the answer.

**The checkable change** — this repairs by saying one thing early rather than by becoming confident. *"I'm going to contribute in the first few minutes of meetings, even when I don't want to"* is small, specific and observable.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. This state will take anything external and feed it straight into the auditing; if that's happening, you're not doing this resource. And if someone with power over you has been undermining you, their account of your work isn't a reliable one.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Audit yourself against the room. Find it before they do.

Check how that landed. Replay the meeting. Work out what you revealed. Get to the fault first, so at least when it comes you saw it coming.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Being found out. Being seen not knowing. Losing the place I've been allowed to stand in.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the hour after everything*, or *the things I turned down because I'd already run how they'd go.*

---

**What it should be attending to instead**

It isn't feeling qualified. That doesn't arrive on demand and evidence has never settled it.

What's available is a different instruction about **who assesses**.

The old one assesses continuously, in advance, from inside — the one place it can't be done from. The successor does the work and lets the people whose job it is do the assessing.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *do it and let it be assessed. Stop marking my own.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *speaks in the first few minutes. Sends it after two passes. Asks a colleague what they thought rather than deciding for them.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Feet on the floor. Says the thing unsteady. Doesn't run the review on the way home.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*

*If this is a work device, remember it is stored on the device — and a work device is not always yours.*
