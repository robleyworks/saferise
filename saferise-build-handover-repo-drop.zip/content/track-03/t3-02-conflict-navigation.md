# t3-02 · The Conflict Navigation Protocol

**Label:** Navigate · **State:** Agitated · **Frameworks:** Porges, Maté · **extras:** `['advisory','invitation']`
**Resources: 11**

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Turn at four seconds.
> **VOICE** — level, unhurried, professional. Talks to someone competent who is in a difficult situation. No warmth-as-comfort.

There's someone you have to keep working with.

> **GOLD/PAUSE** — long

That's the part that makes this different from every other kind of conflict. You can't walk away and you can't have it out, because on Monday you're both still there.

> **GOLD/PAUSE**

Nothing here decides who's right. That question is real and it isn't the one we can work on.

---

### Recognition

Where is it?

> **GOLD/PAUSE** — long

Jaw. Shoulders. A tightness across the chest that arrives when their name comes up. Something in the stomach before a meeting they're in.

> **BLUE/ILLUSTRATION** — two forms at a fixed distance, neither moving, both braced.

One word. **Agitated.**

> **GOLD/PAUSE**

And notice what that leaves out. Them. What they said in the meeting. What they're like.

> **GOLD/PAUSE** — long

None of it in dispute. It's just that your read of them isn't available to work on, and the state in your jaw is.

---

### Regulation

Four counts in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six out. Longer out than in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the middle of your chest.

> **RED/ACTION** — jaw and shoulders. Offered, not instructed.

Unclench the jaw. Let the shoulders come down.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

This works at a desk, in a lift, in the moments before you go in. Nobody can see you doing it.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

There's more here if you want it.

> **GOLD/PAUSE**

If today is a day for getting your jaw loose and stopping there, stop there. That's complete.

> **GOLD/PAUSE** — very long

Still here.

> **GOLD/PAUSE**

Then — one thing first, and everything after rests on it.

> **GOLD/PAUSE**

If what's happening to you is targeted — if you're being undermined, belittled, or made unsafe — that's real, it's theirs, and nothing here hands you a share of it. That's a matter for people with authority, not for this.

> **GOLD/PAUSE** — long

Assuming it's ordinary conflict, and most of it is: two things can be true. They're difficult. And it landed on something already there.

> **GOLD/PAUSE** — very long

---

So — the size of it. Not whether you're right. Why *this* person, and why it doesn't leave you at five o'clock.

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — two braced forms, and beneath them a shared older line neither is looking at.

For a lot of people it isn't the disagreement. It's what the disagreement seems to say — that you're not respected here, or not credible, or that the version of you they're describing is the one everyone else can see.

> **GOLD/PAUSE** — very long

And that's why winning wouldn't settle it. You can be entirely right in a meeting and go home with the same feeling.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

I'm not telling you which one is yours, or where it came from. From outside your life nobody knows.

> **GOLD/PAUSE**

If something surfaced, leave it there. If nothing did, that's a real answer.

> **GOLD/PAUSE** — long

---

And the alertness around them — what's that protecting?

> **GOLD/PAUSE** — very long

Your standing. Your account of yourself in a room where accounts matter. Something in you decided it wouldn't be caught undefended again, and it's been on duty ever since.

> **GOLD/PAUSE**

Expensive. Also loyal.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before we move.

> **GOLD/PAUSE**

There'll be something behind that — usually *it's just work, I shouldn't be this affected.*

> **GOLD/PAUSE** — very long

Put that down. If what's on the table is whether you're respected, then of course it follows you home. Struggling with it is proportionate, not thin-skinned.

> **GOLD/PAUSE** — long

And something in you looked at your own half while the thing is still live. That's harder than building the case, and you've been doing the case for months.

> **GOLD/PAUSE** — very long

One more, and it's simply true rather than comforting. Almost every workplace has two people in exactly this, at any given time, and neither of them mentions it to anyone.

> **GOLD/PAUSE** — very long

None of that makes them right, and none of it makes you wrong. It means you know what the weight is made of now.

---

### Release

Two things are running.

> **GOLD/PAUSE**

There's the conflict, which is real and probably ongoing.

And there's the case. The one you'd present if there were ever a forum for it — with the examples, in order, and the thing they said in March.

> **GOLD/PAUSE** — long

Notice how it's going. You're winning.

> **GOLD/PAUSE**

Of course you are. The part of you assembling it is on your side — that's its whole job — so it hands you the better version every time. It couldn't do anything else.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And here's the cost at work specifically. A case that complete makes ordinary collaboration harder, because every neutral exchange gets read as evidence for or against it.

> **GOLD/PAUSE** — long

The conflict stays. Put down the case.

> **GOLD/PAUSE** — long

And the question. Not *why are they like this* — that's never produced a change in anybody.

**What was this for?**

> **GOLD/PAUSE** — long

Something in you went on alert around this person and hasn't come off it. It's reading tone, storing detail, tracking who said what in front of whom.

> **GOLD/PAUSE**

That's expensive, and it's what a system does when it's decided the ground isn't safe.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

---

### Rise

Step outside it.

Someone at a desk, breathing four and six, in a situation they didn't choose.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Speak to them as *you*.

*You don't have to like them. You have to be able to work.*

> **GOLD/PAUSE** — long

Those are different jobs and only one of them is required.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now forward, and specific. Not the meeting where you're vindicated — you don't control that and it may never come.

The next actual exchange. Where are you. What's the first thing out of your mouth. What does your voice do.

> **GOLD/PAUSE** — long

Civil and clear. Not warm, and not a performance of being fine. Those both cost more than they return.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing already true about your work. Something they have nothing to do with.

> **GOLD/PAUSE**

Now put it down. The case, the exchange, all of it.

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back. Jaw loose.

Nothing's resolved and they haven't changed. What's changed is that you're not carrying a brief into a room where nobody's hearing it.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are agitated.* The state, not your read of them.
**Breathe it** — Four in, six out. Jaw and shoulders.
**Put down the case** — You're winning one nobody's hearing.
**Next exchange only** — Civil and clear. Not warm, not a performance.

### Back

**Recognition** — Find it in your body: jaw, shoulders, chest tightening when their name comes up. Name the state in one word. Leave them out of it — your read of them isn't available to work on and the state in your jaw is.

**Regulation** — Four in, six out. Attention in the centre of your chest. Unclench the jaw, drop the shoulders. Works at a desk, in a lift, in the moments before you go in.

**Release** — Two things. The conflict, which is real. And the case — the one you'd present if there were a forum, with the examples in order. You're winning it, because the part assembling it is on your side. And a case that complete makes ordinary collaboration harder, because every neutral exchange becomes evidence. Put down the case, not the conflict.

**Rise** — See yourself from a distance. *You don't have to like them. You have to be able to work.* Then the next actual exchange: where you are, the first thing out of your mouth, what your voice does. Civil and clear.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

Sustained conflict with someone you can't avoid produces a low, continuous activation rather than episodes. In the body: jaw and shoulders held, a tightening across the chest triggered by their name or their calendar invitation, disturbed sleep before days you'll see them, and attention that tracks them in a room without being asked to.

The distinguishing feature is that it has no discharge point. Ordinary conflict resolves or ends. This one requires you to sit in the same meeting on Thursday.

**Why the state and your read of them come apart**

Your assessment of them may be entirely accurate. Nothing here disputes it.

But it isn't workable material — it's about someone else's behaviour. The state is running in you, and it's the half that answers to anything. Separating them concedes nothing: your read is exactly as intact afterwards.

**Why the exhale is longer than the inhale**

You can't decide a state down. You can decide your breathing, and it's the one reachable control on a system you otherwise can't get at. Lengthening the out-breath relative to the in-breath is what shifts things toward settled.

Jaw and shoulders matter here more than most, because this state holds in both continuously rather than in bursts, and both are visible across a table.

**Why Release goes after the case**

There's the conflict, and there's the brief you've been building.

Two different costs. The case is assembled by the part of you that's on your side, so it comes out unanswerable. That has one specific consequence at work: a complete case makes every neutral exchange readable as evidence. A short reply becomes curt, a decision becomes a manoeuvre, silence becomes a position. You end up in a conflict with someone who may, on a given Tuesday, simply be busy.

Putting it down doesn't mean deciding you were wrong. The conflict is exactly as real afterwards. What stops is the assembly.

**Why the question is about function**

*Why are they like this* asks about their psychology, which you can't see from where you stand and can't change. *What was this for* asks what your own response is doing — and what it usually surfaces is a system that has decided the ground isn't safe and is now reading tone, storing detail, and tracking who said what in front of whom.

That's expensive. It's also, frequently, correct — and knowing it's running is different from being run by it.

**Why the fourth step aims at civil rather than warm**

Warmth you don't feel is a performance, and it costs energy while reading as insincere. Coldness is legible across a room and escalates.

Civil and clear is available, cheap, and unambiguous — and it's the only version that doesn't require the other person to do anything first.

---

> **SHARED BLOCK** — insert *What this track works on* here, verbatim from `SHARED-t3-what-this-track-works-on.md`. Identical on all ten Track 03 protocols. Do not paraphrase or re-cut per protocol.

---

### What we rest on

**Polyvagal Theory — Stephen Porges** · *peer-reviewed* · supplies Recognition and the three state labels

Threat detection runs ahead of thought. The body reads a situation and moves before your thinking catches up. Porges describes three broad conditions: settled and socially available, mobilised for action, and shut down. Agitated, Unsteady and Numb are the member-facing names for those three. *Here it accounts for an alert that doesn't stand down between encounters, because the next encounter is on Thursday.*

*The anatomical premises are contested: a 2026 evaluation in* Clinical Neuropsychiatry *challenged them, with Porges replying in the same issue. The state distinctions are what this platform uses, and they hold independently of that dispute.*

**Compassionate Inquiry — Gabor Maté** · *clinical practice* · supplies Release and the way the question is asked

A response is treated as an adaptation rather than a defect. The kind of question you ask decides the kind of answer you get. *What is wrong with me* asks what is broken, and comes back with a list of what is broken. *What was this for* asks what it was doing, and comes back with something you can use. *Here it moves the question off their character, which is the only place it's been pointed for months.*

*A clinical practice, not a controlled research programme. Used here for the way the question is asked, and nothing wider.*

**Where the reading is yours** — this explains the machinery. Who's right, whether it's resolvable, and what to do about your position are readings that belong to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Unclench the jaw.** Teeth apart, tongue down. It holds here all day and it's visible across a table.

**Shoulders down and back.** Blades gently together, then sliding down. This state rides high in them and reads as braced.

**Long exhale, no ceremony.** Four in, six out, three or four cycles. In the lift, at the desk, before you go in.

**Feet into the floor.** Press down, feel it push back. Invisible while seated opposite someone.

**One horizon.** Look at the furthest thing you can see before a meeting. This state pulls focus to the nearest face.

**Leave the building at lunch.** Even briefly. Continuous proximity with no break is what turns a conflict into a condition.

*Notice when you're rehearsing the case and stop mid-sentence. Not to suppress it — just to see how often it's running.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with the state that comes from sustained conflict at work, using breath, attention and observation. It doesn't resolve the conflict, doesn't assess who's right, and doesn't make you like anyone.

**Pacing**

Once through is a complete use. Before an encounter is a legitimate time — this is one people run in a stairwell.

**What people commonly notice**

The case restarting immediately after the session. That's the state doing what it does; note it and come back to the next exchange.

Anger arriving that's larger than any single incident. That's the accumulation, and it's ordinary.

Relief that doesn't last past the next meeting. Also ordinary — this settles you for an encounter rather than resolving a situation.

**When to slow down**

If Release opens something much older — a much earlier version of the same dynamic, or something from outside work — you can stop there and come back to the breath.

If the state doesn't shift at all across several attempts, that's information rather than failure, and it may be telling you something about the situation rather than about your regulation.

**Where this stops being a regulation problem**

Some workplace conflict isn't conflict. If you're being belittled in front of others, excluded from things you need to do your job, given impossible work and then blamed for it, shouted at, threatened, or targeted for who you are — that is not a two-sided situation and treating it as one puts the responsibility in the wrong place.

That needs bodies with actual authority: HR, a union, occupational health, a regulator, or an employment lawyer. Get advice earlier than feels necessary, and keep your own records — dated, factual, and stored somewhere that isn't a work device.

**When a person in the room is the right tool**

Contact someone — a doctor, a helpline in your country, or a person you trust — if this is affecting your sleep or health across weeks, if you're dreading work in a way you can't shake, if you're using something to get through the day, or if you're having thoughts of harming yourself.

**Alongside other support**

If you're with a therapist, doctor, counsellor or coach, this sits alongside that and replaces nothing.

---

## 06 · Proximity Guide
*How close to stay.*

Workplace conflict rarely permits distance. How much contact there is, and of what kind, is usually the only variable available — and it's more available than it feels.

Three tiers. Which one yours belongs in is your read, on information nobody here has.

**Worth staying engaged with**

Where the disagreement is about the work rather than about you. Where they're difficult and consistent rather than difficult and targeted. Where a direct conversation hasn't been had, and there's no evidence it would go badly.

Distance isn't the tool here — it costs you the working relationship you still need. Regulation, plus one plain conversation, is.

**Worth reducing the surface area of**

Where contact reliably produces the state and a conversation has been had without changing anything. Where you're managing your own behaviour continuously to keep things level.

Reduction here is specific and professional rather than dramatic: written rather than verbal, a third person present, a meeting you send someone else to, decisions minuted, a channel you stop using. None of it announces anything and all of it reduces the surface.

Keeping records belongs here too. Dated, factual, off a work device. Not because you're building the case — that's what the third step asked you to put down — but because if this escalates you'll want the events, and memory reconstructs.

**Past what self-regulation is for**

Where you're being bullied, harassed, discriminated against, or made unsafe. Where your work is being deliberately undermined. Where you're frightened of someone at work.

That isn't a regulation problem, and treating it as one converts a situation needing institutions into a private failure of resilience. What it needs is HR, a union, occupational health, a regulator, or an employment lawyer — and it needs them earlier than most people ask.

**Using this**

Notice the tier. Then notice whether it's the tier you'd assign if a colleague described the same thing. People place their own situation lower than they'd place someone else's.

---

## 07 · Disclosure & Support
*A script for someone close.*

> **This one is for outside work.** A friend, a partner, someone who isn't in the building. The workplace conversation is a different act with different consequences — that's **Raising It**, the next resource.

For someone outside the situation, or a trusted colleague. Take these exactly, or change every word.

**Saying it**
> "There's an ongoing thing with someone at work that's taking up more of me than it should. I'm not looking for you to solve it. I'd rather one person knew."

**Describing what it's actually like**

> "It's physical. Jaw and shoulders all day, and my chest tightens when their name comes up in a calendar invitation."

> "The part I can't switch off is the case. I've got it in order, with examples, ready for a hearing that's never going to happen."

**How to tell it's coming**

> "I go quiet and correct. I start being unusually precise about things. I get short about something unrelated at home."

**What helps**

> "Let me say one example without agreeing they're terrible. If you join in, I've got a bigger case and less chance of working with them on Thursday."

> "Ask me what I actually need to be able to do. Usually it's smaller than winning."

**What doesn't**

> "Telling me to rise above it. I'm above it and underneath it at the same time, which is the problem."

> "Advice about what you'd do. You aren't in the building and you don't know the politics."

**If it's a colleague you're telling**
> "I want to say something and I'm not asking you to take a position or repeat it. I just don't want to be the only person who knows this is going on."

**If they ask what you're doing about it**

> "There's a method I run. I name it as a state rather than as what they're like, do a breathing pattern with attention on my jaw, and stop building the case — because a case that complete makes every ordinary exchange feel like evidence. Then I plan the next actual conversation. Civil and clear, not warm."

*Tell one person outside work. Carrying this entirely inside the building is what turns it into something you take home.*

---

## 08 · Raising It
*Who to tell, how much, and what to ask for.*

Telling a friend costs you nothing. Telling someone at work may go on a record, may change what you're trusted with, and can't be taken back. Different audience, different calculus, different words.

**First: you may not have to say anything.**

Not disclosing is a legitimate choice and often the right one. Nothing here pushes you toward telling anyone. What follows is for if you've decided to, or if something needs to change and saying nothing is what's costing you.

**Who you tell changes what happens**

These are not interchangeable, and most people don't know the difference.

**Your manager** — can change the work. Cannot usually keep it confidential, and shouldn't be expected to.

**HR** — exists to protect the organisation. That doesn't make them hostile, and it does mean they are not neutral and are not your representative. Useful for process; not the place to think out loud.

**Occupational health** — assesses fitness for work and recommends adjustments. Reports to the employer but usually only on what you consent to release. Frequently the most useful route available and almost nobody uses it.

**A union rep** — represents you specifically. If you have access, use it before HR rather than after.

**A colleague** — no power to change anything, and the only one who can be told without it becoming a process.

**Your GP** — outside the building entirely, and the only one who can put something in writing that an employer has to take seriously.

**One addition on this protocol.** If what's happening might be bullying or harassment rather than conflict, the order changes: union or occupational health first, HR second, and keep your own factual record from the start. Approaching the person directly can make those situations worse.

**How much to say**

*I'm dealing with something and it's affecting my sleep* is a different act from naming a condition. Both are honest. The first is almost always enough for a workplace conversation, and it's the version you can't be held to later.

Say what's affecting the work. You are not obliged to explain why.

**Make it a request, not a confession**

This is the move that works at work, and it's the one most people miss.

A specific ask travels. It's actionable, it's answerable, and it puts the conversation on ground the other person knows how to stand on.

An explanation of a state invites a response nobody has been trained to give, and it frequently ends in sympathy and no change.

> **The ask, on this protocol:** *"Can we agree that decisions about X get minuted? It's been unclear more than once and I'd rather it wasn't."*

> Or: *"I'd like a third person in the Thursday sessions. Not because of anything specific — I think it'd make them more productive."*

Structural asks work where a conversation about the relationship doesn't. They change the conditions without requiring anyone to admit anything.

**Put it in writing afterwards**

Verbal is deniable in both directions. If you've asked for something and it matters, follow the conversation with a short email — *thanks for the chat, just confirming we agreed X.* No tone, no argument, no explanation.

That isn't building a case. It's a record of what was agreed, and it protects both of you.

**Two things this resource can't do**

It isn't legal advice. Employment rights differ enormously by country and by contract, and where something might be unlawful, that's a conversation with a union or an employment lawyer rather than with a platform.

And it makes no promise about how it will be received. That varies more than anything else on this track, which is why nothing here tells you to disclose.

---

## 09 · Invitation to Repair
*Reopening it with them.*

⚠ **This resource assumes ordinary professional conflict between two people who can both move.** If you're being bullied, harassed or targeted, this is not the resource for that situation — see the Proximity Guide's third tier. Approaching someone directly can make those situations worse, and the right route is through people with authority.

Send or say it from the far side of the protocol. From inside the state it arrives as an opening position, and it will be answered as one.

**The rule that makes it sendable:** no history. One thing, forward-facing, with no examples attached. Examples turn a conversation into a hearing, and a hearing has a verdict.

**Sendable**
> I think you and I have got into something unproductive and I'd rather name it than keep working around it.
>
> I'm not looking to go back over anything. I'd like to work out how we do [the thing] from here.
>
> Whenever suits you.

**Shorter**
> Can we find a slot? Not about anything specific — I'd just rather clear the air than keep working around it.

**Where you've contributed and you know it**
> I've been short with you in meetings and that's on me, whatever else has been going on. I'd rather say it directly than let it keep setting the tone.

**Where you need something practical to change**
> I want to raise how [the process] works between us. It isn't a complaint about you. It's not working and I'd rather sort it than keep absorbing it.

**Before sending** — count the examples. If there's more than nought, cut them. Then read it for *always*, *never* and *every time*. Then check the setting: a corridor is a request, a meeting invitation with a subject line is a summons.

*If they don't take it, you've done the part that was yours. Whether they meet it is theirs.*

---

## 10 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

If this is a work device, remember it is stored on the device — and a work device is not always yours.

Keep anything you may need factually — dates, what was said, who was present — somewhere separate from this. This is for your state. That is for the record, and it belongs off a work device.

Any of these, or none.

- Where did it sit in your body?
- What actually happened today? Write it as an event, not as evidence.
- What did the case add today?
- Was your reaction proportionate to today's incident?
- *What was this for* — what turned up, without needing to answer it?
- What did you say to yourself from across the room?
- What do you actually need to be able to do? Not what you want to happen to them.
- What was the next exchange? How did it go?
- What did you write here last time? Read it back.

Keep anything you may need factually — dates, what was said, who was present — somewhere separate from this. This is for your state. That is for the record.

---

## 11 · Accountability & Empathy
*What it does outside you.*

⚠ **Read this first.** This resource asks you to look at your own conduct. That's the right work in ordinary professional conflict. If you're being bullied, harassed or targeted, looking harder at yourself is the mechanism that keeps people in those situations — the Proximity Guide's third tier is the resource for that.

Assuming that isn't where you are:

The protocol trains the interior half of the state. The other half exits into a workplace, where more people are watching than in any other setting on this platform.

**The specific blind spot here** — braced reads as hostile. The clipped reply, the correctness, the absence of the ordinary small exchange. From inside it's professionalism under difficult conditions. From outside it's someone who has decided about you, and they brace back — which produces the conflict you were managing.

**The second one** — the audience. Workplace conflict has witnesses, and both of you are being watched by people forming views. From inside you're handling it. From outside, a team is quietly deciding that working with either of you costs something.

**The third one** — the exchanges that get read as evidence. Once your case is complete, a short reply from them is curt, a decision is a manoeuvre, a silence is a position. Some of those readings are correct. Not all of them are, and you've lost the ability to tell which.

**Their earlier information** — a colleague who isn't in it can usually see both of you clearly. Worth asking one you trust: *how does this look from outside?* And then not defending the answer.

**Naming the act, not the character** — *"I've been short with you in meetings for months"* is ownership. *"I'm not good at conflict"* is not; it names nothing and asks them to accept a trait instead of an account.

**No because.** What they did is a real reason and it doesn't belong in the sentence. That's the case arriving as accountability, and at work it will be recognised instantly.

**No self-attack.** *"I've been a nightmare, I don't know how you've put up with me"* is out of register at work and puts a colleague in the position of managing your feelings.

**Describe what was observable, ask about the rest.** *"I've been curt with you and I know it. I'm not going to tell you how that's landed — I'd rather hear it."* Then let them answer without producing your version over the top.

**The checkable change** — this repairs by conduct rather than by resolution. *"I'll come to you directly before I raise something about your work elsewhere"* is small, specific and observable.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. And if what's happening is harassment or bullying, none of this applies. Their account of your conduct is not a reliable one, and the route is through people with authority rather than through repair.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Build the file. Track what they said and to whom.

Store the examples, in order, with dates. Read the tone in every exchange. Keep the brief current, so that if it ever gets heard, it's complete.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*My standing. Being misrepresented in a room I'm not in. Being caught undefended twice.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *how much of my week they occupy*, or *the fact that I'm now hard work with people who've done nothing.*

---

**What it should be attending to instead**

It isn't liking them. That isn't required and it may not be possible.

What's available is a different instruction about **what gets carried into the room**.

The old one brings the brief. The successor brings the next exchange only — civil, clear, and not a performance of being fine.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *turn up to the actual exchange, not to the hearing.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *replies to what was asked rather than to what it implied. Keeps a factual note somewhere separate and doesn't add to the case. Says one plain thing about the process rather than about them.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Unclenches the jaw. Answers the thing in front of them. Doesn't read the tone.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*

*If this is a work device, remember it is stored on the device — and a work device is not always yours.*
