# t3-04 · The Perfectionism Release Protocol

**Label:** Loosen · **State:** Agitated · **Frameworks:** Jung, Maté · **extras:** `[]`
**Resources: 9**

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Turn at four seconds.
> **VOICE** — brisk, plain, faintly impatient with the loop rather than with the listener. Does not reassure about the quality of the work.

It's finished, and you're still holding it.

> **GOLD/PAUSE** — long

Or it's someone else's note about it, and you've read it four times looking for what's underneath.

> **GOLD/PAUSE**

Either way there's a standard involved, and something is being measured against it repeatedly.

---

### Recognition

Where is it?

> **GOLD/PAUSE** — long

Chest, tight and high. Jaw. Shoulders up. A specific restlessness in the hands that wants to go back and change something.

> **BLUE/ILLUSTRATION** — a line drawn, then drawn again over itself. Same line, several times.

One word. **Agitated.**

> **GOLD/PAUSE**

Now — one question, and it takes a second. Whose standard is this?

> **GOLD/PAUSE** — long

Yours, held by you, and nobody has said anything.

> **GOLD/PAUSE**

Or somebody else's, arriving — a note, a review, something said in front of other people.

> **GOLD/PAUSE** — long

Both end up in the same place, and the second half of this works the same either way. But knowing which one you're in changes what you're arguing with.

---

### Regulation

Four counts in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six out. Longer out than in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the middle of your chest.

> **RED/ACTION** — hands off the work. Offered, not instructed.

If you're at the thing right now — hands off it. Physically. Away from the keyboard or the page.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Jaw apart. Shoulders down.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

### Release

Two things.

> **GOLD/PAUSE**

There's the standard. Real, often high for good reasons, and not the problem.

And there's the re-checking. Going back over something already finished. Reading the note again for the tone. Rewriting a sentence you rewrote yesterday.

> **GOLD/PAUSE** — long

Ask it directly: what's the last pass going to find that the previous three didn't?

> **GOLD/PAUSE** — very long

Nothing. That's the answer, and you know it, and it doesn't stop the next pass.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Because it isn't looking for anything. It's looking for permission to stop, and it can't issue one — there's no condition it could meet that would count as finished.

> **GOLD/PAUSE** — long

Keep the standard. Put down the re-checking.

> **GOLD/PAUSE** — long

And the question. Not *why can't I just be satisfied with something* —

**What was this for?**

> **GOLD/PAUSE** — long

Getting it right, before anyone else saw it, was protective once. Somewhere it mattered a great deal that nothing could be found.

> **GOLD/PAUSE** — long

So — what's underneath it? What did you decide would happen if something got through with a fault in it?

> **GOLD/PAUSE** — very long

I'm not answering that. It isn't mine.

> **GOLD/PAUSE**

If something came, it's yours. If nothing did, that's ordinary.

> **GOLD/PAUSE** — long

And the harder one. You might not want to put it down.

> **GOLD/PAUSE** — very long

Of course not — you think it's where the quality comes from. That the standard and the re-checking are the same thing, and letting go of one loses the other.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

They're not the same thing. The standard is a judgement. The re-checking is a search for a permission that doesn't exist. Nobody's asking you to lower anything.

> **GOLD/PAUSE** — very long

---

There's more here if you want it.

> **GOLD/PAUSE**

If today is a day for getting your hands off it and stopping there, stop there. That's complete, and it's the part that changes the afternoon.

> **GOLD/PAUSE** — very long

Still here.

> **GOLD/PAUSE**

Then — imagine it goes out with the fault still in it.

> **GOLD/PAUSE** — long

Not the practical consequence. You already know that, and it's usually small.

> **GOLD/PAUSE**

What does it feel like it would mean?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — a line drawn over itself several times, and beneath it a single earlier line, drawn once.

For a lot of people it isn't about the work being wrong. It's about being seen as someone who lets things through. Someone careless. Someone who can't be relied on.

> **GOLD/PAUSE** — very long

And underneath that there's often something plainer. That the standard is what's been holding your place — and without it, there'd be no particular reason to keep you.

> **GOLD/PAUSE** — very long

That isn't true. But it's what the re-checking believes, and it's why it can't stop on its own.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Whichever of those is nearest, or none of them — I'm not telling you. I don't know, and it isn't mine to name.

> **GOLD/PAUSE** — long

---

And what has the standard been protecting?

> **GOLD/PAUSE** — very long

Somewhere, being exact was how you stayed out of trouble. How you were taken seriously. How something was kept from happening.

> **GOLD/PAUSE**

It worked. It's still working. That's the whole difficulty.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before we move.

> **GOLD/PAUSE**

There'll be something arriving behind that — probably *this is ridiculous, it's only a piece of work.*

> **GOLD/PAUSE** — very long

Put that down. If the standard has been holding your place, then of course this is hard. Struggling with it is the appropriate response and not a lack of perspective.

> **GOLD/PAUSE** — long

And this. Something in you was willing to look at the thing you're most proud of and ask what it's for.

> **GOLD/PAUSE**

That's rarer than the standard is.

> **GOLD/PAUSE** — very long

One more, and it's simply true rather than comforting. Almost everyone who is good at something has some version of this running underneath it. It doesn't get discussed, because from outside it looks like diligence.

> **GOLD/PAUSE** — very long

None of that lowers anything. The standard is still yours. What's different is that you can see what it's carrying — and something you can see is something you can put down for an afternoon.

---

### Rise

Step outside it.

Someone at a desk, hands off the work, breathing four and six.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Speak to them as *you*.

*It's good enough to leave, and you can't tell from in here.*

> **GOLD/PAUSE** — long

That second half is the useful one. Nobody can assess their own work from inside a fourth pass. That's not a failure of judgement — it's a limit of position.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now — one thing, and make it a decision rather than an improvement.

Send it. Hand it over. Say the note's fair and move on. Give the piece to someone else and don't check their version.

> **GOLD/PAUSE** — very long

Small enough to do today, feeling exactly like this.

> **GOLD/PAUSE**

The standard was installed. This one you picked.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing already done. Not well done. Just done.

> **GOLD/PAUSE**

Now put it all down — the work, the note, the question. You don't have to carry it out of here.

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back. Hands where they are.

The standard is intact. Nothing's been lowered and nothing's been let go.

You've just stopped looking for a permission that was never going to arrive.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are agitated.* Whose standard is this?
**Breathe it** — Four in, six out. Hands off the work.
**Stop re-checking** — The next pass finds nothing. It never has.
**Decide, don't improve** — Send it. Hand it over. Let the note stand.

### Back

**Recognition** — Find it in your body: chest tight and high, jaw, shoulders, a restlessness in the hands that wants to go back and change something. Name the state in one word. Then sort it: is this your own standard, held by you with nobody having said anything — or somebody else's, arriving as a note or a review? Both end in the same place, but knowing which changes what you're arguing with.

**Regulation** — Four in, six out. Attention in the centre of your chest. Hands physically off the work. Jaw apart, shoulders down.

**Release** — Two things. The standard, which is real and isn't the problem. And the re-checking — going back over something finished, reading the note again for the tone. Ask what the next pass will find that the last three didn't. Nothing. It isn't looking for anything; it's looking for permission to stop, and it can't issue one. Keep the standard. Put down the re-checking.

**Rise** — See yourself from a distance. *It's good enough to leave, and you can't tell from in here.* Then one decision rather than one improvement: send it, hand it over, let the note stand. Then one thing already done — not well done, just done.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

This is a mobilised state maintained around a piece of work rather than a threat. In the body: tightness high in the chest, jaw and shoulders held, and a specific motor restlessness — the hands wanting to return to the thing and adjust it.

It runs after the work is functionally complete, which is the distinguishing feature. Effort applied before something is finished is just working. This is what continues afterwards.

**Two entry points, one mechanism**

**Your own standard**, held internally, with nobody having said anything. **Or somebody else's**, arriving as a note, a review, or a comment in front of others.

They feel completely different and they produce the same loop. Internally generated, the re-checking is looking for the fault before anyone finds it. Externally triggered, it's re-reading the note for what's underneath it. Both are searching for a resolution that the search itself can't produce.

The Recognition step forks so a member knows which they're in, because it changes what they're arguing with — themselves, or an absent person's opinion.

**Why the exhale is longer, and why the hands come off**

You can't decide a state down. You can decide your breathing, and it's the one reachable control. Lengthening the out-breath relative to the in-breath shifts things toward settled.

Taking your hands physically off the work matters more here than on most protocols, because the loop has a motor component. As long as the work is reachable, the state has somewhere to discharge into, and discharging into it is what keeps it running.

**Why Release goes after the re-checking, not the standard**

There's the standard — a judgement about quality, frequently well-founded, and not what this protocol is about.

And there's the re-checking, which presents as diligence and is a different thing entirely. The tell is in the question: *what will this pass find that the last three didn't?* The answer is reliably nothing, and knowing that reliably fails to stop the next pass.

That's because it isn't a search for faults. It's a search for permission to stop — and there is no condition the work could meet that would issue one. A process looking for something that cannot be produced doesn't terminate.

**Why the reluctance gets named**

Most people running this believe the standard and the re-checking are the same faculty, and that putting down one loses the other. That belief makes the third step impossible while it's unexamined, so it's said out loud: a standard is a judgement, and re-checking is a search for permission. Nothing here lowers anything.

**Why the surplus is worth attending to**

Where a reaction to a small fault outruns the fault, the excess is carrying information about something other than the work. An interpretive lens rather than a finding, and what it shows you is yours to read.

**Why Rise asks for a decision rather than an improvement**

Rehearsing the work being good enough is rehearsing a verdict you can't issue from inside a fourth pass. That's not a failure of judgement — it's a limit of position.

A decision is available regardless: send it, hand it over, let the note stand. And it's the only move that ends the loop, because the loop can only be ended by an action, never by an assessment.

---

> **SHARED BLOCK** — insert *What this track works on* here, verbatim from `SHARED-t3-what-this-track-works-on.md`. Identical on all ten Track 03 protocols. Do not paraphrase or re-cut per protocol.

---

### What we rest on

**Shadow & individuation — C. G. Jung** · *interpretive* · informs Release

What you decline to look at keeps running unattended. The usable test is proportion: when a reaction outruns the event that occasioned it, the surplus is carrying information about something other than the event. There's no finish line and nothing to complete. *Here it accounts for why a small correction can produce a disproportionate day.*

*Offered as a lens rather than a finding, with no controlled evidence behind it. What it shows you is yours to read.*

**Compassionate Inquiry — Gabor Maté** · *clinical practice* · supplies Release and the way the question is asked

A response is treated as an adaptation rather than a defect. The kind of question you ask decides the kind of answer you get. *What is wrong with me* asks what is broken, and comes back with a list of what is broken. *What was this for* asks what it was doing, and comes back with something you can use. *Here it stops the protocol becoming another quality audit, this time of yourself.*

*A clinical practice, not a controlled research programme. Used here for the way the question is asked, and nothing wider.*

**Where the reading is yours** — this explains the machinery. Whether the work is good enough, whether the note was fair, and what your standard is about are readings that belong to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Hands off, physically.** Away from the keyboard, the page, the phone. The loop has a motor component and reachable work keeps it fed.

**Long exhale, no ceremony.** Four in, six out, three or four cycles.

**Jaw apart, shoulders down.** Both hold here continuously.

**Close the file.** Not save-and-leave-open. Close it.

**Send one thing before you're ready.** Small, low stakes, genuinely finished. The experience of nothing happening is worth more than any amount of reasoning about it.

**Walk to a fixed point and back.** This state has no natural stopping place, so borrow one.

*When you notice you're re-reading something, name the pass number. Fourth. Fifth. Counting it is enough to interrupt it more often than not.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with the state that keeps you returning to finished work, using breath, attention and observation. It doesn't lower your standard and it doesn't assess your work.

**Pacing**

Once through is a complete use. Best used with the work out of reach.

**What people commonly notice**

Strong resistance at Release, because putting down the re-checking feels like agreeing to send something flawed. That discomfort is the work rather than a sign of doing it wrong.

The loop restarting immediately afterwards, sometimes about the session. Note it and come back.

Relief on actually sending something, often much larger than expected, and then the loop finding a new object within a day.

**When to slow down**

If Release opens something much larger — something about what a fault once cost you — you can stop there and come back to the breath.

If the protocol turns into an audit of everything you've ever sent that had a mistake in it, stop. That's the loop, running inside the step designed to interrupt it.

**When feedback is the entry point**

If this started with a note or a review, and the note was delivered publicly, repeatedly, or in a way designed to diminish you — that isn't a perfectionism problem. That's how the feedback was given, and it's a matter for the person's manager, HR, or a union rather than a regulation practice.

**When a person in the room is the right tool**

Contact someone — a doctor, a helpline in your country, or a person you trust — if you can't finish or submit things at all, if this is costing you sleep across weeks, if you're using something to get through it, if it's spread from work into everything else, or if you're having thoughts of harming yourself or punishing yourself.

**Alongside other support**

If you're with a therapist, doctor, counsellor or coach, this sits alongside that and replaces nothing.

---

## 06 · Disclosure & Support
*A script for someone close.*

> **This one is for outside work.** A friend, a partner, someone who isn't in the building. The workplace conversation is a different act with different consequences — that's **Raising It**, the next resource.

Take these exactly, or change every word.

**Saying it**
> "I get stuck on finished work. It isn't that I think it's bad — I just can't get to the point of leaving it alone. I'd rather you knew than thought I was being slow."

**Describing what it's actually like**

> "It's physical. Chest tight, jaw, and my hands actually want to go back to it. The wanting is in my hands before it's a thought."

> "The part that's hard to explain is that I know the next pass won't find anything. Knowing doesn't stop it. It isn't looking for faults — it's looking for permission to stop, and nothing can give it."

**How to tell it's coming**

> "I go quiet and stop answering things. I miss the deadline by a small amount. I say 'nearly done' several times."

**What helps**

> "Ask me to send it to you as it is. Not to review — just to have sent it. Getting it out of my hands is the whole thing."

> "Tell me one specific thing that worked. Not that it's great. Something that actually happened in it."

**What doesn't**

> "Telling me it's good enough. You can't know that yet, and neither can I from where I'm standing, so it just sounds like you want me to stop."

> "Asking why I care so much. I don't know, and it makes caring the problem."

**If it's a note you've been given**
> "I've been sitting with that feedback for three days. I'm not arguing with it. I'd just rather say out loud that I've been going round it than keep pretending I read it once."

**If they ask what you're doing about it**

> "There's a method I run. I name it as a state, work out whose standard is involved, take my hands off the work, and stop the re-checking — which turns out to be a search for permission rather than a search for mistakes. Then I make a decision instead of another improvement."

*Tell one person, ideally one who can receive things. The most useful thing anyone can do here is be somewhere to send something.*

---

## 07 · Raising It
*Who to tell, how much, and what to ask for.*

Telling a friend costs you nothing. Telling someone at work may go on a record, may change what you're trusted with, and can't be taken back. Different audience, different calculus, different words.

**First: you may not have to say anything.**

Not disclosing is a legitimate choice and often the right one. Nothing here pushes you toward telling anyone. What follows is for if you've decided to, or if something needs to change and saying nothing is what's costing you.

**Who you tell changes what happens**

These are not interchangeable, and most people don't know the difference.

**Your manager** — can change the work. Cannot usually keep it confidential, and shouldn't be expected to.

**HR** — exists to protect the organisation. That doesn't make them hostile, and it does mean they are not neutral and are not your representative. Useful for process; not the place to think out loud.

**Occupational health** — assesses fitness for work and recommends adjustments. Reports to the employer but usually only on what you consent to release. Frequently the most useful route available and almost nobody uses it.

**A union rep** — represents you specifically. If you have access, use it before HR rather than after.

**A colleague** — no power to change anything, and the only one who can be told without it becoming a process.

**Your GP** — outside the building entirely, and the only one who can put something in writing that an employer has to take seriously.

**How much to say**

*I'm dealing with something and it's affecting my sleep* is a different act from naming a condition. Both are honest. The first is almost always enough for a workplace conversation, and it's the version you can't be held to later.

Say what's affecting the work. You are not obliged to explain why.

**Make it a request, not a confession**

This is the move that works at work, and it's the one most people miss.

A specific ask travels. It's actionable, it's answerable, and it puts the conversation on ground the other person knows how to stand on.

An explanation of a state invites a response nobody has been trained to give, and it frequently ends in sympathy and no change.

> **The ask, on this protocol:** *"Can we agree what 'done' looks like for this before I start? I'd rather work to a stated bar than guess at one."*

> Or: *"I'm going to send you the draft at the point I'd normally do another pass. If it needs more, tell me — but I'd like the check to be yours rather than mine."*

Both hand the permission to stop to someone who can actually issue one, which is the thing the loop has been looking for.

**Put it in writing afterwards**

Verbal is deniable in both directions. If you've asked for something and it matters, follow the conversation with a short email — *thanks for the chat, just confirming we agreed X.* No tone, no argument, no explanation.

That isn't building a case. It's a record of what was agreed, and it protects both of you.

**Two things this resource can't do**

It isn't legal advice. Employment rights differ enormously by country and by contract, and where something might be unlawful, that's a conversation with a union or an employment lawyer rather than with a platform.

And it makes no promise about how it will be received. That varies more than anything else on this track, which is why nothing here tells you to disclose.

---

## 08 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

If this is a work device, remember it is stored on the device — and a work device is not always yours.

Keep anything you may need factually — dates, what was said, who was present — somewhere separate from this. This is for your state. That is for the record, and it belongs off a work device.

Any of these, or none.

- Where did it sit in your body?
- Whose standard was it — yours, or somebody else's arriving?
- Which pass were you on?
- What did the last pass actually change?
- *What was this for* — what turned up, without needing to answer it?
- What did you say to yourself from across the room?
- What was the decision? Did you make it?
- If you sent something: what happened?
- What did you write here last time? Read it back.

That second-to-last one earns its place. The state produces a confident prediction about what happens when something imperfect goes out, and your own record of what actually happened is the only evidence you have that the state didn't write.

---

## 09 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half lands on people waiting for something.

**The specific blind spot here** — from inside, holding work back is care. From outside it's a thing that hasn't arrived, and nobody can tell the difference between work being polished and work not being done. The care is invisible; the absence isn't.

**The second one, and it's the consequential one** — **re-checking finished work is usually what stops you delegating, and not delegating is what keeps the work at your level.** From inside, doing it yourself is faster and safer. From outside, it's a bottleneck with a person in it, and the people who might have done it are doing something less.

**The third one** — the received standard. Applied to your own work it's private. Applied to other people's, silently, it produces a colleague who never quite passes and can't work out why, because the criteria have never been stated.

**Their earlier information** — worth asking whoever waits on your work: *how late does it usually feel to you?* Expect a different number from yours.

**Naming the act, not the character** — *"I held that for a week after it was finished and you were waiting on it"* is ownership. *"I'm a perfectionist"* is not; it names nothing, and it's frequently offered as a credential rather than an account.

**No because.** The standard is a real reason and it doesn't belong in the sentence.

**No self-attack.** *"I'm impossible, I know, I don't know why anyone works with me"* moves the burden across to someone who has been waiting patiently.

**Describe what was observable, ask about the rest.** *"I've been holding things past the point they were done. I'm not going to tell you what that's been like — I'd rather you told me."*

**The checkable change** — this repairs by sending rather than by relaxing. *"I'm going to send it at the point I'd normally start the third pass"* is small, specific and observable.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. And if the standard you're working to was set by someone who moves it, that isn't perfectionism and this isn't the resource for it.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Check it again. Find permission to stop.

Go back over it. Read the note once more for the tone. Rewrite the sentence you rewrote yesterday. There's no condition that counts as finished, so it keeps going.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Something getting through with a fault in it. Being the person who lets things through. Being found careless.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the weekends*, or *the people waiting on me who couldn't move.*

---

**What it should be attending to instead**

It isn't lowering the standard. Nobody's asking, and the standard isn't the problem.

What's available is a different instruction about **what ends it**.

The old one waits for a permission that can't be issued. The successor ends it with a decision, which is the only thing that ever ends it.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *end it with a decision, not with a feeling.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *sends it at the point they'd start the third pass. Hands it over and doesn't check the other version. Agrees what done looks like before starting.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Hands off the work. Makes the call rather than another pass. Doesn't reopen it.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*

*If this is a work device, remember it is stored on the device — and a work device is not always yours.*
