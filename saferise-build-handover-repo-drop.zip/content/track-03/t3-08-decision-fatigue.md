# t3-08 · The Decision Fatigue Protocol

**Label:** Decide · **State:** Numb · **Frameworks:** Porges, HeartMath · **extras:** `['advisory']`
**Resources: 10**

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in late, low. Turn at four seconds.
> **VOICE** — low, few words, generous pauses. Offers rather than instructs. Asks nothing that requires a choice.

Somebody is waiting on an answer from you.

> **GOLD/PAUSE** — long

Probably several people. And they're all small ones, and you can't produce any of them.

> **GOLD/PAUSE** — long

This one asks almost nothing of you. If you only do the first part, that's a complete use of it.

---

### Before we start

> **RED/ACTION** — small deliberate movement. Offered, never insisted on.

Would your fingers move?

> **GOLD/PAUSE** — very long

And your feet, into whatever's underneath them.

> **GOLD/PAUSE** — very long

That happened without a decision. Worth noticing, on a day like this one.

---

### Recognition

One word, and we're not going hunting for it.

> **GOLD/PAUSE**

**Numb.**

> **GOLD/PAUSE** — very long

You don't have to find where it sits. That's often hard here, and not finding it belongs to the state rather than to any failure of yours.

> **BLUE/ILLUSTRATION** — a set of open doors, all the same size. None of them marked.

> **GOLD/PAUSE** — long

And here's the thing people get wrong about this one. It isn't that the decisions are hard. Most of them are trivial.

> **GOLD/PAUSE**

It's that the part of you that decides has been running all day and it's out. That's not a character problem. It's a resource that ran down.

---

### Regulation

Contact first. Counting can wait.

> **RED/ACTION** — hand to sternum, or hold the opposite arm. Offered, not instructed.

A hand on your chest, or hold your own arm. Whichever is nearer.

> **GOLD/PAUSE** — very long

Let it stay there. Warmth and pressure gets through when finer things don't.

> **GOLD/PAUSE** — long

Now the breath, and it doesn't have to be four and six today.

> **TEAL/BREATH** — in, slow
> **TEAL/BREATH** — out, longer

Longer out than in. That's the only part that matters.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Count it if you can. Don't if you can't. Nothing here needs choosing between.

> **GOLD/PAUSE** — extended

---

### Release

Two things are going on.

> **GOLD/PAUSE** — long

There's the volume. Genuinely a lot of decisions, most of them routed to you by other people, and that's real.

And there's the re-deciding.

> **GOLD/PAUSE** — long

Going back over one you already made. Reopening the thing that was settled on Tuesday. Holding four of them in the air at once because none feels finished enough to put down.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

That's the expensive one. Each pass costs what the original decision cost, and the second pass never produces a different answer than the first.

> **GOLD/PAUSE** — long

The volume stays. Put down the re-deciding.

> **GOLD/PAUSE** — long

And the question. Not *why can't I just make my mind up* — you make your mind up constantly. That's the whole problem.

**What was this for?**

> **GOLD/PAUSE** — long

Something in you has decided that getting one wrong carries a cost, and has been checking each one twice as insurance.

> **GOLD/PAUSE**

Reasonable enough, once. Applied to forty a day, it's what emptied the tank.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Nothing needs answering today.

> **GOLD/PAUSE** — very long

---

There's a bit more, and it asks very little.

> **GOLD/PAUSE**

If you'd rather stop there, stop. Come back to the breath and end. That's complete.

> **GOLD/PAUSE** — very long

Still here.

> **GOLD/PAUSE**

Then — what would it mean to get one wrong?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — a set of open doors, and beneath them a single older doorway.

Not the actual consequence. Most of these are small and you know it, which is what makes the weight of them confusing.

> **GOLD/PAUSE** — long

Underneath, for a lot of people, it isn't about the decision. It's that being the one who decides means being the one it comes back to.

> **GOLD/PAUSE** — very long

And somewhere, being the one it came back to went badly.

> **GOLD/PAUSE** — very long

I'm not telling you that's yours. If it landed, leave it there. If it didn't, that's a real answer too.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

---

And the double-checking — what has that been protecting?

> **GOLD/PAUSE** — very long

You from being the person who got it wrong. Checking twice was insurance, and it worked.

> **GOLD/PAUSE**

Applied to one decision it costs almost nothing. Applied to forty a day, it's what emptied you.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before we move.

> **GOLD/PAUSE**

There'll be something behind that. Probably *it's only a lunch order, what is wrong with me.*

> **GOLD/PAUSE** — very long

Put that down. If deciding means being answerable, then small ones cost the same as large ones, and struggling with them is arithmetic rather than a flaw.

> **GOLD/PAUSE** — long

And something in you looked at that on a day with nothing spare in it.

> **GOLD/PAUSE**

That's the part that got you here.

> **GOLD/PAUSE** — very long

One more, and it's simply true rather than comforting. The people who end up here are usually the ones others bring things to. It's a consequence of being trusted, and almost nobody says so out loud.

---

### Rise

Step back a little.

Someone at a desk with a hand on their chest, breathing four and six.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Speak to them as *you*.

*You haven't run out of judgement. You've run out of today's.*

> **GOLD/PAUSE** — long

Those are different, and only one of them is a problem.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now — one decision. Just one, and make it the smallest available.

> **GOLD/PAUSE** — long

Not the important one. The one that's been sitting there for three days because it's too small to be worth the effort and too present to ignore.

> **GOLD/PAUSE** — very long

Decide it now, badly if necessary, and don't revisit it.

> **GOLD/PAUSE**

That's the whole move. One thing that stops being in the air.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing already decided today. Something you settled and haven't reopened.

> **GOLD/PAUSE** — long

Now put the rest of it down. All of it. You don't have to carry any of this out of here.

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back slowly.

The queue hasn't changed. That was never on offer.

What's different is that you've stopped spending on ones that were already made.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

*Before you start — move something. Fingers, feet into the floor.*

**Name it** — *You are numb.* Not indecisive. Out of today's.
**Contact, then breath** — Hand on your chest. Longer out than in.
**Stop re-deciding** — The second pass never gives a different answer.
**One small one, now** — Badly if necessary. Then don't reopen it.

### Back

**Move first** — Before anything else, move something small. Movement comes before attention here, because attention is the part that's reduced.

**Recognition** — One word. *Numb.* Don't search for where it sits. And know this: it isn't that the decisions are hard — most are trivial. It's that the part of you that decides has been running all day and it's out. A resource that ran down, not a character problem.

**Regulation** — Contact before counting. Hand on your chest, or hold your own arm. Then longer out than in. Count if you can, don't if you can't. Nothing here needs choosing between.

**Release** — Two things. The volume, which is real and mostly routed to you by other people. And the re-deciding — reopening what was settled, holding four in the air because none feels finished. Each pass costs what the original cost, and the second never gives a different answer. Put down the re-deciding.

**Rise** — *You haven't run out of judgement. You've run out of today's.* Then one decision, the smallest available — the one that's been sitting three days because it's too small to be worth the effort. Decide it now, badly if necessary, and don't revisit it.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

Deciding draws on something finite. After enough of it the capacity reduces, and what reduces isn't your judgement in general — it's the ability to close.

In the body: heaviness, slowed thought, a flattening of preference, and a marked difficulty starting anything. Sensation is muffled rather than gone, which is why locating it precisely is hard.

The characteristic sign is that trivial decisions become the impossible ones. Lunch. Which email first. Whether to reply now or later. Anything with real stakes usually still gets made, because the stakes supply the push. It's the small ones that sit.

**Why it isn't indecision**

Indecision is difficulty choosing between options. This isn't that — the options are usually obvious and the choosing is what's unavailable.

Naming it as a depleted resource rather than a character trait matters more here than the naming does on most protocols, because the alternative reading is *I've become useless*, which is both wrong and expensive.

**Why movement comes before attention**

Every other protocol opens by asking you to find where the state sits and hold attention there. In a reduced state that's the least available capacity, and opening that way produces someone who has failed at step one.

Small deliberate movement asks nothing of attention and nothing of choice — which matters here specifically, since a protocol that opens by asking a depleted decider to decide something has misunderstood its own subject.

**Why contact comes before the count**

Warmth and pressure at the sternum requires nothing of you and registers when finer inputs don't. The breath follows: lengthening the out-breath relative to the in-breath is what shifts things toward settled. The count is offered rather than required — in this state, counting is one more thing to get right.

**Why Release goes after the re-deciding**

There's the volume, which is real and largely arrives from elsewhere. And there's the re-deciding — reopening what was settled, holding several in the air because none feels closed.

Two different costs. Reopening a decision costs approximately what the original cost, and the second pass reliably produces the same answer. Meanwhile anything held open occupies capacity continuously, so four unclosed decisions cost more than four made ones — regardless of how small they are.

That's the mechanism, and it's why the fourth step asks for a closure rather than a good decision.

**Why the question isn't about willpower**

*Why can't I make my mind up* misreads it — you have made your mind up, repeatedly, all day. What surfaces from *what was this for* is usually a system that decided getting one wrong carries a cost and has been double-checking as insurance. Sensible once. Applied forty times a day, it's what emptied the reserve.

**Why the fourth step asks for the smallest decision available**

Not the important one — that needs a resource you haven't got today, and forcing it produces a decision you'll reopen tomorrow, which is the loop.

The smallest one, closed and not revisited, does something specific: it removes an item from the set being held open. That returns capacity immediately, and it's the only move available in this state that does.

---

> **SHARED BLOCK** — insert *What this track works on* here, verbatim from `SHARED-t3-what-this-track-works-on.md`. Identical on all ten Track 03 protocols. Do not paraphrase or re-cut per protocol.

---

### What we rest on

**Polyvagal Theory — Stephen Porges** · *peer-reviewed* · supplies Recognition and the three state labels

Threat detection runs ahead of thought. The body reads a situation and moves before your thinking catches up. Porges describes three broad conditions: settled and socially available, mobilised for action, and shut down. Agitated, Unsteady and Numb are the member-facing names for those three. *Here it accounts for the reduction — a system carrying more than it can meet, with no single thing to push against, comes down rather than mobilising.*

*The anatomical premises are contested: a 2026 evaluation in* Clinical Neuropsychiatry *challenged them, with Porges replying in the same issue. The state distinctions are what this platform uses, and they hold independently of that dispute.*

**Cardiac coherence — HeartMath** · *peer-reviewed* · supplies Regulation and the count

At roughly six breath cycles a minute, heart rhythm and breath settle into a single smooth wave rather than two competing ones, close to a rhythm the body's blood-pressure regulation already runs at. Four in, six out lands near that rate. The uneven ratio is the mechanism. *Here the count is offered rather than required, because in this state a count is one more thing to get right.*

*The finding is used here; the wider programme is not. There is no measurement of coherence anywhere on this platform and no score attached to any breath.*

**Where the reading is yours** — this explains the machinery. Whether the volume is reasonable, and what to do about where it comes from, are readings that belong to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

Small, deliberately. Any one on its own is a complete use.

**Move one small thing.** Fingers, feet into the floor. No choice required.

**Hand to sternum, or hold your own arm.** The input this state takes when it takes little else.

**Longer out than in.** Three or four breaths. No counting required.

**Close one thing.** Any decision, however small. Reply to the email with the shortest true answer. The point is closure, not quality.

**Remove one choice from tomorrow.** Same lunch, same route, same order. Not a life system — one fewer thing.

**Stand up and go outside the door.** Air and light. Nothing further required.

*If someone asks you to choose between two things today, it's entirely legitimate to say "you pick." That isn't abdication. It's triage.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with a reduced state, using movement, contact, breath and observation. It doesn't restore capacity — only rest does that — and it doesn't make the queue shorter.

**Pacing**

Any single part is a complete use. Moving your fingers and stopping there counts. There's no requirement to reach the fourth step.

**What people commonly notice**

Very little during it, which is common here.

Relief on closing the small decision, often larger than the decision warrants. That's the capacity returning, and it's worth knowing about — it's the fastest available signal that the mechanism is real.

Tiredness afterwards.

**When to slow down**

If the fourth step turns into an attempt on the important decision, stop. That's the state trying to spend what it hasn't got, and the decision made from there gets reopened tomorrow.

If Release opens something much larger than today's load, you can stop there and come back to the breath.

**When it isn't decision fatigue**

If the flatness extends past decisions into everything, if it's been weeks rather than days, or if rest doesn't touch it — that's closer to Burnout & Overload than to this. The distinction matters because the answers are different: this one responds to closing things and to reducing the input, and that one responds to rest and often to a doctor.

**When a person in the room is the right tool**

Contact someone — a doctor, a helpline in your country, or a person you trust — if you can't decide anything at all rather than merely struggling, if this has persisted across weeks, if you're using something to get through the day, or if you're having thoughts of harming yourself.

**Alongside other support**

If you're with a therapist, doctor, counsellor or coach, this sits alongside that and replaces nothing.

---

## 06 · Proximity Guide
*How close to stay.*

Decision load has a source, and it's usually other people routing choices to you. How much of that continues is a real variable and it's more available than it feels.

Three tiers. Which one yours belongs in is your read, on information nobody here has.

**Worth staying engaged with**

Where the volume is high but the decisions are genuinely yours to make — your remit, your call, your consequences. Where asking for something to change produces a change.

Distance isn't the tool here. Closing faster is, and delegating what belongs elsewhere.

**Worth reducing the surface area of**

Where decisions arrive because you've historically made them rather than because they're yours. Where people bring you options instead of recommendations. Where you're the default for anything ambiguous.

Reduction is specific: a standing answer instead of a case-by-case one, a decision you hand to whoever raised it, a request for a recommendation rather than a list, a channel where you stop being copied in.

Two things worth naming here. **Delegating is decision reduction**, and it's the one most often blocked by a different protocol — re-checking other people's work keeps the decisions on your desk. And **a default is worth more than a good decision**, because a default costs nothing to apply.

**Past what self-regulation is for**

Where you're accountable for decisions you don't have the authority or the information to make. Where the volume is structurally impossible and has been for a long time. Where you're being made unwell by it.

That isn't a regulation problem. It's a resourcing or a role problem, and it needs someone with authority — a manager, occupational health, HR, or a union — rather than a practice.

**Using this**

Notice the tier. Then notice whether it's the tier you'd assign if a colleague described the same volume.

---

## 07 · Disclosure & Support
*A script for someone close.*

> **This one is for outside work.** A friend, a partner, someone who isn't in the building. The workplace conversation is a different act with different consequences — that's **Raising It**, the next resource.

Take these exactly, or change every word.

**Saying it**
> "I've got nothing left for choosing things at the moment. It isn't about anything at home. If I go blank when you ask me what I want for dinner, that's what's happening."

**Describing what it's actually like**

> "It isn't that things are hard to decide. Most of them are obvious. It's that the closing part has gone — I can see the answer and I can't land on it."

> "And it's the small ones that go first. I'll sign off something significant at four and then stand in the kitchen at seven unable to pick a meal."

**How to tell it's coming**

> "I start saying 'whatever you like' to everything. I go quiet in the evening. I stop having preferences."

**What helps**

> "Decide for me and tell me what we're doing. That isn't me being difficult — being handed a plan is the most restful thing in the world right now."

> "Ask closed questions. 'Pasta or curry' I can do. 'What do you fancy' I genuinely can't."

**What doesn't**

> "Options. Even kind ones. Three restaurants to choose from is three more decisions."

> "Telling me to relax. Relaxing isn't a decision I can make either."

**If it's affecting the household**
> "I know I've been useless at planning anything lately and it's landed on you. I'm not going to pretend it hasn't. Can we do standing arrangements for a bit — same night, same thing — so neither of us has to keep choosing?"

**If they ask what you're doing about it**

> "There's a method I run. It starts small — move something, name it, hand on my chest before any breathing. Then I stop re-deciding things I already decided, which turns out to be where most of it goes. Then I close one small thing and don't reopen it."

*Tell one person. This is a state that reads as indifference from outside, and one sentence stops it being taken personally.*

---

## 08 · Raising It
*Who to tell, how much, and what to ask for.*

Telling a friend costs you nothing. Telling someone at work may go on a record, may change what you're trusted with, and can't be taken back. Different audience, different calculus, different words.

**First: you may not have to say anything.**

Not disclosing is a legitimate choice and often the right one. What follows is for if you've decided to, or if something needs to change and saying nothing is what's costing you.

**Who you tell changes what happens**

**Your manager** — can change what gets routed to you, which is the actual solution. Cannot usually keep it confidential.

**Whoever brings you the decisions** — often more useful than your manager, and a much smaller conversation. Most people bringing you options would happily bring a recommendation instead; nobody has asked them to.

**HR** — exists to protect the organisation. Not hostile, not neutral, not your representative.

**Occupational health** — the right route if this has gone on for months or arrived with exhaustion.

**How much to say**

*I'm carrying a lot of decisions at the moment* is a different act from describing a state. The first is a workload conversation, which is ordinary. The second invites a response nobody has been trained to give.

**Make it a request, not a confession**

> **The ask, on this protocol:** *"When you bring me these, could you bring a recommendation rather than the options? I'll almost always go with it, and it'll be faster for both of us."*

> Or: *"Can we agree a default for X so it doesn't come to me each time?"*

> Or: *"Which of these actually needs me? I think two of them could be decided closer to the work."*

The first is the highest-value sentence on this protocol. It costs the other person almost nothing and removes most of the load.

**Put it in writing afterwards**

If a default or a delegation is agreed, confirm it in one line. Otherwise it lasts a fortnight.

**Two things this resource can't do**

It isn't legal advice. And it makes no promise about how it will be received, which is why nothing here tells you to disclose.

---

## 09 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

If this is a work device, remember it is stored on the device — and a work device is not always yours.

One line is a complete entry.

- Could you find where it sat, or not? Either is fine.
- How many decisions were in the air at once?
- Which one had you already made and reopened?
- What was the smallest one? Did you close it?
- *What was this for* — anything, or nothing? Nothing is a real answer.
- What did you say to yourself from across the room?
- Which of today's decisions weren't actually yours?
- What did you write here last time? Read it back — without comparing.

That second-to-last one is worth keeping across a fortnight. A pattern in whose decisions you're making is more useful than any single day's count.

---

## 10 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half lands on people waiting for an answer.

**The specific blind spot here, and it's the consequential one** — **decisions that don't get made get made by default, by someone else, or by the deadline.** From inside, holding one open is being careful. From outside, nothing arrived, and the situation resolved itself in whatever direction it was already going.

**The second one** — the people waiting. A small decision held for three days blocks somebody's work for three days, and they usually can't say so because it's too small to chase.

**The third one** — at home, it reads as indifference. *Whatever you like* said forty times is heard as not minding, and after a while people stop offering. From inside it's the only available answer.

**Their earlier information** — worth asking whoever brings you decisions: *how long do these usually sit with me?* Expect longer than you'd say.

**Naming the act, not the character** — *"I sat on that for a week and you couldn't move"* is ownership. *"I'm hopeless at the moment"* is not; it names nothing and asks them to be understanding about an unspecified thing.

**No because.** The volume is a real reason and it doesn't belong in the sentence.

**No self-attack.** *"I'm useless, I don't know how you put up with me"* asks them to reassure you while they're still waiting on the thing.

**Describe what was observable, ask about the rest.** *"I've been slow on things you needed. I'm not going to tell you what that's cost you — I'd rather hear it."*

**The checkable change** — this repairs by closing fast rather than by deciding well. *"If it's small, I'll answer the same day even if the answer is rough"* is small, specific and observable.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. And if you're being asked to decide things you have neither the authority nor the information for, that isn't fatigue and this isn't the resource for it.

---

## 12 · The Decision
*What takes over.*

Short version today. This one asks very little.

---

**What's running now**

Check it twice. Don't be the one who got it wrong.

Reopen the one that was settled. Hold four in the air because none feels closed. Insurance, applied to everything, including the ones that don't warrant it.

It isn't a fault. It's been doing a job.

---

**What takes over**

It isn't deciding better. There's nothing left to decide with today.

What's available is closing one, badly, and not reopening it.

> **One line. What should it be doing instead?**

Something like: *close the small ones fast and leave them closed.*

Yours, if you've got one. If you haven't, leave it and come back — this one keeps.

---

**Who runs the next one**

Not who you are once this lifts. Who's in it while it's happening.

> **One thing they do, in the middle of one.**

*Answers the smallest one with the shortest true answer. Doesn't revisit it. Says you pick, where that's honest.*

---

**Come back to it**

This gets rewritten and nobody arrives at it. On a day like today, having written one line is the whole of it.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*

*If this is a work device, remember it is stored on the device — and a work device is not always yours.*
