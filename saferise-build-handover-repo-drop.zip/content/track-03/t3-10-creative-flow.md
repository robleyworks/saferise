# t3-10 · The Creative Flow Protocol

**Label:** Unlock · **State:** Unsteady · **Frameworks:** Kross, Watts · **extras:** `[]`
**Resources: 9**

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Turn at four seconds.
> **VOICE** — light, curious, unhurried. The least heavy protocol on this track. Nothing is wrong and nobody is in trouble.

It won't come.

> **GOLD/PAUSE** — long

And you've been at it for a while now, which is the part that's actually the problem.

> **GOLD/PAUSE**

Nothing here is going to unlock anything. That's not a thing anyone can do to you, and if it were, it would have happened by now.

---

### Recognition

Where is it?

> **GOLD/PAUSE** — long

Chest, tight in a low way. Jaw. Something behind the eyes. Shoulders that have crept up over the last hour without any input from you.

> **BLUE/ILLUSTRATION** — a closed hand and an open one, drawn at the same size.

One word. **Unsteady.**

> **GOLD/PAUSE**

Notice what that word doesn't say. It doesn't say the work is bad. It doesn't say you've lost it.

> **GOLD/PAUSE** — long

And notice something else. There are two states available for this kind of work, and you can only be in one at a time.

One of them is narrow and pushing. The other is wide and receiving.

> **GOLD/PAUSE**

You're in the first one. That's all that's happened.

---

### Regulation

Four counts in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six out. Longer out than in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the middle of your chest.

> **RED/ACTION** — hands off the work. Offered, not instructed.

Hands off it. Away from the keyboard, the page, the instrument.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Let the shoulders come down. Unclench the jaw.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And now something specific to this one. Let your eyes go soft — look at the whole room rather than at anything in it.

> **GOLD/PAUSE** — long

Wide rather than narrow. That's the whole move, and it's most of what's been missing.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

### Release

Two things are going on.

> **GOLD/PAUSE**

There's the block, which is real. Something isn't arriving.

And there's the forcing. Staying at it. Going back at it. Trying the same approach with more effort, on the assumption that effort is what's short.

> **GOLD/PAUSE** — long

Here's the trouble with that, and it's not a moral point.

The forcing narrows you. And what you're reaching for only shows up in the wide state — the one that takes things in sideways, notices what's next to the thing, connects two items that weren't filed together.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

So the harder you push, the further you get from the only condition it arrives in. That's why the shower works and the desk doesn't.

> **GOLD/PAUSE** — long

The block stays. Put down the forcing.

> **GOLD/PAUSE** — long

And the question. Not *what's wrong with me that I can't do this any more* —

**What was this for?**

> **GOLD/PAUSE** — long

Something in you decided this had to come, today, on schedule, and has been applying pressure ever since. That's usually not about the work. It's about what the work is carrying — a deadline, a reputation, whether you're still any good.

> **GOLD/PAUSE** — long

Which is a lot to hang on an afternoon.

> **GOLD/PAUSE** — very long

---

One further, if there's room. If there isn't, go for a walk — that's the better use of the next hour anyway.

> **GOLD/PAUSE** — long

Still here.

> **GOLD/PAUSE**

Then — what does it feel like it would mean, if it doesn't come?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — a closed hand and an open one, and beneath both an older pair drawn the same size.

Not the deadline. That's real and it's the smaller half.

> **GOLD/PAUSE** — long

For a lot of people it's whether they're still someone who can do this. Whether the thing they've been is something they still are.

> **GOLD/PAUSE** — very long

And under that, sometimes: *if I can't do this, I don't know what I'm for.*

> **GOLD/PAUSE** — very long

Which is a great deal to ask of one afternoon's work, and it's why the pressure narrows you so fast.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

I'm not telling you that's yours. From outside your life nobody knows.

> **GOLD/PAUSE** — long

And the forcing — what's it protecting?

> **GOLD/PAUSE** — very long

The thing you're afraid of losing. It's pushing because it thinks pushing is how you keep hold of it.

> **GOLD/PAUSE**

Wrong about the method. Right about what's at stake.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before we move.

> **GOLD/PAUSE**

Something will arrive behind that — usually *it's just work, get a grip.*

> **GOLD/PAUSE** — very long

Put it down. If what's on the table is what you're for, then of course an empty afternoon does this to you.

> **GOLD/PAUSE** — long

And something in you looked at that instead of going back at the work for a fifth time.

> **GOLD/PAUSE** — very long

One more, simply true rather than comforting. Everyone who makes anything has weeks like this, and almost none of them mention it while it's happening — which is why yours feels like the end of something.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

---

### Rise

Step outside it.

Someone at a desk, hands off the work, eyes soft, breathing four and six.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Speak to them as *you*.

*You're not blocked. You're narrow. Those are different problems.*

> **GOLD/PAUSE** — long

One of them has no solution. The other one has several, and none of them involve trying harder.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now — put your attention somewhere on purpose, and not on the thing that won't come.

> **GOLD/PAUSE**

Not on the finished piece. That one does nothing for you, and picturing it is part of what's been narrowing you.

> **GOLD/PAUSE** — long

On you, doing the work. Not producing it — doing it. The physical part. Where you are, what's in your hands, what the first ordinary movement is.

> **GOLD/PAUSE** — very long

That's the version that's actually available today, and it's the one that lets the wide state back in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one small thing you'll do next. Something that isn't more of the same. Work on a different part. Do the boring section. Go outside. Make it worse on purpose and see what happens.

> **GOLD/PAUSE** — long

Not a technique. Just anything that isn't the thing you've been doing for the last two attempts.

> **GOLD/PAUSE**

And one thing already true about the work. Something in it that's already right.

> **GOLD/PAUSE**

Now put the rest of it down. You don't have to carry it out of here.

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back. Hands where they are. Shoulders down.

It still may not come today. Nothing here promised it would, and it's not a state you can order.

What's changed is that you're no longer standing in the one place it definitely doesn't arrive.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are unsteady.* Narrow, not blocked.
**Breathe it** — Four in, six out. Hands off. Eyes soft, whole room.
**Stop forcing** — Pushing narrows you. It only comes wide.
**Do the next ordinary thing** — Not the finished piece. The doing.

### Back

**Recognition** — Find it in your body: chest low and tight, jaw, something behind the eyes, shoulders crept up over the last hour. Name the state in one word. It doesn't say the work is bad. Two states are available for this kind of work and you can only be in one — narrow and pushing, or wide and receiving. You're in the first. That's all that's happened.

**Regulation** — Four in, six out. Hands physically off the work. Shoulders down, jaw apart. Then let your eyes go soft — look at the whole room rather than at anything in it. Wide rather than narrow is most of what's been missing.

**Release** — Two things. The block, which is real. And the forcing — staying at it, going back at it, more effort on the assumption effort is what's short. But forcing narrows you, and what you're reaching for only arrives in the wide state. The harder you push, the further you get from the only condition it turns up in. That's why the shower works and the desk doesn't.

**Rise** — See yourself from a distance. *You're not blocked. You're narrow.* Then attention on you doing the work — the physical part, not the finished piece. Then one thing that isn't more of the same: a different section, the boring part, outside, or making it worse on purpose.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

This is an unsettled state produced by sustained unsuccessful effort. In the body: low tightness through the chest, jaw and shoulders held, tension behind the eyes, and a narrowing of visual attention onto the work itself that most people don't notice happening.

That narrowing is the whole subject. It isn't a side effect — it's the mechanism.

**Two states, and you can only be in one**

Work of this kind needs a wide, receptive condition: taking things in peripherally, noticing what's adjacent, connecting two things that weren't filed together.

Effort produces the opposite condition — narrow, targeted, and pointed at a single object.

Both are useful. The narrow one executes; it doesn't originate. And the harder you apply it to a problem needing the wide one, the further you move from the only state the answer turns up in.

**Why the shower works and the desk doesn't**

Not mysterious, and not about water. The shower is somewhere the narrow state has nothing to grip — no object, no measurable progress, nothing to push against. Attention widens by default, and what you were reaching for arrives.

The desk supplies an object to push against continuously, so the narrow state persists.

**Why the exhale is longer, and why the eyes**

You can't decide a state down. You can decide your breathing, and it's the one reachable control. Lengthening the out-breath relative to the in-breath shifts things toward settled.

Soft eyes matter more here than on any other protocol. Visual attention and general attention move together — narrowing the gaze narrows the mind, and widening it widens both. Looking at the whole room rather than at anything in it is a direct instruction to the state, and it works faster than anything you could think.

**Why Release goes after the forcing**

There's the block, which is real. And there's the forcing — same approach, more effort.

Two different costs, and the second is unusual on this platform because it isn't a loop that produces nothing. It actively produces the wrong condition. Every additional push deepens the narrowing that's preventing the arrival.

Putting it down isn't giving up on the work. The work stays exactly where it was.

**Why the question is about what the work is carrying**

*What's wrong with me that I can't do this any more* is a verdict, and it narrows further.

*What was this for* asks what the pressure is doing — and what usually surfaces is that the work is carrying something beyond itself. A deadline, a reputation, an answer to whether you're still any good. That's a great deal to hang on an afternoon, and naming it is often enough to take some of the weight off the work.

**Why Rise rehearses the doing rather than the piece**

Rehearsing the finished thing is rehearsing an outcome, and picturing it is part of what narrows you — it puts an object in front of the state to push toward.

Rehearsing yourself doing the work, physically and ordinarily, is available now and is the version that permits the wide condition. The effect is on your own steadiness. Nothing here claims it produces the work.

---

> **SHARED BLOCK** — insert *What this track works on* here, verbatim from `SHARED-t3-what-this-track-works-on.md`. Identical on all ten Track 03 protocols. Do not paraphrase or re-cut per protocol.

---

### What we rest on

**Distance & rehearsal — Kross & Ayduk, with King** · *peer-reviewed* · supplies Rise

Observing an experience from outside it, rather than from inside looking out, lowers distress and later reactivity. Distraction does neither. Second-person self-address is one of the reliable ways to produce that shift. Rehearsing a specific future scene in concrete detail lifts outlook; general optimism does not. *Here it supplies the rule that the rehearsal is of the doing rather than of the finished thing — concrete, present, and about the person rather than the output.*

*The effect is on the person rehearsing. It acts on your own steadiness and makes no claim to act on anyone else, or on how anything turns out.*

**Non-resistance — Alan Watts** · *interpretive* · informs why the third step says *put down* rather than *push through*

The state is one thing. The fight with the state is a second thing. The fight usually costs more, and it's the only one of the two you can put down. Setting it down isn't passivity and isn't giving up on the work. *Here it accounts for the specific shape of this protocol — effort applied to a problem that needs receptivity produces the opposite of what it's reaching for.*

*Watts is an interpreter rather than an originator; the older sources are Laozi and, for the framing used here, D. T. Suzuki. Offered as a lens rather than a finding.*

**Where the reading is yours** — this explains the machinery. Whether the work is any good, whether the block means something, and what to do about the project are readings that belong to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Hands off, physically.** Away from the keyboard, the page, the instrument. The narrow state needs an object and this removes it.

**Soft eyes.** Look at the whole room rather than at anything in it. Ten seconds. The fastest thing on this list and the one people skip.

**One horizon.** Out of a window, down a corridor. Change the focal distance and general attention follows.

**Long exhale, no ceremony.** Four in, six out, three or four cycles.

**Shoulders down, jaw apart.** Both creep up over an unproductive hour without announcing it.

**Walk without solving anything.** Not a thinking walk. If you notice you're working on it, come back to what you can see.

**Do the boring section.** The bit that needs no invention — the formatting, the admin, the tidy-up. It keeps you in contact with the work while the narrow state has nothing to push against.

*Make one deliberately bad version. Fast, ugly, unusable. It removes the object the pressure has been pointed at.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with the narrowing that comes from sustained unsuccessful effort, using breath, attention and observation. **It doesn't produce ideas and doesn't claim to.** It changes the condition you're in, which is the condition the work needs.

**Pacing**

Once through is a complete use. Mid-session is a legitimate time — this is one people run at the desk.

**What people commonly notice**

Nothing arriving during the session. That's ordinary and it isn't a failure. The state changes and the work turns up later, often somewhere else entirely.

Restlessness at the Regulation step, particularly hands off the work. That's the narrow state losing its object.

Something arriving on the walk, in the shower, or the next morning. Common enough to be expected.

**When to slow down**

If the session becomes another attempt at the work, stop. That's the forcing, relocated.

If Release opens something larger than this piece — about the whole project, or about whether you want to be doing this — you can stop there and come back to the breath. That's a bigger question than an afternoon.

**When it isn't a block**

Sometimes the work isn't arriving because you're depleted rather than narrow. If you're exhausted, if this has been going on for weeks, if nothing has arrived across several projects — that's closer to Burnout & Overload than to this, and no amount of widening attention substitutes for rest.

If the work isn't arriving because you don't want to do it, that's information rather than a block, and Career Transition is the nearer protocol.

**When a person in the room is the right tool**

Contact someone — a doctor, a helpline in your country, or a person you trust — if this has extended to everything rather than one project, if you can't start anything at all rather than merely struggling, if you're using something to work, or if you're having thoughts of harming yourself.

If the work is your livelihood and it hasn't come for a long time, the financial pressure is a real problem in its own right and it needs practical advice rather than a regulation practice.

**Alongside other support**

If you're with a therapist, doctor, counsellor or coach, this sits alongside that and replaces nothing.

---

## 06 · Disclosure & Support
*A script for someone close.*

> **This one is for outside work.** A friend, a partner, someone who isn't in the building. The workplace conversation is a different act with different consequences — that's **Raising It**, the next resource.

Take these exactly, or change every word.

**Saying it**
> "The work isn't coming at the moment and I've been quietly panicking about it. I'm not looking for ideas. I'd rather say it out loud than keep pretending it's fine."

**Describing what it's actually like**

> "It's physical. Chest tight, jaw, shoulders up round my ears by mid-afternoon, and my eyes locked on one spot."

> "The part that's hard to explain is that trying harder makes it worse. It needs a wide, loose state and effort produces the opposite one. So the more I push, the further off it gets."

**How to tell it's coming**

> "I get short. I stop talking about the work, which is usually the thing I talk about. I stay at the desk much longer than the work justifies."

**What helps**

> "Get me out of the room. A walk where we talk about something else does more than any amount of encouragement."

> "Ask me about the boring part of it. That's usually where I can still move, and moving anywhere helps."

**What doesn't**

> "Ideas. I know you're trying to help. It gives the pressure a new object."

> "Telling me it'll come. It might not, today, and then I've got your optimism to manage as well."

**If it's affecting the household**
> "This has taken over more of my evenings than it should have and I know you've noticed. I'm not going to fix it tonight. But I'd rather say I've seen it than keep bringing it to the table silently."

**If they ask what you're doing about it**

> "There's a method I run. I name it as a state rather than as a verdict on the work, take my hands off it, soften my eyes and widen out. Then I stop forcing — because forcing narrows me and the thing I'm after only turns up wide. Then I do something that isn't more of the same."

*Tell one person. Work not arriving is one of the states people hide hardest, because saying it out loud sounds like an admission about ability.*

---

## 07 · Raising It
*Who to tell, how much, and what to ask for.*

Telling a friend costs you nothing. Telling someone at work may go on a record, may change what you're trusted with, and can't be taken back. Different audience, different calculus, different words.

**First: you may not have to say anything.**

Not disclosing is a legitimate choice and often the right one. What follows is for if you've decided to, or if something needs to change and saying nothing is what's costing you.

**Who you tell changes what happens**

**Your manager or client** — can change the deadline or the brief, and will also form a view about reliability. Both, from the same conversation.

**A collaborator** — can move the work forward from a different angle, which is frequently the actual solution.

**Someone who does the same work** — the only person who won't be surprised. Almost everyone in creative work has had this and almost nobody mentions it.

**Occupational health or your GP** — the right route if it's gone on for a long time, or if it's arrived with exhaustion.

**How much to say**

*I'm not going to make Thursday and I'd rather tell you now than on Thursday* is a different act from explaining a state. The first is a professional communication. The second invites a response nobody has been trained to give.

**Make it a request, not a confession**

> **The ask, on this protocol:** *"I need three more days on this. I'd rather deliver something I stand behind than something on time that I don't."*

> Or: *"Could we talk through the brief again? I think I've been solving the wrong problem, and half an hour now would save the week."*

> Or, to a collaborator: *"Can you take the next pass? I've been at it too long and I've stopped being able to see it."*

That last one is the most useful and the least used. Handing work sideways isn't an admission — it's the standard tool of every field that produces anything.

**Put it in writing afterwards**

If a deadline moves, confirm it in a short email. No explanation, no apology. Just the new date.

**Two things this resource can't do**

It isn't legal or contractual advice. Where a deadline is contractual and money is attached, that's a conversation with whoever holds the contract.

And it makes no promise about how it will be received, which is why nothing here tells you to disclose.

---

## 08 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

If this is a work device, remember it is stored on the device — and a work device is not always yours.

Any of these, or none.

- Where did it sit in your body?
- How long had you been at it before you noticed you'd narrowed?
- What were you trying that you'd already tried?
- What is this piece of work carrying, beyond itself? A deadline, a reputation, a question about whether you're still good.
- *What was this for* — what turned up, without needing to answer it?
- What did you say to yourself from across the room?
- What was the thing that wasn't more of the same? Did you do it?
- If something arrived later — where were you when it did?
- What did you write here last time? Read it back.

That second-to-last one is worth keeping across months. Your own record of where things actually arrive is more useful than any amount of theory about it, and it's almost never at the desk.

---

## 09 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half lands on people waiting for something, and on people at home.

**The specific blind spot here, and it's the consequential one** — **work that never leaves your hands is indistinguishable, from outside, from work that was never done.** The struggle is invisible. The absence isn't. From inside you've been at it for three weeks; from outside nothing has arrived.

**The second one** — the silence about it. Not saying a deadline will slip until the deadline slips. From inside, holding on is hope that it'll come good. From outside it's a late notification of a thing that was known about for a fortnight, and it removes everyone else's options along with yours.

**The third one** — the evenings. This state colonises time that was somebody else's, and it does it without producing anything. From inside you're working. From outside you're absent and irritable, and there's nothing to show for it that would make sense of either.

**Their earlier information** — worth asking whoever waits on your work: *when did you first think this was going to be late?* Usually well before you told them.

**Naming the act, not the character** — *"I knew on the Monday and I told you on the Friday"* is ownership. *"I'm blocked"* is not; it names nothing and it explains rather than accounts.

**No because.** The state is a real reason and it doesn't belong in the sentence.

**No self-attack.** *"I'm useless at the moment, I don't know why you work with me"* asks the other person to reassure you at the point they're absorbing a delay.

**Describe what was observable, ask about the rest.** *"I sat on the slip for a week. I'm not going to tell you what that cost you — I'd rather hear it."*

**The checkable change** — this repairs by flagging early rather than by delivering on time. *"I'll tell you the day I first think it's at risk, not the day it's due"* is small, specific and observable, and doesn't require the work to start arriving.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you or on the work. And if the brief is genuinely impossible, or keeps changing, that isn't a block and none of this applies.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Push harder. Effort is what's short.

Stay at it. Go back at it. Same approach, more force, on the assumption that this is a problem effort solves. And the harder it's pushed, the narrower everything gets.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*What I'm afraid of losing. Whether I'm still someone who can do this.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the afternoons that produced nothing*, or *the evenings I took it home and still didn't work.*

---

**What it should be attending to instead**

It isn't caring less. You'll care exactly as much, and that isn't the problem.

What's available is a different instruction about **what to do when it won't come**.

The old one applies more effort, which narrows you further from the only condition it arrives in. The successor goes wide — different part, boring section, outside, worse on purpose.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *when it won't come, change what I'm doing rather than how hard.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *does the admin part rather than the creative part. Goes out without taking the problem. Makes a deliberately bad version fast.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Hands off it. Eyes soft, whole room. Does something that isn't the last two attempts.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*

*If this is a work device, remember it is stored on the device — and a work device is not always yours.*
