# t3-01 · The High-Stakes Presence Protocol

**Label:** Steady · **State:** Agitated · **Frameworks:** Porges, HeartMath · **extras:** `[]`
**Resources: 9**

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Five-bar phrase. Turn at four seconds.

A car park. A stairwell. A cubicle. The corridor outside. Wherever you are, that's where this was built to work — you don't need a quiet room and you're not going to get one.

> **GOLD/PAUSE**

This works on the state you'd be walking in with. It leaves the thing itself entirely alone — what you say, how it lands, what happens after.

---

### Recognition

Find where it is in your body, before any of the words.

> **GOLD/PAUSE**

Chest, usually. Something tight and high. The throat. A lightness through the arms. Hands that won't settle. Sometimes the stomach dropping.

> **BLUE/ILLUSTRATION** — a taut line, drawn straight. Held, not fraying.

Now name the state. One word. **Agitated.**

> **GOLD/PAUSE**

Notice what that word doesn't say. It doesn't say you're not ready. It doesn't say it's going to go badly.

This is what a body does before something that matters. It would be stranger if it didn't.

> **GOLD/PAUSE**

The state is not a prediction. It's just a state.

---

### Regulation

Four counts in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six counts out. Longer out than in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Nobody can see you doing this. It works with your eyes open, in a lift, at a table.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the centre of your chest.

> **RED/ACTION** — feet flat, pressed into the floor. Offered, not instructed.

Press your feet into the floor. Feel it push back.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now the throat and jaw. This state closes both, and a closed throat changes your voice before you've said anything.

Let the teeth come apart. Let the tongue drop.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

If you've got a moment more, there's one question worth having.

> **GOLD/PAUSE**

If you haven't, skip it. Go in. The first four steps are the ones that matter today.

> **GOLD/PAUSE** — long

Still here.

> **GOLD/PAUSE**

Then — what does it feel like is actually at stake in there?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — a taut line, and beneath it an older line held under the same tension.

Not the outcome. You know the outcome and it's usually survivable.

> **GOLD/PAUSE**

For most people what's actually on the table is smaller and older. Being taken seriously. Being the person who belongs at that table. Not being found out as someone who talked their way in.

> **GOLD/PAUSE** — very long

That's what makes a twenty-minute meeting feel like the whole thing.

> **GOLD/PAUSE** — long

I'm not telling you which of those is yours. From outside your life nobody knows.

> **GOLD/PAUSE** — long

And the keyed-up feeling — that's not working against you. It's your system getting ready for something it has correctly identified as mattering.

> **GOLD/PAUSE** — very long

It's on your side. It just doesn't know its own strength.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE**

And if something turned up there, don't carry it in. It'll keep.

> **GOLD/PAUSE**

One thing, quickly. Nearly everyone walking into a room like that is carrying some version of this. The ones who look easy have mostly just done it more times.

> **GOLD/PAUSE**

Put it down and go.

---

### Release

Two things are running.

> **GOLD/PAUSE**

There's the state, which turned up because this matters to you.

And there's the pre-playing. Running the room in advance — the question you can't answer, the face in the third row, the moment it goes wrong.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Notice which version you keep running. It's the bad one. It's always the bad one.

That isn't preparation, and it isn't caution either. Every pass through it puts your body back at the start, and it's using the attention you're going to need in the room.

Let the state stand. It's here and it's appropriate.

Put down the pre-playing.

> **GOLD/PAUSE** — long

And the question. Not *what's wrong with me that I still get like this* — plenty of people who are very good at this still get like this.

**What was this for?**

> **GOLD/PAUSE** — long

A body sharpens before something that counts. That's the whole point of the state. It's aimed at helping you, and it's overshooting.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Leave the question there.

---

### Rise

Step outside it.

See yourself from across the room. Someone waiting to go in, breathing four and six, feet on the floor.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Speak to them as *you*.

*You are keyed up, and you are ready. Those are both true.*

> **GOLD/PAUSE**

Neither one cancels the other. You're not waiting to stop feeling this before you go in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now forward, and small. Not the whole thing going well — you don't control most of it, and that's the version we just put down.

The first thirty seconds. Walking in. Where you'll stand. What your hands do. The actual first sentence.

> **GOLD/PAUSE** — long

Just the opening. Once you're in it, you'll be in it, and the rest runs on what you already know.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing already true. Not about how it'll go. Something in the room you're standing in now.

> **GOLD/PAUSE**

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back. Feet on the floor. Jaw loose.

The state may still be here. It usually is, and it isn't the enemy — a flat system performs worse than a keyed-up one. What's changed is that it's no longer spending itself on a room you haven't entered.

Recognition. Regulation. Release. Rise.

Go in.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are agitated.* A state, not a prediction.
**Breathe it** — Four in, six out. Feet down. Jaw loose.
**Stop pre-playing** — You keep running the bad version.
**First thirty seconds only** — Walking in. Where you stand. First sentence.

### Back

**Recognition** — Find it in your body first: high and tight in the chest, the throat, light through the arms. Name the state in one word. It doesn't say you're not ready and it doesn't say this will go badly. It's what a body does before something that matters. The state is not a prediction.

**Regulation** — Four in, six out. Nobody can see you doing it. Attention in the centre of your chest, feet pressed into the floor. Then the throat and jaw — this state closes both, and a closed throat changes your voice before you've said a word. Teeth apart, tongue down.

**Release** — Two things are running. The state, which is here because this matters. And the pre-playing — running the room in advance, and it's always the bad version. That's not preparation. It puts you back at the start each time and spends the attention you'll need in there. Put down the pre-playing.

**Rise** — See yourself from a distance. *You are keyed up, and you are ready.* Both. You're not waiting to stop feeling it before you go in. Then the first thirty seconds only: walking in, where you stand, what your hands do, the first sentence.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

Something that matters is coming, and the body prepares in advance. Heart rate up, breathing shallow and high in the chest, blood toward large muscle, attention narrowing onto one thing. Digestion slows, which is why the stomach is involved.

This is a system doing its job. A completely flat body going into something high-stakes is not a better position — the sharpening is useful, and it is the reason people describe feeling more awake in the room than out of it.

The trouble is that the system doesn't know how far in advance to start, or how much is enough. It overshoots.

**Why the throat matters here more than elsewhere**

The state closes the throat and tightens the jaw. That changes pitch, volume and pace before you've said a word — so the first signal anyone receives is one you didn't choose to send. Opening the jaw and dropping the tongue works on it directly, and it's the reason this protocol spends a step there.

**Why the exhale is longer than the inhale**

You can't decide your heart rate down. You can decide your breathing, and it's the one reachable control on a system you otherwise can't get at. Lengthening the out-breath relative to the in-breath is what shifts things toward settled, which is why the count is uneven and why a bigger breath isn't a better one — pulling hard for volume recruits effort, and effort points the wrong way.

Feet pressed into the floor gives a mobilised system a definite physical signal, which it takes when it will take very little else.

**Why Release goes after the pre-playing**

There's the state, and there's running the room in advance.

Two different costs. Some preparation is real — knowing your material, knowing your opening. But the version people actually run is the one where it goes wrong, repeatedly, and that has two effects. Each pass returns the body to the start. And it spends attention now that you'll need in the room, because attention is finite and rehearsing a disaster is not free.

Putting it down isn't going in unprepared. What you keep is what you know.

**Why Rise rehearses thirty seconds**

Rehearsing the whole thing means rehearsing something you control maybe half of, and the half you don't control is the half you're worried about. Your body doesn't accept it.

The opening is entirely yours. It's specific enough to stick, it's what most people find they can't produce on the spot, and once you're in it the rest runs on what you already know.

The line about being keyed up *and* ready is doing structural work rather than being kind. Waiting to feel calm before going in is the most common reason people go in worse.


---

### What this track works on

Everything here works on you, not on your output.

That isn't modesty about what it can do. It's the actual mechanism. A narrowed system makes worse calls, hears less in a room, and takes longer to start things — so settling it changes what you're able to bring. What it won't do is set you a target, measure what you produced, or tell you that you should be getting more done.

Nothing on this platform will ask you how productive you were. There's no version of a bad week here.

The reason is simple enough. A tool that measures your output becomes one more thing to fail at, and the people who most need this arrive on the days they're already failing at everything else.

---

### What we rest on

**Polyvagal Theory — Stephen Porges** · *peer-reviewed* · supplies Recognition and the three state labels

Threat detection runs ahead of thought. The body reads a situation and moves before your thinking catches up, which is what makes the response fast and also what makes it non-negotiable in the moment. Porges describes three broad conditions: settled and socially available, mobilised for action, and shut down. Agitated, Unsteady and Numb are the member-facing names for those three. *Here it explains why the sharpening is useful and why it starts far earlier than the event.*

*The anatomical premises are contested: a 2026 evaluation in* Clinical Neuropsychiatry *challenged them, with Porges replying in the same issue. The state distinctions are what this platform uses, and they hold independently of that dispute.*

**Cardiac coherence — HeartMath** · *peer-reviewed* · supplies Regulation and the count

At roughly six breath cycles a minute, heart rhythm and breath settle into a single smooth wave rather than two competing ones, close to a rhythm the body's blood-pressure regulation already runs at. Four in, six out lands near that rate. The uneven ratio is the mechanism. *Here it's what you do in the last minute before you walk in, and the reason your voice arrives as your own.*

*The finding is used here; the wider programme is not. There is no measurement of coherence anywhere on this platform and no score attached to any breath.*

**Where the reading is yours** — this explains the machinery. Whether you're ready, how it went, and what any of it means about you are readings that belong to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Long exhale, no ceremony.** Four in, six out, three or four cycles. In a lift, a corridor, at the table.

**Jaw apart, tongue down.** Opens the throat, which is what carries the state into your voice.

**Hum, briefly.** Any low note, a few seconds, somewhere private. A voice already in use arrives steadier than a cold one.

**Feet into the floor.** Press down, feel it push back. Works sitting opposite people, invisibly.

**Shoulders down and back.** This state lifts them and it reads as braced from across a room.

**Warm hands.** Under a tap, or around a cup. Cold hands are part of the state and a cold handshake announces it.

**Walk the route.** If you can, walk the actual path you'll take. Familiar ground is doing something the moment you're on it.

*Say your opening sentence out loud once. Once. A fifth time is pre-playing, which is the thing the protocol asks you to put down.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with the state that arrives before something that matters, using breath, attention and observation. It makes no claim about how the thing will go, and it isn't preparation for the content — that's separate work and it comes first.

**Pacing**

Once through is a complete use, and immediately before is exactly when to use it. If four and six is a stretch, shorten both and keep the ratio uneven.

**What people commonly notice**

The state rising during the breathing as the event gets closer in mind. A strong pull to pre-play once more after finishing — worth resisting, since the protocol works as a stop rather than a warm-up.

Feeling steadier without feeling calm. That's the expected result rather than a partial one.

**When to slow down**

If the breathing itself makes things worse — lightheaded, more panicked — stop counting and let your breath do what it does. Focusing on the breath increases alarm in some people. Run it on Recognition and Rise alone.

**When something else is going on**

If the state is arriving days rather than minutes ahead, if you've started avoiding things you'd normally do, if you're using something to get through them, or if your hands or voice are affected badly enough to worry you, that's worth taking to a doctor. Some of it responds to treatment, and finding out is not an admission of anything.

If you're preparing for something where the stakes are your livelihood, your registration or your safety, this settles you and it doesn't replace advice from someone qualified in that thing.

**Alongside other support**

If you're with a therapist, doctor or counsellor, this sits alongside that and replaces nothing.

---

## 06 · Disclosure & Support
*A script for someone close.*

> **This one is for outside work.** A friend, a partner, someone who isn't in the building. The workplace conversation is a different act with different consequences — that's **Raising It**, the next resource.

Take these exactly, or change every word.

**Saying it**
> "I get keyed up before things that matter. It's physical and it starts early. I'd rather you knew than wondered why I go strange the night before."

**Describing what it's actually like**

> "Chest goes tight and high, throat closes, hands won't settle. It happens whether or not I'm prepared, so telling me I'm prepared doesn't touch it."

> "The bit I can't switch off is running the room in advance — and it's always the version where it goes wrong. It feels like being careful. It's just wearing me out before I get there."

**How to tell it's coming**

> "I go quiet and short. I stop wanting to talk about anything else. I get snappy about small things that aren't the thing."

**What helps**

> "Ask me what my opening line is. Just the first sentence. Making me say it out loud once is worth more than an hour of reassurance."

> "Normal conversation about something else. Being treated as though today isn't special helps more than encouragement does."

**What doesn't**

> "Telling me it'll be fine, or that I'll smash it. You don't know, and now I've got to look confident for your benefit as well."

> "Asking me to run it past you. That's the exact loop I'm trying to stop."

**If they ask what you're doing about it**

> "There's a method I run beforehand. I name the state instead of treating it as a prediction, do a breathing pattern with attention on my jaw and throat, stop pre-playing the room, and then rehearse only the first thirty seconds — because that's the only part that's actually mine."

> "It doesn't make me calm. It gets me in the room as myself."

*Tell one person before, not after. A thing that exists outside your own head before it happens is easier to walk into.*

---

## 07 · Raising It
*Who to tell, how much, and what to ask for.*

Telling a friend costs you nothing. Telling someone at work may go on a record, may change what you're trusted with, and can't be taken back. Different audience, different calculus, different words.

**First: you may not have to say anything.**

Not disclosing is a legitimate choice and often the right one. Nothing here pushes you toward telling anyone. What follows is for if you've decided to, or if something needs to change and saying nothing is what's costing you.

**Who you tell changes what happens**

These are not interchangeable, and most people don't know the difference.

**Your manager** — can change the work. Cannot usually keep it confidential, and shouldn't be expected to.

**HR** — exists to protect the organisation. That doesn't make them hostile, and it does mean they are not neutral and are not your representative. Useful for process; not the place to think out loud.

**Occupational health** — assesses fitness for work and recommends adjustments. Reports to the employer but usually only on what you consent to release. Frequently the most useful route available and almost nobody uses it.

**A union rep** — represents you specifically. If you have access, use it before HR rather than after.

**A colleague** — no power to change anything, and the only one who can be told without it becoming a process.

**Your GP** — outside the building entirely, and the only one who can put something in writing that an employer has to take seriously.

**How much to say**

*I'm dealing with something and it's affecting my sleep* is a different act from naming a condition. Both are honest. The first is almost always enough for a workplace conversation, and it's the version you can't be held to later.

Say what's affecting the work. You are not obliged to explain why.

**Make it a request, not a confession**

This is the move that works at work, and it's the one most people miss.

A specific ask travels. It's actionable, it's answerable, and it puts the conversation on ground the other person knows how to stand on.

An explanation of a state invites a response nobody has been trained to give, and it frequently ends in sympathy and no change.

> **The ask, on this protocol:** *"I do better with high-stakes things when I've had the material a day earlier. Could I have the deck on Wednesday rather than Thursday night?"*

> Or: *"I'd rather present the second half than the first. Same content, and I'll be better in it."*

Neither requires you to explain anything about your state, and both are entirely ordinary requests.

**Put it in writing afterwards**

Verbal is deniable in both directions. If you've asked for something and it matters, follow the conversation with a short email — *thanks for the chat, just confirming we agreed X.* No tone, no argument, no explanation.

That isn't building a case. It's a record of what was agreed, and it protects both of you.

**Two things this resource can't do**

It isn't legal advice. Employment rights differ enormously by country and by contract, and where something might be unlawful, that's a conversation with a union or an employment lawyer rather than with a platform.

And it makes no promise about how it will be received. That varies more than anything else on this track, which is why nothing here tells you to disclose.

---

## 08 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it is never measured against anything you wrote before. Because it is only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

If this is a work device, remember it is stored on the device — and a work device is not always yours.

Keep anything you may need factually — dates, what was said, who was present — somewhere separate from this. This is for your state. That is for the record, and it belongs off a work device.

Any of these, or none.

- Where did it sit in your body?
- What was the version you kept pre-playing? Write the moment it went wrong in.
- Did that moment happen?
- What was your opening sentence? Did you use it?
- *What was this for* — what turned up, without needing to answer it?
- What did you say to yourself from across the room?
- What actually happened, plainly, without the verdict attached?
- What did you write here last time? Read it back.

That third prompt is the one that does the work here. Your own record of how the pre-played disaster compared with the real thing is the only evidence you have that the pre-playing wasn't preparation.

---

## 09 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half exits — and before something high-stakes, most of it lands on people who have nothing to do with the event.

**The specific blind spot here** — the state arrives before you do. A tight throat, a clipped tone, an economy of words. From inside you're conserving yourself for the thing that matters. From outside it's coldness, and the people nearest you get most of it because they're the ones in the room the night before.

**The second one** — the day-before shortness. Snapping about something small that isn't the thing. From inside it's an unrelated irritation. From outside it's being made to carry your nerves without being told they're nerves.

**The third one, at work** — going into the room braced. Braced reads as adversarial, and people brace back. The exchange you were preparing for becomes harder because of how you walked in.

**Their earlier information** — the people who live with you can usually tell days out. Worth asking: *when do you notice it starting?* The answer is usually earlier than you'd guess.

**Naming the act, not the character** — *"I was short with you all evening before the pitch and never said why"* is ownership. *"I'm a nightmare before these things"* is not; it names nothing and asks them to accept it as a fixed feature.

**No because.** The nerves are a real reason and they don't belong in the sentence. They can be said later, if they ask.

**No self-attack.** *"I'm sorry, I'm impossible, I don't know how you stand me"* moves the burden across the table on the night you were already asking a lot.

**Describe what was observable, ask about the rest.** *"I was cold with you last night. I'm not going to tell you what that was like — I'd rather you told me."*

**The checkable change** — this repairs by flagging rather than by being calmer. *"I'll tell you the day before when something's coming, instead of just going quiet"* is small, specific and observable.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. Nobody is owed a better performance from you on the night before something hard.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Run the room first. Find where it goes wrong.

Play it through. The question you can't answer, the face in the third row, the moment it turns. Get there before it does, so nothing arrives unprepared.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Being caught out in front of people whose opinion carries weight. Being found not to belong at that table.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the night before*, or *how much of me was already used up before I walked in.*

---

**What it should be attending to instead**

It isn't going in unprepared. Preparation is the point — running the failure isn't preparation.

What's available is a different instruction about **which version to run**.

The old one runs the one where it goes wrong. The successor runs the first thirty seconds only, and lets the rest of it be whatever it is.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *rehearse the opening, not the disaster.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *knows the first line and nothing after it. Arrives early rather than tightly on time. Stops preparing at the point of diminishing returns.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Feet on the floor, jaw loose. Runs the first line once. Walks in keyed up rather than waiting to feel ready.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*

*If this is a work device, remember it is stored on the device — and a work device is not always yours.*
