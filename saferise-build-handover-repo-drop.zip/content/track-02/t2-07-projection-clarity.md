# t2-07 · The Projection Clarity Protocol

**Label:** Clarify · **State:** Agitated · **Frameworks:** Jung, Maté · **extras:** `[]`
**Resources: 8** · *meditation authored ahead of the remaining resources — Release language here is canonical*

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Turn at four seconds.
> **VOICE** — curious rather than corrective. Interested, never accusing. This protocol could easily sound like being told off, and it must not.

Something set you off, and the size of it didn't match.

> **GOLD/PAUSE** — long

You probably noticed at the time. A small thing, and a very large reaction, and some part of you going *hang on.*

> **GOLD/PAUSE**

Nothing here says you were wrong about what happened. It might have been genuinely annoying. We're interested in the gap between the event and the size.

---

### Recognition

Where is it?

> **GOLD/PAUSE** — long

Heat, usually — face, chest. Something fast. Hands. The particular quality of being very certain very quickly.

> **BLUE/ILLUSTRATION** — a small mark casting a much larger shadow.

One word. **Agitated.**

> **GOLD/PAUSE**

And notice what got left out. Them. The thing they did. Whether they should have.

> **GOLD/PAUSE** — long

Here's what you just did, though — you described a state, and something in you did the describing. Those aren't the same thing, and it's the second one we're using for the next few minutes.

---

### Regulation

Four in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six out.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the middle of your chest.

> **RED/ACTION** — hands open, feet down. Offered, not instructed.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

### Release

Two things.

> **GOLD/PAUSE**

There's the reaction, which is real and is in your body right now.

And there's where you put it. On them. On what they're like, what they always do, what kind of person does that.

> **GOLD/PAUSE** — long

That move is fast and it feels like clarity. And it has one reliable feature — it never reduces anything. The reaction stays exactly where it was, and now there's a person attached to it.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

So put down the placing. Keep the reaction — it's yours and it's information.

> **GOLD/PAUSE** — long

And the useful question here isn't *what's wrong with them.* It isn't *what's wrong with me* either.

**What was this for?**

> **GOLD/PAUSE** — long

When a reaction outruns the event, the extra is carrying something. Not necessarily about the person in front of you. That's a way of looking rather than a fact, and what it shows you is yours to read.

> **GOLD/PAUSE** — very long

So — the gap. The bit that was bigger than the occasion. What's it actually about?

> **GOLD/PAUSE** — very long

I'm not answering that. I genuinely don't know, and anyone who tells you they can name it from outside is guessing.

> **GOLD/PAUSE**

If something arrived, let it sit. If nothing did, that's ordinary — this one usually comes in its own time and rarely on demand.

> **GOLD/PAUSE** — long

> **GOLD/PAUSE** — very long

---

One further, and this is where the protocol earns itself.

> **GOLD/PAUSE**

The gap. The part that was bigger than the occasion.

> **GOLD/PAUSE** — long

What does the thing they did seem to say?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — a small mark with a long shadow, and beneath the shadow an older mark of the same size.

Not what they meant. What it landed as.

> **GOLD/PAUSE** — long

For most people the surplus is carrying something that has a familiar shape — being dismissed, being not taken seriously, being treated as though you don't count for much.

> **GOLD/PAUSE** — very long

And the tell is that it's familiar. If the same size of reaction has turned up before, with different people, it's pointing at something that was already there before any of them arrived.

> **GOLD/PAUSE** — very long

I'm not telling you what it is. From outside your life nobody knows, and anyone naming it from there is guessing.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

And what's the reaction protecting?

> **GOLD/PAUSE** — very long

Something that once needed defending quickly, before it could be done again. It moves fast because speed was the point.

> **GOLD/PAUSE**

That's not a defect. It's an old alarm on a very short fuse, still doing its job.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before we move.

> **GOLD/PAUSE**

Something will arrive behind that — almost certainly *so it was all me.*

> **GOLD/PAUSE** — very long

Put that down. The surplus being yours doesn't mean the whole thing was. They may well have been out of order, and both can be true at once.

> **GOLD/PAUSE** — long

And something in you looked at your own reaction rather than at them, which is the harder direction and the rarer one.

> **GOLD/PAUSE** — very long

One more, simply true rather than comforting. Everyone does this. The difference isn't whether it happens — it's whether anyone ever looks.

> **GOLD/PAUSE** — long

And one thing to be careful of, because it's the trap in this whole protocol. You can look at what's running in you. You cannot look at what's running in them.

> **GOLD/PAUSE**

*That's just your issue* is the same move in the other direction, and it's the most convincing case-builder there is. Still a case.

> **GOLD/PAUSE** — long

---

### Rise

Step back.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Someone over there, breathing four and six, who overreacted and noticed.

Speak to them as *you*.

*Something in that was about you. That's a finding, not a fault.*

> **GOLD/PAUSE** — long

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now one thing you'll do with it. Not an apology unless one is owed — and if one is, that's separate work.

Something for next time. The pause before the certainty. Asking instead of concluding. Saying *that landed bigger than it should have* out loud, which is a sentence almost nobody uses and which changes rooms.

> **GOLD/PAUSE** — very long

Small enough that you'll manage it in the moment, not afterwards.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing already true.

> **GOLD/PAUSE**

Now put it down. You don't have to carry it out of here.

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back.

You might still think they were out of order. That can be true at the same time.

The difference is that the extra is back with you now, where you can do something about it.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are agitated.* Notice the size, not the person.
**Breathe it** — Four in, six out. Hands open, feet down.
**Stop placing it on them** — Keep the reaction. It's information.
**Step out** — *Something in that was about you. A finding, not a fault.*

### Back

**Recognition** — Find it in your body: heat in the face and chest, something fast, the particular quality of being very certain very quickly. Name the state in one word. Leave them out of it. You described a state, and something in you did the describing — that second one is what we're using.

**Regulation** — Four in, six out. Attention in the centre of your chest. Open the hands, feet into the floor.

**Release** — Two things. The reaction, which is real and in your body. And where you put it — on them, on what they're like, on what they always do. That move is fast and feels like clarity, and it never reduces anything. The reaction stays exactly where it was, with a person now attached. Put down the placing. Keep the reaction.

**Rise** — See yourself from a distance. *Something in that was about you. That's a finding, not a fault.* Then one thing for next time — the pause before the certainty, asking instead of concluding, or saying *that landed bigger than it should have* out loud.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

A disproportionate reaction produces the same mobilised machinery as a proportionate one — the difference is only in the ratio between the event and the response.

In the body: heat through the face and chest, speed, tension in the hands, and a distinctive quality of certainty arriving before consideration. That certainty is the tell. Proportionate reactions arrive with some doubt attached. This one doesn't.

**Why the size is the subject, not the person**

Nothing here says you were wrong about what happened. The thing may have been genuinely annoying, and often is.

What's under examination is the gap — the part of the reaction that exceeded the occasion. That's a measurable difference and it belongs to you, which is what makes it workable. Whether they were out of order is a separate question and it may also be true.

**Why the exhale is longer than the inhale**

You can't decide a state down. You can decide your breathing, and it's the one reachable control on a system you otherwise can't get at. Lengthening the out-breath relative to the in-breath is what shifts things toward settled. Opening the hands and pressing the feet down gives a mobilised system somewhere to discharge and then somewhere to stop.

**Why Release goes after the placing**

There's the reaction, and there's where it gets put — onto them, onto their character, onto what people like that always do.

Two different costs. The placing is fast and feels like clarity, and it has one reliable property: it never reduces the reaction. The heat stays exactly where it was, and now there's a person attached to it who has to be dealt with.

Putting it down doesn't mean absorbing the reaction or deciding you overreacted about nothing. It means keeping it where it can be looked at.

**Why the surplus is the whole protocol**

Where a reaction outruns its occasion, the excess is carrying information about something other than the occasion. That's the interpretive claim this protocol rests on, and it's offered as a way of looking rather than a fact about you. What it shows you, if anything, is yours to read.

**The rule this protocol lives or dies by**

You can look at what's running in you. You cannot look at what's running in them.

*That's just your issue* is the same move in the other direction, and it's the most convincing case-builder available — it invalidates the other person's whole position while sounding like insight. It is still a case, and if this protocol produces members who use it on other people it has done more harm than good.

**Why Rise is about the next time**

The reaction has already happened. What's available is the moment before the next certainty — the pause, the question instead of the conclusion. That's specific, it's in your hands, and it's the only part that transfers.

---

> **SHARED BLOCK** — insert *The part that's on your side, and the part that can hear them* here, verbatim from `SHARED-t2-two-instruments.md`. Identical on all ten Track 02 protocols. Do not paraphrase or re-cut per protocol.

---

### What we rest on

**Shadow & individuation — C. G. Jung** · *interpretive* · informs Release

What you decline to look at keeps running unattended, and you tend to meet it as other people's faults. The usable test is proportion: when a reaction outruns the event that occasioned it, the surplus is carrying information about something other than the event. There's no finish line and nothing to complete. *This protocol is the proportion test, used directly.*

*Offered as a lens rather than a finding, with no controlled evidence behind it. What it shows you is yours to read — this platform will not tell you what your surplus is about, and it will not let you tell anyone else what theirs is.*

**Compassionate Inquiry — Gabor Maté** · *clinical practice* · supplies Release and the way the question is asked

A response is treated as an adaptation rather than a defect. The kind of question you ask decides the kind of answer you get. *What is wrong with me* asks what is broken, and comes back with a list of what is broken. *What was this for* asks what it was doing, and comes back with something you can use. *Here it keeps the protocol from becoming self-prosecution, which is the obvious failure mode of looking at your own overreactions.*

*A clinical practice, not a controlled research programme. Used here for the way the question is asked, and nothing wider.*

**Where the reading is yours** — this explains the machinery. What the surplus is about, and whether they were also out of order, are readings that belong to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Open the hands.** Spread the fingers, hold, let them go soft.

**Long exhale, no ceremony.** Four in, six out, three or four cycles.

**Feet into the floor.** Press down, feel it push back.

**One pause before one certainty.** Any conversation, any day. When the conclusion arrives fast, wait three seconds before saying it. That's the whole practice in portable form.

**Ask one question you think you know the answer to.** Out loud, to a real person. Not a test — just the experience of finding out you were partly wrong about something small.

**Cool water on the wrists.** A few seconds when the heat is the loudest part.

*When something lands disproportionately, note the size and nothing else. No analysis. Just: that was bigger than the thing.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with reactions that outrun their occasion, using breath, attention and observation. It doesn't decide whether the other person was in the wrong, and it isn't an instruction to absorb things.

**Pacing**

Once through is a complete use. Best used shortly after rather than during — the certainty is at its strongest in the moment and least available for examination.

**What people commonly notice**

Resistance at the Release step. Taking the reaction back from the person it was placed on feels like letting them off, and it isn't. That discomfort is the work rather than a sign of doing it wrong.

Something older arriving in place of an answer. That's usually the point.

Or nothing, which is ordinary — this one often answers days later rather than in the session.

**When to slow down**

If Release opens something much larger than today's incident, you can stop there and come back to the breath.

If the protocol turns into an inventory of every time you've overreacted, stop. That's self-prosecution wearing the protocol's clothes, and it produces nothing usable.

**Where this protocol can be misused**

This is the one on the platform most easily turned into a weapon. If you find yourself explaining someone else's psychology to them — that they're projecting, that it's really about their father, that it's their issue — you've stopped doing the protocol. You can look at what's running in you. You can't see theirs from where you're standing.

**When the reaction is proportionate**

Sometimes the reaction fits the event exactly and there is no surplus. Then this is the wrong protocol and nothing here applies. Being angry about something worth being angry about is not a pattern to be examined.

**Alongside other support**

If you're with a therapist, doctor or counsellor, this sits alongside that and replaces nothing.

---

## 06 · Disclosure & Support
*A script for someone close.*

Take these exactly, or change every word.

**Saying it**
> "Sometimes I react to something much harder than it deserves, and I've started noticing when it happens. I'm telling you because you've probably been on the end of it."

**Describing what it's actually like**

> "It's physical and it's fast. Heat, and a kind of certainty that arrives before I've thought about anything. That's the bit that catches me — I'm sure before I've considered it."

> "The size doesn't match. That's the whole thing. It might be a real annoyance and the reaction is four times bigger than it should be."

**How to tell it's coming**

> "I get very certain very quickly. My voice changes before my words do. I start using words like *always*."

**What helps**

> "If you can say — not in the moment — 'that seemed bigger than the thing,' that's genuinely useful. In the moment I'll argue. An hour later I won't."

> "Don't tell me what it's about. Even if you're right. It's the one thing that makes me defend it."

**What doesn't**

> "Being told I'm overreacting while I'm doing it. I know the size is wrong; being told adds a second thing to be wrong about."

**If they ask what you're doing about it**

> "There's a method I run. I name it as a state rather than as a verdict on them, do a breathing pattern, and then take the reaction back off them — because putting it on them never makes it smaller. Then I look at the gap between the size of it and the size of what happened."

> "It doesn't mean they were right. It means the extra was mine."

*Tell one person, and pick someone who won't use it against you the next time you're annoyed about something real.*

---

## 07 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

Any of these, or none.

- Where did it sit in your body?
- What actually happened? Write the event plainly, without the reading.
- How big was the reaction, compared to that?
- What did you conclude about them, and how fast?
- *What was this for* — what turned up, without needing to answer it?
- What did you say to yourself from across the room?
- Was any of it proportionate? Which part?
- Is this a familiar size? Has it come up before, with different people?
- What did you write here last time? Read it back.

That second-to-last one is the useful one here. A surplus that shows up repeatedly with different people is pointing at something. One that doesn't may simply have been a bad day.

---

## 08 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half already landed on someone, which is what brought you here.

**The specific blind spot here** — the certainty arrives before the consideration, so from inside it feels like accurate perception. From outside it's being met with a conclusion rather than a question, by someone who wasn't there yet.

**The second one** — the character assessment. Not *that annoyed me* but *that's what you're like.* From inside it's a summary of evidence. From outside it's being told who you are by someone who was angry at the time, and people remember those for years.

**The third one, and it's specific to this protocol** — the risk of coming out of it and explaining their psychology to them. *I've realised that was my projection, and I think yours is about…* That's the whole insight, weaponised. It will feel like generosity and it will land as an assault.

**Their earlier information** — worth asking, well after the event: *does this happen a lot?* And then not disputing the answer, however it comes.

**Naming the act, not the character** — *"I said you always do that, and then I listed four times"* is ownership. *"I'm a difficult person"* is not; it names nothing and asks them to disagree with it.

**No because.** Whatever the surplus turns out to be about, it doesn't belong in the sentence. *I overreacted because of something from my childhood* is an explanation offered as a defence, and it puts them in the position of having to be understanding about the thing you did to them.

**No self-attack.** *"I'm sorry, I'm awful, I don't know why I do this"* moves the burden across the table.

**Describe what was observable, ask about the rest.** *"I came at that much harder than it warranted. I'm not going to tell you what that was like — I'd rather you told me."* Then let them answer without explaining the psychology of it over the top.

**The checkable change** — this repairs by pausing rather than by understanding yourself better. *"I'm going to wait before I say the certain thing"* is small, specific and observable. Insight isn't observable, and offering it as the repair asks them to take your word for it.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. And the surplus being yours doesn't mean the whole thing was. Sometimes both are true: you overreacted, and they were also out of order.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Place it. Work out what they're like.

Something landed hard, so it goes onto them — what kind of person does that, what they always do, what it says about them. Fast, and it feels like clarity.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Something that once needed defending quickly, before it could be done again.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the people I decided about early and never revised*, or *the arguments that were about something else entirely.*

---

**What it should be attending to instead**

It isn't absorbing everything. They may well have been out of order, and that can be true at the same time.

What's available is a different instruction about **where the reaction goes**.

The old one puts it on them, which never reduces it. The successor keeps it where it can be looked at, and asks what the extra was about.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *hold it long enough to see the size of it before I decide whose it is.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *pauses before the certainty. Asks rather than concluding. Says that landed bigger than it should have, out loud.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Notices the certainty arriving fast. Waits three seconds. Doesn't say the sentence about what they're like.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
