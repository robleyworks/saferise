# t2-01 · The Safe Conversation Protocol

**Label:** Speak · **State:** Agitated · **Frameworks:** Porges, HeartMath · **extras:** `['invitation']`
**Resources: 9**

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Five-bar phrase. Turn at four seconds.

There's a conversation you haven't had yet.

> **GOLD/PAUSE**

And you've had it eleven times already, in your head, with both parts written.

> **GOLD/PAUSE**

This works on the state you're in before the conversation. It leaves the conversation itself entirely up to you — what you say, whether you have it at all, and how it goes.

---

### Recognition

Find where it is in your body, before any of the words.

> **GOLD/PAUSE**

Chest, usually. Something tight across the top. The throat closing slightly. A hollowness in the stomach. Hands that want something to hold.

> **BLUE/ILLUSTRATION** — a closed door with light under it. Nothing behind it yet.

Now name the state. One word. **Agitated.**

> **GOLD/PAUSE**

Notice what that word leaves out. It leaves out them. What they'll say, how they'll take it, what happens after.

The conversation hasn't happened yet. Your body has already had it several times.

> **GOLD/PAUSE**

That's what we've got hold of. Not the conversation. The state you'd be walking in with.

---

### Regulation

Four counts in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six counts out. Longer out than in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the centre of your chest.

> **RED/ACTION** — hand to sternum, flat, light. Offered, not instructed.

If a hand there helps, put one there.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

The throat is worth some attention here. This state closes it, and a closed throat changes your voice before you've said anything.

Let the jaw come apart slightly. Let the tongue drop off the roof of the mouth.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

One question before the last step, if there's room. If there isn't, go — you're readier than you were.

> **GOLD/PAUSE** — long

Still here.

> **GOLD/PAUSE**

Then — what does it feel like is at stake in this conversation?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — a closed door with light beneath it, and beneath the threshold an older line.

Not the subject. The subject is usually manageable, which is why the size of the dread is confusing.

> **GOLD/PAUSE** — long

For a lot of people it's what the conversation could end up meaning. That they'll be seen as difficult. That something will be said that can't be unsaid. That the relationship turns out to be more fragile than they hoped.

> **GOLD/PAUSE** — very long

And under that, sometimes: *if I say what I actually want, I'll find out whether it counts.*

> **GOLD/PAUSE** — very long

I'm not telling you which is yours. From outside your life nobody knows.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

And the rehearsing — what's it protecting?

> **GOLD/PAUSE** — very long

You from being caught without the words. Somewhere, being caught without them cost something, and this is a system making sure it never happens again.

> **GOLD/PAUSE**

It means well. It just can't stop.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before we move.

> **GOLD/PAUSE**

Something will arrive behind that — usually *this shouldn't be such a big deal.*

> **GOLD/PAUSE** — very long

Put it down. If what's underneath is whether what you want counts, then of course it's a big deal. That's the right size.

> **GOLD/PAUSE** — long

And something in you looked at that before the conversation rather than afterwards, which is the useful order and the harder one.

> **GOLD/PAUSE** — very long

One more, simply true rather than comforting. Almost everyone dreads a conversation like this, and almost nobody says so beforehand, which is why yours feels like a private weakness.

---

### Release

Two things are running.

> **GOLD/PAUSE**

There's the state, which turned up because something matters and you're about to say it out loud.

And there's the drafting. Running the conversation in advance — what you'll say, what they'll say back, what you'll say to that. You've done several versions. In some of them it goes badly.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

The drafting feels like preparation. Some of it is. Past the second version it stops being preparation and becomes an argument rehearsed with someone who isn't in the room — and notice which way it goes. In every draft, you have the better lines.

> **GOLD/PAUSE**

That isn't you being unfair. It's the part of you doing the drafting. It's on your side, not on the fence, so the version it writes will always come out your way.

Each pass puts your body back where it started.

Let the state be here. It's here because this matters.

Put down the drafting. Keep the thing you want to say.

> **GOLD/PAUSE** — long

And the question. Not *what's wrong with me that I can't just have a conversation* — that returns nothing, and plenty of people find this hard for reasons that make sense.

**What was this for?**

> **GOLD/PAUSE** — long

Preparing hard for a conversation is what you do when conversations have gone badly before, or when saying the true thing has cost you something. It's a protective habit and it was earned somewhere.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Leave the question there. Nothing to work out today.

---

### Rise

Step outside it.

See yourself from across the room. Someone sitting there, about to say something difficult, breathing four and six.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Speak to them as *you*.

*You have something to say. You are allowed to say it badly.*

> **GOLD/PAUSE**

That second half matters. The version where you say it perfectly is not available, and waiting for it is how the conversation never happens.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now forward, and concrete. Not the whole conversation — you don't control most of it, and rehearsing their half is the thing we just put down.

Only your first sentence. Where you'll be. What you'll be doing with your hands. The actual words you'll open with.

> **GOLD/PAUSE** — long

One sentence. That's the part that's yours.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing already true, before you come back. Not about how it'll go. Something here now.

> **GOLD/PAUSE**

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back. Feet on the floor.

The conversation is still ahead of you and it may still be difficult. What's changed is which state you'd be walking in with — and a narrowed system says things it didn't mean.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are agitated.* The state, not them.
**Breathe it** — Four in, six out. Jaw loose, throat open.
**Put down the drafting** — Keep the thing you want to say.
**One sentence** — Just your opening line. The rest isn't yours.

### Back

**Recognition** — Find it in your body: tight across the chest, throat closing, hollow stomach. Name the state in one word. Leave them out of it — the conversation hasn't happened yet, and your body has already had it several times. What you've got hold of is the state you'd walk in with.

**Regulation** — Four in, six out. Attention in the centre of your chest, hand there if it helps. Give the throat some attention — this state closes it, and a closed throat changes your voice before you've said anything. Jaw apart, tongue down.

**Release** — Two things are running. The state, which is here because this matters. And the drafting — running the conversation in advance, several versions, some of them going badly. Past the second version it stops being preparation and becomes an argument with someone who isn't in the room. Put down the drafting. Keep the thing you want to say.

**Rise** — See yourself from a distance. *You have something to say. You are allowed to say it badly.* Then one concrete thing: your opening sentence only. Where you'll be, what your hands are doing, the actual words. The rest of the conversation isn't yours to rehearse.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

An anticipated difficult conversation produces the same mobilised state as a present threat. The body doesn't distinguish well between something happening and something about to happen, which is why the state arrives days early and stays.

In the body: raised heart rate, tightness across the upper chest, the throat closing, breathing shallow and high up, and attention that narrows onto one person and one outcome. Sleep goes before the conversation does.

The throat matters more here than on most protocols. A tight throat is part of the state, and it changes your pitch, your volume and how fast you talk before you've said a word. So the first thing they get is a signal you never meant to send.

**Why Recognition leaves them out**

This state arrives fused to a prediction: what they will say, how it will go. The prediction feels like information.

Some of it may be accurate. But the prediction is not available to work on — it is about someone else's behaviour — while the state is. Naming the state without naming them separates a thing you can affect from a thing you cannot.

**Why the exhale is longer than the inhale**

You cannot decide your heart rate down. You can decide your breathing, and it is the one reachable control on a system you otherwise cannot get at. Lengthening the out-breath relative to the in-breath is what shifts the system toward settled, which is why a bigger breath is not a better one.

Loosening the jaw and dropping the tongue works on the throat directly, and the throat is what carries the state into the room audibly.

**Why Release goes after the drafting**

There is the state, and there is the drafting — running the conversation in advance, repeatedly, with both parts scripted.

Two different costs. Some drafting is real preparation — knowing the one thing you want to say is useful. Past that it's an argument with someone who isn't there, and it does two things. Each pass returns the body to the state from the start. And it locks you into a script, so when they say something you didn't rehearse, you've got less to work with rather than more.

Putting it down is not going in unprepared. The preparation you keep is the sentence you want to say.

The change of question does related work. *What is wrong with me that I cannot just have a conversation* asks about defect. *What was this for* asks about function — and preparing hard for conversations is what people do when conversations have gone badly, or when saying the true thing has cost them. It was earned somewhere.

**Why the fourth step rehearses one sentence**

Running the whole conversation in your head means rehearsing something you only control half of — and the half you don't control is the half you're worried about. Your body doesn't buy it.

The opening sentence is entirely yours. It's the one part that doesn't depend on them. It's specific enough to actually stick. And it's the bit most people find they can't come up with on the spot.

The instruction that you are allowed to say it badly is doing structural work rather than being kind. Waiting to be able to say it well is the most common reason a conversation never happens.

---

### The part that's on your side, and the part that can hear them

Almost everyone in a conflict is doing the same thing: building the case for their own version. It doesn't feel like building a case. It feels like thinking clearly, or finally being honest with yourself about what happened.

What's worth knowing is which part of you is doing the building.

**One part of you is entirely on your side.** It's the part that keeps you safe, and you need it — nothing here is telling you to get rid of it. But it works to a few fixed rules, and the rules aren't about fairness. They're about keeping you standing.

You come first. Not out of selfishness — that's just the job.

Nobody else's version can simply be as true as yours. It has to be measured against yours first.

And it decides what's real. Whether something is fair, or reasonable, or true gets settled by whether it fits what this part already believes.

> **GOLD/PAUSE**

Run an argument through a part of you with those rules and you win. Every time. Not because you're lying — because that's what it's for.

Which is the most useful thing to know about your own case: you'd already won it before you started going over the evidence.

**There's another part, and it works differently.** It can hear someone else's version as a whole thing in its own right, rather than as a wrong version of yours. It doesn't mean agreeing. It isn't the same as being nice. It's a way of taking in something the first part isn't built to accept.

You need both. The first one stops you being flattened in an argument. The second one is the only one that can end it.

**One rule, and it matters more than the rest of this.**

You can look at your own. You can't look at theirs.

You can hold that they've got the same two parts, and that theirs is doing the same job for them. That's what puts you level, rather than one of you above the other.

What you can't do is tell them what their side is up to. You can't see it from where you're standing, and saying it out loud is just the first part again, wearing better clothes. *That's just your ego talking* dismisses their whole version while sounding wise.

If you're explaining someone else's psychology to them in the middle of an argument, that's not insight. That's the case, still being built.

**This sits underneath all four steps here.** Naming the state separates it from your version of events. The breathing settles the body that's producing the case. The third step puts the case-building down. And the fourth asks you to stand somewhere that isn't your own spot — which is the second part, used on purpose, for as long as you can hold it.

*This is easier once you can catch your own state while you're in it. That's what Track 01 builds, and it's why it comes first. Nothing here needs it, and nothing here is judging whether you're ready — but the second part is hard to reach for while the first one is running unwatched.*

---

### What we rest on

**Polyvagal Theory — Stephen Porges** · *peer-reviewed* · supplies Recognition and the three state labels

Threat detection runs ahead of thought. The body reads a situation and moves before your thinking catches up, which is what makes the response fast and also what makes it non-negotiable in the moment. Porges describes three broad conditions: settled and socially available, mobilised for action, and shut down. Agitated, Unsteady and Numb are the member-facing names for those three. *Here it accounts for why an anticipated conversation produces the same state as a present one, and why the settled state is the one that can hold a difficult exchange.*

*The anatomical premises are contested: a 2026 evaluation in* Clinical Neuropsychiatry *challenged them, with Porges replying in the same issue. The state distinctions are what this platform uses, and they hold independently of that dispute.*

**Cardiac coherence — HeartMath** · *peer-reviewed* · supplies Regulation and the count

At roughly six breath cycles a minute, heart rhythm and breath settle into a single smooth wave rather than two competing ones, close to a rhythm the body's blood-pressure regulation already runs at. Four in, six out lands near that rate. The uneven ratio is the mechanism. *Here it is what you do in the ten seconds before you open your mouth, and the reason your voice arrives as your own.*

*The finding is used here; the wider programme is not. There is no measurement of coherence anywhere on this platform and no score attached to any breath.*

**Where the reading is yours** — this explains the machinery. What to say, whether to say it, and what any of it means about the relationship are readings that belong to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Long exhale, no ceremony.** Four in, six out, three or four cycles. Available in a corridor, a car, outside a door.

**Jaw apart, tongue down.** Teeth unclenched, tongue off the roof of the mouth. This opens the throat, and the throat is what carries the state into your voice.

**Hum, briefly.** Any note, low, a few seconds. It puts the voice in use before you need it, and a voice already in use arrives steadier than a cold one.

**Hand to sternum.** Flat, light, centre of the chest.

**Feet into the floor.** Press down, feel it push back. Worth doing while sitting opposite someone — nobody can see it.

**Say the sentence out loud, once, alone.** In a car, at home. Once. Saying it a fifth time is drafting, which is the thing the protocol asks you to put down.

*Shoulders down and back before you go in. This state lifts them and it is visible.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with the state that arrives before a difficult conversation, using breath, attention and observation. It makes no claim about what you should say, whether the conversation is a good idea, or how the other person will take it.

**Pacing**

Once through is a complete use, and immediately before is a legitimate time to use it — this is one of the protocols people run in a car park or a stairwell.

If four and six is a stretch, shorten both and keep the ratio uneven.

**What people commonly notice**

The state rising during Regulation as the conversation gets closer in mind. A strong pull to draft again immediately after finishing. Relief that is smaller than hoped for — this settles the body, it does not make a hard conversation easy.

Sometimes a clear sense that you do not want to have the conversation at all. That is worth noticing rather than overriding.

**When to slow down**

If Release opens something much larger than this conversation, you can stop there and come back to the breath.

If you run the protocol and the state does not shift at all across several attempts, that is information rather than failure, and it may be telling you something about the conversation rather than about your regulation.

**When the conversation is not the right move**

Some conversations should not be had, or not yet, or not by you alone. This protocol does not assess that and neither does anyone else on this platform.

**Where safety is part of it**

If you are frightened of how the other person will react — physically frightened, or frightened of the consequences — that is not a regulation problem and preparation is not the answer to it. Speak to someone outside the situation before you speak to them: a doctor, a helpline, a lawyer, or a friend who knows the whole picture rather than the version you can bear to tell. Your safety is a separate question from your regulation and it comes first.

**Alongside other support**

If you are with a therapist, doctor or counsellor, this sits alongside that and replaces nothing.

---

## 06 · Disclosure & Support
*A script for someone close.*

This is a script for telling a third person — not the one you are about to speak to. Take them exactly, or change every word.

**Saying it**
> "I've got a conversation coming up that I'm dreading. I'm not looking for advice on what to say. I'd just rather one person knew it was happening."

**Describing what it's actually like**

> "It's physical days before. Chest tight, throat closing, not sleeping properly. My body has already had the conversation about eleven times."

> "The part that's hard to explain is the drafting. I run it in my head over and over with both sides scripted, and it feels like getting ready. It isn't — it just puts me back at the start each time."

**What helps**

> "Ask me what the one thing is I want to say. Not the whole thing. Just the sentence. Being made to say it out loud once is worth more than an hour of planning."

> "Being available afterwards, without needing a full report. Just 'how did it go' and then whatever I want to say about it."

**What doesn't**

> "Rehearsing it with me. I know it seems helpful. It's the exact thing that's been keeping me stuck."

> "Telling me it'll be fine. You don't know, and neither do I, and it means I've got to reassure you back."

**If they ask what you're doing about it**

> "I run a method beforehand. Four steps. I name the state instead of the prediction, do a breathing pattern with attention on my throat and jaw, stop the drafting — which is the loop that's been running — and then rehearse only my opening sentence, because that's the only part of the conversation that's actually mine."

*Tell one person before you do it. Not for advice. So that it exists outside your own head before it happens.*

---

## 07 · Invitation to Repair
*Reopening it with them.*

On this protocol the invitation is not the aftermath — it is often the conversation itself, or the way into it. Sending something in writing first is a legitimate move, not an avoidance of the real one, and for some people it is the only version that happens at all.

Send it from the far side of the protocol, not from inside the state.

**The rule that makes it sendable:** no prosecution of them, and no case built in advance. If the message arrives with the argument already assembled, they will read it correctly as an opening move and prepare accordingly — and you will have made the conversation harder before it started.

**Sendable**
> There's something I've been wanting to talk to you about and I've been putting it off, which isn't fair on either of us.
>
> It isn't a complaint and I'm not arriving with a position. I'd just rather say it to you than keep carrying it.
>
> Is there a time this week that works? No rush.

**Shorter**
> Can we talk about something? Nothing bad. I've just been sitting on it too long.

**Where you need to name the subject**
> I want to talk to you about how things have been since [the thing]. I don't have a conclusion about it and I'm not looking to settle who was right. I'd like to hear how it's been for you as much as say how it's been for me.

**Where the conversation has been tried before**
> We've had a version of this conversation before and it didn't go well, and I think that was partly how I came into it. I'd like to try again, differently. If you'd rather not, I'll take that.

**Before sending** — read it back for a case in disguise: *always, never, actually, to be fair, I've realised.* Cut them. Then check the timing you have proposed. A conversation requested for now, tonight, while something is live, is a demand rather than an invitation.

*If they don't take it, or not yet, you have done the part that was yours. Whether they meet it is theirs.*

---

## 08 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it is never measured against anything you wrote before. Because it is only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

Any of these, or none.

- Where did it sit in your body?
- What is the one thing you want to say? Write it as a single sentence.
- How many versions had you drafted? What happened in the worst one?
- What are you actually afraid of — what they'll say, or what it'll mean?
- *What was this for* — what turned up, without needing to answer it?
- What did you say to yourself from across the room?
- What was your opening sentence? Did you use it?
- If it has happened: what did they actually say, compared with what you had them saying?
- What did you write here last time? Read it back.

That last-but-one prompt is the useful one on this protocol. Your record of the gap between the rehearsed version and the real one is the only evidence you have that the drafting was not preparation.

---

## 09 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half exits — and before a conversation, most of it exits before you have said anything at all.

**The specific blind spot here** — the state arrives in the room ahead of your words. A tight throat changes your pitch. A narrowed system makes you brisk. From inside you are being careful. From outside, the first thing they receive is someone braced, and they brace back — which produces the difficult conversation you were preparing for.

**The second one** — the delay. Weeks of not raising something, while your manner changes. From inside that is waiting for the right moment. From outside it is being kept at arm's length by someone who will not say why, and it is usually more corrosive than the conversation would have been.

**The third one** — arriving with the script. When you have drafted eleven versions, the real exchange gets treated as a deviation from the plan. From outside, it is being talked at rather than talked with.

**Their earlier information** — the person you are dreading the conversation with can often tell something is coming. Worth asking, once it is open: *how long had you known something was up?*

**Naming the act, not the character** — *"I've been distant with you for a month and I didn't say why"* is ownership. *"I'm rubbish at this stuff"* is not; it names nothing and asks them to reassure you before you have said the thing.

**No because.** The dread is real and it does not belong in the sentence. It can be said afterwards, if they ask.

**No self-attack.** *"I'm sorry, I always do this, I'm hopeless"* moves the burden across the table — now they are managing your distress about having kept them waiting.

**Describe what was observable, ask about the rest.** *"I've been off with you for a few weeks. I'm not going to tell you what that was like — I'd rather you told me."* Then let them answer without correcting it.

**The checkable change** — this repairs by raising things sooner rather than by raising them better. *"I'm going to say it within a week, even if I say it badly"* is small, specific and observable.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. And if you are frightened of the other person, none of this applies: the Safe Practice section on this protocol is the relevant one, and your safety comes before any conversation.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Draft it. Have every version ready before you go in.

Run the conversation. Then run their reply, and your reply to that. Get the whole thing written so you can't be caught without the words.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Being caught without an answer. Saying it badly and it counting against me. Losing something because I put it wrong.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the week before every difficult conversation*, or *the ones I never had because the drafting never finished.*

---

**What it should be attending to instead**

It isn't going in unprepared. Preparation is fine — it's the eleventh version that isn't.

What's available is a different instruction about **how much to write**.

The old one writes both parts. The successor writes its own first sentence and leaves the rest of the conversation to the conversation.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *know my opening line and nothing after it.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *says the first sentence and then listens. Asks rather than assuming what they'll say. Has it sooner, less prepared.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Opens the throat. Says the opening line as written. Stops rehearsing the moment they start speaking.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
