# t2-03 · The Trust & Betrayal Protocol

**Label:** Rebuild · **State:** Agitated · **Frameworks:** Porges, Maté · **extras:** `['advisory','invitation']`
**Resources: 10** · *meditation authored ahead of the remaining resources — Release language here is canonical*

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Turn at four seconds.
> **VOICE** — steady, unflinching, in no hurry to get to repair. Does not soothe and does not push toward forgiveness. Someone who can hear it without flinching.

There was a before and there's an after, and you know the exact moment.

> **GOLD/PAUSE** — long

And everything on the other side of it got quietly reclassified. Things you were sure of last month are now evidence.

> **GOLD/PAUSE**

Nothing here is going to tell you what to do about them. Not whether to stay, not whether to go, not whether it can be rebuilt. That's yours and it stays yours.

---

### Recognition

Where is it sitting?

> **GOLD/PAUSE** — long

Chest and stomach, usually, at the same time. Something hot and something dropping. The jaw. A restlessness that has nowhere to put itself.

> **BLUE/ILLUSTRATION** — a surface with a fracture running through it. Both halves still present, still whole.

One word. **Agitated.**

> **GOLD/PAUSE**

And notice what that leaves out. It leaves out them. What they did, when, and how long it went on.

> **GOLD/PAUSE** — long

Not because any of that is in question. It happened, and this doesn't touch it.

> **GOLD/PAUSE**

But there are two things in you and only one moves. The account of what they did is sitting there, complete, and it will be exactly as complete when we finish. The state is here, in your chest, and that one is reachable.

---

### Regulation

Four counts in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six out. Longer out than in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the middle of your chest.

> **RED/ACTION** — hand to sternum, flat, light. Offered, not instructed.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Sleep's probably gone. That's what this state does — it doesn't stand down at night because it's decided nights are when things get past you.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

### Release

Two things running, and the first one is not up for discussion.

> **GOLD/PAUSE**

Something happened. It was real. It cost you something.

> **GOLD/PAUSE** — long

And the second thing is the going back through everything else. Every conversation, every trip, every ordinary Tuesday — re-read, looking for what you missed.

> **GOLD/PAUSE** — long

Does it ever come out clean?

> **GOLD/PAUSE** — very long

It doesn't. Every pass finds something, because anything can be read two ways once you're reading for it. You could go through five years and never reach the end.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

The betrayal stays. Put down the re-reading.

> **GOLD/PAUSE** — long

That's not deciding you were wrong about anything. It's stopping a search that has no last page.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And the question. Not *how did I not see it* — that one puts the fault on the person who was lied to, and it'll run all night if you let it.

**What was this for?**

> **GOLD/PAUSE** — long

Something in you went to high alert and hasn't come off it. It's checking things. Reading tones. Storing details.

> **GOLD/PAUSE**

That's not madness. That's a system that got surprised once and has decided never again.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Leave it there.

> **GOLD/PAUSE** — long

---

There's more here if you want it, and it takes longer.

> **GOLD/PAUSE**

If today is a day for getting steady and stopping there, stop there. Come back to the count, finish, and go. That's a complete use of this.

> **GOLD/PAUSE** — very long

Still here.

> **GOLD/PAUSE**

Then one thing has to be said first, because everything after it depends on it.

> **GOLD/PAUSE**

What they did happened. It was real, it was theirs, and nothing in the next few minutes reduces it or hands you a share of it.

> **GOLD/PAUSE** — long

Two things can be true at once. They did something. And it landed on something already in you.

> **GOLD/PAUSE** — very long

That second part is the only one either of us can work on from here.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

So. The intensity of it.

Not whether it's warranted — it is. The size of it.

> **GOLD/PAUSE** — long

What did it seem to say about you?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — a fracture, and beneath it a second line running deeper and further than the first.

For a lot of people it says something like — *I wasn't worth telling the truth to.* Or *I wasn't the one chosen.* Or the one that does the most damage: *I can't trust what I see any more.*

> **GOLD/PAUSE** — very long

Those aren't conclusions. They're what a system reaches for when something it relied on turns out to have been false.

> **GOLD/PAUSE** — long

And notice which of those, if any, is doing the most.

> **GOLD/PAUSE** — very long

I'm not answering that. I don't know, and nobody outside your life does.

> **GOLD/PAUSE**

If something surfaced, let it have been said. Don't do anything with it yet.

> **GOLD/PAUSE** — long

If nothing came, that's a real answer too, and this one usually arrives later than you'd want.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

---

Now — what has been trying to protect you since?

> **GOLD/PAUSE** — long

The checking. The alertness. The going back over everything. That's not you falling apart.

> **GOLD/PAUSE**

That's a system that got told, once, that its reading of the world was wrong — and has been double-checking ever since so it never happens again.

> **GOLD/PAUSE** — very long

It's expensive. It's also loyal to you.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before we move.

> **GOLD/PAUSE**

If you've just seen the size of it, there'll be something arriving behind that. Some version of *I should be over this by now.*

> **GOLD/PAUSE** — very long

Put that down. What you found under there is not a small thing, and struggling with it is the appropriate response — not a failure to cope with it.

> **GOLD/PAUSE** — long

And this. Something in you was willing to look under it while it's still open and still hurting.

> **GOLD/PAUSE**

That took something. It was yours before today, and it's what the rest of this runs on.

> **GOLD/PAUSE** — very long

One more, and it's simply true rather than comforting. Whatever you found under there — you're not the only one. Not close to it. Almost nobody says it out loud, which is the only reason it feels rare.

> **GOLD/PAUSE** — very long

And none of that decides anything. What they did is still what they did. The signal has given you information about yourself, and information isn't a verdict — it's yours to do something with, when you choose to.

> **GOLD/PAUSE** — long

If it opened something bigger than today, come back to the count now and end here. Going further on your own isn't the brave version. It's just the unaccompanied one.

---

### Rise

Step outside it.

Someone across the room, breathing four and six, holding something heavy and holding it steadily.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Speak to them as *you*.

*You were right about what happened. And nothing has to be settled today unless it does.*

> **GOLD/PAUSE** — long

Both halves. The second one is the one people skip.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now forward, and small. Not the conversation where it's resolved — you don't control that half, and it may not be available at all.

Today. Somewhere specific, doing something ordinary, with this unresolved. What's in your hands. What's around you.

> **GOLD/PAUSE** — long

Carrying it and still going. That's the only version on offer, and it's more than it sounds.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing that's still yours. Something this didn't take.

> **GOLD/PAUSE**

Now put the rest of it down. You don't have to carry it out of here.

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back. Feet on the floor.

Nothing's decided and nothing's forgiven. That was never on the table today.

What's changed is that you're not searching, and you'll think better about all of it from here than from where you were.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are agitated.* The state, not the account.
**Breathe it** — Four in, six out. Hand to your chest.
**Stop re-reading the past** — It has no last page.
**Step out** — *You were right about what happened. Nothing has to be settled in the next hour.*

### Back

**Recognition** — Find it in your body: chest and stomach together, something hot and something dropping. Name the state in one word. Leave out what they did and when — not because any of it is in question, but because the account is finished and the state isn't. One of the two is reachable.

**Regulation** — Four in, six out. Attention in the centre of your chest, hand there if it helps. Sleep has probably gone; this state doesn't stand down at night because it has decided nights are when things get past you.

**Release** — Two things are running. The betrayal, which happened and cost you something. And the re-reading — every conversation, every trip, every ordinary Tuesday, gone through again looking for what you missed. It never comes out clean, because anything can be read two ways once you're reading for it. Put down the re-reading. Keep the account.

**Rise** — See yourself from a distance. *You were right about what happened, and you don't have to decide anything today.* Then one concrete ordinary thing today, with this unresolved. Then one thing that's still yours.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

Discovering you were wrong about something you relied on produces a mobilised state, and it produces a specific version of it: high alert with no off switch.

In the body — raised heart rate, heat and dropping at once, disturbed sleep, appetite gone, and attention that will not settle on anything unrelated. Sleep goes first and stays gone longest, because the system has concluded that not-watching is when things get past you.

**Why the account and the state come apart**

Both are real and they are not the same object. The account of what happened is finished — it has all its evidence and it is not going to change during a session.

The state is a physical condition running in you now, and it answers to different tools than the account does. While they are fused, settling the body feels like conceding the account, so people stay lit for months. Splitting them costs you nothing you were holding.

**Why the exhale is longer than the inhale**

You can't decide a state down. You can decide your breathing, and it's the one reachable control on a system you otherwise can't get at. Lengthening the out-breath relative to the in-breath is what shifts things toward settled. Contact and warmth at the sternum is a related input and one of the fastest available.

**Why Release goes after the re-reading**

There's the betrayal. And there's going back through everything else — the ordinary weeks, the explanations that made sense at the time, the trips.

Two different costs. The re-reading feels like establishing the truth. But once you are reading for something, everything reads two ways, so every pass finds material and no pass concludes. You could go through five years and never reach a last page.

That is the tell. A search that cannot terminate is not investigation.

The change of question does related work. *How did I not see it* puts the fault on the person who was lied to, and it will run all night. *What was this for* asks about function — and what it surfaces is a system that got surprised once and has decided never again. Understanding that is not endorsement, of anyone.

**Why Rise doesn't move toward a decision**

Whether this is rebuildable is not a question a session can answer, and it is not one you have to answer today. Rehearsing the resolution rehearses an event you control half of at most, and possibly none of.

What is available is an ordinary hour, carried out while this is unresolved. That's the scene that transfers.

---

> **SHARED BLOCK** — insert *The part that's on your side, and the part that can hear them* here, verbatim from `SHARED-t2-two-instruments.md`. Identical on all ten Track 02 protocols. Do not paraphrase or re-cut per protocol.

---

### What we rest on

**Polyvagal Theory — Stephen Porges** · *peer-reviewed* · supplies Recognition and the three state labels

Threat detection runs ahead of thought. The body reads a situation and moves before your thinking catches up. Porges describes three broad conditions: settled and socially available, mobilised for action, and shut down. Agitated, Unsteady and Numb are the member-facing names for those three. *Here it accounts for the alert that will not stand down, including at night.*

*The anatomical premises are contested: a 2026 evaluation in* Clinical Neuropsychiatry *challenged them, with Porges replying in the same issue. The state distinctions are what this platform uses, and they hold independently of that dispute.*

**Compassionate Inquiry — Gabor Maté** · *clinical practice* · supplies Release and the way the question is asked

A response is treated as an adaptation rather than a defect. The kind of question you ask decides the kind of answer you get. *What is wrong with me* asks what is broken, and comes back with a list of what is broken. *What was this for* asks what it was doing, and comes back with something you can use. *Here it stops the protocol becoming a search for what you should have noticed.*

*A clinical practice, not a controlled research programme. Used here for the way the question is asked, and nothing wider.*

**Where the reading is yours** — this explains the machinery. What happened, what it means, and whether any of it can be rebuilt are readings that belong entirely to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Long exhale, no ceremony.** Four in, six out, three or four cycles.

**Hand to sternum.** Flat, light, at the place the heat sits.

**Phone and messages further than an arm.** Re-reading is a physical loop before it's a mental one, and distance interrupts the loop rather than the wanting.

**Feet into the floor.** Press down, feel it push back. This state makes the ground feel unreliable and the correction is literal.

**Cool water on the wrists.** A few seconds at a tap when the heat is the loudest part.

**One thing with a definite end.** A short walk to a fixed point, a single task, a shower. This state has no natural stopping place, so borrow one.

**Be near people who don't know.** A shop, a café, a queue. Not to talk. Undirected proximity, with nothing required of you.

*Sleep is likely to be the last thing to come back. That's ordinary here and it isn't a measure of how you're doing.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with the state that follows a betrayal, using breath, attention and observation. It makes no ruling on what happened, doesn't assess whether the relationship can be rebuilt, and doesn't move you toward forgiveness.

**Pacing**

Once through is a complete use. Use it when the state is there. If four and six is a stretch, shorten both and keep the ratio uneven.

**What people commonly notice**

The state rising at Release rather than settling, particularly early on. Anger arriving where grief was, or the reverse, sometimes within a minute. Physical symptoms that surprise people — nausea, appetite gone, a heart rate that won't come down. Sleep disturbed for a long time after the rest has eased.

**When to slow down**

If the re-reading continues right through the session and won't drop at all, end it and use the somatic activities instead. Running the protocol while the loop is going teaches your body that the protocol is part of the loop.

If Release opens something much older than this — a previous betrayal, something from a long way back — you can stop there and come back to the breath.

**When a person in the room is the right tool**

Contact someone — a doctor, a helpline in your country, or a person you trust — if you're not sleeping across weeks rather than days, if you're not eating, if you're using something to get through it, if you're checking or monitoring in ways you'd be uncomfortable describing out loud, or if you're having thoughts of harming yourself.

**Where safety is part of it**

If what happened involved violence, if you're frightened of them, or if you're being controlled or monitored, this is not a regulation problem and no practice addresses it. Speak to someone outside the situation: a doctor, a helpline, a lawyer, or a friend who knows the whole picture rather than the version you can bear to tell. Your safety is a separate question from your regulation and it comes first.

**Alongside other support**

If you're with a therapist, doctor or counsellor, this sits alongside that and replaces nothing. This is one of the protocols where having a person is worth a great deal.

---

## 06 · Proximity Guide
*How close to stay.*

This state has a live external source, and how much contact you have with it is one of the few variables you hold.

Three tiers. Which one yours belongs in is your read, on information nobody here has.

**Worth staying engaged with**

Where the account is now complete — you know what happened, they've stopped defending it, and nothing further is being withheld. Where their conduct has actually changed rather than been promised. Where contact is difficult but doesn't reliably produce the state.

Distance isn't the tool here. Time is, and the protocol is what makes the time bearable rather than a slow accumulation of the same state.

**Worth reducing the surface area of**

Where contact reliably relights it. Where new information keeps arriving in pieces. Where you're managing your own behaviour constantly to keep things level, or checking to establish whether it's still happening.

Reduction here is specific: fewer occasions, ones with other people present, a channel you close, a period with no contact at all that isn't announced as a decision about the future.

Checking deserves separate attention. It feels like establishing the truth. It reliably produces material and never produces certainty, and it changes what you are in the relationship as much as what you know.

**Past what self-regulation is for**

Where you're being lied to about the lying. Where you're being told your memory is wrong. Where information is withheld and then produced to manage you. Where you're frightened, or being monitored, or being made unsafe.

That isn't a regulation problem, and treating it as one converts a situation needing other people into a private failure of coping. What it needs is a doctor, a lawyer, a helpline, or a friend who knows the whole picture rather than the version you can bear to tell.

**Using this**

Notice the tier. Then notice whether it's the tier you'd assign if a friend described the same thing. Where it goes next is yours — this platform doesn't tell members to leave or stay, and nobody here knows what you'd be giving up.

---

## 07 · Disclosure & Support
*A script for someone close.*

For telling a third person — not the one this is about. Take these exactly, or change every word.

**Saying it**
> "Something happened with [them] that I'm still in. I'm not looking for you to tell me what to do about it. I'd rather one person knew where I actually am."

**Describing what it's actually like**

> "It's physical before it's anything else. Heat and a dropping feeling at the same time, and I'm not sleeping. That's not me dwelling on it — my body decided nights are when things get past you and it hasn't reconsidered."

> "The part I can't switch off is going back through everything else. Every trip, every conversation, checking what I missed. It never comes out clean, because once you're looking for something everything reads two ways."

**How to tell it's coming**

> "I go very quiet, or very busy. I start checking things. I ask you the same question in slightly different ways."

**What helps**

> "Believe the account without adding to it. If you tell me what you always thought of them, I now have to manage that as well."

> "Ask me what I actually want, rather than what I should do. I get a lot of should."

> "Ordinary company. Sitting somewhere with you and talking about something else is worth more than another round of the subject."

**What doesn't**

> "Telling me what you'd do. You aren't in it and you don't have the whole thing, and neither of those is your fault."

> "Asking whether I'm going to leave. I don't know, and being asked makes it a decision I have to have an answer to before I've got one."

**If they ask what you're doing about it**

> "There's a method I run. I name it as a state rather than as the whole account, do a breathing pattern with a hand on my chest, stop the going-back-through-everything — which is the loop that's been eating my nights — and then look at it from a distance and get through an ordinary day with it unresolved."

> "It doesn't tell me what to do. It stops the searching."

*Tell one person, and pick one who won't require you to have decided. The pressure to have an answer is the thing most people can't carry alongside the rest of it.*

---

## 08 · Invitation to Repair
*Reopening it with them.*

⚠ **This resource assumes you have chosen to open a conversation.** It doesn't recommend one, and there are situations where opening one is the wrong move — see Safe Practice. If you're frightened of them, or being controlled or monitored, this isn't the resource for that situation.

Send it from the far side of the protocol, not the middle. From inside the state it carries the whole account regardless of the words, and it will be answered defensively.

**The rule that makes it sendable:** no prosecution, and no demand for an answer you've already scripted. That's harder here than anywhere else on the platform, because you are the one who was wronged and the case is entirely available. Leaving it out is not conceding it. It's declining to open with it.

**Sendable**
> I've been carrying this on my own and I don't want to keep doing that.
>
> I'm not writing to go back through it. I know what happened and I imagine you know what you know.
>
> What I'd want is to talk — not to settle anything today, and without me arriving with a list. If you'd rather not, or not yet, I'll take that.

**Shorter**
> I want to talk about it properly at some point. Not today, and not to relitigate. Just so you know that's where I am.

**Where you need something specific**
> There's one thing I need to understand, and it isn't the whole thing. Can we do that one, on its own, without it turning into everything?

**Where you don't want a conversation yet, and want to say so**
> I'm not ready to talk about it and I don't know when I will be. I'd rather tell you that than have you read the silence as something else.

**Before sending** — read it back for the case in disguise: *always, never, obviously, how could you, I've realised.* Cut them. Then check what answer would make it a success. If only one answer works, it's a demand.

*If they don't take it, you've done the part that was yours. Whether they meet it is theirs, and it always was.*

---

## 09 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

Any of these, or none.

- Where did it sit in your body?
- What happened? Write it once, plainly, as events.
- What did the re-reading turn up today? Was any of it unambiguous?
- How long have you been going through the same period?
- *What was this for* — what turned up, without needing to answer it?
- What did you say to yourself from across the room?
- What do you actually want? Not what you should want.
- Is anything different from a month ago? Including no.
- What did you write here last time? Read it back.

That last one is worth more on this protocol than most. The state produces a confident, changing account of the past, and your own record from a month ago is the only version of it that isn't being rewritten by today.

---

## 10 · Accountability & Empathy
*What it does outside you.*

⚠ **Read this first.** This resource asks you to look at your own conduct. That's the right work where both people can move. Where you're being controlled, monitored or made afraid, looking harder at yourself is the mechanism that keeps people in those situations — the Proximity Guide's third tier is the resource for that, and your safety is a separate question from your regulation.

Assuming that isn't where you are:

The protocol trains the interior half of the state. The other half exits, and after a betrayal it lands on people who had nothing to do with it.

**The specific blind spot here** — the alert doesn't discriminate. The checking, the tone in ordinary questions, the second look at a plausible explanation from someone unrelated. From inside it's caution you've earned. From outside, people who never lied to you are being treated as though they might.

**The second one** — the account, told repeatedly. Every telling firms it up, and the version you'd give now is further from the events than the first one was. That isn't dishonesty; it's what retelling does. But it means the people around you are holding a version you can no longer amend without admitting you built it.

**The third one** — the withdrawal. Cancelling, not replying, being present and elsewhere. From inside it's having nothing spare. From outside it's being dropped by someone in a crisis they'd have helped with.

**Their earlier information** — the people close to you often saw something before you did, and most of them have said nothing because there was nothing safe to say. Worth asking, once: *did anything seem off to you, before?* And then not making them justify the answer.

**Naming the act, not the character** — *"I've been short with you for a month and you had nothing to do with any of it"* is ownership. *"I'm a mess"* is not; it names nothing and asks them to reassure you.

**No because.** The betrayal is an enormous reason and it doesn't belong in the sentence. Everyone already knows it. It can be said afterwards, if they ask.

**No self-attack.** *"I'm sorry, I'm impossible, I don't know why you put up with me"* moves the burden across at exactly the point they've been carrying you.

**Describe what was observable, ask about the rest.** *"I've been hard work for a while. I'm not going to tell you what that's been like — I'd rather you told me."*

**The checkable change** — this repairs by flagging rather than by being better. *"I'll tell you when it's a bad day instead of just going quiet"* is small, specific and doesn't require you to have recovered.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. And on this protocol specifically: the person who lied to you is not a reliable narrator of your conduct.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Re-read everything. Never be surprised again.

Go back through the ordinary weeks. Check what was said, what was meant, what got past you. Store the details. Read the tone. Make sure nothing like that can arrive unannounced twice.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Being taken in again. Being the one who didn't see it. Not being able to trust my own reading of a room.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the nights*, or *the way I now hear people who've done nothing.*

---

**What it should be attending to instead**

It isn't trusting them again. That's a separate question, it's yours, and nothing here has a view on it.

What's available is a different instruction about **what to watch**.

The old one re-reads the past, which has no last page. The successor watches what happens from here — which is the only evidence that can actually tell you anything.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *watch what they do from now on, not what they did before.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *doesn't go back through old messages. Notices something that happened today. Says what they need rather than testing whether it'll be given.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Names the state. Doesn't open the search. Waits for something that actually happens.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
