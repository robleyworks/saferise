# t2-02 · The Rupture & Repair Protocol

**Label:** Repair · **State:** Unsteady · **Frameworks:** Porges, Maté · **extras:** `['invitation']`
**Resources: 9**

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Five-bar phrase. Turn at four seconds.

It's still open. That's why you're here.

> **GOLD/PAUSE**

Something went wrong between you and someone, and neither of you has moved.

> **GOLD/PAUSE**

Something has gone wrong between you and someone. This works on the state you're in about it, and it makes no ruling on what happened or who did what.

---

### Recognition

Find where it is in your body, before any of the words.

> **GOLD/PAUSE**

Chest, often — an ache rather than a tightness. The stomach. Something in the throat. A restlessness that has nowhere to go, because the thing it wants to do involves another person.

> **BLUE/ILLUSTRATION** — two forms with a break between them. The break has an edge on both sides.

Now name the state. One word. **Unsteady.**

> **GOLD/PAUSE**

Notice what that word leaves out. It leaves out the account. What was said, in what order, who started it, what it was really about.

> **GOLD/PAUSE**

You have an account. They have one too, and theirs will not match yours, and that on its own is not evidence of anything.

We're not touching either account. Only the state.

---

### Regulation

Four counts in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six counts out. Longer out than in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the centre of your chest — including the part that aches. We're not going around it.

> **RED/ACTION** — hand to sternum, flat, light. Offered, not instructed.

If a hand there helps, put one there.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

This state pulls toward the phone. Toward sending something, or checking whether they've sent something. Not yet.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

One further, if there's room.

> **GOLD/PAUSE**

What happened between you is real, and nothing here reassigns it.

> **GOLD/PAUSE** — long

And two things can be true. Something went wrong. And it landed on something already there.

> **GOLD/PAUSE** — very long

So — what does it seem to say, that it's still open?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — two forms with a break between them, and beneath both an older line running under the gap.

For a lot of people it's some version of *I'm not worth the repair.* Or *they're not going to come, and I'll have been the one who cared more.*

> **GOLD/PAUSE** — very long

That's what makes the silence heavier than the rupture. The rupture happened once. The silence keeps saying something.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

I'm not telling you which is yours. From outside your life nobody knows.

> **GOLD/PAUSE** — long

And the accounting — what's it protecting?

> **GOLD/PAUSE** — very long

You from reaching first and finding out it wasn't mutual. As long as the ledger says they owe the first move, you don't have to discover the answer.

> **GOLD/PAUSE**

That's not stubbornness. That's protection from a specific answer you'd rather not have.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before we move.

> **GOLD/PAUSE**

Something will arrive behind that — usually *I'm being childish about this.*

> **GOLD/PAUSE** — very long

Put it down. If what's underneath is whether you're worth someone crossing the room for, then of course it's been sitting there for weeks.

> **GOLD/PAUSE** — long

And something in you looked at your own half while it's still open.

> **GOLD/PAUSE** — very long

One more, simply true rather than comforting. Almost every unrepaired thing has two people in it waiting for the other one to move, both of them certain they're the one being left.

---

### Release

Two things are running.

> **GOLD/PAUSE**

There's the rupture. Something happened, it hurt, and it's still open. That's real and it isn't being minimised.

And there's the accounting. Going back through it to establish the ledger — what they did, what you did, what the proportions were, who owes what. You've done several passes and the total keeps coming out in your favour.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

The accounting feels like getting clear. What it's doing is preparing a case, and a case needs someone to lose.

> **GOLD/PAUSE**

And notice the total. It comes out in your favour, every time you run it.

That isn't dishonesty. The part of you going over it is on your side, not on the fence. You'd won before any of the evidence went in.

Let the rupture be here. It happened.

Put down the accounting. Only that. Not your view of what happened — that stays, entire.

> **GOLD/PAUSE** — long

And the question. Not *what's wrong with me that this keeps happening* — that returns nothing you can use.

**What was this for?**

> **GOLD/PAUSE** — long

Something in you moved fast when the rupture happened, and it moved to protect something. Understanding what it was protecting doesn't excuse anyone, and it doesn't settle who was right.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Leave the question there.

---

### Rise

Step outside it.

See yourself from across the room. Someone sitting there with something unresolved, breathing four and six.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Speak to them as *you*.

*Something broke, and you want it back. That's all this is so far.*

> **GOLD/PAUSE**

No verdict. Nothing about whether you should want it back, or whether they deserve it.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now stay out there a moment longer, and stand somewhere else.

Where they were standing. Same room, same evening, seen from their side. What landed, from there. What they didn't know that you did.

> **GOLD/PAUSE** — long

Not agreeing with them. Just standing where they stood, briefly.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now forward, and concrete. Not the scene where it's resolved — you don't control that half.

One move that's yours. What you'd send, or say, or do first. Where you are when you do it. The actual opening words.

> **GOLD/PAUSE** — long

And one thing that's still here. Something the rupture didn't take.

> **GOLD/PAUSE**

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back. Feet on the floor.

Nothing is repaired. That was never going to happen in here, and it takes two.

What's changed is that you're no longer building a case, and the move that's yours is available from where you're now standing.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are unsteady.* The state, not the account.
**Breathe it** — Four in, six out. Phone down. Hand to your chest.
**Put down the accounting** — Not your view. A case needs someone to lose.
**Step out, then stand where they stood** — Then one move that's yours.

### Back

**Recognition** — Find it in your body: an ache in the chest, the stomach, the throat. Name the state in one word. Leave the account out of it — you have one, they have one, and theirs won't match yours. That mismatch is not evidence of anything on its own.

**Regulation** — Four in, six out. Attention in the centre of your chest, including the part that aches. Hand there if it helps. This state pulls toward the phone — toward sending, or checking. The count first.

**Release** — Two things are running. The rupture, which happened and still hurts. And the accounting — going back through to establish who owes what, with the total always coming out in your favour. That feels like getting clear. It's building a case, and a case needs someone to lose. Put down the accounting. Keep your view of what happened.

**Rise** — See yourself from a distance. *Something broke, and you want it back.* Then stand where they stood — same room, same evening, seen from their side. Not agreeing. Standing there. Then one move that's yours: what you'd send or say first, and the actual opening words.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

Falling out with someone close registers as a threat, and your body handles it with the same equipment it uses for physical danger. The reading happens below awareness and moves before your thinking catches up.

In the body: an ache rather than a tightness through the chest, disturbance in the stomach, the throat closing, broken sleep, and a restlessness with nowhere to discharge, because the action it wants involves another person who is not available.

**Why Recognition leaves the account out**

Both people have an account of what happened, and the accounts will not match. That is not usually evidence of dishonesty — two people in the same exchange have different information, different histories and different vantages, and produce different records.

While the state and the account are fused, working on the state feels like conceding the account, so people stay lit. Separating them lets the body settle without giving anything up. Your account is still there afterwards, unchanged.

**Why the exhale is longer than the inhale**

You cannot decide a state down. You can decide your breathing, and it is the one reachable control on a system you otherwise cannot get at. Lengthening the out-breath relative to the in-breath is what shifts the system toward settled. Contact and warmth at the sternum is a related signal and one of the quickest available.

**Why Release goes after the accounting**

There is the rupture, and there is the accounting — going back through it to establish the ledger.

Two different costs. Going over it feels like getting clear, and it produces something that looks like an answer. But it's building a case — and a case is built to be won, which means somebody has to lose. That is the opposite of the thing you want, and it is why the accounting reliably makes reconciliation harder while feeling like progress toward it.

Putting it down doesn't mean deciding you were wrong. Your view of what happened stays exactly as it is. What stops is the building.

The change of question does related work. *What is wrong with me that this keeps happening* asks about defect and returns answers about defect. *What was this for* asks about function, and what it surfaces is that something moved fast to protect something. Understanding what a response was doing is not endorsement — of the response, or of anyone's conduct — and it settles nothing about who was right.

**Why the fourth step has an extra move**

On most protocols the fourth step is distance from your own experience. Here there is a second position: standing where the other person stood.

That's the same move, turned outward. Stepping outside your own spot settles you. Stepping into theirs gives you something you can't get from inside your own version. It isn't agreeing with them and it isn't deciding they were right. It's standing somewhere else for a minute.

The forward move is then deliberately one-sided. Rehearsing the resolution is rehearsing an event you control half of. The move that is yours — what you send, what you say first — is available regardless of what they do.

---

### The part that's on your side, and the part that can hear them

Almost everyone in a conflict is doing the same thing: building the case for their own version. It doesn't feel like building a case. It feels like thinking clearly, or finally being honest with yourself about what happened.

What's worth knowing is which part of you is doing the building.

**One part of you is entirely on your side.** It's the part that keeps you safe, and you need it — nothing here is telling you to get rid of it. But it works to a few fixed rules, and the rules aren't about fairness. They're about keeping you standing.

You come first. Not out of selfishness — that's just the job.

Nobody else's version can simply be as true as yours. It has to be measured against yours first.

And it decides what's real. Whether something is fair, or reasonable, or true gets settled by whether it fits what this part already believes.

> **GOLD/PAUSE**

Run an argument through a part of you with those rules and you win. Every time. Not because you're lying — because that's what it's for.

Which is the most useful thing to know about your own case: you'd already won it before you started going over the evidence.

**There's another part, and it works differently.** It can hear someone else's version as a whole thing in its own right, rather than as a wrong version of yours. It doesn't mean agreeing. It isn't the same as being nice. It's a way of taking in something the first part isn't built to accept.

You need both. The first one stops you being flattened in an argument. The second one is the only one that can end it.

**One rule, and it matters more than the rest of this.**

You can look at your own. You can't look at theirs.

You can hold that they've got the same two parts, and that theirs is doing the same job for them. That's what puts you level, rather than one of you above the other.

What you can't do is tell them what their side is up to. You can't see it from where you're standing, and saying it out loud is just the first part again, wearing better clothes. *That's just your ego talking* dismisses their whole version while sounding wise.

If you're explaining someone else's psychology to them in the middle of an argument, that's not insight. That's the case, still being built.

**This sits underneath all four steps here.** Naming the state separates it from your version of events. The breathing settles the body that's producing the case. The third step puts the case-building down. And the fourth asks you to stand somewhere that isn't your own spot — which is the second part, used on purpose, for as long as you can hold it.

*This is easier once you can catch your own state while you're in it. That's what Track 01 builds, and it's why it comes first. Nothing here needs it, and nothing here is judging whether you're ready — but the second part is hard to reach for while the first one is running unwatched.*

---

### What we rest on

**Polyvagal Theory — Stephen Porges** · *peer-reviewed* · supplies Recognition and the three state labels

Threat detection runs ahead of thought. The body reads a situation and moves before your thinking catches up. Porges describes three broad conditions: settled and socially available, mobilised for action, and shut down. Agitated, Unsteady and Numb are the member-facing names for those three. *Here it accounts for why a rupture with someone close produces the same machinery as physical threat, and why the settled state is the only one that can hold a repair conversation.*

*The anatomical premises are contested: a 2026 evaluation in* Clinical Neuropsychiatry *challenged them, with Porges replying in the same issue. The state distinctions are what this platform uses, and they hold independently of that dispute.*

**Compassionate Inquiry — Gabor Maté** · *clinical practice* · supplies Release and the way the question is asked

A response is treated as an adaptation rather than a defect — something that was doing a job, whether or not it is still the right job. The kind of question you ask decides the kind of answer you get. *What is wrong with me* asks what is broken, and comes back with a list of what is broken. *What was this for* asks what it was doing, and comes back with something you can use. Understanding is not endorsement. *Here it is what lets you look at your own part without either prosecuting yourself or dropping your view of what happened.*

*A clinical practice, not a controlled research programme. Used here for the way the question is asked, and nothing wider.*

**Where the reading is yours** — this explains the machinery. What happened, who did what, whether the relationship is worth repairing, and what to do next are readings that belong entirely to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Phone face-down, out of reach.** Not away forever — further than an arm. Checking is a physical loop and distance interrupts the loop rather than the wanting.

**Long exhale, no ceremony.** Four in, six out, three or four cycles.

**Hand to sternum.** Flat, light, at the place the ache sits.

**Weight into the chair or the ground.** Press down, feel it push back. This state makes the body feel unsupported.

**Walk, without composing anything.** Movement with nothing required of it. If you notice you are drafting a message, that is the accounting — come back to what you can see.

**Be near people you are not in a rupture with.** A shop, a café, a room with others in it. This state isolates and the isolation makes the accounting louder.

*Unclench the jaw when you notice it. It holds here quietly.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with the state that follows a rupture, using breath, attention and observation. It makes no ruling on what happened, does not assess who was at fault, and does not tell you whether to repair.

**Pacing**

Once through is a complete use. Use it when the state is there. If four and six is a stretch, shorten both and keep the ratio uneven.

**What people commonly notice**

The ache becoming more noticeable before it eases, particularly at Release. Tears, which is an ordinary end to this state. A strong pull to send a message immediately after finishing — worth waiting out, because the protocol works better as a delay than as a preparation.

Discomfort at the standing-where-they-stood move. That is expected. It is the step people most often skip and the one that does most of the work.

**When to slow down**

If the fourth step turns into an argument for their position against your own, stop. That is not the move — it is self-erasure wearing perspective-taking's clothes. Come back to the breath and end there.

If Release opens something much older than this rupture, you can stop and come back to the breath.

**When repair is not the right frame**

Not every rupture is a repair problem. If the same thing has happened repeatedly and nothing has changed after it was named, or if what happened was not a rupture but a harm, then this protocol will settle your state and will not address the situation.

**Where safety is part of it**

If you are frightened of the other person, if what happened involved violence, or if you are being controlled, this is not a regulation problem. Speak to someone outside the situation: a doctor, a helpline, a lawyer, or a friend who knows the whole picture rather than the version you can bear to tell. Your safety is a separate question from your regulation and it comes first.

**Alongside other support**

If you are with a therapist, doctor or counsellor, this sits alongside that and replaces nothing.

---

## 06 · Disclosure & Support
*A script for someone close.*

This is for telling a third person — not the one you are in the rupture with. Take these exactly, or change every word.

**Saying it**
> "Something's gone wrong between me and [them] and it's still open. I'm not looking for you to take a side. I'd just rather one person knew."

**Describing what it's actually like**

> "It's physical. An ache across my chest, stomach unsettled, not sleeping well. And a restlessness that has nowhere to go, because the only thing that would help involves them."

> "The part I can't switch off is the going back through it. Working out who did what and in what proportion. It feels like getting clear and it just keeps me lit."

**What helps**

> "Listen without agreeing that I'm right. If you tell me they were terrible it feels good for an hour and then makes it harder to go back."

> "Ask me what I actually want to happen. I usually haven't asked myself that."

**What doesn't**

> "Taking my side. I know it's what I seem to be asking for. It builds the case up, and the case is the thing stopping me."

> "Telling me to just talk to them. I know. That isn't the obstacle."

**If they ask what you're doing about it**

> "There's a method I run. I name the state instead of the account, do a breathing pattern, stop the accounting — the ledger I keep building of who owes what — and then look at it from a distance, including from where they were standing. Then one move that's actually mine."

> "It doesn't fix anything. It stops me arriving with a case."

*Tell one person, and pick someone who won't automatically agree with you. On this protocol, the friend who takes your side is the least useful one available.*

---

## 07 · Invitation to Repair
*Reopening it with them.*

Send it from the far side of the protocol, not the middle. Sent from inside the state, it carries the case even when the words are careful, and it will be read that way.

**The rule that makes it sendable:** no prosecution of them. Not a soft one either — no *I've been reflecting and I've realised what you did.* The moment it contains a charge it stops being an invitation and becomes the first line of an argument. You are not conceding by leaving the charge out. You are declining to open with it.

**Sendable**
> I don't want to leave things where they are.
>
> I'm not writing to go back over it. I've got my version and I imagine you've got yours, and I don't think trading them gets us anywhere useful.
>
> I'd like to talk, without either of us needing to arrive with a position. No rush, and if you'd rather not yet, I'll take that.

**Shorter**
> I don't want to leave this. Can we talk — not to settle who was right, just to talk?

**Where you did the damage**
> I've been thinking about how I was with you. I'm not going to explain it, because an explanation is a defence and that isn't what I want to hand you. I'd like to hear what it was like on your end, and to say sorry properly rather than in passing.

**Where you both did**
> I think we both got it wrong in different directions, and I'd rather sort that out with you than work out the split on my own. Can we talk?

**Before sending** — read it back for a case in disguise: *always, never, actually, to be fair, I've realised.* Cut them. Then check what you are expecting back. If a slow reply or a short one would land badly, it is early. An invitation with a required answer is not an invitation.

*If they don't take it, you have done the part that was yours. Whether they meet it is theirs, and always was.*

---

## 08 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it is never measured against anything you wrote before. Because it is only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

Any of these, or none.

- Where did it sit in your body?
- What happened? Write it as an account of events, not as a case.
- What does the accounting say the ledger is? Write the total it keeps arriving at.
- Standing where they stood: what didn't they know that you did?
- *What was this for* — what turned up, without needing to answer it?
- What did you say to yourself from across the room?
- What do you actually want to happen? Not what should happen. What you want.
- What was the move that was yours? Did you make it?
- What did you write here last time? Read it back.

---

## 09 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half exits — and after a rupture, it exits directly at the person you are ruptured with.

**The specific blind spot here** — the state exits as coldness. Shorter replies. Ordinary civility with the warmth removed. Being technically present and unavailable. From inside, each of those is holding a boundary while you work out what you think. From outside, it is punishment, administered daily, without anything having been said.

**The second one** — the account you have been giving other people. Every telling firms it up, and the version you would now give is further from the events than the first one was. From outside, if it reaches them, it is a case circulated before they were asked for theirs.

**The third one** — the wait. From inside, waiting for them to move first is fairness: they did it, so they should. From outside it is a standoff, and both of you are in it for the same reason.

**Their earlier information** — worth asking, once it is open: *when did you know something was wrong?* Usually earlier than you think.

**Naming the act, not the character** — *"I went cold on you for two weeks and didn't say why"* is ownership. *"I'm terrible at conflict"* is not; it names nothing and asks them to accept an explanation instead of an account.

**No because.** The rupture is a real reason and it does not belong in the sentence. What they did does not belong there either — that is the case arriving under cover.

**No self-attack.** *"I'm impossible, I don't know why you bother with me"* moves the burden across the table, and after a rupture it also functions as a bid for reassurance from the person you are ruptured with.

**Describe what was observable, ask about the rest.** *"I've been cold with you since it happened. I'm not going to tell you what that's been like — I'd rather you told me."* Then let them answer without correcting it, and without producing your account in response.

**The checkable change** — this repairs by saying it sooner next time rather than by never rupturing. Ruptures are ordinary; the interval before repair is the variable. *"I'm not going to let it sit for two weeks again"* is small, specific and observable.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. If what happened involved violence or control, this is not the resource: your safety comes first and the Safe Practice section is the relevant one.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Keep the account. Establish who owes what.

Go back over it. Work out the proportions, who started it, what the ratio was. Get the ledger straight so that when it's discussed, the position is defensible.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Reaching first and finding out it wasn't mutual. Being the one who cared more. Being wrong about where I stood.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the weeks it stayed open*, or *the times I waited for them to move and they were waiting too.*

---

**What it should be attending to instead**

It isn't conceding the account. Your version stays entire and nobody is auditing it.

What's available is a different instruction about **what to do with it**.

The old one holds the ledger until it's settled. The successor makes the move that's theirs and lets the ledger stay unbalanced.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *do my half without waiting to see if they'll do theirs.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *sends the short thing rather than the complete one. Says what they did without the surrounding case. Lets a small one go unrecorded.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Puts the phone down. Names their own half. Doesn't run the total.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
