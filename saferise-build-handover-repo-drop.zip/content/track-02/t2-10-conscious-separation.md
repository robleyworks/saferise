# t2-10 · The Conscious Separation Protocol

**Label:** Close · **State:** Numb · **Frameworks:** Maté, Watts · **extras:** `['advisory']`
**Resources: 9** · *meditation authored ahead of the remaining resources — Release language here is canonical*

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in late, very low. No turn until the close.
> **VOICE** — quiet, honest, no brightness. Never implies this is for the best. Long pauses. Nothing is being resolved.

It's ending, or it's ended.

> **GOLD/PAUSE** — very long

And nothing anyone says about that helps very much, including anything I'm about to say.

> **GOLD/PAUSE** — long

So — nothing here is going to tell you it was right, or that it'll make sense later, or that you'll be glad. I don't know any of that and neither do you yet.

---

### Before we start

> **RED/ACTION** — small deliberate movement. Offered, never insisted on.

Move your fingers.

> **GOLD/PAUSE** — very long

Feet into whatever's underneath them.

> **GOLD/PAUSE** — very long

---

### Recognition

One word, and we're not going looking.

> **GOLD/PAUSE**

**Numb.**

> **GOLD/PAUSE** — very long

You don't have to find where it sits. That's often hard here and not finding it is the state, not a failure of attention.

> **BLUE/ILLUSTRATION** — a door, open, with light on both sides of it.

> **GOLD/PAUSE** — long

Two things are stacked here.

There's what's happened.

And there's you, in a state about it.

> **GOLD/PAUSE** — long

Only one of those moves today.

---

### Regulation

Contact first.

> **RED/ACTION** — hand to sternum, or hold your own arm. Offered, not instructed.

> **GOLD/PAUSE** — very long

Now, longer out than in. Count it if you can.

> **TEAL/BREATH** — in, slow
> **TEAL/BREATH** — out, longer
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

### Release

There's the ending. That happened, and it stays happened.

> **GOLD/PAUSE** — long

And there's the going back through it. The point it turned. The thing you should have said. The version where you both did something differently and it held.

> **GOLD/PAUSE** — very long

Does that one ever finish?

> **GOLD/PAUSE** — very long

It doesn't reopen anything. It just runs, and it costs the day, and it lands you back at the start each time.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

The ending stays. Put down the going back through.

> **GOLD/PAUSE** — long

And be clear what that isn't. It isn't accepting it in the sense of finding it acceptable. It isn't being at peace with anything. It's stopping an argument with something that already happened.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

The question, if you want it. Not *what's wrong with me that I can't get past this* — there's a schedule hidden in that one and no such schedule exists.

**What was this for?**

> **GOLD/PAUSE** — very long

Reducing is what a body does when it's had more than it can meet and there's nothing to push against. It's protective, and it's expensive, and it will lift.

> **GOLD/PAUSE** — long

Nothing needs answering today.

---

### Rise

Step back, if you can.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Someone sitting there with a hand on their chest, in the middle of something that hasn't finished being hard.

Speak to them as *you*.

*This is a lot. You're still here.*

> **GOLD/PAUSE** — very long

No correction in that.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now — one thing later that's yours to decide. Small enough to be certain of. Not a step toward moving on. Not a step toward anything.

> **GOLD/PAUSE** — long

Standing up. Going outside. Eating something.

> **GOLD/PAUSE** — very long

Just something that's yours, on a day when almost nothing is.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And before you come back — something in you got you here today. The part that noticed and sat down with it anyway.

> **GOLD/PAUSE** — long

That was yours before today and it stays yours after.

> **GOLD/PAUSE**

Now put it all down. You don't have to carry any of this out of here.

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back slowly.

Nothing's resolved. That was never the offer.

What you've got is a bit of ground, and one thing that's yours.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

*Before you start — move something. Fingers, feet into the floor.*

**Name it** — *You are numb.* Two things are stacked. Only one moves.
**Contact, then breath** — Hand on your chest. Longer out than in.
**Stop going back through it** — It doesn't reopen anything.
**One thing that's yours** — Not a step toward moving on. Just yours.

### Back

**Move first** — Before anything else, move something small. Movement comes before attention here, because attention is the part that's reduced.

**Recognition** — One word. *Numb.* Don't search for where it sits; not finding it belongs to the state. Two things are stacked and get treated as one: what's happened, and you in a state about it. Only one of them moves today.

**Regulation** — Contact before counting. Hand on your chest, or hold your own arm. Then longer out than in. Count if you can, don't if you can't.

**Release** — There's the ending, which happened and stays happened. And there's going back through it — the point it turned, the thing you should have said, the version where you both did something different and it held. It doesn't reopen anything. It runs, it costs the day, and it puts you back at the start. Put down the going back through. That isn't calling it acceptable.

**Rise** — See yourself from a distance. *This is a lot. You're still here.* Then one thing later that's yours to decide, small enough to be certain of. Not a step toward moving on. Not a step toward anything.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

A separation produces a reduced state rather than a mobilised one, because there's nothing left to push against. The thing that would resolve it isn't available, so the system doesn't stay activated. It comes down.

In the body: heaviness, distance from your own limbs, flattened sensation, slowed thought, disrupted sleep and appetite, and a marked drop in the capacity to start anything. Sensation is muffled rather than gone, which is why locating it precisely is hard.

This will also move — flat for days, then suddenly not. That instability is characteristic and it isn't a sign of anything going wrong.

**Why the ending and the state come apart**

They arrive fused: an ending that can't be changed, and a flattened body, experienced as one condition.

While they're fused, working on the state feels like accepting the ending, so people won't. Separating them concedes nothing. The ending is exactly as final afterwards, and the state is the only one of the two that answers to anything today.

**Why movement comes before attention**

Every other protocol opens by asking you to find the state in your body and hold attention there. In a reduced state that's the least available capacity, and opening that way produces someone who has failed at step one.

Small deliberate movement asks nothing of attention. It also does something particular here: it's a chosen act with an immediate result, in a state whose central feature is that nothing you do produces an effect.

**Why contact comes before the count**

Warmth and pressure at the sternum is a direct input requiring nothing of you, and it registers when finer inputs don't. The breath follows: lengthening the out-breath relative to the in-breath is what shifts things toward settled. The count is offered rather than required, because counting is itself a demand in this state.

**Why Release goes after the going back through**

There's the ending, and there's the reconstruction — the point it turned, the sentence that would have changed it, the version where you both did something different.

Two different costs. The first isn't optional. The second is generated continuously, reopens nothing, and returns the body to the start of the state each time. It presents as understanding what happened. Mechanically it's a loop with no last page.

Putting it down is not acceptance in the sense of finding the separation acceptable, and it is not being at peace with it. That distinction matters, because people asked to accept something usually hear that they're being asked to approve of it, and refuse — correctly. What's being put down is an argument with a fact.

**Why the question has no timetable in it**

*What's wrong with me that I can't get past this* has a schedule hidden inside it, and no such schedule exists. *What was this for* asks about function — and what it surfaces is that reducing is protective when there's nothing to push against. Expensive, and protective.

**Why the forward move isn't a step toward anything**

Rehearsing being over it rehearses a scene there's no route to, and the system won't take it. Framing today's small thing as progress makes it another measurement to fail.

One thing that's yours, chosen and done, is available. That's the whole of it.

---

> **SHARED BLOCK** — insert *The part that's on your side, and the part that can hear them* here, verbatim from `SHARED-t2-two-instruments.md`. Identical on all ten Track 02 protocols. Do not paraphrase or re-cut per protocol.

---

### What we rest on

**Compassionate Inquiry — Gabor Maté** · *clinical practice* · supplies Release and the way the question is asked

A response is treated as an adaptation rather than a defect. The kind of question you ask decides the kind of answer you get. *What is wrong with me* asks what is broken, and comes back with a list of what is broken. *What was this for* asks what it was doing, and comes back with something you can use. *Here it removes the implied timetable from the question people ask themselves after an ending.*

*A clinical practice, not a controlled research programme. Used here for the way the question is asked, and nothing wider.*

**Non-resistance — Alan Watts** · *interpretive* · informs why the third step says *accept*

The state is one thing. The fight with the state is a second thing. The fight usually costs more, and it is the only one of the two you can put down. Setting it down isn't passivity, isn't approval, and isn't agreement that the situation is acceptable. *Here it is the distinction the protocol turns on — the ending stays, the argument with the fact of it doesn't have to.*

*Watts is an interpreter rather than an originator; the older sources are Laozi and, for the framing used here, D. T. Suzuki. Offered as a lens rather than a finding.*

**Where the reading is yours** — this explains the machinery. What happened, whose it was, whether it was right, and what any of it means are readings that belong entirely to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

Small, deliberately. Any one on its own is a complete use.

**Move one small thing.** Fingers, toes, ankles. A chosen act with an immediate result.

**Hand to sternum, or hold your own arm.** The input this state takes when it takes little else.

**Longer out than in.** Three or four breaths. No counting required.

**Feet into the floor.** Press down, feel it push back.

**One decision, any size.** Which mug, which window, whether to sit or lie down. The point isn't the outcome — it's that you chose and something followed.

**Go outside the door and come back.** Air and light on skin. Nothing further required.

**Eat something at a normal time.** Not a nutrition instruction. A time instruction. This state loses the shape of a day first.

*Saying one sentence out loud, to anyone or nobody, is worth knowing about. Voice goes quiet early here.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with the reduced state that follows an ending, using movement, contact, breath and observation. It doesn't tell you whether the separation was right, doesn't move you toward or away from reconciliation, and doesn't have a view about how long any of this should take.

**Pacing**

Any single part is a complete use. Moving your fingers and stopping there counts. There's no requirement to reach the fourth step.

**What people commonly notice**

Feeling nothing during or after — common here and not a sign nothing happened. Emotion arriving suddenly as the state lifts, sometimes as anger rather than grief. Considerable tiredness. Sleep and appetite disturbed for a long time.

The state moving unpredictably: functional for days, then not, with no visible trigger.

**When to slow down**

If the practice feels like one more demand, do a single somatic item and leave the session.

If Release opens something much larger — an older loss, something from a long way back — you can stop and come back to the breath.

If emotion arrives hard while you're on your own with it, stop, let it be there, and consider whether there's someone you could be near.

**Where practical matters are involved**

If there are children, money, housing or legal proceedings in this, those are not regulation problems and no practice addresses them. They need people with the relevant expertise, and getting that help early costs less than getting it late.

**Where safety is part of it**

If you are frightened of them, being followed or contacted persistently, or being threatened, that is not a separation problem in the sense this protocol addresses. Speak to someone outside it: a doctor, a helpline in your country, a lawyer, or a friend who knows the whole picture. Your safety is a separate question from your regulation and it comes first.

**When a person in the room is the right tool**

Contact someone today — a doctor, a helpline, or a person you trust — if you're having thoughts of harming yourself or of not being here, if you feel there's no point continuing, if you haven't been able to eat, wash or leave the house for days, if you're using something to get through it, or if this has been going on for months with no movement at all.

**Alongside other support**

If you're with a therapist, doctor or counsellor, this sits alongside that and replaces nothing. This is one of the protocols where having a person matters most.

---

## 06 · Proximity Guide
*How close to stay.*

An ending rarely ends contact. Where contact continues — children, shared property, a workplace, mutual friends — how much of it there is, and of what kind, is one of the few things you hold.

Three tiers. Which one yours belongs in is your read, on information nobody here has.

**Worth staying engaged with**

Where contact is necessary and possible without producing the state. Where exchanges stay on the subject they're about. Where you can end a conversation without it costing you the day.

Distance isn't the tool here. Structure is — a channel, a subject, a time — and the protocol is what makes the contact survivable rather than a slow re-entry into the whole thing.

**Worth reducing the surface area of**

Where contact reliably relights it. Where conversations about practical matters become conversations about the relationship. Where you're checking things you don't need to know — where they are, who they're with, what they've posted.

Reduction here is specific and it is not a statement about the future: written rather than spoken, one subject per exchange, a set time rather than whenever, a mutual friend you stop asking, an account you stop looking at.

Checking deserves its own attention. It feels like keeping track. It produces material every time and certainty never, and it keeps the ending permanently in progress rather than finished.

**Past what self-regulation is for**

Where you're being contacted persistently after asking for it to stop. Where you're being threatened, followed, or told things about yourself designed to destabilise you. Where children are being used as a route to you.

That isn't a regulation problem and no practice addresses it. It needs a lawyer, a doctor, a helpline, or the police, depending on what's happening — and it needs them earlier than most people ask.

**Using this**

Notice the tier. Then notice whether it's the tier you'd assign if a friend described the same arrangement.

---

## 07 · Disclosure & Support
*A script for someone close.*

This state removes the impulse to reach for anyone. Any of these can be sent as a message rather than said.

**Saying it**
> "Things have ended with [them] and I'm not doing brilliantly. I'm not looking for advice and I don't want to talk about whether it was right. I'd just rather one person knew where I actually am."

**Describing what it's actually like**

> "It's flat rather than sad, most of the time. Heavy, slowed down, a bit far away from myself. Starting anything is the hard part — not doing it, starting it."

> "And then it isn't flat, with no warning. Fine on Tuesday, unreachable on Wednesday. That's not me being difficult, it's just how this moves."

**How to tell it's coming**

> "I stop replying. I go still. I say I'm fine in a flat voice. I stop making plans, including ones I want."

**What helps**

> "Turn up. You don't have to say anything useful. Being in the room is most of it."

> "Do a small specific thing rather than offering generally. 'I'm coming round Thursday' works. 'Let me know if you need anything' doesn't — I won't let you know, and that's the state rather than me not wanting to."

> "Say their name if it comes up naturally. People step around it and the stepping is louder than the mention."

**What doesn't**

> "Telling me it's for the best, or that I'll see it differently later. You don't know that and neither do I yet."

> "Asking whether we might get back together. Whatever the answer is, being asked makes it a thing I have to have a position on."

> "Telling me what you always thought of them. I now have to manage your version as well as mine."

**If they ask what you're doing about it**

> "There's a method I run. It starts small — move something, name the state, hand on my chest before any breathing. Then I stop going back through it looking for the moment it turned, which is the loop that eats the days. Then one small thing that's actually mine to decide."

> "It doesn't change anything. It stops me adding to it."

**If you need someone to act**
> "I need to see a doctor and I can't face arranging it. Could you help me do that this week?"

*Tell one person. Endings isolate people at exactly the point they can least afford it, and the isolation is produced by the state rather than chosen.*

---

## 08 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

There's no arc here and nothing accumulating toward a good end. Some entries will be much worse than earlier ones and that means nothing about how you're doing.

One line is a complete entry.

- What did you manage today? Anything at all.
- Where did it sit, or could you not find it? Either is fine.
- What did the going-back-through find today? Was any of it new?
- *What was this for* — anything, or nothing? Nothing is a real answer.
- What did you say to yourself from across the room?
- What was the one thing that was yours? Did you do it?
- What's still here that this didn't take?
- What did you write here last time? Read it back — without comparing today to it.

---

## 09 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half lands on people who are also in it — and on some who aren't.

**The specific blind spot here** — the state exits as absence, and after an ending people expect absence, so nobody says anything. Messages unanswered for weeks. Plans that lapse. Friends who kept checking until they stopped. From inside there was no decision at any point. From outside it's a series of small closures.

**The second one** — the account, told repeatedly. Every telling firms it up and moves it further from the events. The people around you end up holding a version you can no longer amend without admitting you built it, and some of them are also holding a friendship with the other person.

**The third one, where it applies** — the people in the middle. Mutual friends, family on both sides, and children if there are any. From inside, saying what happened is being honest. From outside, for someone who cares about both of you, it's being asked to hold a position.

**Their earlier information** — worth asking, later: *how long did you keep trying before you stopped?* The answer is usually longer than you'd guess, and it's usually more generous.

**Naming the act, not the character** — *"I didn't answer you for six weeks and you kept messaging"* is ownership. *"I've been a mess"* is not; it names nothing and invites them to say it's understandable, which lets both of you skip it.

**No because.** The ending is an enormous reason and everyone already knows it. Attached to the sentence it converts an account into a defence — and it's the one protocol where the because is most true and most tempting.

**No self-attack.** *"I'm a wreck, I don't know why anyone bothers with me"* asks them to reassure you, which is a thing several of them have already been doing for months.

**Describe what was observable, ask about the rest.** *"I disappeared on you. I'm not going to tell you what that was like — I'd rather you told me."*

**The checkable change** — this repairs by flagging rather than by recovering. *"I'll send you one line when I go under, even if that's all I can manage"* is small, specific, observable, and doesn't ask you to be different.

**Where this stops** — this isn't an instruction to be less affected for other people's convenience, and you don't owe anyone a better performance. If today isn't the day for this resource, that's a legitimate answer — it's the one here you can leave for as long as you need to.

---

## 12 · The Decision
*What takes over.*

Short version today. This one asks very little.

---

**What's running now**

Go back through it. Find where it turned.

Run it again. The thing that should have been said, the point it went, the version where you both did something different and it held.

It isn't a fault. It's been doing a job.

---

**What takes over**

It isn't being at peace with it. It isn't acceptable and nothing here says it is.

What's available is stopping the argument with something that already happened.

> **One line. What should it be doing instead?**

Something like: *stop looking for the version where it held.*

Yours, if you've got one. If you haven't, leave it and come back — this one keeps.

---

**Who runs the next one**

Not who you are once this lifts. Who's in it while it's happening.

> **One thing they do, in the middle of one.**

*Moves one thing. Decides one small thing that's theirs. Doesn't reopen it tonight.*

---

**Come back to it**

This gets rewritten and nobody arrives at it. On a day like today, having written one line is the whole of it.

*Written on your device and kept there. Nobody else sees it, and it is never measured against anything you wrote before. Because it is only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
