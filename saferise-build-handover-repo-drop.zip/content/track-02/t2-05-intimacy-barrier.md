# t2-05 · The Intimacy Barrier Protocol

**Label:** Open · **State:** Unsteady · **Frameworks:** Porges, Jung · **extras:** `['invitation']`
**Resources: 9** · *meditation authored ahead of the remaining resources — Release language here is canonical*

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, low. Turn at four seconds.
> **VOICE** — gentle, unhurried, entirely without pressure. Never encourages opening. The state is about being pushed toward closeness, so the voice must not do that.

There's a distance, and it didn't arrive all at once.

> **GOLD/PAUSE** — long

Nothing dramatic happened. It just got a bit further, and then a bit further, and now there's a shape to it that you'd both recognise and neither of you names.

> **GOLD/PAUSE**

Nothing here is going to ask you to close it. Not today, not at all. That's not what this is.

---

### Recognition

Where is it?

> **GOLD/PAUSE** — long

Chest, often — not tight exactly. More like something held slightly apart. Throat. A stillness through the middle of you that isn't calm.

> **BLUE/ILLUSTRATION** — two forms, near each other, not touching. The space between them even and deliberate.

One word. **Unsteady.**

> **GOLD/PAUSE**

And notice what it doesn't say. It doesn't say you're closed off. It doesn't say there's something wrong with you.

> **GOLD/PAUSE** — long

You just described a state, and something in you did the describing. Those aren't the same thing.

---

### Regulation

Four in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six out.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the middle of your chest.

> **RED/ACTION** — hand to sternum, flat, light. Offered, not instructed.

A hand there if you want one. Your own warmth, at the place that's been held apart.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

### Release

Two things going on.

> **GOLD/PAUSE**

There's the distance, which is real.

And there's the managing of it. Watching how close things are getting. Adjusting. A joke where something else was about to happen. Being busy at the moment it might have gone somewhere.

> **GOLD/PAUSE** — long

That takes constant work, and it's so practised you've stopped noticing you're doing it.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

The distance can stay exactly as it is. Put down the managing — just for the next few minutes, in a room where nobody's coming closer.

> **GOLD/PAUSE** — very long

And the question. Not *what's wrong with me that I can't just be open* — that one arrives from outside and it's never helped anyone.

**What was this for?**

> **GOLD/PAUSE** — long

Something in you decided that a certain amount of closeness is where it stops being safe. And it decided that, and it's been enforcing it since, and it doesn't consult you.

> **GOLD/PAUSE** — long

So — what's underneath it? What did you learn that closeness costs?

> **GOLD/PAUSE** — very long

I'm not answering that one. It isn't mine to answer.

> **GOLD/PAUSE**

If something surfaced, let it have been said. If nothing did, that's ordinary and this one often comes slowly.

> **GOLD/PAUSE** — long

And here's the harder one. You might not want to put it down.

> **GOLD/PAUSE** — very long

That's fair. It works. Whatever it's cost you, some part of you knows exactly what it's been keeping out.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Nobody's asking you to take it down. You'd be right to refuse. Only to notice it was built with what you had at the time, and it hasn't been told anything since.

> **GOLD/PAUSE** — very long

---

There's more here if you want it.

> **GOLD/PAUSE**

If today is a day for noticing the cost and stopping there, stop there. Come back to the breath and finish. That's complete.

> **GOLD/PAUSE** — very long

Still here.

> **GOLD/PAUSE**

Then one thing first, because the rest rests on it.

> **GOLD/PAUSE**

If someone has given you a reason to keep a distance — if being open with a particular person has cost you before — that's real, and none of what follows takes it off them.

> **GOLD/PAUSE** — long

Two things can be true. Something happened. And it landed on something already there.

> **GOLD/PAUSE** — very long

Here's the question, and it isn't *why can't you be close to people.*

> **GOLD/PAUSE** — long

What feels dangerous about being fully seen?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — two forms, and between them something drawn as structure rather than as absence.

Not the abstract version. The specific one. What is it that you think would happen.

> **GOLD/PAUSE** — very long

For some people it's being found ordinary. For some it's being compared and coming second. For some it's being known well enough that leaving becomes possible.

> **GOLD/PAUSE** — long

And for a lot of people it isn't about them at all — it's the loss of the say you have over how much anyone gets.

> **GOLD/PAUSE** — very long

Whichever of those is nearest, notice it and leave it there. I'm not telling you which. I don't know, and it isn't mine to name.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

---

Now the other direction.

> **GOLD/PAUSE**

What has the distance been keeping safe?

> **GOLD/PAUSE** — very long

Not what it's been costing you — you already know that, it's why you're here.

What it has been protecting.

> **GOLD/PAUSE** — very long

Because it has been protecting something, and doing it well, for a long time, without being asked.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before we move.

> **GOLD/PAUSE**

If any of that landed, something will be arriving behind it. Usually *there's something wrong with me for being like this.*

> **GOLD/PAUSE** — very long

Put that down. Whatever the distance is protecting, holding it there is a reasonable response to it. You've been doing something sensible with incomplete information, which is all anyone does.

> **GOLD/PAUSE** — long

And this. Something in you was willing to look at the one thing it's been arranged not to look at.

> **GOLD/PAUSE**

That's the part worth acknowledging. It was there before today.

> **GOLD/PAUSE** — very long

One more, and it's simply true rather than comforting. What you found under there is far more common than it feels. It's just that people who keep a distance don't tend to describe it to anyone, which is what makes it seem rare.

> **GOLD/PAUSE** — very long

And nothing is decided by any of that. The distance is still yours. What's changed is that you know what it's for — and something you understand is something you can choose about, which is different from being run by it.

> **GOLD/PAUSE** — long

---

### Rise

Step back a little.

Someone over there with a hand on their chest, breathing four and six.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Speak to them as *you*.

*You're not cold. You're guarded. Those are different things.*

> **GOLD/PAUSE** — long

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now — one thing, and make it smaller than you think.

Not opening up. Not the conversation. Something almost invisible — staying in the room a minute longer. Answering the actual question instead of the near one. Not making the joke.

> **GOLD/PAUSE** — very long

Small enough that you'll actually do it, guarded exactly as you are now.

> **GOLD/PAUSE**

The distance arrived on its own, over years. This one you picked.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing already here. Something that isn't about closeness at all.

> **GOLD/PAUSE**

Now put it down. All of it.

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back whenever.

Nothing's opened and nothing needed to. You've just spent a few minutes not maintaining it, and that's the first time in a while.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are unsteady.* Guarded isn't the same as cold.
**Breathe it** — Four in, six out. Hand to your chest.
**Stop managing the distance** — Just for now. Nobody's coming closer.
**One small thing** — Smaller than you think. Not opening up.

### Back

**Recognition** — Find it in your body: chest, held slightly apart rather than tight. Throat. A stillness through the middle that isn't calm. Name the state in one word. It doesn't say you're closed off and it doesn't say something's wrong with you — you described a state, and something in you did the describing.

**Regulation** — Four in, six out. Attention in the centre of your chest, hand there if you want one. Your own warmth, at the place that's been held apart.

**Release** — Two things. The distance, which is real. And the managing of it — watching how close things are getting, adjusting, the joke where something else was about to happen, being busy at exactly the moment it might have gone somewhere. That's constant work and it's so practised you've stopped noticing. Put down the managing, not the distance.

**Rise** — See yourself from a distance. *You're not cold. You're guarded. Those are different things.* Then one thing, smaller than you think — staying in the room a minute longer, answering the actual question, not making the joke.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

This isn't a spike. It's a maintained position — a distance held at a constant, adjusted continuously, and adjusted below the level you notice.

In the body: something held slightly apart across the chest rather than tight, a stillness that isn't settledness, tension in the throat, and a readiness to redirect that activates in the half-second before closeness arrives. Most people experience it as a personality trait rather than a state, because it's been running so long there's no contrast to compare it against.

**Why the naming step separates two things**

*I'm not good at intimacy* is a verdict about who you are. *There is a distance and I am maintaining it* is a description of something happening.

The first has no handle on it. The second does, and the difference is not semantic — a state can be worked with and a character trait can only be regretted.

**Why the exhale is longer than the inhale**

You can't decide a maintained state down. You can decide your breathing, and it's the one reachable control on a system you otherwise can't get at. Lengthening the out-breath relative to the in-breath is what shifts things toward settled.

Contact at the sternum matters more here than the count. It's your own warmth at exactly the place that's been held apart, and it requires no other person, which is what makes it usable at all on this protocol.

**Why Release goes after the managing rather than the distance**

There's the distance. And there's the maintenance of it — the monitoring, the redirection, the timing.

Two different costs. The distance is static and costs nothing to have. The maintenance runs continuously: watching how close things are getting, and intervening. That's a job, done constantly, invisibly, for years, and the exhaustion people report in relationships they describe as easy is usually this rather than the relationship.

Putting it down for the length of a session isn't opening up. Nothing changes with anyone. It's noticing what it costs to hold, by briefly not holding it, in a room where nothing is approaching.

**Why nothing here asks you to close it**

Pressure to be more open is what the member has been receiving from outside for a long time, and it produces more distance rather than less — because the pressure is itself something to be managed.

The protocol's position is that the distance is yours, it was built for reasons, and nothing on this platform is going to ask you to take it down. What's on offer is a clearer view of what maintaining it costs.

**Why the surplus is worth attending to**

Where a reaction to closeness outruns what actually happened, the excess is carrying information about something other than the moment. An interpretive lens rather than a finding, and what it shows you, if anything, is yours to read.

**Why Rise is deliberately tiny**

Rehearsing being open is rehearsing a state you can't produce on demand, and your body doesn't accept it. Staying in the room a minute longer is available today, guarded exactly as you are — and it's the only version that transfers.

---

> **SHARED BLOCK** — insert *The part that's on your side, and the part that can hear them* here, verbatim from `SHARED-t2-two-instruments.md`. Identical on all ten Track 02 protocols. Do not paraphrase or re-cut per protocol.

---

### What we rest on

**Polyvagal Theory — Stephen Porges** · *peer-reviewed* · supplies Recognition and the three state labels

Threat detection runs ahead of thought. The body reads a situation and moves before your thinking catches up. Porges describes three broad conditions: settled and socially available, mobilised for action, and shut down. Agitated, Unsteady and Numb are the member-facing names for those three. *Here it accounts for a redirection that fires in the half-second before closeness, ahead of any decision about it.*

*The anatomical premises are contested: a 2026 evaluation in* Clinical Neuropsychiatry *challenged them, with Porges replying in the same issue. The state distinctions are what this platform uses, and they hold independently of that dispute.*

**Shadow & individuation — C. G. Jung** · *interpretive* · informs Release

What you decline to look at keeps running unattended. The usable test is proportion: when a reaction outruns the event that occasioned it, the surplus is carrying information about something other than the event. There's no finish line and nothing to complete. *Here it accounts for why an ordinary moment of closeness can produce a disproportionate retreat.*

*Offered as a lens rather than a finding, with no controlled evidence behind it. What it shows you is yours to read — this platform will not tell you what your distance is about.*

**Where the reading is yours** — this explains the machinery. What the distance is about, where it came from, and whether you want it any different are readings that belong entirely to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Hand to sternum.** Flat, light, at the place that's held apart. Your own warmth, requiring nobody.

**Long exhale, no ceremony.** Four in, six out, three or four cycles.

**Unclench the jaw and let the throat open.** Both hold here quietly, and both are what a redirect runs through.

**Stay thirty seconds past the point you'd normally move.** In any conversation, with anyone. Not a big moment — an ordinary one where you'd usually find something to do.

**Answer the actual question.** When someone asks how you are, say one true thing rather than the near one. Once a day is plenty.

**Sit next to rather than opposite.** Where you have a choice. Side by side asks less and permits more.

*Notice the joke before you make it. Not necessarily to stop — just to see it arriving. That's the whole exercise.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with a maintained distance, using breath, attention and observation. It doesn't ask you to close it, doesn't set a target for closeness, and makes no claim about what your relationships should look like.

**Pacing**

Once through is a complete use. This is a constant state rather than an episodic one, so pick a time rather than waiting for a peak.

**What people commonly notice**

Very little at first. A maintained state has no contrast, so the first few times through can feel like nothing happened.

Then, often, tiredness — the recognition that something has been running continuously. Some people describe the session as the first time in years they weren't monitoring proximity, and find that itself unsettling.

Resistance at the Release step. That's the state doing exactly what it does, and noticing it is the work rather than a failure at it.

**When to slow down**

If Release opens something much larger — something older, something about what closeness has cost before — you can stop there and come back to the breath. This protocol surfaces material more often than its surface suggests.

If the practice starts to feel like pressure to be different, stop. That is the thing this protocol exists not to do, and if it's happening the session has gone wrong rather than you.

**When a person in the room is the right tool**

Contact someone — a doctor, a therapist, or a person you trust — if the distance is costing you relationships you want, if it followed something that happened to you, if you can't be touched or can't be alone with someone without significant distress, or if you're having thoughts of harming yourself.

If what's underneath this is something that was done to you, that isn't a pattern to be managed privately. It needs a person, and needing one isn't a failure of the practice.

**Alongside other support**

If you're with a therapist, doctor or counsellor, this sits alongside that and replaces nothing. This is one of the protocols where having a person is worth a great deal.

---

## 06 · Disclosure & Support
*A script for someone close.*

The hardest one to say, because saying it is the thing the state exists to prevent. It can be sent as a message.

**Saying it**
> "There's a distance I keep, and it isn't about you. I've never really said that out loud to anyone. I'm not promising to change it — I'd just rather you knew it was there than thought it was about how I feel."

**Describing what it's actually like**

> "It's physical. Something holds apart in my chest when things get close, and it happens before I've decided anything."

> "The part that's hard to explain is that it's constant work. I'm managing how near things get, all the time, without noticing I'm doing it. I get tired in relationships that other people would call easy."

**How to tell it's coming**

> "I make a joke. I get busy. I change the subject to something practical. I answer a question next to the one you asked."

**What helps**

> "Don't chase it. If you come toward me when I've moved back, I have to manage that as well, and it doubles the work."

> "Stay near without needing anything. Same room, different activity. That's genuinely the easiest thing in the world for me and it's worth a lot."

> "Ask specific questions rather than open ones. I can answer 'what was the meeting like' — 'how are you feeling' is a room with no walls."

**What doesn't**

> "Telling me I'm closed off. I know. Being told adds a thing to manage on top of the thing."

> "Big conversations about the relationship. They're the highest-pressure version of the exact thing I struggle with."

**If they ask what you're doing about it**

> "There's a method I run. I name it as a state rather than as something wrong with me, do a breathing pattern with a hand on my chest, and then stop managing the distance for a few minutes — which is when I notice how much work it's been. Then one very small thing. Not opening up. Something almost invisible."

*Tell one person. This state's whole instruction is that you don't, so saying it at all is the move — regardless of what happens after.*

---

## 07 · Invitation to Repair
*Reopening it with them.*

On this protocol the invitation is usually the first time it's ever been said, rather than a repair of something specific. Written is legitimate and for many people it's the only version that happens.

**The rule that makes it sendable:** no promise about what changes. A message that offers to be different creates an expectation you may not be able to meet, and the failure will cost more than the silence did.

**Sendable**
> There's something I've never said and I'd rather say it badly than keep not saying it.
>
> I keep a distance. It isn't about you and it isn't about anything you've done. It's been there a long time and I'm only now looking at it properly.
>
> I'm not promising it changes. I just didn't want you to keep reading it as how I feel about you.

**Shorter**
> The distance isn't about you. I've never said that and I should have.

**Where they've raised it before and you deflected**
> You've said something about this before, more than once, and I moved past it every time. That wasn't fair. You were right, and I wasn't ready to look at it. I am now, a bit.

**Where you want to name the cost to them**
> I know it's meant you've had to do most of the reaching. I'd rather say I've noticed than keep letting you wonder whether I have.

**Before sending** — read it for promises. Anything shaped like *I'll try to be more* creates a debt. Then check whether you're asking for anything back. If a warm reply is required for it to have been worth sending, wait.

*If they don't take it, you've done the part that was yours. Whether they meet it is theirs.*

---

## 08 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

Any of these, or none.

- Where did it sit in your body?
- What was the moment you moved back from? Write the actual thing that was about to happen.
- What did you do instead — the joke, the task, the subject change?
- How long had you been managing it before you noticed?
- *What was this for* — what turned up, without needing to answer it?
- What did you say to yourself from across the room?
- What was the small thing? Did you do it?
- Do you want this different? It's a fair question and no is a real answer.
- What did you write here last time? Read it back.

---

## 09 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half lands on someone who has usually been trying for a long time.

**The specific blind spot here** — the redirect is invisible to the person doing it and completely visible to the person receiving it. The joke, the change of subject, the sudden task. From inside, each is a single small movement. From outside, it's a pattern with a shape, and they can predict it.

**The second one** — the asymmetry of effort. If you keep the distance, they do the reaching. All of it, for years, without it being agreed. Most people on the receiving end stop mentioning it long before they stop noticing it.

**The third one** — what your unavailability gets read as. From inside it's protection with nothing to do with them. From outside, in the absence of any explanation, the default reading is that they aren't enough to warrant more. That reading has usually been running for a long time.

**Their earlier information** — they know the shape of it better than you do, because they've been on the outside of it. Worth asking: *what do you see me do?* And then not defending the answer.

**Naming the act, not the character** — *"I change the subject when you say something serious"* is ownership. *"I'm emotionally unavailable"* is not; it's a label, it names no act, and it invites them to reassure you about it.

**No because.** Whatever's underneath is real and doesn't belong in the sentence.

**No self-attack.** *"You deserve better than me"* is the worst available version — it sounds like accountability, and what it actually does is hand them the job of arguing you out of it, which is more reaching.

**Describe what was observable, ask about the rest.** *"I've kept you at a distance for a long time. I'm not going to tell you what that's been like — I'd rather you told me."* Then let them answer without explaining yourself over the top of it.

**The checkable change** — this repairs by staying rather than by feeling more. *"When you say something serious, I'm going to stay in it for one more exchange before I move"* is small, specific, observable, and doesn't require you to be different.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. And if what's underneath this is something that was done to you, this isn't the resource for it. That needs a person.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Manage the distance. Adjust it continuously.

Watch how close it's getting. Make the joke where something else was about to happen. Be busy at exactly the moment it might have gone somewhere. Keep it at the setting that's survivable.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Being fully known and found ordinary. Being seen properly and having them leave anyway. Losing the say I have over how much anyone gets.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the tiredness in relationships other people would call easy*, or *the person who eventually stopped reaching.*

---

**What it should be attending to instead**

It isn't opening up. Nobody here is asking for that and you'd be right to refuse.

What's available is a different instruction about **the half-second**.

The old one redirects before anything can land. The successor stays for one more exchange — not open, just present for slightly longer than usual.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *stay in it one exchange past the point I'd normally move.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *answers the actual question rather than the near one. Doesn't make the joke. Stays in the room after something serious was said.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Notices the redirect arriving. Doesn't take it. Stays where they are.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
