# t2-04 · The Resentment Release Protocol

**Label:** Release · **State:** Unsteady · **Frameworks:** Maté, Jung · **extras:** `['advisory','invitation']`
**Resources: 10** · *meditation authored ahead of the remaining resources — Release language here is canonical*

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Turn at four seconds.
> **VOICE** — dry, direct, faintly amused at how well-kept the ledger is. Never mocking. Talks to someone who has been reasonable for far too long.

You've got a list.

> **GOLD/PAUSE**

You probably wouldn't call it that. But you could produce it right now, in order, with dates.

> **GOLD/PAUSE** — long

That's what we're here about. Not whether the items on it are accurate — I'd assume they are.

---

### Recognition

Where does it sit?

> **GOLD/PAUSE** — long

Chest, tight rather than hot. Jaw. Something in the shoulders. A heaviness that's been there so long it stopped registering as a feeling and started registering as a fact about your life.

> **BLUE/ILLUSTRATION** — a stack of marks, evenly spaced, going back further than the frame.

One word. **Unsteady.**

> **GOLD/PAUSE**

And notice what that word doesn't include. It doesn't include the list. Not one item from it.

> **GOLD/PAUSE** — long

The list stays. Nobody is auditing it and nothing here says you've kept it unfairly.

---

### Regulation

Four in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six out.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the middle of your chest.

> **RED/ACTION** — hands and jaw. Offered, not instructed.

Unclench the jaw. Open the hands if they've closed. This one holds quietly and it holds for years.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

### Release

So — two things.

> **GOLD/PAUSE**

There's what happened. Repeatedly, probably, over a long time, and you were reasonable about most of it.

And there's the keeping. Adding to it. Reviewing it. Checking whether the total has moved.

> **GOLD/PAUSE** — long

Has it ever come out level?

> **GOLD/PAUSE** — very long

It doesn't come out level. It's not built to. A tally you're keeping about someone who isn't keeping one back will never balance, and some part of you has been waiting for it to.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

The grievance stays. Every item on it stays.

Put down the keeping.

> **GOLD/PAUSE** — long

Which isn't forgiving anyone. Nobody's asking. It's stopping an accounting that was never going to be settled by more accounting.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And the question. Not *what's wrong with me that I can't let this go* — that's the thing everyone else says to you and it's never once helped.

**What was this for?**

> **GOLD/PAUSE** — long

A list like that gets kept for a reason. Usually because saying it at the time wasn't available — it would have cost too much, or it wouldn't have been heard, or you'd have been the difficult one.

> **GOLD/PAUSE** — long

So it got written down instead. That's not a character flaw. That's what you do when there's nowhere to put something.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

So — what's actually underneath it? What did you decide it meant that these things kept happening and you kept absorbing them?

> **GOLD/PAUSE** — very long

I'm not answering that. I don't know, and it isn't mine.

> **GOLD/PAUSE**

If something came, it's yours. If nothing did, that's ordinary.

> **GOLD/PAUSE** — very long

---

One further, if there's room.

> **GOLD/PAUSE**

The items are real. Nothing here takes one of them off the list.

> **GOLD/PAUSE** — long

But two things can be true. They did those things. And each one landed on something already there.

> **GOLD/PAUSE** — very long

So — what did it come to mean, that these kept happening and you kept absorbing them?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — a stack of marks, and beneath the earliest one a single deeper line.

For a lot of people it's some version of *what I want counts less.* Or *if I said it, it wouldn't change anything, and then I'd know that for certain.*

> **GOLD/PAUSE** — very long

That second one is worth sitting with. Not saying it keeps the possibility alive that saying it would have worked.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

---

And the keeping — what's it protecting?

> **GOLD/PAUSE** — very long

The record. Somebody has to hold what happened, and if it was never said out loud, the list is the only place it exists.

> **GOLD/PAUSE**

That's not bitterness. That's testimony, kept by the only witness.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before we move.

> **GOLD/PAUSE**

Something will arrive behind that — probably *I should have said something years ago.*

> **GOLD/PAUSE** — very long

Put it down. You couldn't say it at the time. That's the whole reason there's a list, and it's the same answer as before.

> **GOLD/PAUSE** — long

And something in you looked at what the list is for rather than adding to it today.

> **GOLD/PAUSE** — very long

One more, simply true rather than comforting. Almost everyone who has been reasonable for a long time is carrying one of these. Almost nobody says so, which is why it feels like a private failing rather than an extremely ordinary one.

> **GOLD/PAUSE** — long

And one more thing, quietly. If any of that landed, there's usually a second arrival — *why did I let it go on this long.* Put that down too. You couldn't say it at the time. That's the whole reason there's a list.

> **GOLD/PAUSE** — long

---

### Rise

Step back.

Someone over there, breathing four and six, who has been reasonable for a very long time.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Speak to them as *you*.

*You kept a fair account. And it was never going to be paid.*

> **GOLD/PAUSE** — long

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now — you can see where your attention's been. On a ledger, mostly, for years.

So put it somewhere by choice.

> **GOLD/PAUSE**

Not the scene where they finally understand. That's their move and you can't make it for them.

> **GOLD/PAUSE** — long

One thing you'll say, or stop absorbing, or decline. Small enough that you'll do it this week, feeling exactly as you do now.

> **GOLD/PAUSE** — very long

Got it? Say it once to yourself.

> **GOLD/PAUSE**

The list arrived on its own, item by item. This one you picked.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing already yours. Something the list has nothing to do with.

> **GOLD/PAUSE**

Now put all of it down. You don't have to carry it out.

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back.

The list is intact. Nothing's been conceded and nothing's been forgiven.

You've just stopped adding it up for a while.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are unsteady.* The state, not the list.
**Breathe it** — Four in, six out. Jaw and hands.
**Stop adding it up** — The list stays. The tally goes.
**One thing you'll say** — Or stop absorbing. Or decline.

### Back

**Recognition** — Find it in your body: tight rather than hot, chest, jaw, shoulders. A heaviness that's been there long enough to feel like a fact about your life. Name the state in one word. The list isn't in it — the list stays, and nobody is auditing whether you kept it fairly.

**Regulation** — Four in, six out. Attention in the centre of your chest. Unclench the jaw, open the hands. This one holds quietly and it holds for years.

**Release** — Two things. What happened, repeatedly, while you were reasonable about it. And the keeping — adding, reviewing, checking whether the total's moved. It never comes out level; a tally you're keeping about someone who isn't keeping one back can't balance. Put down the keeping, not the grievance.

**Rise** — See yourself from a distance. *You kept a fair account, and it was never going to be paid.* Then one thing you'll say, or stop absorbing, or decline — small enough to do this week, feeling exactly as you do now.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

Resentment is a low-grade activation held over a long period rather than a spike. In the body: tightness across the chest, jaw and shoulders, a shallow held quality to the breath, and a heaviness that people frequently stop identifying as a feeling at all and start experiencing as a fact about their circumstances.

That's the distinguishing feature. Most states announce themselves. This one goes quiet and becomes furniture.

**Why the list isn't the target**

The items on it are usually accurate. Nothing here audits them and nothing here suggests you've kept them unfairly.

But the list and the state are two objects. While they're fused, working on the state feels like conceding that the items don't count — so people won't, and the state stays for years. Separating them costs you nothing: the account is exactly as complete afterwards.

**Why the exhale is longer than the inhale**

You can't decide a state down. You can decide your breathing, and it's the one reachable control on a system you otherwise can't reach. Lengthening the out-breath relative to the in-breath is what shifts things toward settled.

Jaw and hands matter here more than on most protocols, because this state holds in both continuously rather than in bursts, and the holding has been going on long enough to feel normal.

**Why Release goes after the keeping**

There's what happened, and there's the tally — adding, reviewing, checking whether the balance has moved.

Two different costs, and the second runs whether or not anything new occurs. It's built to reach a total, and it can't: an account you're keeping about someone who isn't keeping one back has no mechanism for settlement. Some part of you has been waiting for a payment that was never going to be made.

Putting it down isn't forgiveness. Nobody is asking for that. It's stopping an accounting that more accounting was never going to settle.

**Why the question is about the keeping rather than the grievance**

*What's wrong with me that I can't let this go* is what everyone else says to you, and it has never once helped, because it locates the problem in the wrong place.

*What was this for* asks about function — and what it usually surfaces is that saying it at the time wasn't available. It would have cost too much, or it wouldn't have been heard, or you'd have become the difficult one. So it got written down instead. That's not a defect; it's what people do when there's nowhere to put something.

**Why the surplus is worth attending to**

Where a reaction outruns the event that occasioned it, the excess is carrying information about something other than the event. That's an interpretive lens rather than a finding, offered as a way of looking. What it shows you, if anything, is yours to read.

**Why Rise is one sentence rather than a reckoning**

Rehearsing the conversation where they finally understand rehearses their move, which you don't control. One thing you'll say, or stop absorbing, or decline is entirely available — and it's the first item in years that goes on the list by choice.

---

> **SHARED BLOCK** — insert *The part that's on your side, and the part that can hear them* here, verbatim from `SHARED-t2-two-instruments.md`. Identical on all ten Track 02 protocols. Do not paraphrase or re-cut per protocol.

---

### What we rest on

**Compassionate Inquiry — Gabor Maté** · *clinical practice* · supplies Release and the way the question is asked

A response is treated as an adaptation rather than a defect. The kind of question you ask decides the kind of answer you get. *What is wrong with me* asks what is broken, and comes back with a list of what is broken. *What was this for* asks what it was doing, and comes back with something you can use. *Here it moves the question off "why can't I let this go" — which is the sentence everyone else has already tried on you.*

*A clinical practice, not a controlled research programme. Used here for the way the question is asked, and nothing wider.*

**Shadow & individuation — C. G. Jung** · *interpretive* · informs Release

What you decline to look at keeps running unattended, and you tend to meet it as other people's faults. The usable test is proportion: when a reaction outruns the event that occasioned it, the surplus is carrying information about something other than the event. There's no finish line here. *Here it accounts for why one small instance can carry the weight of the whole list.*

*Offered as a lens rather than a finding, with no controlled evidence behind it. What it shows you is yours to read.*

**Where the reading is yours** — this explains the machinery. Whether the items are fair, what they mean, and what to do about the relationship are readings that belong to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Unclench the jaw.** Teeth apart, tongue down, lower face heavy. This state holds there constantly and you've stopped noticing.

**Open the hands.** Spread the fingers, hold, let them go soft.

**Long exhale, no ceremony.** Four in, six out, three or four cycles.

**Shoulders down and back.** Blades gently together, then sliding down. Years of this ride high in the shoulders.

**Say one item out loud, alone.** In the car, at home. One. Once. Saying the whole list is reviewing it, which is the thing the protocol asks you to put down.

**Push against something immovable.** Palms to a wall, steady pressure for a slow five, then release completely. Low-grade activation held for years has nowhere to discharge, and this gives it somewhere and then a stop.

*Do one thing purely because you want to, with no one benefiting from it. Resentment accumulates fastest in people who have stopped doing that.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with resentment as a state, using breath, attention and observation. It leaves your account of what happened entirely intact and it doesn't move you toward forgiveness.

**Pacing**

Once through is a complete use. This is a state that's usually present at a low level rather than in episodes, so there isn't an obvious moment to use it — pick one rather than waiting for a peak.

**What people commonly notice**

Anger arriving, sometimes much larger than expected. Resentment is often anger with nowhere to go, held down for a long time, and when it does move it can move suddenly.

Grief underneath it, which surprises people. Tiredness afterwards.

Or very little, which is ordinary here — a state held this long doesn't shift in one session.

**When to slow down**

If Release opens something much larger — an older grievance, something from a long way back — you can stop and come back to the breath.

If the item you said out loud starts a rehearsal rather than a discharge, stop. Once is release; repeatedly is the keeping.

**When a person in the room is the right tool**

Contact someone — a doctor, a helpline in your country, or a person you trust — if the resentment has become constant rather than episodic, if you're using something to manage it, if it's spreading to people who haven't done anything, or if you're having thoughts of harming yourself.

**Where the situation is the thing**

If what you're carrying is about something ongoing that hasn't stopped, this settles you and doesn't change it. Where something can be said, asked for or declined, the useful next moves are outside this platform. The Proximity Guide goes further.

**Alongside other support**

If you're with a therapist, doctor or counsellor, this sits alongside that and replaces nothing.

---

## 06 · Proximity Guide
*How close to stay.*

Resentment nearly always has a live source that's still supplying it. How much contact you have is a real variable and it's often more available than it feels after this long.

Three tiers. Which one yours belongs in is your read.

**Worth staying engaged with**

Where the pattern responds when it's named. Where you haven't actually said it — not hinted, not raised it sideways, but said it plainly once — and there's no evidence it would go badly.

Distance isn't the tool here. Saying it is, and the protocol is what makes you fit to say it once rather than deliver it.

**Worth reducing the surface area of**

Where you've said it, more than once, and nothing changed. Where your capacity is treated as the thing that flexes. Where things arrive addressed to you because you've historically absorbed them.

Reduction is specific: things you stop volunteering for, a standing arrangement you let end, an ask you answer with a date rather than a yes, an occasion you decline without a reason attached.

This is also the tier where the surplus is worth attending to. If your reaction to a small ask is much larger than the ask, the excess is carrying something — a lens rather than a finding, and what it shows you is yours.

**Past what self-regulation is for**

Where you're being exploited. Where the arrangement depends on you not saying anything. Where saying something has costs you can't absorb — money, housing, access to children, your job.

That isn't a regulation problem, and treating it as one converts a situation needing other people into a private failure of patience. What it needs is a lawyer, a union, a doctor, a helpline, or someone who can see the whole arrangement.

**Using this**

Notice the tier. Then notice whether it's the tier you'd assign if a friend described the same arrangement. People carrying resentment place their own one tier lower than they'd place someone else's, more reliably than on any other protocol.

---

## 07 · Disclosure & Support
*A script for someone close.*

Take these exactly, or change every word.

**Saying it**
> "There's something I've been carrying about [them] for a long time and I've never really said it out loud. I'm not asking you to do anything with it. I'd just rather it existed outside my own head."

**Describing what it's actually like**

> "It isn't dramatic. It's low, and constant, and it's been there so long I'd stopped thinking of it as a feeling. It just felt like what my life is like."

> "The part I can't switch off is the adding up. I can produce the whole list, in order, with dates. And it never comes out level, because they aren't keeping one."

**How to tell it's coming**

> "I go flat and polite. I get very reasonable in a way that isn't warm. I start being unavailable in small ways."

**What helps**

> "Let me say one of them without making it a case. If you get outraged on my behalf, I have to manage that too, and it makes the whole thing bigger."

> "Ask me what I'd actually want to be different. I've been so busy tallying that I haven't asked myself."

**What doesn't**

> "Telling me to let it go. Everyone has. It's never helped once and it locates the problem in me for still minding."

> "Telling me they're terrible. It feels good for an hour and then I've got a bigger version of it to carry."

**If they ask what you're doing about it**

> "There's a method I run. I name it as a state rather than as the list, do a breathing pattern, and stop the adding up — which turns out to be the expensive part, not the grievance. Then I pick one thing I'll actually say or stop doing."

> "The list is still there. I've just stopped totalling it every day."

*Tell one person. Resentment kept entirely private thickens, because nothing ever tests whether it's still the right size.*

---

## 08 · Invitation to Repair
*Reopening it with them.*

Send it from the far side of the protocol. From inside the state it arrives as the case, however carefully worded — and after this long, the case is very well made.

**The rule that makes it sendable:** one item, not the list. This is the whole difficulty on this protocol. Years of material are available and every instance supports the point, and a message carrying all of it cannot be answered, only defended against.

**Sendable**
> There's something I've been sitting on for a long time and I'd rather say it than keep being slightly off with you about it.
>
> It isn't a list and I'm not building a case. There's one thing, and I'd like to say it and hear what you make of it.
>
> No rush. If now isn't the time, tell me when.

**Shorter**
> Can we talk about something? One thing, not a big conversation. I've been carrying it a while.

**Where you've gone quiet rather than said it**
> I've been polite with you for a long time and not much else, and that's on me — I've been managing something instead of raising it. I'd rather do it the other way round from here.

**Where the ask is practical**
> I want to change something about how we do [the thing]. I'm not saying it's been unfair. I'm saying I've stopped being able to do it the way we've been doing it.

**Before sending** — count the instances. If there's more than one, cut back to one. Then read it for *always* and *never*, which are the list arriving in two words.

*If they don't take it, you've done the part that was yours. Whether they meet it is theirs.*

---

## 09 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

Any of these, or none.

- Where did it sit in your body?
- Write one item from the list. Just one, and write it plainly.
- How old is the oldest thing on it?
- What was happening that meant you couldn't say it at the time?
- *What was this for* — what turned up, without needing to answer it?
- Was your reaction proportionate to the last instance? If not, how far off?
- What did you say to yourself from across the room?
- What do you actually want to be different? Not what should be different.
- What did you write here last time? Read it back.

---

## 10 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half exits — and resentment's exterior is unusually deniable, which is what makes it damaging.

**The specific blind spot here** — it exits as correctness. Polite, reasonable, entirely fair, and cold. Nothing is ever said that could be objected to. From inside that's restraint. From outside it's being frozen out by someone who will not name it, and there's nothing to respond to because nothing has technically happened.

**The second one** — the small withdrawals. Not volunteering. Being slightly unavailable. Doing the thing but not offering. Individually invisible, cumulatively unmistakable.

**The third one** — the sideways version. The remark with an edge, the joke that isn't one, the *no, it's fine.* From inside it's a pressure valve. From outside it's the list being delivered in instalments without ever being opened.

**Their earlier information** — the person on the other end usually knows something is wrong and often has no idea what. Worth asking: *how long have you known I was off with you?* Expect the answer to be longer than you'd guess.

**Naming the act, not the character** — *"I've been polite with you for two years and not much else"* is ownership. *"I'm a resentful person"* is not; it names nothing and asks them to disagree with it.

**No because.** The items are real and they don't belong in the sentence. That's the list arriving as justification, and it converts an account into a case.

**No self-attack.** *"I'm awful, I've been holding this against you for years"* moves the burden across the table and asks them to manage your guilt about the thing you did to them.

**Describe what was observable, ask about the rest.** *"I've been cold with you and I never said why. I'm not going to tell you what that's been like — I'd rather you told me."* Then let them answer without producing the list in response.

**The checkable change** — this repairs by saying things at the time rather than by no longer minding. *"I'm going to say it in the week it happens, even badly"* is small, specific and observable.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. If the arrangement you're in genuinely depends on your silence, none of this applies and the Proximity Guide's third tier does.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Keep the record. Somebody has to.

Add it to the list. Review it. Check whether the total's moved. If it was never said out loud, the list is the only place it exists — so it gets kept, carefully, with dates.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Nobody ever knowing what it was like. Absorbing it and having it count for nothing. Being the reasonable one, forever, unnoticed.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the years of being polite and not much else*, or *what it's done to how I am with them now.*

---

**What it should be attending to instead**

It isn't forgiving anyone. Nobody's asking, and that's a separate decision that stays entirely yours.

What's available is a different instruction about **when it gets said**.

The old one collects because saying it at the time wasn't available. The successor says it in the week it happens, which is the only thing that stops the list growing.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *say it in the week, even badly, rather than filing it.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *says the small one at the time. Declines something without a reason attached. Answers an ask with a date rather than a yes.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Notices the item arriving. Says it or lets it go. Doesn't add it.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
