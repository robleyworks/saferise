# t2-09 · The Pursue & Withdraw Protocol

**Label:** Meet · **State:** Unsteady · **Frameworks:** Porges, Maté · **extras:** `['advisory','invitation']`
**Resources: 10** · *meditation authored ahead of the remaining resources — Release language here is canonical*

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Turn at four seconds.
> **VOICE** — even-handed, unhurried, audibly holding two people in mind. Never takes a side and never implies both are equally at fault.

One of you moves toward and one of you moves away.

> **GOLD/PAUSE** — long

And whichever end you're on, it feels like the only sensible response to what the other one is doing.

> **GOLD/PAUSE**

Nothing here is going to tell you which of you started it. That question has no answer and looking for one is part of the pattern.

---

### Recognition

Where is it?

> **GOLD/PAUSE** — long

If you're the one moving toward — chest, high and fast, and something urgent in the hands. If you're the one moving away — a stillness, a flattening, something behind the eyes.

> **GOLD/PAUSE**

Both are the same machinery going in opposite directions.

> **BLUE/ILLUSTRATION** — two forms, one leaning in, one angled out. The distance between them constant.

One word. **Unsteady.**

> **GOLD/PAUSE** — long

And notice what it left out. Them. What they do. What they always do.

---

### Regulation

Four in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six out.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the middle of your chest.

> **RED/ACTION** — hand to sternum, feet down. Offered, not instructed.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

If you're the pursuer, this will feel like doing nothing while something is unresolved. If you're the withdrawer, it'll feel like an unusually easy few minutes. Both are the pattern, showing up in the practice.

> **GOLD/PAUSE** — extended

---

### Release

Two things.

> **GOLD/PAUSE**

There's the gap between you, which is real.

And there's the manoeuvring. Pushing harder because they've gone quiet. Going quieter because they've pushed.

> **GOLD/PAUSE** — long

Each move is a completely reasonable response to the other one. And together they make the gap bigger, reliably, every single time.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Neither of you is doing it wrong. You're both doing the thing that works on a threat, at someone who isn't one.

> **GOLD/PAUSE** — long

Put down the manoeuvring. Just yours — you can't put down theirs and trying is another move.

> **GOLD/PAUSE** — long

And the question. Not *why do they always do this* — that one has never once produced a change.

**What was this for?**

> **GOLD/PAUSE** — long

Moving toward keeps you from being left. Moving away keeps you from being overwhelmed. Both are protection, both work, and they were both learned somewhere.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Leave that open.

> **GOLD/PAUSE** — long

---

There's more here if you want it.

> **GOLD/PAUSE**

If today is a day for putting down your half and stopping there, stop there. That's complete, and it's the part that changes things.

> **GOLD/PAUSE** — very long

Still here.

> **GOLD/PAUSE**

Then one thing first. We're only looking at your half here. Not theirs, and not what they should be doing differently.

> **GOLD/PAUSE**

Their half is real and it isn't available to you from here.

> **GOLD/PAUSE** — long

---

So. When the distance opens up between you — what does it seem to say?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — two forms at a fixed distance, and beneath each of them a line running down further than the gap between them.

If you're the one who moves toward, it tends to say something like *I'm being left.* And underneath that, often, *this is how it starts.*

> **GOLD/PAUSE** — very long

If you're the one who moves away, it says something different. Closer to *there won't be any of me left in this.* Or *I disappear if I stay in it.*

> **GOLD/PAUSE** — very long

Neither of those is irrational. Both are a system reading a room using everything it has ever learned about rooms.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Notice which one is yours. And notice whether it's familiar — whether this is the first relationship it's shown up in.

> **GOLD/PAUSE** — very long

I'm not telling you which of those is yours, or what it's about. I don't know, and from outside your life nobody does.

> **GOLD/PAUSE**

If something landed, leave it there. If neither did, that's a real answer too.

> **GOLD/PAUSE** — long

Whatever it is, it isn't a fault. It's information about how long it's been running.

> **GOLD/PAUSE** — long

---

Now — what is it protecting?

> **GOLD/PAUSE** — very long

Moving toward keeps you from being left. Moving away keeps you from being overwhelmed by someone.

> **GOLD/PAUSE**

Both are guarding something that mattered a great deal at some point.

> **GOLD/PAUSE** — very long

And both work. That's why they're still running.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before we move.

> **GOLD/PAUSE**

There'll be something arriving behind that. Usually *this is my fault*, or its reverse, *so it's all been them.*

> **GOLD/PAUSE** — very long

Put both down. What you found is a protection doing its job. Struggling inside it is the appropriate response, not evidence about who's to blame.

> **GOLD/PAUSE** — long

And this. Something in you looked at your own half while the thing is still live between you.

> **GOLD/PAUSE**

That's harder than looking at theirs, and it's the only half that moves.

> **GOLD/PAUSE** — very long

One more, and it's simply true rather than comforting. This pattern is one of the most common there is between two people who care about each other. It almost never gets named out loud, which is the only reason it feels like a private failure.

> **GOLD/PAUSE** — very long

And none of it decides anything. You still don't control their half, and you never did. What you have now is a clearer view of yours — and a move made from that view is a choice rather than a reflex.

---

### Rise

Step back.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Someone across the room, breathing four and six, halfway through a pattern that has two people in it.

Speak to them as *you*.

*You're not the problem. And your half is the only half you've got.*

> **GOLD/PAUSE** — long

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now — one move that isn't the usual one. Not a strategy, and not something designed to make them do something.

> **GOLD/PAUSE**

If you pursue: the message you don't send, or the plain sentence instead of the third attempt. If you withdraw: staying in the room a minute longer, or saying *I've gone quiet and it isn't about you.*

> **GOLD/PAUSE** — very long

Small enough that you'll do it, feeling exactly like this.

> **GOLD/PAUSE**

And notice what it isn't. It isn't a lever. If you do it in order to change what they do, it's the manoeuvring again in a nicer coat.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing already here. Something outside the two of you.

> **GOLD/PAUSE**

Now put it down.

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back.

The pattern needs two people and it'll still be there. What's changed is that your half is under your hand.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are unsteady.* The state, not what they always do.
**Breathe it** — Four in, six out. Feet down, hand to chest.
**Stop manoeuvring** — Yours only. You can't put down theirs.
**One move that isn't the usual one** — And not a lever.

### Back

**Recognition** — Find it in your body. Pursuing: chest high and fast, something urgent in the hands. Withdrawing: a stillness, a flattening, something behind the eyes. Same machinery, opposite directions. Name the state in one word and leave them out of it.

**Regulation** — Four in, six out. Attention in the centre of your chest, feet into the floor. If you pursue, this will feel like doing nothing while something is unresolved. If you withdraw, it'll feel like an unusually easy few minutes. Both are the pattern, showing up in the practice.

**Release** — Two things. The gap between you, which is real. And the manoeuvring — pushing harder because they've gone quiet, going quieter because they've pushed. Each move is a reasonable response to the other, and together they widen the gap reliably. Put down yours. You can't put down theirs, and trying is another move.

**Rise** — See yourself from a distance. *You're not the problem. And your half is the only half you've got.* Then one move that isn't the usual one — small enough to do feeling exactly like this. And check it isn't a lever: if you're doing it to change what they do, it's the manoeuvring in a nicer coat.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

Both ends of this are the same threat response pointed in opposite directions. One system mobilises toward — closing distance restores safety. The other reduces and withdraws — space restores it.

In the body, pursuing: raised heart rate, breathing high and fast, urgency in the hands, attention locked on one person. Withdrawing: flattening, a stillness that isn't calm, slowed thought, and a strong pull toward being somewhere else.

Neither is a character. Both are what a system does when connection registers as at risk, and the two responses happen to be exactly incompatible.

**Why the naming step leaves the other person out**

The reading you have — *they always do this* — is usually accurate as description and useless as material. It's about someone else's behaviour, which is not available to work on.

The state is running in you now. That's the half that answers to anything.

**Why the exhale is longer than the inhale**

You can't decide a state down. You can decide your breathing, and it's the one reachable control on a system you otherwise can't get at. Lengthening the out-breath relative to the in-breath shifts things toward settled.

The step lands differently depending on which end you're on, and that's worth knowing in advance. For a pursuer, sitting still while something is unresolved is the hardest instruction on the protocol. For a withdrawer, it's the easiest, which is its own kind of information.

**Why Release goes after the manoeuvring**

There's the gap, and there's what each of you does about it.

Two different costs. The gap is a condition. The manoeuvring is generated continuously, by both of you, and it has a specific property: each move is a completely reasonable response to the other person's move, and the two together enlarge the thing they're each trying to fix.

That's why it doesn't resolve by either party trying harder at their own strategy. Trying harder is the strategy.

**Why you can only put down your half**

Putting down theirs isn't available. Waiting for them to move first is a position, not a solution, and both of you are holding it for the same reason.

This is also where the protocol is most easily misused. A move made in order to produce a move from them is the manoeuvring with better manners, and it will be felt as such.

**Why the question is about function**

*Why do they always do this* has never produced a change in anyone. *What was this for* asks what each response is protecting: moving toward keeps you from being left, moving away keeps you from being overwhelmed. Both work. Both were learned somewhere.

Understanding that is not endorsement, and it doesn't allocate fault. Nothing here says both parties are equally responsible for a given situation — only that each of you has one half you can reach.

---

> **SHARED BLOCK** — insert *The part that's on your side, and the part that can hear them* here, verbatim from `SHARED-t2-two-instruments.md`. Identical on all ten Track 02 protocols. Do not paraphrase or re-cut per protocol.

---

### What we rest on

**Polyvagal Theory — Stephen Porges** · *peer-reviewed* · supplies Recognition and the three state labels

Threat detection runs ahead of thought. The body reads a situation and moves before your thinking catches up. Porges describes three broad conditions: settled and socially available, mobilised for action, and shut down. Agitated, Unsteady and Numb are the member-facing names for those three. *Here it accounts for why one of you mobilises and the other reduces in response to the same event.*

*The anatomical premises are contested: a 2026 evaluation in* Clinical Neuropsychiatry *challenged them, with Porges replying in the same issue. The state distinctions are what this platform uses, and they hold independently of that dispute.*

**Compassionate Inquiry — Gabor Maté** · *clinical practice* · supplies Release and the way the question is asked

A response is treated as an adaptation rather than a defect. The kind of question you ask decides the kind of answer you get. *What is wrong with me* asks what is broken, and comes back with a list of what is broken. *What was this for* asks what it was doing, and comes back with something you can use. *Here it applies to both ends — the pursuit and the withdrawal are both protective, and neither is the malfunctioning one.*

*A clinical practice, not a controlled research programme. Used here for the way the question is asked, and nothing wider.*

**Where the reading is yours** — this explains the machinery. Who started it, whether it's worth continuing, and what any of it means are readings that belong to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Long exhale, no ceremony.** Four in, six out, three or four cycles.

**Feet into the floor.** Press down, feel it push back.

**Hand to sternum.** Flat, light, at the centre of the chest.

**If you pursue — put the phone down and set it further than an arm.** The reaching is physical before it's anything else, and distance interrupts the loop rather than the wanting.

**If you withdraw — stay in the room past the point you'd normally leave.** Not talking. Just present.

**Say the plain version once.** *I've gone quiet and it isn't about you*, or *I've been on at you and I know it.* One sentence, said once, not as an opening move.

*Notice which of the two you are. Most people are one in most relationships and the other in one particular relationship, and that's worth knowing.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with the state that arrives inside a pursue-and-withdraw dynamic, using breath, attention and observation. It doesn't allocate fault, doesn't tell you whether the relationship is working, and doesn't change the other person's half.

**Pacing**

Once through is a complete use. Best used after an episode rather than during one, in the gap where both of you have stopped.

**What people commonly notice**

Pursuers: strong discomfort at the Regulation step, because sitting still while something is unresolved is the exact thing the state is built to prevent. Withdrawers: an unusual ease, and sometimes a suspicion that they're doing it wrong because it isn't hard.

A pull to send something, or to leave, immediately after finishing. Worth waiting out.

**When to slow down**

If Release opens something much older — a much earlier version of the same dynamic — you can stop there and come back to the breath.

If putting down your half starts to feel like being the only one making an effort, stop and end there. That feeling is real and this protocol can't resolve it. It's a conversation, not a regulation problem.

**Where safety is part of it**

Some dynamics that look like pursue-and-withdraw are not. If someone monitors your movements, controls your access to money or people, punishes you with silence for days, or makes you afraid — that is not a pattern with two halves, and treating it as one puts the responsibility in the wrong place.

If any of that is familiar, this is not the right protocol for the situation. Speak to someone outside it: a doctor, a helpline in your country, a lawyer, or a friend who knows the whole picture rather than the version you can bear to tell. Your safety is a separate question from your regulation and it comes first.

**When a person in the room is the right tool**

Contact someone if the dynamic is affecting your health or your sleep across weeks, if you're using something to manage it, or if you're having thoughts of harming yourself.

**Alongside other support**

If you're with a therapist, doctor or counsellor — individually or together — this sits alongside that and replaces nothing.

---

## 06 · Proximity Guide
*How close to stay.*

⚠ **Before this section applies at all.** It assumes two people who can both move. If you are being controlled, monitored, punished with silence, or made afraid, the tiers below don't describe your situation and calibrating your own distance is not the right work. Go to the third tier directly, and read the Safe Practice section above.

Three tiers. Which one yours belongs in is your read, on information nobody here has.

**Worth staying engaged with**

Where the dynamic is uncomfortable but both of you can name it. Where a plain sentence — *I've gone quiet* or *I've been chasing you* — gets received rather than used. Where the gap closes on its own within a reasonable time.

Distance isn't the tool here. Naming it is, and the protocol is what makes you fit to name it once rather than deliver it.

**Worth reducing the surface area of**

Where episodes are frequent and nothing changes after them. Where you're managing your own behaviour continuously to keep things level. Where naming it has produced irritation rather than a conversation, more than once.

Reduction is specific: not being the one who always initiates repair, letting a gap sit without filling it, having other people in your week, an occasion you decline. For a pursuer this is the harder direction. For a withdrawer, the harder direction is the opposite — staying engaged where you'd normally reduce.

**Past what self-regulation is for**

Where silence is used as a punishment with a duration. Where contact is withdrawn to produce compliance. Where you are frightened, monitored, or isolated from people.

That is not two halves of a pattern. It is one person doing something to another, and treating it as a dynamic you contribute to is the reading that keeps people in it.

What that needs is other people: a doctor, a helpline, a lawyer, or someone who can see the whole picture. This platform does not tell members to leave or stay, and nobody here knows what you'd be giving up — but your safety is not a regulation question.

**Using this**

Notice the tier. Then notice whether it's the tier you'd assign if a friend described the same thing.

---

## 07 · Disclosure & Support
*A script for someone close.*

For a third person — not the one you're in the dynamic with. Take these exactly, or change every word.

**Saying it**
> "There's a pattern with me and [them] where one of us pushes and one of us backs off, and it's wearing us both out. I'm not asking you to take a side."

**Describing what it's actually like**

> "It's physical. If I'm the one reaching, everything goes fast and urgent. If I'm the one backing off, it goes still and far away. Either way it happens before I've decided anything."

> "The part that's hard to explain is that both of us are doing something completely reasonable. Their move makes my move sensible and mine makes theirs sensible, and together we make the gap bigger every single time."

**How to tell it's coming**

> "I start messaging more, or I start replying less. I get very busy. I ask you what you think they meant."

**What helps**

> "Don't tell me what they should be doing. I can only reach my half and being handed theirs makes it worse."

> "Ask me what I'd do if their behaviour weren't going to change. That question is unpleasant and it's the useful one."

**What doesn't**

> "Taking my side. It feels good and it makes the gap wider, because now I'm right and still stuck."

> "Telling me to just talk to them. I know. The talking is the thing the pattern eats."

**If they ask what you're doing about it**

> "There's a method I run. I name it as a state rather than as what they always do, do a breathing pattern, and then put down my half of the manoeuvring — which is the only half I've got. Then one move that isn't the usual one, and isn't designed to make them do anything."

*Tell one person, and pick someone who can hold that you're both being reasonable. A friend who thinks the other person is the problem is the least useful one available on this protocol.*

---

## 08 · Invitation to Repair
*Reopening it with them.*

⚠ **This resource assumes a dynamic between two people who can both move.** If you're being controlled or made afraid, this is not the resource for that situation — see the Proximity Guide's third tier. Telling someone more, in that situation, is not the move.

Send it from the far side of the protocol. From inside the state, a pursuer's message reads as another approach and a withdrawer's reads as further distance, whatever the words say.

**The rule that makes it sendable:** it can't require a response. If a slow reply would count as evidence, or a warm one as success, it's a move rather than an invitation — and the other person will feel which it is before they've read it properly.

**Sendable**
> I think we've got into something where I do one thing and you do another and it keeps making the same gap.
>
> I'm not saying it's your half. I'm saying I've noticed mine, and I'd rather say that than keep doing it quietly.
>
> No answer needed. I just wanted it said.

**If you're the one who pursues**
> I've been coming at you a lot and I know it's been relentless. That's mine. I'm going to stop doing the third message, and I'm not telling you that so you'll do something — I'd just rather you heard it from me than noticed it.

**If you're the one who withdraws**
> When I go quiet it isn't a punishment and it isn't about how I feel about you. It's what I do when there's too much at once. I know what it looks like from your side and I'd rather say so than let you keep guessing.

**Where you want to name the pattern rather than your half**
> Can we talk about the thing that happens — not the last time it happened. I don't think either of us is doing it on purpose.

**Before sending** — read it back and ask what answer would make it a success. If only one answer works, it's a lever. Rewrite until no reply at all would still leave it worth having sent.

*If they don't take it, you've done the part that was yours. Whether they meet it is theirs, and always was.*

---

## 09 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

Any of these, or none.

- Where did it sit in your body?
- Which end were you on this time?
- What was the move — the extra message, the going quiet, the being busy?
- What had they just done? Write it plainly, as an event.
- *What was this for* — what turned up, without needing to answer it?
- What did you say to yourself from across the room?
- What was the move that wasn't the usual one? Did you make it?
- Was it a lever? Be honest. Were you waiting to see what they'd do?
- What did you write here last time? Read it back.

That second-to-last one earns its place. On this protocol the difference between a move and a manoeuvre is entirely in what you were expecting back, and it's easier to see in your own writing than in the moment.

---

## 10 · Accountability & Empathy
*What it does outside you.*

⚠ **Read this first.** This resource asks you to look at your own conduct. That's the right work where both people can move. Where you're being controlled, monitored or made afraid, looking harder at yourself is the mechanism that keeps people in those situations — the Proximity Guide's third tier is the resource for that, and your safety is a separate question from your regulation.

Assuming that isn't where you are:

The protocol trains the interior half of the state. The other half lands directly on the person at the other end of the pattern.

**If you pursue** — from inside, each approach is one message, one question, one attempt to sort it out. From outside it's a sequence arriving faster than it can be answered, and every slow reply raises the cost of the next one. The other person often can't name it either. They just start feeling watched, and then feeling guilty about feeling watched.

**If you withdraw** — from inside, going quiet is the only way to stop drowning. From outside, silence with no stated reason is indistinguishable from punishment, and it is read as the thing they were most afraid of. The absence of an explanation is the whole difference between space and abandonment.

**The one that belongs to both** — the certainty about the other person's motives. *They're doing it deliberately. They know exactly what this does.* From inside it's a conclusion drawn from evidence. From outside it's being assigned an intention you never had.

**Their earlier information** — worth asking, in a calm week: *what do you see me do, before I know I'm doing it?* Expect the answer to be more specific than yours would be.

**Naming the act, not the character** — *"I sent you eleven messages on Sunday and then didn't speak to you on Monday"* is ownership. *"I'm too much"* or *"I'm emotionally unavailable"* are not; they name nothing, they're labels, and both ask the other person to disagree with them.

**No because.** Their half is a real reason and it does not belong in the sentence. That's the manoeuvring arriving as accountability, and it will be recognised.

**No self-attack.** On this protocol it does specific damage — a pursuer's self-attack is another approach, and a withdrawer's is a reason for the other person to come and reassure them, which restarts the whole thing.

**Describe what was observable, ask about the rest.** *"I went silent for three days and never said why. I'm not going to tell you what that was like — I'd rather you told me."* Then let them answer without explaining your half over the top of it.

**The checkable change** — this repairs by flagging rather than by stopping. Pursuers: *"I'm going to say it once and then leave it with you."* Withdrawers: *"I'll tell you I've gone quiet, even if I can't say more than that."* Both are small, specific, observable, and neither requires the other person to do anything.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. And nothing here says both halves are equal in size. Two people can both be doing something and one of them can be doing considerably more of it.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Close the gap. Or protect the space.

One of those, depending on which end you're on. Push harder because they've gone quiet, or go quieter because they've pushed. Either way it's the reasonable response to what they just did.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Being left. Or being overwhelmed and disappearing inside it. Whichever one is yours, it mattered a great deal at some point.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the same argument for years*, or *how far apart we are now compared to when it started.*

---

**What it should be attending to instead**

It isn't stopping being who you are. Pursuers won't become withdrawers and it wouldn't help.

What's available is a different instruction about **what to do with the impulse**.

The old one acts on it. The successor says what's happening instead of moving — which is the only move that doesn't feed the other person's half.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *say what's happening rather than doing the thing.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples, depending which end: *doesn't send the third message and says one plain sentence instead* — or — *says I've gone quiet and it isn't about you, and stays in the room.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Notices the pull. Names it out loud rather than acting on it. Doesn't check what they did with that.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
