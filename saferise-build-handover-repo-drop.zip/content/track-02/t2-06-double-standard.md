# t2-06 · The Double Standard Protocol

**Label:** Level · **State:** Unsteady · **Frameworks:** Jung, Maté · **extras:** `['invitation']`
**Resources: 9** · *meditation authored ahead of the remaining resources — Release language here is canonical*

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Turn at four seconds.
> **VOICE** — level, fair-minded, unhurried. Sounds like someone who would agree with you and isn't going to make that the point.

There's a rule, and it applies to you and not to them.

> **GOLD/PAUSE** — long

Or it applies to them and not to you, which stings differently and just as much.

> **GOLD/PAUSE**

You've probably tested it a few times to be sure. And you were sure.

---

### Recognition

Where does it sit?

> **GOLD/PAUSE** — long

Chest. Throat, sometimes — the place where the thing you didn't say is. A tightness that comes up sharply when it happens again.

> **BLUE/ILLUSTRATION** — two measures side by side, marked differently.

One word. **Unsteady.**

> **GOLD/PAUSE**

And notice what that leaves out. It leaves out the rule, the instances, and how clearly you can lay them out.

> **GOLD/PAUSE** — long

None of which is in dispute here. Being right and being settled are two separate projects, and you can have both — just not in the same minute.

---

### Regulation

Four in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six out.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the middle of your chest.

> **RED/ACTION** — jaw and shoulders. Offered, not instructed.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

### Release

Two things.

> **GOLD/PAUSE**

There's the unevenness, which you noticed correctly.

And there's the scorekeeping. Collecting instances. Building the case so that when you finally say it, it'll be unanswerable.

> **GOLD/PAUSE** — long

Notice how the case is going. You're winning it.

> **GOLD/PAUSE**

Of course you are. The part of you assembling it is on your side — that's its entire job — so it hands you the better version every time. It was never going to do anything else.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And here's the cost. A case that unanswerable can't be raised without a fight, so it doesn't get raised. It just gets bigger.

> **GOLD/PAUSE** — long

The observation stays. Put down the collecting.

> **GOLD/PAUSE** — long

And the question. Not *why am I the one who has to put up with this* —

**What was this for?**

> **GOLD/PAUSE** — long

Something in you is very good at noticing when things aren't even. That's a skill and it was learned somewhere, usually somewhere it mattered a great deal to know.

> **GOLD/PAUSE** — long

So — what's underneath it? What did you decide it meant, when the rule bent one way and not the other?

> **GOLD/PAUSE** — very long

Not mine to answer. If something came, it's yours.

> **GOLD/PAUSE** — long

One thing worth being careful about, though. You can look at what's running in you. You can't look at what's running in them — you can't see it from where you're standing, and saying it out loud is just the case again, wearing better clothes.

> **GOLD/PAUSE** — long

---

One further, if there's room.

> **GOLD/PAUSE**

The unevenness is real. Nothing here decides you're imagining it.

> **GOLD/PAUSE** — long

But two things can be true. The rule bends one way. And the bending landed on something already there.

> **GOLD/PAUSE** — very long

So — what does it seem to say, that it applies to you and not to them?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — two measures marked differently, and beneath both an older single measure.

For a lot of people it's some version of *I'm the one who has to earn it.* Or plainer — *I matter slightly less here, and everyone has quietly agreed.*

> **GOLD/PAUSE** — very long

That's why a small instance can carry so much. It isn't the instance. It's the confirmation.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

I'm not telling you which is yours. From outside your life nobody knows.

> **GOLD/PAUSE** — long

And the noticing — what's it protecting?

> **GOLD/PAUSE** — very long

You from being taken advantage of without registering it. Somewhere, not noticing cost you something, and something in you has kept score ever since so it can't happen unseen.

> **GOLD/PAUSE**

Exhausting. Also accurate, most of the time.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before we move.

> **GOLD/PAUSE**

Something will arrive behind that — usually *I'm being petty about this.*

> **GOLD/PAUSE** — very long

Put it down. If what it's touching is whether you matter equally here, then it isn't petty and the size is right.

> **GOLD/PAUSE** — long

And something in you looked at what it means rather than adding another instance to the pile.

> **GOLD/PAUSE** — very long

One more, simply true rather than comforting. Almost every arrangement has someone in it doing this quietly, and almost none of them mention it, which is why yours feels singular.

> **GOLD/PAUSE**

---

### Rise

Step back.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Someone across the room, breathing four and six, holding an accurate observation.

Speak to them as *you*.

*You're not imagining it. And you don't need a case to say it.*

> **GOLD/PAUSE** — long

That second part is the whole thing. A case needs someone to lose. A sentence doesn't.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

So — one sentence. Not the argument. The plain observation, said once, without the eleven supporting instances behind it.

> **GOLD/PAUSE** — very long

What are the actual words. Where are you when you say them. What happens in your voice.

> **GOLD/PAUSE** — long

The noticing arrived on its own. Saying it plainly is the part you pick.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing already true, before you come back.

> **GOLD/PAUSE**

Now put it down — the case, the instances, all of it. You don't have to carry it out of here.

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back.

You're still right. Nothing about that changed.

You've just stopped needing to prove it before you're allowed to mention it.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are unsteady.* The state, not the rule.
**Breathe it** — Four in, six out. Jaw and shoulders.
**Stop collecting instances** — You're winning a case you can't raise.
**One sentence** — The observation, said once. Not the argument.

### Back

**Recognition** — Find it in your body: chest, throat, the place the unsaid thing sits. Name the state in one word. Leave out the rule and the instances — none of it is in dispute here. Being right and being settled are two separate projects and you can have both, just not in the same minute.

**Regulation** — Four in, six out. Attention in the centre of your chest. Unclench the jaw, drop the shoulders.

**Release** — Two things. The unevenness, which you noticed correctly. And the scorekeeping — collecting instances so that when you finally say it, it'll be unanswerable. Notice you're winning that case. Of course you are; the part assembling it is on your side. And a case that unanswerable can't be raised without a fight, so it doesn't get raised. It just gets bigger.

**Rise** — See yourself from a distance. *You're not imagining it. And you don't need a case to say it.* A case needs someone to lose; a sentence doesn't. Then one plain sentence — the actual words, without the eleven supporting instances behind it.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

Detecting unequal treatment produces a low, persistent activation rather than a spike. In the body: tightness across the chest, the throat — particularly the place where the unsaid thing sits — the jaw, and a sharp rise when it happens again.

The state's characteristic is accumulation. Each instance is individually small enough not to raise, and collectively large enough to change how you feel about someone.

**Why the naming step leaves the rule out**

The observation is usually accurate. Nothing here audits it.

But an accurate observation and a settled body are separate objects, and while they're fused, settling feels like conceding the point. So people stay lit and keep the observation as evidence that they should be. Splitting them costs nothing — the rule is exactly as uneven afterwards.

**Why the exhale is longer than the inhale**

You can't decide a state down. You can decide your breathing, and it's the one reachable control on a system you otherwise can't get at. Lengthening the out-breath relative to the in-breath is what shifts things toward settled.

**Why Release goes after the collecting**

There's the unevenness, and there's the case being built from it.

Two different costs, and the second has a specific failure built into it. The case is assembled by the part of you that's on your side — that's its job — so it comes out unanswerable. And an unanswerable case can't be raised without producing a fight, so it doesn't get raised at all. It accumulates instead, and the longer it accumulates the less raiseable it becomes.

That's the trap. The thing that was supposed to make it possible to say is the thing that made it impossible.

Putting down the collecting isn't deciding you were wrong. The observation stays. What stops is the assembly.

**Why the question is about the noticing**

*Why am I the one who has to put up with this* is a question about fairness, and it returns more evidence about fairness — which you already have.

*What was this for* asks about function. What it usually surfaces is that you're unusually good at noticing when things aren't even, and that's a skill that was learned somewhere it mattered a great deal to know.

**Why the surplus is worth attending to**

Where a reaction outruns the instance that occasioned it, the excess is carrying information about something other than the instance. An interpretive lens rather than a finding, and what it shows you is yours to read.

**Why Rise is one sentence**

A case needs someone to lose. A sentence doesn't. The plain observation, said once, without the supporting instances, is the version that can actually be answered — and being answered is the only route to anything changing.

---

> **SHARED BLOCK** — insert *The part that's on your side, and the part that can hear them* here, verbatim from `SHARED-t2-two-instruments.md`. Identical on all ten Track 02 protocols. Do not paraphrase or re-cut per protocol.

---

### What we rest on

**Shadow & individuation — C. G. Jung** · *interpretive* · informs Release

What you decline to look at keeps running unattended, and you tend to meet it as other people's faults. The usable test is proportion: when a reaction outruns the event that occasioned it, the surplus is carrying information about something other than the event. There's no finish line. *Here it accounts for why one small instance can carry the weight of every previous one.*

*Offered as a lens rather than a finding, with no controlled evidence behind it. What it shows you is yours to read.*

**Compassionate Inquiry — Gabor Maté** · *clinical practice* · supplies Release and the way the question is asked

A response is treated as an adaptation rather than a defect. The kind of question you ask decides the kind of answer you get. *What is wrong with me* asks what is broken, and comes back with a list of what is broken. *What was this for* asks what it was doing, and comes back with something you can use. *Here it turns the noticing from a grievance into a skill with a history.*

*A clinical practice, not a controlled research programme. Used here for the way the question is asked, and nothing wider.*

**Where the reading is yours** — this explains the machinery. Whether the rule is unfair, what it means, and what to do about it are readings that belong to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Unclench the jaw.** Teeth apart, tongue down. The unsaid thing lives here.

**Long exhale, no ceremony.** Four in, six out, three or four cycles.

**Shoulders down and back.** Blades gently together, then sliding down away from the ears.

**Say the sentence out loud, once, alone.** The plain version, not the case. Hearing how short it is does something that thinking about it doesn't.

**Push against something immovable.** Palms to a wall or the underside of a desk, steady pressure for a slow five, then release completely.

**Write the instance down and stop.** One line, on paper, and then leave it. This puts it somewhere other than the running tally without adding to the tally.

*Note when the next instance happens and don't add it to anything. Just notice it, and let it be one thing.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with the state that comes from being held to a different standard, using breath, attention and observation. It leaves your observation entirely intact and makes no ruling on whether the treatment is fair.

**Pacing**

Once through is a complete use. Use it when the state is there, or shortly after an instance rather than in the middle of one.

**What people commonly notice**

Anger arriving, often larger than the instance warrants. That's the accumulation moving, and it's ordinary.

The case reassembling immediately after the session. That's the state doing what it does; note it and come back to the sentence.

A reluctance to give up the collecting, which is worth taking seriously — see the third step.

**When to slow down**

If Release opens something much older — a family arrangement, a much earlier version of the same unevenness — you can stop there and come back to the breath.

If saying the sentence out loud starts a rehearsal rather than a discharge, stop. Once is release. Repeatedly is the case, being polished.

**When a person in the room is the right tool**

Contact someone — a doctor, a helpline in your country, or a person you trust — if the unevenness is constant and you can't raise it without cost, if it's affecting your work or your health, if you're using something to manage it, or if you're having thoughts of harming yourself.

**Where the situation is the thing**

If the arrangement is genuinely unequal and hasn't moved when named, this settles you and doesn't change it. The Proximity Guide is not on this protocol — the tier work here belongs to whichever relationship or workplace it sits in, and where it's a workplace, HR, a union or an employment lawyer are the relevant next moves.

**Alongside other support**

If you're with a therapist, doctor or counsellor, this sits alongside that and replaces nothing.

---

## 06 · Disclosure & Support
*A script for someone close.*

Take these exactly, or change every word.

**Saying it**
> "There's a thing where a rule seems to apply to me and not to them, and I've been carrying it rather than saying it. I'm not asking you to referee. I'd rather it existed outside my own head."

**Describing what it's actually like**

> "It's physical — chest, jaw, and a specific tightness in my throat which is where the thing I didn't say ends up."

> "The part I can't switch off is the collecting. Every instance goes on the pile so that one day I can say it and it'll be undeniable. Except the pile is now so big I can't raise it without starting a war, so I don't."

**How to tell it's coming**

> "I go quiet and very fair. I start agreeing with things I don't agree with. I get short about something unrelated."

**What helps**

> "Ask me what the one sentence is. Not the whole thing — the plain version. Making me say the short one out loud is worth more than an hour of building the case."

> "Believe the observation without joining in. If you start listing their faults, I've got a bigger pile and less chance of saying anything."

**What doesn't**

> "Telling me to pick my battles. I've been picking none, which is how the pile got this size."

> "Explaining why they do it. They might have reasons. It doesn't change what it's like."

**If they ask what you're doing about it**

> "There's a method I run. I name it as a state rather than as the case, do a breathing pattern, and stop collecting instances — because the case being unanswerable is the reason I can't raise it. Then I work out the one plain sentence."

*Tell one person. Being uneven with someone privately for years costs more than the unevenness does.*

---

## 07 · Invitation to Repair
*Reopening it with them.*

Send it from the far side of the protocol. From inside the state, every sentence arrives supported by eleven instances, and they'll hear all eleven.

**The rule that makes it sendable:** the observation without the evidence. That feels wrong — you have the evidence and it's good — but evidence turns an observation into a charge, and a charge gets defended rather than answered.

**Sendable**
> There's something I've noticed and I've never said it, which is on me.
>
> It seems like [the thing] works one way for me and a different way for you. I'm not saying that's deliberate and I'm not building a case about it.
>
> I'd rather say it plainly once and hear what you think than keep quietly minding it.

**Shorter**
> Can I say something? I think [the thing] works differently for me than it does for you, and I've been sitting on it.

**Where you've been going along with it**
> I've been agreeing to this arrangement for a long time without ever saying I minded, so you'd have had no way of knowing. I mind. That's the whole message.

**Where it's at work**
> I want to raise something about how [the thing] is applied. I'm not making an accusation. I'd like to understand whether it's intentional, because from where I sit it looks uneven.

**Before sending** — count the instances in it. If there's more than nought, cut them. Then read it for *always*, *never* and *every time*, which are the pile arriving in two words.

*If they don't take it, you've done the part that was yours. Whether they meet it is theirs.*

---

## 08 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

Any of these, or none.

- Where did it sit in your body?
- What's the rule, in one line?
- Write today's instance. Just today's.
- Was your reaction proportionate to today's instance? If not, how far off?
- *What was this for* — what turned up, without needing to answer it?
- What did you say to yourself from across the room?
- What's the one plain sentence? Write it as you'd actually say it.
- Have you ever said it? What happened?
- What did you write here last time? Read it back.

---

## 09 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half exits as something almost impossible to name from outside.

**The specific blind spot here** — it exits as fairness with the warmth removed. Scrupulously reasonable, entirely correct, and cold. From inside that's restraint, and you're proud of it. From outside it's being held at a distance by someone who won't say why, and there is nothing to respond to because nothing has been said.

**The second one** — the compliance that isn't agreement. Going along with things while minding them. From outside, agreement looks like agreement, so the other person keeps doing the thing believing it's fine. Every instance you absorb silently makes the next one more likely.

**The third one** — the eventual delivery. When the pile finally goes, it goes as eleven instances at once, and the person receives an unanswerable case about things they'd have changed if asked. That's the outcome the collecting produces, and it lands as an ambush.

**Their earlier information** — worth asking: *did you know I minded?* Expect no more often than you'd think.

**Naming the act, not the character** — *"I've been going along with this for two years and never said I minded"* is ownership. *"I'm a doormat"* is not; it names nothing and asks them to disagree with it.

**No because.** The instances are real and they don't belong in the sentence. That's the pile arriving as justification.

**No self-attack.** *"I should have said something, I'm useless at this"* moves the burden across the table at the moment you're finally raising something.

**Describe what was observable, ask about the rest.** *"I've been cool with you and I never said what it was about. I'm not going to tell you what that's been like — I'd rather you told me."*

**The checkable change** — this repairs by raising things at the time rather than by no longer noticing. *"I'm going to say it in the week, even if it's awkward"* is small, specific and observable.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. If the arrangement is genuinely unequal and raising it carries real cost — your job, your standing, your safety — this isn't the resource for that, and the relevant next moves are outside this platform.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Collect instances. Build something unanswerable.

Note it. Add it to the others. Make sure that when it's finally said, it can't be argued with — because if it can be argued with, it'll be argued with, and then it'll have been for nothing.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Being taken advantage of without registering it. Being the one it's easier to ask. Not noticing until it's too far gone.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *how long I've been quietly cool with them*, or *the fact that the case is now too big to raise.*

---

**What it should be attending to instead**

It isn't deciding you were wrong. The observation is accurate and stays.

What's available is a different instruction about **evidence**.

The old one builds a case that needs someone to lose. The successor says the plain observation once, with nothing behind it — which is the only version that can actually be answered.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *say it once, with no instances attached.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *raises the small one on the day. Says it without the word always. Lets one go without adding it.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Feels it arrive. Says the one sentence or lets it pass. Doesn't file it.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
