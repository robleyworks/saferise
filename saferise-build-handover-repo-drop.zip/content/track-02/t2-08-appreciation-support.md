# t2-08 · The Appreciation & Support Protocol

**Label:** Appreciate · **State:** Numb · **Frameworks:** HeartMath, Kross · **extras:** `[]`
**Resources: 8** · *meditation authored ahead of the remaining resources — Release language here is canonical*

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in late, light rather than low. Turn at four seconds.
> **VOICE** — warm, easy, unbothered. This is the least somber protocol on the platform. Nothing is wrong and nobody is in trouble.

Something good happened, and you felt almost nothing.

> **GOLD/PAUSE** — long

Or someone was kind to you and it went straight past. Or you got the thing, and there was a flatness where the feeling should have been.

> **GOLD/PAUSE**

That's not ingratitude and it isn't a character problem. It's a state, and states shift.

---

### Before we start

> **RED/ACTION** — small deliberate movement. Offered, never insisted on.

Move your fingers. That's the whole ask for now.

> **GOLD/PAUSE** — very long

And your feet, into whatever's underneath them.

> **GOLD/PAUSE** — very long

---

### Recognition

One word, and we're not going hunting for it.

> **GOLD/PAUSE**

**Numb.**

> **GOLD/PAUSE** — very long

No need to find where it sits. In this state that's hard, and not finding it belongs to the state rather than to you.

> **BLUE/ILLUSTRATION** — colour present in the frame, viewed through something. Not absent. Muted.

> **GOLD/PAUSE** — long

Here's the thing worth knowing. Flatness isn't selective. It doesn't turn down the bad and leave the good — it turns everything down together. The good things are still there. They're just arriving quietly.

---

### Regulation

Contact before counting.

> **RED/ACTION** — hand to sternum, or hold your own arm. Offered, not instructed.

> **GOLD/PAUSE** — very long

Now the breath. Longer out than in. Count it if you can.

> **TEAL/BREATH** — in, slow
> **TEAL/BREATH** — out, longer
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

### Release

Two things, and the second is the one that stings.

> **GOLD/PAUSE**

There's the flatness. That turned up on its own.

And there's what you've been saying to yourself about it. *They went to all that effort. Other people would be thrilled. What is wrong with me.*

> **GOLD/PAUSE** — long

That's a reproach, running underneath, and it doesn't lift the flatness. It adds to it.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Put down the reproach. Keep the flatness — it isn't doing any harm on its own.

> **GOLD/PAUSE** — long

And the question. Not *what's wrong with me that I can't feel this* —

**What was this for?**

> **GOLD/PAUSE** — long

Turning everything down is what a system does when it's had more than it can process. It doesn't discriminate. It's a volume control, not a judgement about what's worth feeling.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

---

### Rise

Step back a little.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Someone over there. Breathing four and six. Not in any trouble.

Speak to them as *you*.

*You're flat. It isn't the same as not caring.*

> **GOLD/PAUSE** — long

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now — one specific good thing. Not a list, and don't try to feel anything about it. Just name one that's factually true.

> **GOLD/PAUSE** — very long

Somebody did something. Something went right. Something is still here.

> **GOLD/PAUSE** — long

You don't have to feel it for it to be true. That's the whole move, and it's a relief once you've got it — the fact doesn't need the feeling to sign it off.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one small thing you'll do about it. Say the thing out loud to the person. Send the message you didn't send. Not because you feel it — because it's true and they don't know.

> **GOLD/PAUSE** — long

Now put it down. All of it.

> **GOLD/PAUSE**

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back whenever.

The flatness may well still be here. It usually outstays the session.

What's gone is the second thing — the telling yourself off for it. That was the expensive half.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

*Before you start — move something. Fingers, feet into the floor.*

**Name it** — *You are numb.* Flatness isn't selective.
**Contact, then breath** — Hand on your chest. Longer out than in.
**Stop the telling-off** — The reproach adds to it. It never lifts it.
**Name one true good thing** — You don't have to feel it for it to be true.

### Back

**Move first** — Before anything else, move something small. In this state movement comes before attention, because attention is the part that's reduced.

**Recognition** — One word. *Numb.* Don't search for where it sits; not finding it belongs to the state. And know this: flatness isn't selective. It doesn't turn down the bad and leave the good — it turns everything down together. The good things are still there, arriving quietly.

**Regulation** — Contact before counting. Hand on your chest, or hold your own arm. Then longer out than in. Count if you can, don't if you can't.

**Release** — Two things. The flatness, which turned up on its own. And what you've been saying to yourself about it — *they went to all that effort, other people would be thrilled, what's wrong with me.* That's a reproach, and it doesn't lift the flatness. It adds to it. Put down the reproach.

**Rise** — See yourself from a distance. *You're flat. It isn't the same as not caring.* Then name one specific good thing that's factually true — don't try to feel anything about it. Then one small thing you'll do about it: say it out loud to the person, send the message. Not because you feel it. Because it's true and they don't know.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

A reduced state lowers the whole range rather than selecting parts of it. Sensation flattens, thought slows, and the capacity to begin things drops.

The thing people miss is the indiscriminacy. There's a widespread assumption that flatness means you've stopped caring about specific things — that the good news didn't land because it didn't matter to you. That isn't how it works. The volume came down on everything at once, including the parts you'd very much like to be feeling.

**Why movement comes before attention**

Every other protocol opens by asking you to find where the state sits and hold attention there. In a reduced state, sustained attention is precisely what's diminished — so opening that way asks for the least available thing and produces someone who's failed at step one.

Small deliberate movement asks nothing of attention, gives immediate physical return, and confirms the body is responsive.

**Why Recognition is one word**

Naming does the same job here as everywhere: it puts a small distance between you and the state. But the hunt for a bodily location, useful in the mobilised states, tends to fail here, and the failure gets taken personally.

So the step is the naming and nothing else.

**Why contact comes before the count**

Warmth and pressure at the sternum is a direct input that requires nothing of you, and it registers when finer inputs don't. The breath follows: lengthening the out-breath relative to the in-breath is what shifts things toward settled. The count is offered rather than required, because in a reduced state counting can itself become a demand.

**Why Release goes after the reproach**

There's the flatness, and there's the commentary about it — *they made an effort, anyone else would be delighted, what is wrong with me.*

Two different costs. The flatness is a state and it will move on its own timeline. The reproach is generated continuously, adds load to a system that reduced because of load, and has never once produced feeling. It's the more expensive of the two and the only one you can put down.

**Why the fourth step separates fact from feeling**

The move that does the work here is the smallest one on the platform: a good thing can be true without being felt. You don't have to produce the feeling for the fact to stand.

That matters because the usual instruction — try to appreciate it, count your blessings — asks for exactly the capacity that's offline, and failing at it confirms the reproach. Naming something factually true asks nothing of the feeling apparatus at all.

**Why the forward move is a communication rather than an emotion**

Saying the true thing to the person is available today. Feeling it isn't. And the saying does something the feeling wouldn't have done anyway — they didn't know, and now they do.

---

> **SHARED BLOCK** — insert *The part that's on your side, and the part that can hear them* here, verbatim from `SHARED-t2-two-instruments.md`. Identical on all ten Track 02 protocols. Do not paraphrase or re-cut per protocol.

---

### What we rest on

**Cardiac coherence — HeartMath** · *peer-reviewed* · supplies Regulation and the count

At roughly six breath cycles a minute, heart rhythm and breath settle into a single smooth wave rather than two competing ones, close to a rhythm the body's blood-pressure regulation already runs at. Four in, six out lands near that rate. The uneven ratio is the mechanism. *Here the count is offered rather than required, because in a reduced state counting is itself a demand.*

*The finding is used here; the wider programme is not. There is no measurement of coherence anywhere on this platform and no score attached to any breath.*

**Distance & rehearsal — Kross & Ayduk, with King** · *peer-reviewed* · supplies Rise

Observing an experience from outside it, rather than from inside looking out, lowers distress and later reactivity. Distraction does neither. Second-person self-address is one of the reliable ways to produce that shift. Rehearsing a specific future scene in concrete detail lifts outlook; general optimism does not. *Here it supplies the specific-and-concrete rule that keeps the fourth step from becoming an instruction to count your blessings.*

*The effect is on the person rehearsing. It acts on your own steadiness and makes no claim to act on anyone else, or on how anything turns out.*

**Where the reading is yours** — this explains the machinery. What the flatness is about, and what it means, are readings that belong to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

Smaller than on most protocols. Any one of these on its own is a complete use.

**Move one small thing.** Fingers, toes, ankles. Movement before attention, always.

**Hand to sternum, or hold your own arm.** The input this state takes when it takes little else.

**Longer out than in.** Three or four breaths. No counting required.

**Say one true thing out loud.** To a person, or to nobody. *That was kind of you.* It doesn't require feeling.

**Send one message you've been meaning to send.** One line. The bar is that it's true, not that you mean it warmly today.

**Stand up.** That's the whole item.

*Warm water on the hands, held longer than necessary, is worth knowing about on the days none of the rest is available.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with a reduced state, using movement, contact, breath and observation. It doesn't produce feeling and doesn't ask you to.

**Pacing**

Any single part is a complete use. Moving your fingers and stopping there counts.

**What people commonly notice**

Nothing much, which is more common here than anywhere and doesn't mean nothing happened.

Guilt arriving in place of feeling — the flatness itself becoming the thing being reproached. That's the second step's whole subject.

Emotion arriving suddenly as the state lifts, sometimes days later and often disproportionately. Ordinary.

**When to slow down**

If the practice feels like one more demand, do a single somatic item and leave the session.

**When this needs a person rather than a practice**

Reduced states are the ones people carry longest, because the state removes the impulse to reach for anyone.

Contact someone — a doctor, a helpline in your country, or a person you trust — if you're having thoughts of harming yourself or of not being here, if you haven't been able to eat, wash or leave the house for days, if you can't remember when this started, if you're using something to get through it, or if this has been going on for weeks rather than days.

That last one particularly. A flat week is ordinary. A flat month is worth a doctor's appointment, and going is not an admission of anything.

**If the flatness is only around good things**

If the rest of your range is intact and it's specifically appreciation, support or affection that won't land, that's worth mentioning to someone. It sometimes points at something the practice isn't built for.

**Alongside other support**

If you're with a therapist, doctor or counsellor, this sits alongside that and replaces nothing.

---

## 06 · Disclosure & Support
*A script for someone close.*

This state removes the impulse to explain itself, which is why it needs a script. Any of these can be sent rather than said.

**Saying it**
> "Something's gone flat in me and it isn't about you. If I didn't react much to [the thing], that's the flatness, not what I think of you."

**Describing what it's actually like**

> "It's like the volume's come down on everything at once. Not just the bad stuff — the good things too. They're still there, they're just arriving quietly."

> "The part people misread is that it looks like not caring. It isn't. I know it's a good thing. I just can't feel it at the moment."

**How to tell it's coming**

> "I go still. I stop suggesting things. I say thanks in a flat voice and then feel bad about how it sounded."

**What helps**

> "Don't stop telling me things. I know I'm a poor audience right now. It's landing even if it doesn't look like it."

> "Small and specific rather than big and warm. A cup of tea beats a conversation about how I'm doing."

**What doesn't**

> "Asking why I'm not more pleased. I don't know, and now I've got that to feel bad about as well."

> "Being told to be grateful. That asks for exactly the thing that isn't working."

**If they ask what you're doing about it**

> "There's a method I run. It starts small — move something, then name it, then a hand on my chest before any breathing. Then I stop telling myself off for being flat, which turns out to cost more than the flatness. Then I name one good thing that's factually true, without trying to feel it."

> "And then I say it to the person. Which is this, basically."

*Tell one person. This is the state where the person who's been good to you is most likely to conclude they got it wrong, and one sentence prevents that.*

---

## 07 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.

One line is a complete entry.

- Could you find where it sat, or not? Either is fine.
- What good thing happened that didn't land?
- What did the reproach say? Write the actual words.
- Name one thing that's true whether or not you felt it.
- *What was this for* — anything, or nothing? Nothing is a real answer.
- What did you say to yourself from across the room?
- Did you say the true thing to the person? What happened?
- What did you write here last time? Read it back — without comparing.

---

## 08 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half lands on people who were trying to do something good.

**The specific blind spot here** — flatness reads as indifference, and the person on the receiving end usually concludes they misjudged it. They made an effort, it landed on nothing, and the reading available to them is that it wasn't wanted. From inside you know that isn't true. From outside there's no evidence for anything else.

**The second one** — the diminishing return. People stop offering. Not out of resentment — because the feedback said don't. That's the cost that compounds, and by the time you feel like yourself again, some of it has quietly stopped.

**The third one** — the flat thank you. Said, technically. Received as a formality. From inside it was all you had. From outside it can read as worse than nothing, because a formality implies the thing wasn't worth a real response.

**Their earlier information** — worth asking, once you can: *did you think I wasn't interested?* Expect yes.

**Naming the act, not the character** — *"You told me about the job and I barely responded"* is ownership. *"I'm a terrible friend"* is not; it names nothing and asks them to reassure you.

**No because.** The flatness is a real reason and it doesn't belong in the sentence, though on this protocol it can be said very shortly afterwards — because unlike most states, the explanation genuinely changes what happened for them.

**No self-attack.** *"I'm useless, I don't know why you bother"* asks them to look after you at the moment you're apologising for not looking after them.

**Describe what was observable, ask about the rest.** *"I've been unreachable for a while. I'm not going to tell you what that's been like — I'd rather you told me."*

**The checkable change** — this repairs by saying the true thing late rather than by feeling it on time. *"I'm going to tell you the thing even when I can't feel it"* is small, specific, observable, and doesn't require the state to have lifted.

**Where this stops** — this isn't an instruction to perform enthusiasm you don't have. A flat true sentence is worth more than a warm false one, and the people who know you will take it.

---

## 12 · The Decision
*What takes over.*

Short version today. This one asks very little.

---

**What's running now**

Tell yourself off for not feeling it.

They went to the effort. Anyone else would be pleased. So the flatness becomes a fault, and the reproach runs underneath everything.

It isn't a fault. It's been doing a job.

---

**What takes over**

It isn't feeling more. That isn't available on request and never has been.

What's available is saying the true thing without waiting to feel it.

> **One line. What should it be doing instead?**

Something like: *say it because it's true, not because I can feel it.*

Yours, if you've got one. If you haven't, leave it and come back — this one keeps.

---

**Who runs the next one**

Not who you are once this lifts. Who's in it while it's happening.

> **One thing they do, in the middle of one.**

*Names one good thing as a fact. Says it to the person. Doesn't apologise for the flatness while saying it.*

---

**Come back to it**

This gets rewritten and nobody arrives at it. On a day like today, having written one line is the whole of it.

*Written on your device and kept there. Nobody else sees it, and it is never measured against anything you wrote before. Because it is only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
