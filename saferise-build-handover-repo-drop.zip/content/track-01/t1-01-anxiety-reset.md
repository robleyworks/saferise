# t1-01 · The Anxiety Reset Protocol

**Label:** Regulate · **State:** Agitated · **Frameworks:** Porges, HeartMath · **extras:** `[]`
**Resources: 8** · free protocol, no account gate

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Five-bar phrase. Turn at four seconds.
> **VOICE** — steady, unhurried, unbothered. Someone who has seen this many times and is not alarmed by it. Not soothing.

There's something running fast, and it got here before you did.

> **GOLD/PAUSE**

That's the order it happens in. Body first, explanation afterwards — and the explanation is usually catching up rather than leading.

> **GOLD/PAUSE**

Four moves. You don't have to hold on to them. I'll take you through.

---

### Recognition

Somewhere in you there's a signal. Where's it loudest?

> **GOLD/PAUSE** — long

Chest. Throat. Stomach. Behind the eyes. Somewhere else entirely. There's no correct answer and you're not being marked.

> **BLUE/ILLUSTRATION** — a single word settling onto a still surface. No ripple.

Now one word for it. Not the story — the state.

**Agitated.**

> **GOLD/PAUSE**

And notice what just happened there. You were inside it. And for a second you were also the one looking at it.

> **GOLD/PAUSE** — long

Both at once. That second is the whole thing this is built on.

---

### Regulation

Now the breath, and the count matters more than the size.

Four in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six out. Longer out than in, every time.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Don't pull for a big one. A big breath asks for effort and effort is pointing the wrong way. Small is fine. Long is what matters.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the middle of your chest. The count keeps going on its own now.

> **RED/ACTION** — hand to centre of chest, flat, light. Offered, not instructed.

If a hand there helps, there's no reason not to.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Stay here a while. This is the part that does the most and it's the part people cut short.

> **GOLD/PAUSE** — extended

---

### Release

Now — there's a second thing going on, underneath.

> **GOLD/PAUSE**

Not the state. The argument with the state. It sounds like *not now.* Or *not again.* Or *what is wrong with me.*

> **GOLD/PAUSE** — long

That one costs more than the first, and it's the only one of the two you can put down.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

The state turned up. You're not being asked to want it, or approve of it, or find it interesting. Only to stop spending yourself on the fact that it arrived.

> **GOLD/PAUSE** — long

And swap the question. Instead of *what's wrong with me* —

**What was this for?**

> **GOLD/PAUSE** — long

Your body runs a fast state because a fast state is useful. It goes ahead of thought. That's the point of it, and it's why it doesn't check with you first.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Leave that one open. Nothing needs answering.

> **GOLD/PAUSE** — long

---

There's more here if you want it, and it takes longer.

> **GOLD/PAUSE**

If today is a day for getting steady and stopping there, stop there. Come back to the count, finish, and go. That's a complete use of this.

> **GOLD/PAUSE** — very long

Still here.

> **GOLD/PAUSE**

Then — what would you say this is about?

> **GOLD/PAUSE** — very long

Whatever came, that's the top layer. It's usually accurate. It's rarely the whole of it.

> **GOLD/PAUSE** — long

Here's what I mean by that.

Someone frightened of flying will tell you it's the plane. And it is, partly.

> **GOLD/PAUSE**

But go underneath and it's usually not the crash. It's everything on the other side of the crash. The people who'd be left. The things they'd never get round to. The ordinary Tuesday afternoons they'd miss.

> **GOLD/PAUSE** — very long

And under that there's usually one more thing.

> **GOLD/PAUSE**

It wouldn't be fair. And there'd be nothing they could do about it.

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — a surface, and something further beneath it than expected. Depth rendered as depth, not as darkness.

That isn't fear of flying. That's grief, arriving early, with nowhere to put itself.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

So. Yours.

> **GOLD/PAUSE** — long

What's underneath the thing you'd say it's about?

> **GOLD/PAUSE** — very long

And under that — what makes it unbearable, rather than just unwelcome?

> **GOLD/PAUSE** — very long

I'm not answering either of those. I don't know, and anyone telling you from outside your own life is guessing.

> **GOLD/PAUSE**

If something surfaced, let it have been said. Don't do anything with it yet.

> **GOLD/PAUSE** — long

If nothing came, that's a real answer too. These arrive in their own time, and often not while you're looking.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

---

Now the other direction. What has this been protecting?

> **GOLD/PAUSE** — very long

Something in you went to work early. Before there was anything to act on, before you'd decided anything, it started getting ready.

> **GOLD/PAUSE**

Whatever you just found under there — that's what it's been standing over. Not to torment you. To keep the thing you'd hate to lose in view.

> **GOLD/PAUSE** — very long

It's expensive, and it's loyal to you. Both are true.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

---

Two things before we move.

> **GOLD/PAUSE**

If you've just seen the size of what you've been carrying, there's usually something arriving right behind it. Some version of *I should be able to handle this.*

> **GOLD/PAUSE** — very long

Put that down.

Whatever you just found — it would be strange not to struggle with it. Struggling is the appropriate response to it. You've been doing that already, without knowing what it was you were up against.

> **GOLD/PAUSE** — long

And the other thing.

> **GOLD/PAUSE**

Something in you brought that up. Not the part that's frightened — the part that was willing to look underneath it while it was still happening.

> **GOLD/PAUSE** — very long

That took something. It's yours, it was yours before today, and it's the thing this whole practice runs on.

> **GOLD/PAUSE** — long

One more, and it's simply true rather than comforting.

> **GOLD/PAUSE**

Whatever you found under there — you're not the only one. Not close to it. It's one of the most ordinary things there is, and almost nobody says it out loud.

> **GOLD/PAUSE** — very long

If it opened something bigger than today, come back to the count now and end here. Going further on your own isn't the brave version. It's just the unaccompanied one.

---

### Rise

Step outside it.

Picture yourself from across the room. Not close up — across.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

There's a person over there, breathing four and six. Talk to them the way you'd talk to anyone else. Use *you*.

*You're having a fast day. You've had these before.*

> **GOLD/PAUSE**

Stay out there. The distance is doing its own work and it doesn't need help.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now — once you can see where your attention is, you can put it somewhere on purpose. That's what all of this is actually for.

> **GOLD/PAUSE**

So: later today. Somewhere specific, doing something specific, in this steadier state.

Where are you. What's in your hands. Who's there, or nobody. What's the first thing you say.

> **GOLD/PAUSE** — long

Detail. A general hope does nothing at all — it has to be a scene.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing already here before you come back. Small beats large. The chair. The light. That you stopped and did this.

> **GOLD/PAUSE**

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back when you're ready. Feet on the floor.

You may feel different. You may not. Both are ordinary and neither is a verdict on anything.

Now put it down — the state, the question, all of it. You don't have to carry any of it out of here.

The four are yours. Recognition. Regulation. Release. Rise. They work with your eyes open, anywhere, without me.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are agitated.* One word. No verdict.
**Breathe it** — Four in, six out. Attention on your chest.
**Stop fighting it** — Ask *what was this for*, not *what's wrong with me*.
**Step out** — See yourself from across the room. Say *you*.

### Back

**Recognition** — Find where it's loudest in your body. Name the state in one word. Notice you can see it while you're inside it. That noticing is the faculty everything else runs on.

**Regulation** — Four counts in, six counts out. Longer out than in, every time. Small breath is fine — a big one asks for effort and effort points the wrong way. Attention in the centre of your chest. Hand there if it helps. Keep going past where you'd normally stop.

**Release** — The state is one thing. Fighting the state is a second thing, and it costs more. Let the fact of it stand. Change the question to *what was this for* and leave it unanswered. What you do about it is separate, and comes later.

**Rise** — See yourself from a distance. Address yourself as *you*. Then one concrete scene, later today: where, what's in your hands, first thing you say. Detail, not hope. Then one thing already here.

---

## 03 · How This Works
*Why it works.*

**What the fast state is**

Before you have a thought about a situation, your body has already read it. That reading happens below awareness and runs faster than deliberation — it had to, because it evolved for situations where waiting to think was expensive.

In that state the body does specific things. Heart rate rises. Breathing goes shallow and fast and moves up into the chest. Blood shifts toward large muscle. Attention narrows and scans. Digestion slows, which is why the stomach is one of the common places to feel it.

None of that is malfunction. It's a working system doing its job.

**Why Recognition comes first**

The rest needs a subject. Naming a state in plain specific language does something describing it at length does not: it puts a small distance between you and the state while you are still inside it. That gap is where the next three steps operate. Without it there's nothing to work on, only weather.

**Why the exhale is longer than the inhale**

You can't decide your heart rate down. You can decide your breathing, and it's the one reachable control on a system you otherwise can't get at. The exhale is where the work happens — lengthening the out-breath relative to the in-breath is the part that shifts the system toward settled.

Which is why the count is uneven, and why a bigger breath isn't a better one. Pulling hard for volume recruits effort, and effort points the other way.

**Why Release addresses the second problem**

The state turned up on its own. Then a second thing started: fighting the fact that it's here. *Not now. Not again. What's wrong with me.*

Those are two different costs, and the second one is usually bigger. It's also the only one you can do anything about. Setting it down doesn't mean you're fine with the state. It means you stop spending yourself on the fact that it turned up.

The question changes for the same reason. *What is wrong with me* asks about defect and returns answers about defect. *What was this for* asks about function and returns something you can use.

**Why Rise is fourth**

Distance is available once the system has settled, and not much before. The forward rehearsal has one condition: it has to be concrete. Specific detailed scenes change outlook; general optimism doesn't.

---

### What we rest on

**Polyvagal Theory — Stephen Porges** · *peer-reviewed* · supplies Recognition and the three state labels

Threat detection runs ahead of thought. The body reads a situation and moves before deliberation catches up, which is what makes the response fast and also what makes it non-negotiable in the moment. Porges describes three broad conditions: settled and socially available, mobilised for action, and shut down. Agitated, Unsteady and Numb are the member-facing names for those three. *Here it names the fast state without attaching a verdict to it.*

*The anatomical premises are contested: a 2026 evaluation in* Clinical Neuropsychiatry *challenged them, with Porges replying in the same issue. The state distinctions are what this platform uses, and they hold independently of that dispute.*

**Cardiac coherence — HeartMath** · *peer-reviewed* · supplies Regulation and the count

At roughly six breath cycles a minute, heart rhythm and breath settle into a single smooth wave rather than two competing ones, close to a rhythm the body's blood-pressure regulation already runs at. Four in, six out lands near that rate. The uneven ratio is the mechanism. *Here it is the whole of the second step, and the reason a small breath beats a large one.*

*The finding is used here; the wider programme is not. There is no measurement of coherence anywhere on this platform and no score attached to any breath.*

**Where the reading is yours** — this explains the machinery. What any of it means about you, your history or your life is a reading that belongs to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Long exhale, no ceremony.** Four in, six out, three or four cycles. Eyes open, mid-conversation. Nobody can see you doing it.

**Weight into the chair.** Push your feet gently into the floor and let the chair take you, for a slow count of ten. The body treats supported and unsupported differently and stops noticing support unless attention is sent there.

**Hand to sternum.** Flat hand, centre of the chest, light. Contact and warmth at that spot is one of the quickest available signals of the settled state.

**Unclench the jaw, drop the shoulders.** Teeth apart, tongue off the roof of the mouth, shoulders down away from the ears. It creeps back. Do it again.

**Walk, and count something.** Lamp posts, red cars, doors. Not thinking while walking — counting while walking. The counting is what makes it different.

**Name three things in the room.** Something you can see, something you can hear, something you can feel against your skin. Recognition, applied outward.

*Cool water on the wrists at a sink also works. Comfortable, not shocking.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with a fast state while it's happening, using breath, attention and observation. You run it on your own, at the moment you need it, without booking anything or telling anyone.

**Pacing**

Once through is a complete use. Use it when the state is there rather than to a schedule. If four and six is a stretch, shorten both and keep the ratio uneven — three and five works, two and four works. The relationship between the counts is the mechanism, not the numbers.

**What people commonly notice**

Tingling in the hands or face during the breathing, which comes from breathing more evenly than usual and passes. Yawning, or a sigh arriving on its own. Feeling more of the state before less, particularly at Release, because you've stopped pushing against it. Tiredness afterwards. Or nothing much, which is also an ordinary result and not a sign you did it wrong.

**When to slow down**

If the breathing itself makes you feel worse — lightheaded, more panicked — stop counting and let your breath do whatever it does. Focusing on the breath increases alarm in some people rather than settling it. Use Recognition and Rise on their own and leave the count out. The protocol still works with three moves.

If Release opens something much larger than the day's state — a memory, a grief you weren't looking for — you can stop there. Surfacing isn't an instruction to follow it.

**When a person in the room is the right tool**

Some states need another human being, and no self-guided practice substitutes for one. Contact someone today — a doctor, a crisis line in your country, or a person you trust — if you're having thoughts of harming yourself, if the fast state doesn't let up over days rather than hours, if you're avoiding leaving the house, or if you're using something to get through it.

**Alongside other support**

If you're already working with a therapist, doctor or counsellor, this sits alongside that. It replaces nothing and competes with nothing. Tell them you're using it — most will want to know, and some will have views about the breathing worth hearing.

---

## 06 · Disclosure & Support
*A script for someone close.*

Take these exactly, or change every word.

**Saying it**
> "I get a thing where my body goes into a fast state — heart, breathing, everything speeds up. It's happening a fair bit at the moment. I wanted you to know so it isn't a mystery if you see it."

**Describing what it's actually like**

Most people name the mood and not the body, so the other person hears worry rather than a description. The body is the part that makes it land.

> "It's physical before it's anything else. Chest goes tight, breathing goes shallow and high up, stomach turns over. My attention narrows down and starts scanning. All of that happens before I've had a thought about anything."

> "The part that's hard to explain is that it often has no subject. People assume there's a thing I'm worried about. Sometimes there is. Often the state arrives first and then goes looking for something to be about."

**How to tell it's coming**

> "There are signs before I feel it. I start checking things. My sentences get shorter. I go still in a way that isn't calm, or I can't sit down at all."

> "If you notice that, something simple helps — not 'what's wrong', just 'do you want to go outside'. Earlier is much easier than later."

**What helps**

> "Stay nearby without making it an event. Being in the same room doing something else is genuinely better than being asked about it."

> "Offer the specific thing rather than asking what I need — a walk, some air, leaving where we are. I usually can't answer an open question while it's happening."

**What doesn't**

> "Being told to calm down, or asked what's wrong when I don't have an answer yet. Not your fault — the question needs a reason and I often haven't got one."

**If they ask what you're doing about it**

The version with parts in it is more reassuring than the vague one.

> "I run a method when it starts. Four steps. First I name the state instead of the story — that alone puts a bit of distance in. Then a breathing pattern, four counts in and six out, which is the part that brings the physical side down. Then I stop fighting the fact that it's happening, which is a separate cost from the thing itself. Then I look at it from across the room and pick one concrete thing to do next."

> "There's more than the session. A card with the four steps for when there's no time to think, a few physical things for in between, and something I write in afterwards."

*Tell one person. It doesn't have to be the closest person, and it can be a professional rather than a friend. States like this get heavier in proportion to how privately they're carried.*

---

## 07 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before.

Any of these, or none.

- Where in your body was it loudest?
- What word did you use? The accurate one, or the nearest to hand?
- What was happening in the hour before it started?
- At Release, what did the resistance actually sound like? Write the sentence it used.
- *What was this for* — what turned up, without needing to answer it?
- What did you say to yourself from across the room?
- What was the concrete scene? Has any of it happened since?
- What did you write here last time? Read it back.

---

## 08 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half exits — into a room, a tone, a silence, something you did or didn't do — and lands somewhere you can't see from where you're standing.

**The specific blind spot here** — anxiety mostly exits as absence. Cancelling. Not replying. Being physically present and clearly elsewhere. Leaving early. From inside, each of those is a small private management decision. From outside, they read as disinterest, and they accumulate. Nobody tells you, because the polite reading of a cancelled plan is to say it's fine.

**Their earlier information** — people close to you often see the onset before you feel it. That makes them a genuine instrument, and worth asking directly: *what do you see, before I know?*

**Naming the act, not the character** — *"I cancelled on you three times and didn't explain why"* is ownership. *"I'm a terrible friend"* is not; it names nothing and asks them to disagree with it.

**No because.** The state is a real reason and it still doesn't belong in the sentence. It can be said afterwards, if they ask.

**No self-attack.** *"I'm so sorry, I'm useless"* moves the burden across — now they're managing your distress about the thing. Self-attack is *what is wrong with me* wearing the clothes of accountability; it returns nothing usable.

**Describe what was observable, ask about the rest.** You don't know their interior. *"I've cancelled a lot lately. I'm not going to tell you what that's been like — I'd rather you told me."* The asking is how the information arrives.

**The checkable change** — anxiety repairs by saying the true short thing at the time rather than explaining later. *"I'm not going to make it, and it isn't about you"* sent on the day is worth more than a full account a week on.

**Where this stops** — a reaction is information about the exterior of your state. It isn't a verdict on you, and someone else's account of you isn't automatically more accurate than your own. What you find when you look is yours to read.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Scan everything. Find the exposure before it finds you.

That's the instruction, and it's been followed faithfully for years. Check the tone of the message. Notice who didn't reply. Run the worst version so it can't arrive without warning. Get there first.

It isn't a fault and it isn't irrational. Somewhere, being caught unprepared cost you something, and this was the answer to that.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Being caught out. Not seeing it coming. Being the last to know.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the sleep*, or *the things I didn't try because I'd already run how they'd go.*

---

**What it should be attending to instead**

Here's the part that matters, and it isn't the opposite of scanning.

The opposite of scanning is not looking, and you won't do that. It isn't safe and some part of you knows it.

What's available is a different instruction about **where** attention goes.

The old one attends to what might go wrong. The successor attends to what's worth going toward.

That's not optimism and it isn't carelessness. It's still careful — it just isn't spending the whole day on exposure.

> **So: what should it be on?**
>
> Not a value. Something concrete. What are you actually moving toward — the work, the person, the thing you'd be doing if you weren't checking.

Write it as an instruction, the way the old one is written. Something like: *attend to what's being built, not to what might fall.* Or plainer. Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive contact with a bad morning. Behaviour.

> **On an ordinary day, what do they do?**
>
> Examples people write: *reads the message once. Sends the thing without rehearsing the reply. Asks rather than assuming. Goes out even without knowing how it'll go.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, chest going, and not going down.

That's the difference between them.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.
>
> *Breathes it. Names it. Doesn't send the message. Stays where they are and lets it come up and go down.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old pattern took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
