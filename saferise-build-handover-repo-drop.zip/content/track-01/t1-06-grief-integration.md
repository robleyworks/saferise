# t1-06 · The Grief Integration Protocol

**Label:** Integrate · **State:** Unsteady · **Frameworks:** Maté, Watts · **extras:** `[]`
**Resources: 8**

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in from the first word. Very low. No turn until the close.
> **VOICE** — slow, sparse, unafraid of silence. Says less than it wants to. Sits alongside rather than comforts. More pauses than any other protocol.

Some days it's a long way off.

> **GOLD/PAUSE** — long

Today it isn't.

> **GOLD/PAUSE** — very long

There's no hurry in any of this. If you need to stop partway, stop partway.

> **GOLD/PAUSE** — long

And one thing before we start, because plenty of things pretend to be this. Nothing here is going to move you through anything. What we're doing is smaller. We're going to make the carrying cost less.

---

### Recognition

Where is it today?

> **GOLD/PAUSE** — very long

Chest, probably. A weight, or a hollow. Some days both together, which makes no sense and is still what happens.

> **GOLD/PAUSE** — long

Throat. Behind the eyes. Or a tiredness with nothing to do with sleep.

> **BLUE/ILLUSTRATION** — a shape with a space in it. The space is part of the form, not damage to it.

> **GOLD/PAUSE** — very long

One word. **Unsteady.**

> **GOLD/PAUSE** — long

That's the accurate one. This doesn't hold still. Gone for a week, then back in a supermarket aisle over nothing.

> **GOLD/PAUSE** — long

It's here today. There's no backwards for it to be.

---

### Regulation

Four counts in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six out.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

If it catches, let it catch. Don't smooth it out for me.

> **GOLD/PAUSE** — long

> **RED/ACTION** — hand to sternum, flat, light. Offered, not instructed.

A hand on your chest, if you'd like one there.

> **GOLD/PAUSE** — very long

Attention into the middle of your chest. Including the part that hurts.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

If crying arrives, it's arriving into the right room.

> **GOLD/PAUSE** — extended

---

### Release

Two things here, and only one of them is the grief.

> **GOLD/PAUSE** — long

The first is the loss. That stays. It isn't going to be reframed or argued down or set anywhere.

> **GOLD/PAUSE** — very long

The second one is quieter, and it's been running a long time.

Bracing before it comes. Trying to have it at convenient hours. Checking whether this is too much of it, or too long, or the wrong shape.

> **GOLD/PAUSE** — long

And underneath, usually — *this shouldn't have happened.* Said again, and again, to something that already did.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Which of those two is costing you more today?

> **GOLD/PAUSE** — very long

So — put down the fight. Only that.

Not the grief. Not the love it's made of. Not them.

> **GOLD/PAUSE** — very long

Nobody's asking you to be at peace with it. It isn't acceptable. It just already happened.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

There's a question, and you don't have to take it.

**What was this for?**

> **GOLD/PAUSE** — very long

Grief is the shape love takes when what it was pointed at isn't there.

> **GOLD/PAUSE** — long

Not a malfunction. It's the size it is because that's the size it was.

---

### Rise

Step back a moment.

Someone sitting there, carrying something, breathing four and six.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Say it to them as *you*.

*You're carrying something heavy. Of course you are.*

> **GOLD/PAUSE** — very long

Nothing to fix in that. No second half where it gets better.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now — later today. Not the day this is finished. That day isn't available and I won't pretend it is.

An ordinary hour, carried out while carrying this.

> **GOLD/PAUSE** — long

Where are you. What's in your hands. What's around you.

> **GOLD/PAUSE** — very long

Both things at once. Not instead of it. Alongside.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one last thing, and listen to how it's put.

> **GOLD/PAUSE**

Not something to be grateful for about the loss. Nobody's asking you for that.

> **GOLD/PAUSE** — long

Something that's still here. Something it didn't take.

> **GOLD/PAUSE** — very long

Now put the rest of it down. You don't have to carry any of this out of the room.

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back when you're ready. No rush on that either.

> **GOLD/PAUSE**

You'll be in this again. Probably soon.

> **GOLD/PAUSE**

This is a thing you carry. All of it was about the carrying.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are unsteady.* Arriving isn't a setback.
**Breathe it** — Four in, six out. Let it catch if it catches.
**Drop the fight** — Not the grief. Ask *what was this for*.
**Step out** — *You are carrying something heavy. Of course you are.*

### Back

**Recognition** — Find where it sits: chest, throat, behind the eyes, a tiredness unrelated to sleep. Name the state in one word. Grief doesn't hold still and it comes with no schedule — being in it today isn't something you're doing wrong. Naming it doesn't reduce it. It means for a second you were the one looking.

**Regulation** — Four in, six out. If the breath catches, let it. Attention in the centre of your chest, including the part that hurts — you're not going around it. Hand there if it helps. If crying arrives, that's the session working.

**Release** — Two things are running. The loss, which stays. And the fight with it — bracing, trying to have it at convenient times, monitoring whether it's too much or too long, and the quarrel with the fact of it. The fight is the larger expense and the only one you have a say over. Set down the fight, not the grief. This isn't peace with it and it isn't calling it acceptable.

**Rise** — See yourself from a distance. *You are carrying something heavy. Of course you are.* Then one concrete ordinary scene later today, carrying this — not the day it's over. Both things at once. Then one thing that remains.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

Grief isn't a single state and doesn't behave like one. It moves — heaviness, agitation, numbness, ordinary functioning, and back — sometimes within an hour. Unsteady is the accurate label because instability is the characteristic, not any one of the states it passes through.

In the body: weight or hollowness in the chest, tightness in the throat, pressure behind the eyes, and a fatigue disproportionate to activity. Appetite and sleep both change. Attention is unreliable in a way people frequently mistake for something wrong with their mind.

**Why nothing here is arranged in stages**

Grief doesn't proceed through a sequence, and the widely known stage model was never a description of how bereaved people move through loss. What it produces in practice is a member measuring themselves against a schedule that doesn't exist and concluding they're behind.

There's no completion here, no arc with a good end, and nothing to finish. The practice is about the carrying.

**Why the exhale is longer than the inhale**

You can't decide a state down. You can decide your breathing, and it's the one reachable control. Lengthening the out-breath relative to the in-breath is what shifts the system toward settled.

The instruction to let the breath catch matters. A caught breath is what the body does under this state, and smoothing it deliberately turns the step into another thing to be managed. The count is somewhere to return to, not a standard to hold.

**Why Release targets the fight and not the grief**

There's the loss, which stays. And there's the resistance to it — bracing for its arrival, timing it, monitoring whether it's proportionate, and the low running argument with the fact that it happened.

Two different costs. The first isn't optional — the loss stays. The second starts again every day, changes nothing, and is the only one you can put down.

Setting the fight down isn't acceptance in the sense of finding the loss acceptable, and it isn't peace with it. The distinction matters because people asked to *accept* a loss usually hear that they're being asked to approve of it, and refuse — correctly. What's being set down is the argument with a fact, not the feeling about it.

The change of question does related work. *What's wrong with me that I'm still like this* has a timetable built into it. *What was this for* asks about function, and what it surfaces is that grief is proportionate to attachment — the cost of having been attached to something, rather than a malfunction to be corrected.

**Why Rise rehearses carrying rather than finishing**

Rehearsing the day it's over is rehearsing a scene you have no route to. Rehearsing an ordinary hour, carried out while carrying this, is a scene that's actually available — and it's the one that transfers.

The final move asks for something that remains, not for gratitude about the loss. Gratitude for a loss is not a thing this platform will ask anyone for.

---

### What we rest on

**Compassionate Inquiry — Gabor Maté** · *clinical practice* · supplies Release and the way the question is asked

A response is treated as an adaptation rather than a defect — something that was doing a job. The kind of question you ask decides the kind of answer you get. *What is wrong with me* asks what is broken, and comes back with a list of what is broken. *What was this for* asks what it was doing, and comes back with something you can use. *Here it removes the implied timetable from the question people ask themselves about grief.*

*A clinical practice, not a controlled research programme. Used here for the way the question is asked, and nothing wider.*

**Non-resistance — Alan Watts** · *interpretive* · informs why the third step says *accept*

The state is one thing. The fight with the state is a second thing. The fight usually costs more, and it's the only one of the two you can put down. Setting the fight down isn't passivity, isn't approval, and isn't agreement that the situation is acceptable. *Here it is the distinction the whole protocol turns on — the loss stays, the quarrel with the fact of it doesn't have to.*

*Watts is an interpreter rather than an originator; the older sources are Laozi and, for the framing used here, D. T. Suzuki. Offered as a lens rather than a finding.*

**Where the reading is yours** — this explains the machinery. What your grief means, what the relationship was, and what you carry forward from it are readings that belong entirely to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Long exhale, no ceremony.** Four in, six out. If it catches, let it catch.

**Hand to sternum.** Flat, light, centre of the chest. Warmth and contact at the place the weight sits.

**Weight into the chair or the ground.** Press down, feel it push back, hold for a slow five. Grief makes the body feel unsupported and this is a direct contradiction of that, at the level the body reads.

**Walk without a destination.** Not exercise and not a task. Movement with nothing required of it. This state tolerates walking when it tolerates almost nothing else.

**Warm water on the hands, or a hot drink held.** Held rather than drunk. Warmth in the hands is one of the few inputs that reliably registers.

**Be near people without talking to them.** A café, a park, a shop. Undirected proximity, nothing required of you. This state isolates, and the isolation compounds it.

*If you need to lie on the floor, lie on the floor. Getting lower is a real option and it isn't giving up.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with a state that moves and doesn't resolve, using breath, attention and observation. It doesn't reduce grief, doesn't shorten it, and doesn't move you through anything. It makes the carrying less expensive.

**Pacing**

Use it when you want it. There's no rate that's correct and no interval that means anything. Some people use it daily for a period and then rarely. Both are ordinary.

If four and six is a stretch, shorten both and keep the ratio uneven.

**What people commonly notice**

Crying, often, and often at the Regulation step rather than where they expected. Grief arriving harder during the session than before it — that's the state having room rather than the practice going wrong. Exhaustion afterwards. Long stretches of feeling almost nothing, which people worry about and which is an ordinary part of this.

**When to slow down**

If the session opens something you're not ready to be in on your own, stop and come back to the breath, and end there. That's not a failure. Grief is one of the few states where stopping partway through is often the correct decision.

Anniversaries, birthdays and the ordinary dates are heavier and arrive with less warning than people expect. Using the protocol before one rather than during it is worth knowing about.

**When a person in the room is the right tool**

Grief is not a condition and doesn't need treating. But it isn't meant to be carried alone, and a self-guided practice is not company.

Contact someone — a doctor, a bereavement service, a helpline in your country, or a person you trust — if you're having thoughts of harming yourself or of not being here, if you can't eat or sleep across an extended period, if you're using something to get through the days, if you can't function at all rather than functioning badly, or if the loss was sudden, violent, or a death by suicide. That last one specifically: it carries things ordinary bereavement support isn't built for, and there are services specifically for it in most countries.

If the loss is recent — days or a few weeks — a practice is not the priority. People are. Come back to this when you want it.

**Alongside other support**

If you're with a therapist, doctor, counsellor or bereavement service, this sits alongside that and replaces nothing.

---

## 06 · Disclosure & Support
*A script for someone close.*

People want to help and have no idea what to do, so they either avoid the subject or produce something clumsy. Telling them what actually helps spares everyone.

**Saying it**
> "I'm still in it. I know it's been a while by everyone else's clock. I'd rather say that than keep performing being fine."

**Describing what it's actually like**

> "It isn't constant. It comes and goes with no pattern, and it can arrive over nothing — a song, a supermarket aisle. That's the part people don't expect, and it's why I sometimes go strange out of nowhere."

> "It's physical. Weight in my chest, throat closing, tired in a way sleep doesn't touch. And my concentration is genuinely worse. That's not me being distant from you."

**What helps**

> "Say their name. People avoid it and the avoiding is worse than the mentioning. I'd rather hear it than have everyone step around it."

> "Specific offers rather than 'let me know if you need anything'. I won't let you know. 'I'm bringing food Thursday' is something I can accept."

> "Just be around. You don't have to say anything at all, and it's better if you don't try to."

**What doesn't**

> "Anything with a silver lining in it. That they're at peace, or it was their time, or that I'll be stronger for this. I know it's meant kindly and it lands as being asked to feel better for your benefit."

> "Asking how I'm doing in a particular voice. Just ask normally, or don't ask."

**If they ask what you're doing about it**

> "There's a method I run. It doesn't fix anything and it isn't meant to — there's nothing here to fix. It makes the carrying cost less. I name the state, do a breathing pattern, stop fighting the fact that it's happening, and then look at it from a bit of distance and get on with an ordinary hour while still carrying it."

> "The main thing it did was stop me measuring myself against a schedule that doesn't exist."

**If you need to say the hard version**
> "I don't want to be talked out of this. I want someone to sit near me while I'm in it. That's the whole ask."

*Tell someone. This is the state that most reliably isolates the person in it, and the isolation is produced by the grief rather than chosen.*

---

## 07 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before.

There's no arc here and nothing accumulating toward a good end. Some entries will be much worse than earlier ones and that means nothing about how you're doing.

Any of these, or none.

- Where did it sit in your body today?
- What brought it in? Sometimes there's nothing. Write that if there's nothing.
- What was the fight today — bracing, timing it, monitoring it, or arguing with the fact of it?
- What did you say to yourself from across the room?
- What was the ordinary thing you did while carrying it?
- What remains? Something the loss didn't take.
- Is there anything you'd want to say to them, that you can write here instead?
- What did you write here last time? Read it back, without comparing.

---

## 08 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half exits — and grief's exterior is one of the least discussed, because nobody wants to be the person raising it with someone bereaved.

**The specific blind spot here** — grief exits as unpredictability. Fine on Tuesday, unreachable on Wednesday, sharp with someone on Thursday over nothing. From inside, each of those is just what the day was. From outside, the people around you are walking on ground that moves, and they've stopped knowing which version of you they're going to get.

**The second one** — the disappearing. Not returning calls, letting things lapse, being unavailable for months. From inside it's having nothing to give. From outside it's being dropped, and the people who care most usually say nothing about it because raising it feels like an accusation against someone who's grieving.

**Their earlier information** — people close to you often see the day going before you feel it. Worth asking: *what do you see, before I know?*

**Naming the act, not the character** — *"I snapped at you on Thursday over the thing with the car"* is ownership. *"I've been impossible"* is not; it names nothing and it invites them to say it's understandable, which lets both of you skip it.

**No because.** And this one is unusually hard, because the because is enormous and everybody already knows it. It's still a defence when it's attached to the sentence. Grief explains conduct. It doesn't dissolve it, and the person on the receiving end knows that even if they'd never say so.

**No self-attack.** *"I'm a mess, I'm sorry, I don't know why anyone bothers"* asks them to reassure you, which is a thing they've probably been doing for months already.

**Describe what was observable, ask about the rest.** *"I've been unreliable for a while and I've stopped asking how you are. I'd rather hear what that's been like than assume."*

**The checkable change** — grief repairs by flagging rather than by improving. *"I'm going to tell you when it's a bad day instead of just going quiet"* is small, specific, observable, and doesn't require you to be different.

**Where this stops** — this resource is not an instruction to be less grieving for other people's comfort, and it isn't a suggestion that you owe anyone a better performance. It's the missing half of the information about your own state. A reaction is data about the exterior, not a verdict on you. And if you're not up to this today, that's a legitimate answer — this is the one resource on this protocol you can leave for a long time.

---

## 12 · The Decision
*What takes over.*

Short version today. This one asks very little.

---

**What's running now**

Brace for it. Have it at manageable times.

Check whether this is too much grief, or too long, or the wrong shape. Get ahead of it so it doesn't arrive in the wrong room.

It isn't a fault. It's been doing a job.

---

**What takes over**

It isn't grieving less, and it isn't grieving on schedule. Neither is available and neither is the point.

What's available is letting it arrive when it arrives.

> **One line. What should it be doing instead?**

Something like: *let it come when it comes, and don't check whether it's allowed.*

Yours, if you've got one. If you haven't, leave it and come back — this one keeps.

---

**Who runs the next one**

Not who you are once this lifts. Who's in it while it's happening.

> **One thing they do, in the middle of one.**

*Lets it happen. Doesn't leave the room to have it privately. Doesn't check how long it's been.*

---

**Come back to it**

This gets rewritten and nobody arrives at it. On a day like today, having written one line is the whole of it.

*Written on your device and kept there. Nobody else sees it, and it is never measured against anything you wrote before. Because it is only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
