# t1-08 · The Jealousy Release Protocol

**Label:** Release · **State:** Unsteady · **Frameworks:** Jung, Maté · **extras:** `['advisory','invitation']`
**Resources: 10** · all conditionals apply

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Five-bar phrase. Turn at four seconds.
> **VOICE** — frank, unembarrassed, faintly wry. Treating this as ordinary is the intervention. No gentleness, no pity.

Right. This is the one nobody wants to say out loud.

> **GOLD/PAUSE**

People will admit to almost anything before they'll admit to this one. So let's just have it in the room, plainly, and get on.

> **GOLD/PAUSE**

Nothing here is going to tell you whether you're right about what's happening. You might be. That stays open and we're not touching it.

---

### Recognition

Where is it?

> **GOLD/PAUSE** — long

Stomach, usually. That turning over. Sometimes heat up through the chest and into the face — sometimes a coldness instead, which catches people out.

> **BLUE/ILLUSTRATION** — two shapes, one lit and one in shadow, the shadow slightly larger.

One word. **Unsteady.**

> **GOLD/PAUSE**

Now — notice how much came attached to that. A whole scene. People in it, a history, and a fairly persuasive case.

> **GOLD/PAUSE** — long

That's what makes this one feel like information rather than a state.

> **GOLD/PAUSE**

Underneath all of it there's just a body doing something. That's the bit we can work on. The scene will keep.

---

### Regulation

Four in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six out.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention to the middle of your chest.

> **RED/ACTION** — hand to sternum, or phone face-down. Offered, not instructed.

This one pulls hard toward looking. A phone, a profile, a room.

> **GOLD/PAUSE**

Not yet. Look afterwards if you still want to — you probably won't, and that's information in itself.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

### Release

Now the comparing.

> **GOLD/PAUSE**

You against them. Over and over, in a contest nobody entered and nobody is judging.

> **GOLD/PAUSE** — long

And it gives you the same answer every round. It was always going to — you're running it, and you know exactly which way it goes.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

The state can stay. Put down the measuring.

> **GOLD/PAUSE** — long

And the question — not *what's wrong with me that I'm this person.* You've asked. It gave you nothing.

**What was this for?**

> **GOLD/PAUSE** — long

Here's what usually turns up, and it's more useful than it sounds.

Jealousy points at something. Often not at the person — past them, at something you want and haven't said out loud. Sometimes haven't said to yourself.

> **GOLD/PAUSE** — long

And the size of it is worth noticing. When the reaction is much bigger than whatever set it off, the extra is about something.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

So — what's underneath it? What did you decide this meant about you, and when?

> **GOLD/PAUSE** — very long

I'm not going to answer that. I don't know, and anyone who claims to is selling you something.

If something surfaced, it's yours. If nothing did, that's a real answer too — plenty of people never get one and manage perfectly well.

> **GOLD/PAUSE** — very long

---

One further, if there's room.

> **GOLD/PAUSE**

What does it feel like their having it says about you?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — two forms, one lit, and beneath both a shared line running deeper than either.

Because that's the part with the heat in it. Not that they have it. That there's a limited amount, and it went elsewhere, and something about you is why.

> **GOLD/PAUSE** — very long

And under that, usually: *I'm not the one who gets chosen.*

> **GOLD/PAUSE** — very long

I'm not telling you that's yours. If it landed, leave it there. If it didn't, that's a real answer.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

---

And the comparing — what's it protecting?

> **GOLD/PAUSE** — very long

It's keeping track of where you stand. Somewhere, knowing exactly where you stood mattered a great deal, and something in you has never stopped measuring.

> **GOLD/PAUSE**

Exhausting. Also the reason you notice things other people miss.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before we move.

> **GOLD/PAUSE**

Something will arrive behind that. Almost certainly *I'm a bad person for feeling this.*

> **GOLD/PAUSE** — very long

Put that down. If what's underneath is not being the one who gets chosen, then of course this is heavy. That isn't pettiness — it's the size of what it's touching.

> **GOLD/PAUSE** — long

And something in you was willing to look at the state people are least willing to admit to.

> **GOLD/PAUSE**

That took something.

> **GOLD/PAUSE** — very long

One more, simply true rather than comforting. Everyone has this. Almost nobody says so, which is exactly why it feels like a private defect.

> **GOLD/PAUSE** — long

---

### Rise

Step back.

Someone over there with their phone face down, breathing four and six.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Say it to them as *you*.

*You want something. That's all this is so far.*

> **GOLD/PAUSE**

No verdict in that. Nothing about whether you should want it, or whether they deserve theirs.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now — you can see where your attention has been sitting. On them, mostly. Which has never once produced anything.

> **GOLD/PAUSE**

So put it somewhere on purpose.

Not the scene where they lose something. That costs you an afternoon and changes nothing.

> **GOLD/PAUSE** — long

You, later, doing the thing that's actually yours. Where are you. What's in your hands. What are you making, or asking for, or starting.

> **GOLD/PAUSE** — long

And one small thing you'll actually do about it. Today, feeling exactly like this — not on a better day.

> **GOLD/PAUSE**

That's the difference between the two things now in there. The comparison arrived on its own. This one you picked.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing already yours. Not compared to anyone. Just yours, and here.

> **GOLD/PAUSE**

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back. Phone still face down.

The state may well still be here — it doesn't clear in one go. What's different is that it's pointing somewhere now instead of just running.

Put the rest of it down. You don't have to carry it out.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are unsteady.* The state, not the scene.
**Breathe it** — Four in, six out. Phone down. Hand to your chest.
**Stop comparing** — Ask *what was this for*, not *what's wrong with me*.
**Step out** — *You want something. That's all this is so far.*

### Back

**Recognition** — Find it in your body first: stomach turning over, heat through the chest, sometimes cold instead. Name the state in one word. Leave them out of the naming — this state arrives with a whole scene attached, and underneath the scene is a state running in a body. That's the part you can work on. The scene can wait.

**Regulation** — Four in, six out. Attention in the centre of your chest, hand there if it helps. This state pulls hard toward looking — a phone, a profile, a room. The count first. Looking after, if you still want to.

**Release** — Two things are running. The state, which turned up on its own. And the comparing — running yourself against them, again and again, in a contest nobody called. Every round gives the same result and puts you back at the start. Set down the comparing. Keep the state. Ask *what was this for* and leave it open.

**Rise** — See yourself from a distance. *You want something. That's all this is so far.* Then one concrete scene, later, doing something that's actually yours — not the scene where they lose. Then one thing already yours, uncompared.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

This is an unsettled state rather than a fully mobilised one. In the body: the stomach turning over, heat rising through the chest and face, sometimes a coldness instead, restlessness in the hands, and attention that locks onto one person and won't move off.

It has a comparing shape. Where anger moves toward and fear moves away, this one measures — you against them, repeatedly, on whatever dimension is live.

**Why Recognition leaves the other person out**

This state arrives with unusual amounts of content attached: a scene, a cast, a history, often a plausible case. That content is what makes it feel like information rather than a state.

Some of it may be accurate. But while the state and the scene are fused, working on the state feels like conceding the scene — so people stay in it. Naming the state without naming them separates the two, and the scene is still there afterwards, unchanged, to be looked at from somewhere steadier.

**Why the exhale is longer than the inhale**

You can't decide a state down. You can decide your breathing, and it's the one reachable control on a system you otherwise can't get at. Lengthening the out-breath relative to the in-breath is what shifts the system toward settled. Contact at the sternum is a related signal and one of the quickest available.

**Why Release goes after the comparing**

There's the state, and there's the comparing — running yourself against them, again and again.

Two different costs. The comparing feels like assessment, or like facing facts. But it returns the same answer every round, it doesn't finish, and each pass puts the body back where it started. Nothing comes out of it.

Setting it down isn't deciding you don't mind. It's stopping a measurement that was never going to produce a number.

The change of question does the rest. *What is wrong with me that I'm like this* asks about defect and returns answers about defect. *What was this for* asks about function — and what it usually surfaces is that the state is pointing at something wanted and unsaid. Often the other person is standing in front of the thing rather than being the thing.

**The size of it is information**

When a reaction is much larger than the event that caused it, the extra is carrying something. That's the one interpretive move this protocol makes, and it's offered as a way of looking rather than as a fact: the surplus is worth attending to, and what it turns out to be about is yours to work out.

Understanding what a response was doing is not the same as endorsing it, and it says nothing about whether your read of the situation is correct.

**Why Rise rehearses your own thing**

Rehearsing a scene where the other person loses something is rehearsing an event you don't control, and it changes nothing about your position. Rehearsing yourself doing the thing you actually want is a scene that's available. That's the one that transfers — and it's the practical form of what the third step just surfaced.

---

### What we rest on

**Shadow & individuation — C. G. Jung** · *interpretive* · informs Release

What you decline to look at keeps running unattended, and you tend to meet it as other people's faults. The usable test is proportion: when a reaction outruns the event that occasioned it, the surplus is carrying information about something other than the event. There's no finish line and nothing to complete. *Here it is the reason the size of the reaction is treated as data rather than as something to be ashamed of.*

*Offered as a lens rather than a finding, with no controlled evidence behind it. What it shows you, if anything, is yours to read — this platform will not tell you what your surplus means.*

**Compassionate Inquiry — Gabor Maté** · *clinical practice* · supplies Release and the way the question is asked

A response is treated as an adaptation rather than a defect. The kind of question you ask decides the kind of answer you get. *What is wrong with me* asks what is broken, and comes back with a list of what is broken. *What was this for* asks what it was doing, and comes back with something you can use. Understanding is not endorsement. *Here it turns a state most people are ashamed of into one they can look at directly.*

*A clinical practice, not a controlled research programme. Used here for the way the question is asked, and nothing wider.*

**Where the reading is yours** — this explains the machinery. What your jealousy is pointing at, whether your read of the situation is right, and what to do about it are readings that belong to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Phone face-down, out of reach.** Not away forever — further than an arm. The looking is a physical loop and putting distance into it interrupts the loop rather than the wanting.

**Long exhale, no ceremony.** Four in, six out, three or four cycles. Available anywhere.

**Hand to sternum.** Flat, light, centre of the chest. Warmth where the heat sits.

**Unclench the hands.** This state closes the grip quietly, without the heat that anger brings. Open them, spread the fingers, let them go soft.

**Do one thing that's yours.** Twenty minutes on the thing you'd be doing if nobody else existed. Not as a distraction — as the actual answer to what the state was pointing at.

**Walk somewhere with people in it.** A shop, a street. This state feeds on isolation and on screens, and undirected proximity to actual people interrupts both.

*Cool water on the wrists helps when the heat is the main thing.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with the state, using breath, attention and observation. It doesn't tell you whether what you suspect is happening, and it doesn't tell you what your jealousy means. It gets you steady enough to look at the situation with a system that isn't narrowed.

**Pacing**

Once through is a complete use. Use it when the state is there. If four and six is a stretch, shorten both and keep the ratio uneven.

**What people commonly notice**

Shame arriving alongside the jealousy, sometimes larger than it — this is one of the few states people are embarrassed to admit to, and the embarrassment often runs hotter than the thing itself. That's ordinary.

A strong pull to check something immediately after finishing. Worth waiting out; the protocol works better as a delay than as a preparation.

Something unrelated surfacing at the third step — an old ambition, something you gave up on. That's usually the point rather than a distraction.

**When to slow down**

If Release opens something much larger than today's situation, you can stop there and come back to the breath.

If the comparing continues right through the session and won't drop at all, end it and use the somatic activities instead. Repeating the protocol while the loop is running teaches your body that the protocol is part of the loop.

**When a person in the room is the right tool**

Contact someone — a doctor, a helpline in your country, or a person you trust — if you're checking or monitoring someone in ways you'd be uncomfortable describing out loud, if you can't be around a specific person at all, if you're using something to manage it, or if you're having thoughts of harming yourself.

**Where this affects someone else**

If the state has turned into monitoring another person — their phone, their movements, their messages, who they're with — that has crossed from a state you're managing into conduct affecting somebody else, and it's worth telling a professional rather than working on privately. That's a straightforward observation, not a judgement.

If someone is monitoring *you*, this protocol will help you stay steady and is not a way to manage them. Your safety and your privacy are separate questions from your regulation and they come first.

**Alongside other support**

If you're with a therapist, doctor or counsellor, this sits alongside that and replaces nothing.

---

## 06 · Proximity Guide
*How close to stay.*

This state usually has a live external source — a person, a rivalry, a feed. How much contact you have is real, and it's often the part you have most say over.

Three tiers. Which one yours belongs in is your read, on information nobody here has.

**Worth staying engaged with**

The comparison is uncomfortable but the contact is genuinely good for you. You'd miss them. When you've named something, it was received rather than used against you. Your reaction is roughly proportionate and settles once it's been named.

Distance isn't the tool here. Saying it is — once, plainly — and the protocol is what makes you fit to. The Invitation to Repair is written for this tier.

**Worth reducing the surface area of**

Contact reliably produces the state, and naming it changed nothing. Where your reaction consistently exceeds the event. Where you've noticed you're managing your own behaviour to look unbothered.

Reduction here is rarely dramatic. It's specific: muting rather than unfollowing, fewer occasions, not being the one who checks, a feed you stop opening at night. Reducing the surface area is a real option and isn't the same as ending anything.

This is also the tier where the surplus is worth attending to. Where the reaction is much bigger than the event, the extra is about something — and quite often not about them.

**Past what self-regulation is for**

Where someone is deliberately provoking it. Where you're being kept uncertain as a way of managing you. Where information is withheld and then produced. Where you're frightened.

That isn't a regulation problem, and treating it as one converts a situation needing other people into a private failure of coping. What it needs is a doctor, a helpline, or a friend who knows the whole picture rather than the version you can bear to tell.

**Using this**

Notice the tier. Then notice whether it's the tier you'd assign if a friend described the same thing. Where it goes next is yours — this platform doesn't tell members to leave or stay, and nobody here knows what you'd be giving up.

---

## 07 · Disclosure & Support
*A script for someone close.*

This is a hard one to say out loud, because the word itself carries a verdict. Most people would rather admit to almost anything else. Saying it plainly is most of the work.

**Saying it**
> "I've been getting jealous about something and I don't like it much. I'm telling you because carrying it privately is making it bigger, not because I want you to fix it."

**Describing what it's actually like**

> "It's physical. Stomach turns over, heat up through my chest, and my attention locks onto one thing and won't move. That all happens before I've thought anything."

> "The part that's hardest to explain is the comparing. It runs on a loop, gives the same answer every time, and I can't switch it off by deciding to."

**How to tell it's coming**

> "I go quiet in a specific way. I start checking things. I get strangely light and jokey about a subject I clearly mind about."

> "If you notice, the useful thing is direct and small — 'you've gone quiet, is this about the thing?' Being named gently takes most of the charge out of it."

**What helps**

> "Facts rather than reassurance. A specific true thing about what's actually happening lands. 'You've got nothing to worry about' bounces straight off."

> "If it's about you, telling me the thing before I find it out is worth an enormous amount. Not being surprised is most of it."

**What doesn't**

> "Being told I'm being ridiculous. I know. Knowing hasn't stopped it once, and now I've got to hide it as well as have it."

**If it's about them, and you want to say so**
> "I got jealous about something and I want to say it out loud rather than let it turn into a mood you have to work out. I'm not accusing you of anything."

**If they ask what you're doing about it**

> "There's a method I run. Four steps. First I name it as a state rather than as the whole scene it comes with. Then breathing, four in and six out, with my phone face-down. Then I stop the comparing, which is the loop that keeps it going. Then I look at it from a distance — and the useful bit is that it's usually pointing at something I want and haven't said."

*Tell one person. It can be a professional. This is the state people most reliably keep entirely private, and privacy is what lets it grow.*

---

## 08 · Invitation to Repair
*Reopening it with them.*

Send it from the far side of the protocol, not the middle. From inside the state, an invitation reads as an accusation with a question mark on the end, and gets answered as one.

**The rule that makes it sendable:** no prosecution of them, and no request that they change to manage your state. *"Can you stop being so friendly with him?"* is not an invitation. It's a request to be managed, and it will be resented even if granted.

**Sendable**
> There's something I want to say rather than carry around.
>
> I've been jealous about something, and I'd rather tell you than have it come out sideways in how I am with you. I'm not accusing you of anything and I'm not asking you to change what you're doing.
>
> I'd just rather you knew. And if there's anything you want to say back, I'd want to hear it.

**Shorter**
> I've been jealous about something and I'd rather say it than let it become a mood. Not an accusation. Just telling you.

**Where you've behaved badly with it**
> I've been checking up on you, and I don't want to be someone who does that. I'm not going to explain why, because an explanation would be a defence. I'd rather hear what it's been like from your side.

**Where it's a friend rather than a partner**
> Something's been off with me around you lately and it's mine, not yours. I've been comparing myself to you and it's made me strange. I'd rather say that than keep being slightly distant about it.

**Before sending** — read it back for a request in disguise. If the message would only be successful if they changed something, it isn't an invitation. Also look for the case: *always, never, you clearly, obviously.* Cut them.

*If they don't take it, you've done the part that was yours. Whether they meet it is theirs, and always was.*

---

## 09 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before.

Any of these, or none.

- Where did it sit in your body?
- What was the actual event? Write it plainly, without the reading attached.
- What was the comparison? On what dimension, exactly?
- Was the size of the reaction proportionate to the event? If not, how far off?
- *What was this for* — what turned up, without needing to answer it?
- What is it you want? Write it even if it seems unreasonable, even if it isn't about them at all.
- What did you say to yourself from across the room?
- Is this the same jealousy as last time, with different people in it?
- What did you write here last time? Read it back.

---

## 10 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half exits — and this one exits in ways that are unusually hard to see, because most of it is done privately.

**The specific blind spot here** — this state exits as withdrawal of warmth. Slightly less generous. Slightly slower to congratulate. A flatness when their good news comes up. From inside, each of those is you managing yourself and saying nothing. From outside, it's the person closest to your success being the one who seems least pleased about it, and they usually notice long before you do.

**The second one** — the small diminishing. The qualifying remark, the joke with an edge, the *well, they had help.* From inside it's a passing thought said out loud. From outside it's a pattern, and it's the one that damages friendships quietly over years.

**The third one, where it applies** — checking. Looking at what you weren't invited to look at. From inside it's needing to know. From outside it's a breach, and it stays a breach regardless of what you found.

**Their earlier information** — people close to you often see it before you feel it. Worth asking directly: *what do you see, before I know?*

**Naming the act, not the character** — *"I went quiet when you told me about the promotion, and I never said congratulations properly"* is ownership. *"I'm a jealous person"* is not; it names nothing, it's a verdict, and it asks them to talk you out of it.

**No because.** The want underneath is real and it doesn't belong in the sentence. It can be said afterwards, if they ask.

**No self-attack.** *"I'm horrible, I don't know why you put up with me"* hands them the job of reassuring you about the thing you did to them.

**Describe what was observable, ask about the rest.** *"I've been flat with you about your news. I'm not going to tell you what that was like — I'd rather you told me."* Then let them answer without correcting it.

**The checkable change** — this repairs by saying the good thing out loud, promptly, and by not qualifying it. *"I'm going to congratulate you properly when things go well for you"* is small, specific and immediately observable.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. If someone is deliberately provoking this state, their account of your conduct isn't a reliable one. And if the checking has become monitoring, that needs a professional rather than a repair conversation.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Measure. Know exactly where you stand.

Check the gap. Look again. Work out what they have and what that says about what you don't. Keep the running total current, because not knowing where you stand is worse.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Being left behind without noticing. Not seeing it coming. Being the one who thought things were fine.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the evenings on a phone*, or *the friendships I quietly cooled on for reasons I'd never say out loud.*

---

**What it should be attending to instead**

It isn't not comparing. You'll compare — everyone does, and pretending otherwise is how this stays private and gets bigger.

What's available is a different instruction about **what the comparison is for**.

The old one measures to establish position. The successor uses it as a pointer — if it stung, it's pointing at something you want. Then goes and does something about that instead of measuring again.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *when it stings, ask what it's pointing at, then go and do one thing about that.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *puts the phone down and does a small piece of the thing they actually want. Says out loud what they want. Doesn't look again after looking once.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Names it without flinching. Puts the phone face down. Does the smallest piece of their own thing.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
