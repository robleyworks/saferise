# t1-03 · The Overwhelm Threshold Protocol

**Label:** Reduce Load · **State:** Agitated · **Frameworks:** Porges, HeartMath · **extras:** `['advisory']`
**Resources: 9**

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Five-bar phrase. Turn at four seconds.

Before anything else — is there too much coming in right now? Noise, light, screens, people talking.

> **GOLD/PAUSE**

If there is, deal with that first. Go somewhere quieter. Turn something off. Put headphones on. That isn't skipping the practice — when too much is coming in, turning the input down *is* the practice, and everything after this works better once you have.

> **GOLD/PAUSE**

You don't have time for this. That's the state talking, and it says the same thing every time.

Nothing needs arranging. Stay where you are and we'll be quick.

This works on the state, which is the part that's actually reachable right now. Your list stays your list — sorting it is a separate job, and it goes better from the far side of this one.

---

### Recognition

Find where it is in your body, before any of the words about it.

> **GOLD/PAUSE**

Chest, usually. Tightness across the top. Sometimes the throat. Sometimes a lightness in the head, or a hum through the arms with nowhere to go.

> **BLUE/ILLUSTRATION** — many fine lines converging on one point, none resolving.

Now name the state. One word. **Agitated.**

> **GOLD/PAUSE**

Notice what that word leaves out. The list. The deadline. The person waiting. The thing you forgot.

Overwhelm feels like a fact about how much there is. In the body it's a state — and the state and the volume are two different things. Related. Not the same. They come apart.

> **GOLD/PAUSE**

Now one sorting question. It takes a second. Too much of *what*?

Too much to do — the list, the deadlines, the people waiting.

Too much coming in — noise, light, people, screens.

Or too much at once inside you — angry and frightened and sad, all live, and no way to pick one.

> **GOLD/PAUSE**

No wrong answer, and some days it's all three. The reason for asking comes at the third step.

> **GOLD/PAUSE**

And if the honest answer is *I don't know, I just can't tell what's wrong with me today* — that is a real answer, and it's the third one. Not being able to pick is what several things at once feels like from inside.

> **GOLD/PAUSE**

The load is real. Nobody's telling you it isn't. It just isn't what we're working on right now.

---

### Regulation

Four counts in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six counts out. Longer out than in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Overwhelm breathes high and fast, up at the top of the chest. We're going the other way.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the centre of your chest. Not the list.

> **GOLD/PAUSE**

The list will interrupt. That's what it does. When it does, you haven't failed at this — you've noticed, which is the whole skill. Come back to the count.

> **RED/ACTION** — feet pressed into the floor, steady, not straining.

Press your feet into the floor. Feel the floor push back.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

There's nothing you could do about any of it in the next minute anyway.

> **GOLD/PAUSE** — extended

---

One question, if there's room. If there isn't, go and do the next thing — that's the point of this one.

> **GOLD/PAUSE** — long

Still here.

> **GOLD/PAUSE**

Then — what does it feel like would happen if you dropped one?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — many converging lines, and beneath them one older line running underneath all of them.

Not what would actually happen. Usually that's survivable and you know it.

> **GOLD/PAUSE** — long

Underneath, for a lot of people, it's that dropping one would show something. That you can't do this. That you've been holding it together and the holding is the only thing keeping it up.

> **GOLD/PAUSE** — very long

And under that, sometimes: *nobody is coming, and I can't stop.*

> **GOLD/PAUSE** — very long

I'm not telling you that's yours. From outside your life nobody knows.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

And the holding-it-all-at-once — what's that protecting?

> **GOLD/PAUSE** — very long

Everything staying up. Nothing being dropped in front of anyone. It's been working, which is exactly why it won't let go.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things, quickly.

> **GOLD/PAUSE**

Something will arrive behind that — *other people manage more than this.*

> **GOLD/PAUSE** — very long

Put it down. If nobody is coming, then of course you can't put any of it down. That's arithmetic, not weakness.

> **GOLD/PAUSE** — long

And something in you stopped and looked at that on a day with no time in it.

> **GOLD/PAUSE** — very long

One more, simply true rather than comforting. Almost everyone carrying this much is doing it without saying so. You're not the exception you feel like.

---

### Release

Two things are running, and only one of them is the load.

> **GOLD/PAUSE**

The first is that there's genuinely a lot. That one's real and it isn't going anywhere.

The second is something you're doing — and which one depends on your answer a moment ago.

> **GOLD/PAUSE**

Too much to do: you're going round the list. Checking it, then checking it again, touching everything and starting nothing. Each pass tells you what you already knew.

Too much coming in: you're pushing through. Carrying on as though the noise and the light weren't landing. Holding a normal face on. Spending everything on looking fine.

Too much at once inside you: you're sorting. Trying to work out which feeling to deal with first, as though there were an order, and getting nowhere because there isn't one.

> **GOLD/PAUSE**

Different in each case. The same in the way that matters — it's the expensive one, it doesn't finish, and it's the one you can put down.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Let the amount be the amount. It isn't being denied and it isn't being minimised.

Set down the scanning. Only the scanning.

> **GOLD/PAUSE** — long

And the question. Not *what's wrong with me that I can't cope with this* — that returns nothing usable, and it may not even be the right question. The volume might be genuinely unreasonable.

**What was this for?**

> **GOLD/PAUSE** — long

The state came up because something registered as more than could be met. That's a system doing its job, loudly, with no way to reduce the input.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Don't answer it. Just have that question in the room instead of the other one.

---

### Rise

Step outside it.

Picture yourself from a little way off. Someone with a great deal on, breathing four and six.

> **BLUE/ILLUSTRATION** — figure at middle distance, converging lines now behind them rather than around them.

Speak to them as *you*.

*You have a lot on. It is a lot. And you are steadier now than when you sat down.*

> **GOLD/PAUSE**

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now forward, and small. Not the version where it's all done — that scene isn't available and building it would be a lie.

One thing. The next thing. Where are you, what's in front of you, what's the first movement you make.

> **GOLD/PAUSE** — long

Not the most important one. Not the one you're most behind on. The next one.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing already handled. Something on the pile that's done, or was never as bad as it looked, or is somebody else's now.

> **GOLD/PAUSE**

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back. Feet on the floor.

The load hasn't changed. It was never going to, and the offer was never that. What's changed is which state you approach it from — and a narrowed, scanning system is worse at this than a settled one, reliably.

Recognition. Regulation. Release. Rise.

Go and do the next thing.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

*Before you start — if too much is coming in, turn it down. Somewhere quieter, one thing off, headphones on.*

**Name it** — *You are agitated.* Too much to do, coming in, or at once inside you?
**Breathe it** — Four in, six out. Feet into the floor.
**Put down the second thing** — Not the load. Ask *what was this for*.
**Step out** — Then one thing. The next thing, not the biggest.

### Back

**Recognition** — If too much is coming in, turn it down before you start. Then find it in your body before you find words for it — usually high in the chest, sometimes the throat. Name the state in one word. Then sort it: too much to do, too much coming in, or too much at once inside you? If you can't tell what's wrong, that's the third one.

**Regulation** — Four in, six out. Overwhelm breathes high and fast; go slow and uneven. Attention in the centre of your chest. Press your feet into the floor and feel it push back. The list will interrupt — noticing that is the skill, not a failure at it. Come back to the count.

**Release** — There's the amount, which is real. And there's the thing you're doing on top of it. Too much to do: going round the list. Too much coming in: pushing through as if it weren't landing. Too much at once: trying to work out which feeling comes first. Whichever it is, it's the expensive one, it doesn't finish, and it's the one you can put down. Keep the load. Ask *what was this for* and leave it open.

**Rise** — See yourself from a distance. *You have a lot on. It is a lot.* Then one concrete scene: the next thing, not the biggest thing. Where you are, what's in front of you, the first movement. Then one thing already handled.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

Overwhelm is a mobilised state with a particular signature: mobilisation with no single target.

Fear has an object. Anger has an object. Overwhelm has a volume. The system is prepared for action and can't identify which action, so the preparation runs continuously without discharging.

In the body that's fast shallow breathing high in the chest, raised heart rate, and attention that scans rather than settles. Working memory narrows — the capacity to hold several things at once goes down. That's the part people take personally, and it's a feature of the state rather than a fact about your competence. It reverses when the state does.

**Three ways it arrives**

Overwhelm isn't one thing with one source. Three fairly different situations produce it.

**Too much to do.** Volume of tasks, demands and deadlines.

**Too much coming in.** Noise, light, screens, several people talking. This one has nothing to do with quantity of work — the input itself is more than the system can process at the rate it's arriving.

**Too much at once inside you.** Several states live simultaneously — angry and frightened and sad together. Overwhelm here isn't a separate state; it's what several of them at the same time feels like from the inside. Being unable to say what's wrong is characteristic, not a failure of self-knowledge.

The body does the same thing in all three, so the second and fourth steps don't change. What changes is the third step, because what you're doing on top of the load is different in each case — going round the list, pushing through as if the input weren't landing, or trying to sort feelings into an order they don't have.

**When too much is coming in, the breath is not the first move.** Reducing input comes first: leave the room, turn something off, put headphones on. Counting to six in a loud bright room asks the system to settle while the thing unsettling it is still arriving. That order matters, and it's the one thing on this protocol that overrides the sequence.

**Why Recognition separates the state from the load**

Overwhelm presents itself as a fact about quantity: there's too much. That framing has no handle on it, because the quantity often can't be changed today.

The volume may be genuinely unreasonable — nothing here assumes it isn't. But the state is a physiological condition running in you, and it answers to different tools than the schedule does. Naming it as a state rather than as a verdict on the day puts a handle where there wasn't one.

**Why the exhale is longer than the inhale**

You can't decide your heart rate down. You can decide your breathing, and it's the one reachable control on a system you otherwise can't get at. Lengthening the out-breath relative to the in-breath is what shifts the system toward settled — which is why a bigger breath isn't a better one. Pulling for volume recruits effort, and effort points the wrong way.

The feet into the floor do something related: a mobilised system with no target benefits from a definite physical signal, and pressure against a fixed surface is the simplest one available.

**Why Release targets the scanning**

There's the load, which is real. And there's a second thing you're doing on top of it, which differs by source.

**Going round the list.** Checking it, then checking it again, touching everything and starting nothing. Each pass tells you what you already knew: it's all still there. Nothing gets done and the list is the same length. It feels like staying on top of things. It's a circle.

**Pushing through.** Carrying on as though the noise and the light weren't landing, holding a normal expression, answering normally. That costs a great deal and none of it goes into the thing you're actually doing. It feels like coping. It's paying twice.

**Sorting.** Trying to decide which feeling to deal with first, as though there were a correct order. There isn't one, so it doesn't resolve, and the attempt keeps all of them live.

In each case the load sits there whether or not you do the second thing — and the second thing is the one that keeps your body in the state that started it.

**Why Rise goes small**

Rehearsing the completed pile is rehearsing a scene you have no route to, and the system doesn't accept it. Rehearsing the next single action is a scene that's actually available, and that's the one that transfers.

---

### What we rest on

**Polyvagal Theory — Stephen Porges** · *peer-reviewed* · supplies Recognition and the three state labels

Threat detection runs ahead of thought. The body reads a situation and moves before deliberation catches up. Porges describes three broad conditions: settled and socially available, mobilised for action, and shut down. Agitated, Unsteady and Numb are the member-facing names for those three. *Here it names mobilisation with no single target, which is why the preparation runs without discharging.*

*The anatomical premises are contested: a 2026 evaluation in* Clinical Neuropsychiatry *challenged them, with Porges replying in the same issue. The state distinctions are what this platform uses, and they hold independently of that dispute.*

**Cardiac coherence — HeartMath** · *peer-reviewed* · supplies Regulation and the count

At roughly six breath cycles a minute, heart rhythm and breath settle into a single smooth wave rather than two competing ones, close to a rhythm the body's blood-pressure regulation already runs at. Four in, six out lands near that rate. The uneven ratio is the mechanism. *Here the feet into the floor do a related job — a definite signal for a system that can't find one.*

*The finding is used here; the wider programme is not. There is no measurement of coherence anywhere on this platform and no score attached to any breath.*

**Where the reading is yours** — this explains what the body does under load. Whether your load is reasonable, and what it says about your work or the choices in front of you, is a reading that belongs to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Turn something off.** One source of input, removed. The radio, a screen, the overhead light, the notifications. The most effective thing on this list and the one people skip, because it feels too simple to count.

**Headphones, no music.** Or ear plugs. Taking the top off the noise is often enough on its own, and it's socially invisible.

**Long exhale, no ceremony.** Four in, six out, three or four cycles, eyes open, at your desk. Nobody can see you doing it.

**Feet into the floor.** Press both down steadily, feel the floor push back, hold for a slow five, release.

**One horizon.** Look at the furthest thing you can see. Overwhelm pulls focus to arm's length and holds it there; changing the focal distance changes something in the state, and it takes seconds.

**One at a time, out loud.** When several feelings are live, name them one after another rather than trying to rank them. *Angry. Frightened. Tired.* Naming them separately stops the sorting, which is the part that was costing you.

**Forearms flat on the desk.** Weight through them, shoulders dropped. Overwhelm holds the arms slightly lifted and ready, and the readiness feeds the state.

**Name three things in the room.** Something you can see, hear, and feel against your skin. This interrupts the scan by giving attention a finite set.

**Write the list down and turn the paper over.** Not to organise it — to get it out of working memory and onto a surface. It's still there. It doesn't need watching.

*Walking to a door and back also works. The point is that it finishes.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with the state that arrives under load, using breath, attention and observation. It doesn't organise your workload and doesn't claim to reduce it. It changes which state you meet it from, which matters more than it sounds — a narrowed, scanning system performs worse at exactly the work the load requires.

**Pacing**

Once through is a complete use. Use it when the state is there. If four and six is a stretch — and under load it often is — shorten both and keep the ratio uneven. Three and five works. Two and four works.

**What people commonly notice**

Restlessness during the breathing, and a strong pull to get up and start doing something. The list interrupting repeatedly — noticing that is the skill rather than a failure at it. Tiredness afterwards, sometimes sudden; mobilised states are expensive and the bill arrives when they end. Or very little change, which is an ordinary result.

**When too much is coming in**

If the source is noise, light, screens or people rather than workload, reduce the input before you do anything else. Leave the room, turn something off, put headphones on. This is the one place on this protocol where the order changes — asking the body to settle while the thing unsettling it is still arriving doesn't work, and concluding the method failed would be the wrong lesson.

If you can't leave and can't turn it down, use the somatic activities rather than the session, and come back to it later.

**When several things are live at once**

If you can't tell what's wrong, this protocol is the right place to be. It's the one that doesn't ask you to identify which state you're in before you start. You don't have to pick, and picking wasn't going to work anyway.

**When to slow down**

If the breathing itself makes things worse — lightheaded, more alarmed — stop counting and let your breath do what it does. Focusing on the breath increases alarm in some people rather than settling it. Run the protocol on Recognition and Rise alone. Three steps still works.

If sitting still is genuinely unbearable today, use the somatic activities and come back to the session later. That's a legitimate use of the protocol, not a lesser one.

**When a person in the room is the right tool**

Contact someone today — a doctor, a helpline in your country, or a person you trust — if the state isn't letting up over days rather than hours, if you've stopped sleeping, if you're unable to start anything at all rather than merely behind, if you're using something to get through the day, or if you're having thoughts of harming yourself.

**When the load itself is the thing to address**

A regulation practice helps you think clearly inside an unreasonable situation. It won't make the situation reasonable and wasn't built to. If the volume is beyond what one person can carry, the useful next moves are outside this platform — a conversation with a manager, a doctor, a union, or whoever holds the authority to change the input. The Proximity Guide goes further into that.

**Alongside other support**

If you're with a therapist, doctor or counsellor, this sits alongside that and replaces nothing. Tell them you're using it.

---

## 06 · Proximity Guide
*How close to stay.*

Overwhelm usually has an external source that keeps supplying it — a job, a caring responsibility, a household, a set of people who route things to you. How much of it you're in contact with is a real variable, and often more available than it feels from inside the state.

Three tiers. Which one your situation belongs in is your read, on information nobody here has.

**Worth staying engaged with**

Heavy but finite, and responsive when named. There's a version of the conversation you haven't had — about scope, about the deadline, about what comes off if something goes on. The volume moves when you ask for it to move.

Distance isn't the tool here. Regulation plus a specific request is, and the protocol is what makes you fit to make the request rather than absorb the load silently a fourth time.

**Worth reducing the surface area of**

The conversation has been had, more than once, and nothing changed. Your capacity is treated as the variable that flexes. Things arrive addressed to you because you've historically absorbed them rather than because they're yours.

Reduction here is rarely dramatic. It's specific: things you stop volunteering for, hours you stop being available in, a channel you leave, a standing commitment you let end, a request you answer with a date rather than a yes. Declining one thing is not a change of life.

There's also the load you've arranged for yourself, which is the harder one to see. If a reaction to being asked for something exceeds what was asked, the surplus is worth attending to — an interpretive lens rather than a finding, and what it shows you is yours to read.

**Past what self-regulation is for**

Where the volume is structurally impossible and no arrangement of your own state will meet it. Where you're held responsible for outcomes you have no authority over. Where the caring responsibility has no relief built into it and no end date. Where you're being made unwell by it.

Treating that as a regulation problem has a cost: it converts a situation that needs other people into a private failure of coping. What it needs is a doctor, a manager with actual authority, a union, a carers' service, or someone who can see the whole picture rather than the version you can bear to describe.

**Using this**

Notice the tier. Then notice whether it's the tier you'd assign if a friend described the same situation. Most people place their own load one tier lower than they'd place someone else's. Where it goes next is yours — nobody here knows what you'd be putting down.

---

## 07 · Disclosure & Support
*A script for someone close.*

Take these exactly, or change every word.

**Saying it**
> "I'm carrying more than I can comfortably hold at the moment. I'm not asking you to fix it. I just didn't want to keep pretending everything was fine."

**Describing what it's actually like**

> "It's physical. Tight across the top of my chest, breathing high and fast, and my attention won't settle on anything — it goes round the whole pile and lands on nothing."

> "The part that's hardest to explain is that I get worse at things, not just slower. I can't hold several things in my head at once when it's like this. That isn't me being careless. It comes back when the state does."

**How to tell it's coming**

> "I start doing the small easy things and avoiding the big one. I check things repeatedly. I stop finishing sentences."

> "If you see that, the useful thing isn't a suggestion — it's asking whether there's one thing you could take. Or just saying you've noticed."

**What helps**

> "Specific rather than general. If you can take one actual thing off me — not offer, take — that's worth more than a conversation about it."

> "And if there's nothing to take, just say you know. That helps too."

**What doesn't**

> "Suggestions are hard right now. It isn't that they're wrong — it's that another thing I could be doing lands as another thing on the list. If I want ideas I'll ask."

**If they ask what you're doing about it**

> "I run a method when it peaks. Four steps. First I name the state rather than the list — the load and the state are different things and separating them gives me something to work on. Then a breathing pattern, four in and six out, with my feet pressed into the floor. Then I drop the scanning, which is the loop that produces nothing. Then I look at it from a distance and pick the next single thing rather than the biggest thing."

> "It doesn't shrink the pile. It makes me better at facing it. That was the missing part."

**If it's at work and you're asking for something**

> "I'm at capacity. If this new piece comes to me, I need to know what comes off. I'm not saying no — I'm asking which."

That last sentence is the one that changes the conversation. It moves the decision to the person who owns it.

*Tell one person. It can be a doctor rather than a friend. Overwhelm carried entirely privately tends to get quietly worse, because nobody adjusts anything for a load they can't see.*

---

## 08 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before.

Any of these, or none.

- Where did it sit in your body?
- Which kind was it — too much to do, too much coming in, or too much at once inside you?
- What was on the list at the moment it peaked? Write it as it was, unsorted.
- If it was input: what was in the room? Would turning one thing off have changed it?
- When did the second thing start? Is there a point before it you can find?
- Is the volume the thing, or is it one specific item wearing the whole pile's clothes?
- *What was this for* — what turned up, without answering it?
- What did you say to yourself from across the room?
- What was the next thing you built? Did you do it?
- What's on this list because it's yours, and what's on it because you were the one who'd take it?
- What did you write here last time? Read it back.

---

## 09 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half exits — into a room, a tone, a silence — and lands somewhere you can't see from where you're standing.

**The specific blind spot here** — overwhelm exits as shortness and unavailability. Replies that answer the question and nothing else. Not asking how anyone is. Being in the room and clearly not in the room. From inside, each of those is efficiency, and it feels necessary. From outside it reads as being deprioritised, and the people closest to you absorb the most of it because they're the ones who complain least.

**The one nobody sees coming** — under load you get worse at things, not just slower. Working memory narrows and you drop details you'd normally hold. Other people experience that as carelessness about them specifically, because they don't have the state in view.

**Their earlier information** — people around you usually see the onset before you feel it. Worth asking directly: *what do you see, before I know?*

**Naming the act, not the character** — *"I've been giving you two-word answers for a fortnight"* is ownership. *"I've been useless lately"* is not; it names nothing and asks them to disagree with it.

**No because.** The load is a real reason and it still doesn't belong in the sentence. It can be said afterwards, if they ask. Attached here it converts the account into a defence.

**No self-attack.** *"I'm so sorry, I'm dropping everything, I'm a mess"* moves the burden across the table — now they're managing your distress about the thing. Self-attack is *what's wrong with me* wearing the clothes of accountability, and it returns nothing usable.

**Describe what was observable, ask about the rest.** *"I've been short with you for weeks. I'm not going to tell you what that's been like — I'd rather you told me."* The asking is how the information arrives.

**The checkable change** — overwhelm repairs by saying the true thing at the time rather than absorbing and going quiet. *"I've got nothing left today, it isn't you"* said on the day is worth more than an explanation a month later.

**Where this stops** — a reaction is information about the exterior of your state. It isn't a verdict on you, and someone else's account of you isn't automatically more accurate than your own. What you find when you look is yours to read.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Hold all of it at once. Drop nothing.

Everything stays in the air, because the moment one goes down it might not come back up. Check the list, check it again, touch everything, start nothing.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Everything staying up. Nothing being dropped in front of anyone. Being the one who has it under control.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the hours going round the list*, or *the things that got done badly because everything got some of me and nothing got enough.*

---

**What it should be attending to instead**

It isn't doing less. You may genuinely not be able to do less, and telling you to would be useless.

What's available is a different instruction about **how many at a time**.

The old one holds all of it. The successor does the next one and lets the rest wait, on the understanding that waiting isn't losing.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *one at a time, and the rest can be where they are.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *does the next thing rather than the most urgent. Writes it down and stops holding it. Finishes one before opening another.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Puts feet on the floor. Picks the next one. Doesn't look at the whole of it until that one's done.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
