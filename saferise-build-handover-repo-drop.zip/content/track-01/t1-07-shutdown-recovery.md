# t1-07 · The Shutdown Recovery Protocol

**Label:** Restore · **State:** Numb · **Frameworks:** Porges, HeartMath · **extras:** `[]`
**Resources: 8**

> **Build note.** The four steps run in the same order, but the entry differs. In a shut-down state, sustained attention is the faculty that has reduced — so Recognition is short and undemanding, and movement and contact come *before* the count rather than after it. Applies to this protocol and t1-10.

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in late, sits low throughout.
> **VOICE** — low, few words, generous pauses. Offers rather than instructs. Nothing at stake in getting it right.

You got here.

> **GOLD/PAUSE** — long

That took more than it looks like from where you are.

> **GOLD/PAUSE** — long

This one starts differently and it asks for very little. If you only do the first part, that's a complete use of it.

> **GOLD/PAUSE**

You may not feel much of any of this. That's expected here.

---

### Before we start

> **RED/ACTION** — small deliberate movement. Offered, never insisted on.

Would your toes move?

> **GOLD/PAUSE** — very long

And your fingers. One hand is plenty.

> **GOLD/PAUSE** — very long

If your feet can press into whatever's under them, let them. Not hard. Just enough to notice the floor is there.

> **GOLD/PAUSE** — very long

That's the first step done. Nothing bigger than that for a while.

---

### Recognition

One word, and we're not going hunting.

> **GOLD/PAUSE**

**Numb.**

> **GOLD/PAUSE** — very long

That's the whole step. There's no need to find where it sits — in this state that's often hard, and not finding it belongs to the state rather than to any failure of yours.

> **BLUE/ILLUSTRATION** — a still surface with movement beneath it. The surface is not the whole of it.

> **GOLD/PAUSE** — long

Numb isn't nothing, though. It's somewhere your body has moved to, and it moved there for a reason. Something is happening. Just at a level you don't have a window onto.

> **GOLD/PAUSE**

You noticed you were in it. That's the part that counted, and it's already done.

---

### Regulation

Contact, before any counting.

> **RED/ACTION** — hand to sternum, or hold the opposite arm. Offered, not instructed.

A hand on your chest. Or hold your own arm — whichever is nearer.

> **GOLD/PAUSE** — very long

Let it stay. Warmth and weight is what gets through when finer things don't.

> **GOLD/PAUSE** — long

Now the breath, and it doesn't have to be four and six today.

> **TEAL/BREATH** — in, slow
> **TEAL/BREATH** — out, longer

Longer out than in. That's the only part that matters.

> **TEAL/BREATH** — in, slow
> **TEAL/BREATH** — out, longer

The count is four and six if you want it. If counting is too much, leave it out.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

Nothing to achieve here.

---

### Release

There's the shutdown. And there's something quieter running underneath it.

> **GOLD/PAUSE** — long

You know the one. *Pathetic. Lazy. Everyone else manages.*

> **GOLD/PAUSE** — very long

Running all day, low, at a volume you've stopped hearing.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

It isn't gentler for being quiet. It's the same thing the loud states do, in a lower voice.

> **GOLD/PAUSE** — long

The state can stay. It arrived and it's not being argued with, and it isn't being ranked against how you were last month.

Put down the other one.

> **GOLD/PAUSE** — very long

And the question. Not *what's wrong with me that I can't function* — you've been asking that all week and it's given you nothing.

**What was this for?**

> **GOLD/PAUSE** — very long

Shutting down is what a body does when what's arriving is more than it can meet and pushing back isn't available. It's protection. Expensive, and protection.

> **GOLD/PAUSE** — long

Nothing needs answering today.

---

### Rise

Step back a little. Gently.

Someone sitting or lying there, hand on their chest.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Say it to them as *you*.

*You're shut down today. And you did this anyway.*

> **GOLD/PAUSE** — long

Both halves.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now something very small. Not the day you're back to yourself — that scene isn't available and I'm not going to build it for you.

One thing. Standing up. A glass of water. Opening a window.

> **GOLD/PAUSE** — very long

Small isn't a reduced version of this step. Today it's the whole of it.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And before you come back — you did this. On a day like this one. That's the whole of it and it doesn't need anything added.

> **GOLD/PAUSE** — long

Now put it down. All of it.

> **GOLD/PAUSE**

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back slowly. This state doesn't like being stood up quickly.

You may feel nothing different. That's an ordinary result here, more than anywhere else, and it doesn't mean nothing happened.

Recognition. Regulation. Release. Rise. You did all four.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

*Before you start — move something. Toes, fingers, feet into the floor. That's all it takes to begin.*

**Name it** — *You are numb.* One word. Don't go hunting for where.
**Contact, then breath** — Hand on your chest. Longer out than in. Count only if you can.
**Put down the contempt** — Not the state. Ask *what was this for*.
**One small thing** — Standing up. A glass of water.

### Back

**Move first** — Before anything else, move something small. Toes, fingers, feet pressed into the floor. In this state movement comes before attention, because attention is the part that's reduced.

**Recognition** — One word. *Numb.* Don't search for where it sits — in this state that's often hard, and not finding it is part of the state rather than a failure to look. Numb isn't nothing; it's a state your body moved into for a reason.

**Regulation** — Contact before counting. A hand on your chest, or hold your own arm. Warmth and pressure is what this state takes when it won't take much else. Then breathe, longer out than in. Four and six if you can. If counting is too much, don't count.

**Release** — Two things are running. The shutdown, and the contempt for being in it — *pathetic, lazy, everyone else manages*. That runs underneath all day and it isn't gentler for being quiet. Put down the contempt. Keep the state. Ask *what was this for* and leave it open.

**Rise** — See yourself from a distance. *You are shut down today. You did this anyway.* Then one very small thing: standing up, a glass of water, opening a window. Small isn't a lesser version of this step. Today it's the whole of it.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

Shutdown is the third of the three broad conditions the body moves between — not settled, not mobilised, but reduced. It's what a system does when what's arriving is more than it can meet and mobilising either isn't working or isn't available.

In the body: heaviness, a sense of distance from your own limbs, flattened sensation, slowed thought, and a marked drop in the capacity to start things. Sensation is muffled rather than absent, which is why locating anything precisely is hard.

None of that is nothing happening. It's something happening, at a level below deliberate access.

**Why movement comes before attention**

Every other protocol opens by asking you to find where the state sits and hold attention there. In this state, sustained attention is precisely the faculty that has reduced — so opening that way asks for the thing that's least available and produces a member who concludes they've failed at step one.

Small deliberate movement doesn't require it. Toes, fingers, feet against the floor — these are motor actions with immediate proprioceptive return, and they work whether or not attention is holding. They also confirm the body is responsive, which is information this state does not currently have.

**Why Recognition is one word here**

Naming the state is doing the same job as everywhere else: putting a small distance between you and it. But the hunt for a bodily location, which is useful in the mobilised states, tends to fail here and the failure gets read as personal.

So the step is reduced to the naming and nothing else. Not finding a location is characteristic of the state, not a shortfall in looking.

**Why contact comes before the count**

Warmth and pressure at the sternum or on the arm is a direct physical input that requires nothing of you. It registers when finer inputs don't.

The breath then does what it does everywhere — lengthening the out-breath relative to the in-breath shifts the system toward settled. The count is offered rather than required on this protocol, because in a reduced state counting can itself become a demand, and a demand is what the state has too much of already.

**Why Release goes after the contempt**

There's the shutdown, and there's the running commentary about being in it — *pathetic, lazy, everyone else manages*.

Two different costs. The commentary is quieter than the loud states' loops but it runs continuously and it doesn't clear. It also adds load to a system that entered this state because of load, which is the part that makes it more than a matter of tone.

Putting it down isn't approving of the state. It's stopping the second thing.

The change of question does the rest. *What is wrong with me that I can't function* asks about defect and returns answers about defect, and it's the question already running. *What was this for* asks about function — and what it surfaces is that reducing is protective, expensive, and a response rather than an absence of one.

**Why Rise stays small**

Rehearsing a return to normal function is rehearsing a scene there's no route to today, and the system doesn't take it. Rehearsing standing up, or a glass of water, is a scene that's actually available. That's the one that transfers, and on this protocol small is the whole step rather than a reduced version of it.

---

### What we rest on

**Polyvagal Theory — Stephen Porges** · *peer-reviewed* · supplies Recognition and the three state labels

Threat detection runs ahead of thought. The body reads a situation and moves before deliberation catches up. Porges describes three broad conditions: settled and socially available, mobilised for action, and shut down. Agitated, Unsteady and Numb are the member-facing names for those three. *This protocol works entirely in the third, and the account of shutdown as a protective response rather than a failure is where the whole approach comes from.*

*The anatomical premises are contested: a 2026 evaluation in* Clinical Neuropsychiatry *challenged them, with Porges replying in the same issue. The state distinctions are what this platform uses, and they hold independently of that dispute.*

**Cardiac coherence — HeartMath** · *peer-reviewed* · supplies Regulation and the count

At roughly six breath cycles a minute, heart rhythm and breath settle into a single smooth wave rather than two competing ones, close to a rhythm the body's blood-pressure regulation already runs at. Four in, six out lands near that rate. The uneven ratio is the mechanism. *Here the ratio is kept and the count is optional — the relationship between in and out is what does the work, not the numbers.*

*The finding is used here; the wider programme is not. There is no measurement of coherence anywhere on this platform and no score attached to any breath.*

**Where the reading is yours** — this explains the machinery. What brought this on, what it means, and what to do next are readings that belong to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

Smaller than on any other protocol, deliberately. Any one of these on its own is a complete use.

**Move one small thing.** Toes, fingers, ankles. Movement before attention, always, in this state.

**Feet into the floor.** Press down, feel it push back. Confirms the ground is there and that you're getting a return.

**Hand to sternum, or hold your own arm.** Warmth and pressure. The input this state takes when it takes little else.

**Longer out than in.** Three or four breaths. No counting required.

**Stand up.** That's the whole item. Standing is a different physiological position from sitting and this state settles into whatever position it finds.

**Open a window, or go to a door.** Air and light on skin, briefly. Nothing further required.

**Say one sentence out loud.** To anyone, or to nobody. Voice is one of the things that goes quiet first, and using it is a direct contradiction of the state.

*Warm water on the hands, held longer than necessary, is worth knowing about on the days none of the rest is available.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with a reduced state, using movement, contact, breath and observation. It doesn't ask you to be more active than you are, and it treats getting through it as a complete use.

**Pacing**

Any single part of this is a complete use. Moving your toes and stopping there counts. There is no requirement to reach the fourth step, and stopping early is not a partial anything.

**What people commonly notice**

Feeling nothing during or after, which is more common on this protocol than anywhere else on the platform and does not mean nothing happened. Heaviness increasing before it eases. Emotion arriving suddenly as the state lifts — sometimes tears, sometimes anger — which is what tends to happen when a reduced state comes up rather than a sign of something going wrong. Tiredness.

**When to slow down**

If the practice itself feels like one more demand, do a single item from the somatic list instead and leave the session. That's a correct decision, not an avoidance of one.

If emotion arrives hard as the state lifts and you're on your own with it, stop and let it be there, and consider whether there's someone you could be near.

**When this needs a person rather than a practice**

Reduced states are the ones people most often carry alone and longest, because the state itself removes the impulse to reach for anyone.

Contact someone today — a doctor, a helpline in your country, or a person you trust — if you're having thoughts of harming yourself or of not being here, if you haven't been able to eat, wash or leave the house for days, if you can't remember when this started, if you're using something to get through it, or if this has been going on for weeks rather than days.

That last one particularly. A day like this is ordinary. A month like this is a reason to see a doctor, and going is not an admission of anything.

**If you're not sure you can make the call**

Ask someone else to make it, or send a message rather than speaking. *"I need to see someone and I can't do the phone today"* sent to one person is enough, and it's a legitimate way to do it.

**Alongside other support**

If you're with a therapist, doctor or counsellor, this sits alongside that and replaces nothing. This is one of the protocols where having a person matters most.

---

## 06 · Disclosure & Support
*A script for someone close.*

This state removes the impulse to tell anyone, which is what makes it the one most worth having a script for. You can send any of these as a message rather than saying them.

**Saying it**
> "I've gone quite flat. It isn't a mood exactly — it's more that everything's got heavy and far away. I'd rather tell you than have you think I've gone cold on you."

**Describing what it's actually like**

> "It's physical. Heavy, slowed down, a bit distant from my own body. Starting anything is the hard part — not doing it, starting it."

> "The thing people misread is that it isn't sadness. It's more like the volume's been turned down on everything, including the bad stuff."

**How to tell it's coming**

> "I stop replying to things. I go still. I say I'm fine in a flat voice. I stop suggesting anything."

> "If you notice, the useful thing is specific and small — 'I'm coming round at four' rather than 'let me know if you need anything'. I won't let you know. That's the state, not me not wanting to."

**What helps**

> "Turn up. You don't have to do anything. Being in the room with me is genuinely most of it."

> "Do a small thing rather than ask what I need. Put the kettle on. Open a window. Go for a short walk with me. Decisions are the expensive part right now."

**What doesn't**

> "Being encouraged to snap out of it, or told about someone who had it worse. And big plans — anything that needs me to be organised lands as another thing I'm failing."

**If they ask what you're doing about it**

> "There's a method I run. It starts smaller than the others — move something, then just name the state, then a hand on my chest before any breathing. Then I stop the running commentary about being pathetic for being like this, which turns out to cost more than the state does. Then one very small next thing."

> "It doesn't fix it. It stops me adding to it."

**If you need someone to act**
> "I need to see a doctor and I can't face arranging it. Could you help me do that this week?"

*Tell one person. This is the state that most reliably keeps people silent, and the silence is produced by the state rather than chosen.*

---

## 07 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before.

One line is a complete entry. On this protocol especially, writing nothing is a legitimate use.

- What did you manage today? Anything at all.
- Could you find where it sat in your body, or not? Either answer is fine.
- What did the commentary say? Write the actual words it used.
- *What was this for* — anything, or nothing? Nothing is a real answer.
- What did you say to yourself from across the room?
- What was the small thing? Did you do it?
- Is anything different from yesterday? Including no.
- What did you write here last time? Read it back — without comparing today to it.

---

## 08 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half exits — and this one exits as absence, which is the hardest kind to see from inside because from inside it feels like nothing happening at all.

**The specific blind spot here** — shutdown exits as not-doing. Unanswered messages. Plans that quietly lapse. Being in the room and not in it. From inside, each is not a decision — it's the absence of the capacity to make one. From outside, the difference between *couldn't* and *didn't* is invisible, and what lands is being dropped.

**The second one** — the flat *I'm fine*. From inside it's the only available answer. From outside it's a door closing, repeatedly, on someone who keeps trying it.

**Their earlier information** — people close to you usually see it before you do, because the first signs are things you stop doing rather than things you start.

**Naming the act, not the character** — *"I didn't reply to you for three weeks and I didn't say why"* is ownership. *"I'm a waste of space"* is not; it names nothing, it's the commentary again, and it asks them to argue with it.

**No because.** And this is the protocol where the because is most true and most tempting. It still doesn't belong in the sentence. It can be said afterwards, if they ask.

**No self-attack.** On this protocol that's the whole thing, because the state's own commentary is already self-attack running all day. An apology built out of it is the state, out loud, at somebody — and it hands them the job of reassuring you about the thing you did to them.

**Describe what was observable, ask about the rest.** *"I went quiet on you for a long time. I'm not going to tell you what that was like — I'd rather you told me."* Then let them answer without correcting it.

**The checkable change** — this repairs by sending something rather than by improving. *"When I go under, I'll send you one line saying so, even if that's all I can manage"* is small, specific, observable, and doesn't require you to be different.

**Where this stops** — this resource is not an instruction to be less shut down for other people's convenience, and you don't owe anyone a better performance. If today isn't the day for this one, that's a legitimate answer — it's the resource on this protocol you can leave for as long as you need to.

---

## 12 · The Decision
*What takes over.*

Short version today. This one asks very little.

---

**What's running now**

Push through. Don't let anyone see it.

Keep going, keep the face on, and treat the not-functioning as something to be hidden rather than something happening.

It isn't a fault. It's been doing a job.

---

**What takes over**

It isn't doing more. There isn't more available today.

What's available is stopping the second job — the one where you also have to look fine.

> **One line. What should it be doing instead?**

Something like: *stop pretending, even to myself.*

Yours, if you've got one. If you haven't, leave it and come back — this one keeps.

---

**Who runs the next one**

Not who you are once this lifts. Who's in it while it's happening.

> **One thing they do, in the middle of one.**

*Says it out loud, even if only to themselves. Does one small thing. Doesn't rank today against last month.*

---

**Come back to it**

This gets rewritten and nobody arrives at it. On a day like today, having written one line is the whole of it.

*Written on your device and kept there. Nobody else sees it, and it is never measured against anything you wrote before. Because it is only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
