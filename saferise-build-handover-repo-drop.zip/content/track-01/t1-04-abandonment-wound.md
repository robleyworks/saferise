# t1-04 · The Abandonment Wound Protocol

**Label:** Repair · **State:** Agitated · **Frameworks:** Porges, Maté · **extras:** `['advisory','invitation']`
**Resources: 10** · all conditionals apply

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Five-bar phrase. Turn at four seconds.
> **VOICE** — warm and close. Stays present throughout. The tone is doing something the words are not.

There's a message you haven't had an answer to. Or a room that went quiet. Or something in how they said goodbye.

> **GOLD/PAUSE** — long

And you've been carrying it around all day like it's already been decided.

> **GOLD/PAUSE**

Nothing here is going to tell you whether you're being left. That question is real and it stays open. We're working on the state that arrived while you don't know.

---

### Recognition

Where is it sitting?

> **GOLD/PAUSE** — long

Usually low. A drop through the stomach. Sometimes a pull across the chest, or the throat closing. Sometimes a hum through all of you that won't hold still.

> **BLUE/ILLUSTRATION** — a held breath rendered as a suspended shape, not falling.

One word for it. **Agitated.**

> **GOLD/PAUSE**

Now notice something. You just described a state — and something in you did the describing.

> **GOLD/PAUSE** — long

Those aren't the same. The state is here in the room. You're the one who noticed it was here. You're already standing somewhere slightly outside it.

> **GOLD/PAUSE**

And notice what the word left out. It left out them. The message, the tone, what it probably means.

> **GOLD/PAUSE** — long

Because here's what's happened. There's a question with no answer yet, and your body has gone ahead and answered it. That's what it does with silence — it fills it, fast, so it isn't standing in an unknown.

---

### Regulation

Four counts in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six counts out.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the middle of your chest.

> **RED/ACTION** — hand to sternum, flat, light. Offered, not instructed.

A hand there, if you want one. Warmth at that spot does something on its own that nothing you think will match.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

You'll feel the pull toward the phone. Toward checking. Toward saying the thing that would settle it right now.

> **GOLD/PAUSE**

It'll still be there in a few minutes. The count first.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

### Release

There's the state. And there's the searching.

> **GOLD/PAUSE**

Going back through it. Rereading the message. Replaying the conversation, hunting for the exact moment the tone changed.

> **GOLD/PAUSE** — long

Does it ever finish?

> **GOLD/PAUSE** — long

It doesn't. Every pass finds something, and everything it finds could mean two things, so you go round again. That's not investigation. That's a circuit.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Let the state stay. It's here and nobody's arguing with it.

Put down the searching. Just that.

> **GOLD/PAUSE** — long

And the question. Not *what's wrong with me that I'm like this about people* — you've asked that one a hundred times and it has never once given you anything.

**What was this for?**

> **GOLD/PAUSE** — long

Something in you moves very fast when connection looks like it might be going. Early, hard to argue with, ahead of any thinking.

> **GOLD/PAUSE**

That's what protection looks like from the inside.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Where it learned to do that — that's not today's work, and it isn't mine to tell you.

> **GOLD/PAUSE** — very long

---

Though there's one question, if there's room for it.

> **GOLD/PAUSE**

If today is a day for getting steady and stopping there, stop there. That's complete.

> **GOLD/PAUSE** — very long

Still here.

> **GOLD/PAUSE**

Then — the silence. What does it seem to say?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — a suspended shape, and beneath it an older one in the same position.

On the surface: they're going, or they've gone off you, or something's wrong.

> **GOLD/PAUSE** — long

Underneath, for most people, it's plainer and older than that. Some version of — *I was always going to be the one left.*

> **GOLD/PAUSE** — very long

And under that, the part that makes it unbearable rather than just unwelcome: there'd be nothing you could do to stop it. It would simply happen to you.

> **GOLD/PAUSE** — very long

I'm not telling you that's yours. From outside your life nobody knows.

> **GOLD/PAUSE**

If something landed, leave it there. If nothing did, that's a real answer.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

---

And the searching — what has it been protecting?

> **GOLD/PAUSE** — very long

Not being caught out. Seeing it coming this time, so it can't arrive without warning the way it did before.

> **GOLD/PAUSE**

That's not neediness. That's an early warning system, still running, still trying to give you notice.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before we move.

> **GOLD/PAUSE**

There'll be something behind that. Usually *I'm too much*, or *nobody else needs this much reassurance.*

> **GOLD/PAUSE** — very long

Put it down. If what's underneath is being left with no say in it, then of course an unanswered message does this. Struggling with it is proportionate.

> **GOLD/PAUSE** — long

And something in you was willing to look at that while the question is still open and unanswered. That's the harder time to look.

> **GOLD/PAUSE** — very long

One more, simply true rather than comforting. Whatever you found under there, you're not the only one — this is one of the most common things there is, and almost nobody admits to it.

> **GOLD/PAUSE** — long

One thing, though, before we move.

If any of that landed, there's usually a second thing right behind it. *How did I not see this. Look how long I've been doing it.*

> **GOLD/PAUSE**

Put that down too. It's the same thing wearing a different coat. You couldn't have seen it — it was there before you had a say, and things like that don't announce themselves.

> **GOLD/PAUSE** — long

You're not late. You're here.

---

### Rise

Step outside it.

Someone across the room, phone face down, breathing four and six.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Speak to them as *you*.

*You don't know yet. And you're steady enough to not know for a while.*

> **GOLD/PAUSE** — long

That's the whole sentence. Not that it's fine. That you can stand in the not-knowing without the state deciding it on your behalf.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now forward. Not the scene where they reply — that one isn't yours to build and rehearsing it is what we just put down.

You, somewhere specific, later today, with this still unresolved. What's in your hands. What's around you. What are you doing that isn't waiting.

> **GOLD/PAUSE** — long

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing that hasn't gone anywhere. Something still here. Small.

> **GOLD/PAUSE**

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back. Feet on the floor.

You still don't know, and that was never going to change in here.

What's changed is that the state isn't answering the question for you any more.

Now put it down. All of it. You don't have to carry it out of here.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are agitated.* The state, not them.
**Breathe it** — Four in, six out. Hand to your chest. Phone down.
**Drop the search** — Not the question. Ask *what was this for*.
**Step out** — *You don't know yet, and you can not-know for a while.*

### Back

**Recognition** — Find where it sits, usually low — stomach, chest, throat. Name the state in one word. Keep them out of the naming. You've been treating an unanswered question as an answer; the body fills silence fast, so it isn't standing in an unknown. Whether the thing you fear is happening is still open.

**Regulation** — Four in, six out. Attention in the centre of your chest, hand there if it helps. This state pulls hard toward checking, and toward saying the thing that will settle it now. The count first. Everything else after.

**Release** — Two things are running. The state, which arrived on its own. And the search — rereading, going back through, finding the sentence where the tone changed. Every pass finds something and everything found is ambiguous, so the search keeps producing the state. Set down the search. Keep the question. Ask *what was this for* and leave it open.

**Rise** — See yourself from a distance. *You don't know yet, and you are steady enough to not know for a while.* Then one concrete scene later today with this still unresolved — not the scene where they reply. Then one thing that hasn't gone anywhere.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

This is a mobilised state triggered by a signal about connection rather than about physical danger. The machinery is the same: the reading happens below awareness and moves before deliberation catches up.

In the body that's a drop or pull low in the torso, raised heart rate, tightness in the chest or throat, and attention that locks onto one source and won't move off it. Sleep goes first. The pull toward checking is part of the state, not a decision inside it.

**Why an unanswered question becomes an answer**

An unresolved signal is expensive to hold. The system prefers a bad answer to no answer, because a bad answer permits a response and no answer permits nothing. So ambiguity gets closed, fast, usually in the direction the system already leans.

Recognition interrupts that by naming the state without naming the conclusion. It doesn't tell you the conclusion is wrong. It reopens the question the state had already shut.

**Why the exhale is longer than the inhale**

You can't decide your heart rate down. You can decide your breathing, and it's the one reachable control on a system you otherwise can't get at. Lengthening the out-breath relative to the in-breath is what shifts the system toward settled. A bigger breath isn't a better one — pulling for volume recruits effort, and effort points the wrong way.

Contact at the sternum is a related signal, and one of the quickest available.

**Why Release targets the search**

There's the state, and there's the search — the rereading, the going back through, the hunt for the moment it changed.

It feels like working it out. But every time you go back through it you find something, and everything you find could mean two things. So you go through it again.

You never reach the end, because there isn't one. That's the tell.

The change of question works the same way. *What is wrong with me* asks about defect and returns answers about defect. *What was this for* asks about function, and what it tends to surface is that something in you moves very fast when connection looks like it might be going — early, hard to argue with, which is what a protective response looks like from inside.

Understanding what a response was doing is not the same as knowing whether it's the right response now. It also says nothing about what's happening with this person today.

**Why Rise rehearses the unresolved version**

Rehearsing the scene where they reply is rehearsing an event you don't control, and the system doesn't accept it. Rehearsing yourself steady while it's still open is a scene that's actually available. That's the one that transfers.

---

### What we rest on

**Polyvagal Theory — Stephen Porges** · *peer-reviewed* · supplies Recognition and the three state labels

Threat detection runs ahead of thought. The body reads a situation and moves before deliberation catches up. Porges describes three broad conditions: settled and socially available, mobilised for action, and shut down. Agitated, Unsteady and Numb are the member-facing names for those three. *Here it accounts for why a signal about connection produces the same machinery as a signal about danger.*

*The anatomical premises are contested: a 2026 evaluation in* Clinical Neuropsychiatry *challenged them, with Porges replying in the same issue. The state distinctions are what this platform uses, and they hold independently of that dispute.*

**Compassionate Inquiry — Gabor Maté** · *clinical practice* · supplies Release and the way the question is asked

A response is treated as an adaptation rather than a defect — something that was doing a job, whether or not it's still the right job. The kind of question you ask decides the kind of answer you get. *What is wrong with me* asks what is broken, and comes back with a list of what is broken. *What was this for* asks what it was doing, and comes back with something you can use. *Here it is what stops the protocol becoming another round of self-interrogation.*

*A clinical practice, not a controlled research programme. Used here for the way the question is asked, and nothing wider. It makes no claim about where any pattern came from, and neither does this platform.*

**Where the reading is yours** — this explains the machinery. What your response means, where it came from, and what to do about this relationship are readings that belong to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Long exhale, no ceremony.** Four in, six out, three or four cycles. Available anywhere, eyes open.

**Hand to sternum.** Flat, light, centre of the chest. Contact and warmth there is one of the quickest signals of the settled state. Under a jacket, on a train, nobody notices.

**Phone face-down, out of reach.** Not away forever — just further than an arm. The checking is a physical loop and putting distance in it interrupts the loop rather than the wanting.

**Weight into the chair or the floor.** Press down, feel it push back, hold for a slow five. Something is holding you up and the body stops registering it unless attention is sent there.

**One thing that is still here.** Look at something in the room that was there last week and will be there next week. Not a thought exercise — an actual object, looked at.

**Walk with someone, or near someone.** A shop, a busy street, a room with other people in it. This state worsens in isolation faster than most, and undirected proximity to people helps without requiring anything of you.

*Unclenching the jaw and dropping the shoulders is always available and always creeping back.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with the state that arrives when connection looks uncertain, using breath, attention and observation. It doesn't tell you what's happening in your relationship, and it doesn't tell you whether your read is right.

**Pacing**

Once through is a complete use. Use it when the state is there. If four and six is a stretch, shorten both and keep the ratio uneven — three and five works, two and four works.

**What people commonly notice**

The pull toward the phone getting stronger before it gets weaker, particularly during Regulation. Tears at the Release step, which is an ordinary end to a mobilised state. Tiredness afterwards. The urge to send a message immediately after finishing, which is worth waiting out — the protocol works better as a delay than as a preparation.

Or very little, which is also an ordinary result.

**When to slow down**

If Release opens something much larger than today — an older loss, something from a long way back — you can stop there and come back to the breath. Surfacing isn't an instruction to follow it, and this protocol will surface things more often than most.

If the state doesn't settle at all across several attempts, that's information rather than failure, and it points toward a person rather than a practice.

**When a person in the room is the right tool**

Contact someone today — a doctor, a helpline in your country, or a person you trust — if you're having thoughts of harming yourself, if you can't eat or sleep across days rather than one night, if you're using something to get through it, or if the state is now attached to almost everyone rather than one person.

Grief and abandonment overlap, and a real loss is not a pattern to be worked on. If someone has died or has genuinely gone, that needs a different kind of support and probably a person.

**Alongside other support**

If you're with a therapist, doctor or counsellor, this sits alongside that and replaces nothing. This is one of the protocols where having a person is worth a great deal, and the practice doesn't substitute for it.

---

## 06 · Proximity Guide
*How close to stay.*

This state usually has a live external source — a specific person whose availability is the variable. How much contact you have is real, and it's the one part of the situation you have any say over.

Three tiers. Which one your situation belongs in is your read, on information nobody here has.

**Worth staying engaged with**

The uncertainty is real but the relationship can hold being asked about. There's a version of the conversation you haven't had. When you've named something, it's been received rather than punished. Their unavailability, when you've checked, has usually turned out to be about their life rather than about you.

Distance isn't the tool here. Asking is — and the protocol is what makes you fit to ask once, plainly, rather than eleven times in a way that asks them to reassure you. The Invitation to Repair on this protocol is written for this tier.

**Worth taking some distance from**

Where availability is inconsistent in a way that produces the state reliably. Where asking has been answered with irritation, or with reassurance that doesn't hold past the next day. Where you've noticed you're managing your own behaviour constantly to keep the connection level.

Distance here is rarely all-or-nothing. It's specific: not being the one who always messages first, letting a gap sit, having other people in the week, declining an occasion. Reducing the surface area is a real option and it isn't the same as ending anything.

There's also the surplus to attend to — where the reaction outruns the event repeatedly, the excess is carrying information about something other than the event. An interpretive lens rather than a finding, and what it shows you is yours to read.

**Past what self-regulation is for**

Where someone controls your access to them as a way of managing you. Where reassurance is given and withdrawn in a pattern. Where you're being isolated from other people. Where you're frightened.

That isn't a regulation problem, and treating it as one has a cost — it converts a situation that needs other people into a private failure of coping. What it needs is a doctor, a helpline, or a friend who knows the whole picture rather than the version you can bear to tell.

**Using this**

Notice the tier. Then notice whether it's the tier you'd assign if a friend described the same thing. Where it goes next is yours — this platform doesn't tell members to leave or stay, and nobody here knows what you'd be giving up.

---

## 07 · Disclosure & Support
*A script for someone close.*

Take these exactly, or change every word.

**Saying it**
> "I get a thing where I'm suddenly certain someone's pulling away, and it takes over completely. It isn't always about anything. I'd rather you knew than kept wondering what was going on with me."

**Describing what it's actually like**

> "It's physical first. Drops through my stomach, chest goes tight, and my attention locks onto one person and won't move. It happens before I've thought anything."

> "The part that's hard to explain is what silence does. An unanswered message isn't neutral to me — my body fills it in, fast, and then I'm reacting to the version it filled in rather than to anything that happened."

**How to tell it's coming**

> "I go quiet and start checking things. Or I get very light and jokey in a way that isn't quite right. I start rereading old messages."

> "If you notice, the useful thing is small and direct — 'I'm here, I'm just busy today'. A short specific sentence does more than a long reassuring one."

**What helps**

> "Say the specific thing. 'I'll message you tonight' is worth ten times 'don't worry'. My body accepts times and facts; it doesn't accept reassurance."

> "If you're going to be out of contact for a while, telling me beforehand costs you nothing and saves me a day."

**What doesn't**

> "Being told I'm overthinking. I know I am. Knowing doesn't stop it, and hearing it means I've now got to manage the state and hide it."

> "Reassurance with no specifics in it. It sounds like being handled, and it wears off in about an hour."

**If they ask what you're doing about it**

> "I run a method when it starts. Four steps. First I name the state instead of naming what I think they're doing — that reopens the question my body had already closed. Then a breathing pattern, four in and six out, with a hand on my chest. Then I stop the searching-back-through-it, which is the loop that keeps regenerating the whole thing. Then I look at it from a distance and get on with something while it's still unresolved."

> "It doesn't tell me whether I'm right. It stops my body deciding for me."

*Tell one person. It can be a professional rather than a friend. This state gets worse in isolation faster than most, and the isolation is often the thing the state itself produces.*

---

## 08 · Invitation to Repair
*Reopening it with them.*

Send it from the far side of the protocol, not the middle. Sent from inside the state, it asks them to fix how you feel — and it will be read that way and answered defensively, however carefully it's worded.

**The rule that makes it sendable:** no prosecution of them, and no request for reassurance disguised as a question. *"Are we okay?"* is not an invitation. It's a demand for a specific answer, and both of you know which one.

**Sendable**
> Hi — something's been sitting with me and I'd rather say it than carry it.
>
> I've noticed I've been reading a lot into how much we've been in touch, and I don't want to do that quietly and let it turn into something.
>
> I'm not asking you to reassure me. I'd just rather tell you than manage it on my own. If there's something on your end, I'd want to know that too.

**Shorter**
> I've been in my head about us a bit. Not asking you to fix it — just didn't want to go quiet about it.

**Where you've asked too often and you know it**
> I've been checking in a lot lately, and I think it's been landing as pressure. I'm going to stop doing that. Not going cold on you — just not making you the answer to something that's mine.

**Before sending** — read it back for a required answer. If a slow reply or a short one would land badly, it's early. An invitation with a required answer isn't one.

Also read it back for the case in disguise: *always, never, actually, you never.* Cut them.

*If they don't take it, you've done the part that was yours. Whether they meet it is theirs, and always was.*

---

## 09 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before.

Any of these, or none.

- Where did it sit in your body?
- What was the signal? Write the actual thing that happened, plainly, without the reading attached.
- What did your body fill the silence in with?
- How long between the signal and the certainty?
- What did the search find? Was any of it unambiguous?
- *What was this for* — what turned up, without answering it?
- What did you say to yourself from across the room?
- Is this the same state as last time, with a different person in it?
- What did you write here last time? Read it back. How did that one turn out?

That last one matters more here than anywhere. This state produces confident predictions, and your own record of how the previous ones landed is the only evidence you have that isn't generated by the state itself.

---

## 10 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half exits — into messages, into a tone, into what you did while you were certain — and lands on someone who has no view of what produced it.

**The specific blind spot here** — this state exits as pressure, and it doesn't feel like pressure from inside. From inside it's checking, or clarifying, or one more message. From outside it's a series of requests to be reassured, arriving faster than they can be answered, each one raising the cost of a slow reply. The other person often can't name it either. They just start feeling watched.

**The second one** — the pre-emptive withdrawal. Going cold first, to be the one who did it. From inside that's protection. From outside it's the thing you were afraid of, arriving from your side.

**Their earlier information** — the people closest to you can usually see it before you feel it. Worth asking directly: *what do you see, before I know?*

**Naming the act, not the character** — *"I sent you nine messages on Tuesday and then went silent for two days"* is ownership. *"I'm too much"* is not. It names nothing, it's a verdict on you rather than an account of anything, and it asks them to talk you out of it — which is another request for reassurance.

**No because.** The state is a real reason and it doesn't belong in the sentence. It can be said later, if they ask.

**No self-attack.** This is the protocol where self-attack is most likely to arrive dressed as accountability, and where it does the most damage — because *I'm too much, I'm sorry, I don't know why you put up with me* hands the other person the job of proving otherwise. That's the pattern, repeating inside the apology for the pattern.

**Describe what was observable, ask about the rest.** *"I've been checking in a lot. I'm not going to tell you what that's been like on your end — I'd rather you told me."* Then let them answer without correcting it.

**The checkable change** — this repairs by saying it once, plainly, and then not raising it again that day. *"I'm going to tell you when I'm in it, and then leave it with you"* is small, specific and observable.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. Someone else's account of you isn't automatically more accurate than your own — and on this protocol especially, a person who benefits from your uncertainty is not a reliable narrator of your conduct. What you find when you look is yours to read.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Watch for the going. See it coming this time.

Read the tone. Notice the gap. Check whether they replied differently to last week. Get the warning early so it can't arrive without notice.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Being left with no warning. Being the last to know. Having it happen to me again while I wasn't looking.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the evenings spent reading a message*, or *the times I made it worse by asking one more time.*

---

**What it should be attending to instead**

It isn't trusting blindly. You can't decide to do that and nobody sensible would.

What's available is a different instruction about **what counts as evidence**.

The old one reads silence as an answer. The successor waits for something that actually happened, and does something else in the meantime.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *wait for a thing they did, not a thing they didn't.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *reads the message once. Doesn't send the third one. Says what they need rather than testing whether it'll be offered.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Puts the phone somewhere else. Says the state out loud to themselves. Does one thing that isn't waiting.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
