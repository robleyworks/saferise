# t1-05 · The Shame Dissolution Protocol

**Label:** Dissolve · **State:** Unsteady · **Frameworks:** Maté, Jung · **extras:** `[]`
**Resources: 8**

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Five-bar phrase. Turn at four seconds.

This one doesn't want to be looked at. That isn't incidental — it's most of what it is.

> **GOLD/PAUSE**

So we'll go slowly, and nothing here asks you to say anything out loud, to anyone, ever.

> **GOLD/PAUSE**

---

### Recognition

Find where it sits in your body, before any of the words.

> **GOLD/PAUSE**

Face and neck, often. Heat there. A sinking through the chest. Something in the shoulders that curls forward. A wish to be smaller, which is a physical wish before it's an idea.

> **BLUE/ILLUSTRATION** — a form turning inward, not crushed. Contained, not diminished.

Now name the state. One word. **Unsteady.**

> **GOLD/PAUSE**

Notice what that word doesn't do. It doesn't agree with you. It doesn't say the verdict is correct.

Because this state arrives with a verdict already attached, and the verdict presents itself as simply true. Not *I did something bad*. Something closer to *I am the thing that's wrong*.

> **GOLD/PAUSE** — long

For now, only this: that's a state. Whatever else it is, it is first a state, running in a body, with a name.

---

### Regulation

Four counts in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six counts out. Longer out than in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the centre of your chest.

> **RED/ACTION** — hand to sternum, flat, light. Offered, not instructed.

If a hand there helps, put one there. This state pulls the body inward, and warmth at the chest is one of the few things it accepts.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Let the shoulders come back a little. Not straightening up. Just less curled.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

### Release

Two things are running.

> **GOLD/PAUSE**

There's the state. And there's the case being built against you, which has been running quietly and has been gathering evidence for a while. Old things. Things nobody else remembers. Things that weren't your fault, filed as if they were.

That prosecution is doing the expensive work. It's not investigating anything — it's confirming.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Let the state be here. It arrived, it's unpleasant, and it isn't being argued with.

Set down the case. Only the case. Not whatever real thing may be underneath it — that stays, and you can look at it later, from somewhere steadier.

> **GOLD/PAUSE** — long

And the question. You already know the other one. *What is wrong with me* — you've asked it many times and it has never once returned anything you could use. It only ever returns more of itself.

**What was this for?**

> **GOLD/PAUSE** — long

Something in you learned to go small and quiet and hidden. That's not a defect. It's a manoeuvre, and it's aimed at something — usually at not being cast out.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Things that are aimed at something were built. Which means somewhere, at some point, they got put there.

> **GOLD/PAUSE** — long

---

There's one more question, and it's a bigger one than the rest of this. You don't have to take it today.

> **GOLD/PAUSE**

If today is a day for getting steady and stopping there, stop there. Come back to the count and finish.

> **GOLD/PAUSE** — long

Still here?

> **GOLD/PAUSE**

Underneath the feeling there's usually something older. Not a memory, necessarily. More like a rule. Something you know without having been told recently.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

So — why does this one carry the weight it carries?

> **GOLD/PAUSE** — long

Something in you decided what this means about you. And it decided a long time ago, probably before you had any say in it.

> **GOLD/PAUSE** — long

Whose voice is it in.

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — a still surface. Something rising toward it, not yet broken through.

I'm not answering that one. I don't know, and anyone who says they do is selling you something.

> **GOLD/PAUSE**

If something surfaced, it's yours. Don't do anything with it yet.

> **GOLD/PAUSE** — long

If nothing came, that's a real answer too. Some of these take years. Some never arrive.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Go one further, if there's room.

> **GOLD/PAUSE**

Whatever the rule is — what does it say would happen, if people knew?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — a contained form, and beneath it a second one it has been standing over.

Not the practical answer. The one underneath.

> **GOLD/PAUSE** — long

For most people it's some version of being put outside. Not argued with, not corrected — set apart from everyone, and left there.

> **GOLD/PAUSE** — very long

That's why this one goes so deep and why it can't be reasoned with. It isn't about being wrong. It's about being cast out for it.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

And the going small — what has that been protecting?

> **GOLD/PAUSE** — very long

Exactly that. Take up less room and there's less to be found. It's the oldest defence there is against being cast out, and it works.

> **GOLD/PAUSE**

Expensive. Also entirely on your side.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

And one more thing, simply true rather than comforting. Whatever you found under there — you're not the only one. Almost nobody says it, which is the only thing that makes it feel rare.

> **GOLD/PAUSE** — very long

If it opened something bigger than today, come back to the count now and end here. Going further on your own isn't the brave version. It's just the unaccompanied one.

> **GOLD/PAUSE** — long

One more thing before we move, and this one is about you rather than about where any of it came from.

> **GOLD/PAUSE**

When something like that surfaces, a second thing usually arrives right behind it. A quiet *how did I not see that.* All those years, carrying it, and not noticing.

> **GOLD/PAUSE** — long

Put that down too. It's the same thing wearing different clothes.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

You couldn't have seen it. It was put there before you had a say in it, and the entire nature of a thing like that is that it doesn't announce itself. You carried it the way you carry your own weight — without any sense there was something to notice.

> **GOLD/PAUSE** — long

You're not late. You're here.

> **GOLD/PAUSE** — long

And there's a second one, harder to admit than the first.

> **GOLD/PAUSE**

You might not want to put it down.

> **GOLD/PAUSE** — very long

That isn't a failing and it isn't stubbornness. That thing worked. It got you through something, and whatever it has cost you since, some part of you knows exactly what would have happened without it.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

So of course there's a reluctance. You're being asked to set down the thing that kept you standing.

> **GOLD/PAUSE** — long

Here's what's actually true, and it's smaller than *let it go*.

> **GOLD/PAUSE**

It was built with what you had at the time. What you had then and what you have now aren't the same thing. You've got more room than you did, and more steadiness, and you can see a state while you're inside it — you did that a few minutes ago, at the start of this.

> **GOLD/PAUSE** — long

That part of you doesn't know any of that. Nobody told it. It's still working off the last information it got, and that information is old.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

You don't have to make it stand down. You're not being asked to, and you'd be right to refuse.

> **GOLD/PAUSE** — long

You're only being asked to notice that the person it's guarding isn't the one it started guarding.

---

### Rise

Step outside it.

See yourself from across the room. Someone sitting there, shoulders forward, breathing four and six.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Speak to them as *you*, not *I*.

*You are having a bad hour with yourself. That's what this is.*

> **GOLD/PAUSE**

Stay out there.

Notice something about the distance: from here, there's a person and there's a state, and they aren't the same object. From inside, they were the same object. That's what this state does — it fuses them.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now forward, and concrete. Later today, somewhere specific, doing something ordinary. Not a scene where you've resolved anything about yourself.

Where are you. What's in your hands. Who can see you.

> **GOLD/PAUSE** — long

Ordinary is the point. This state says you should be hidden. The scene where you're just out, doing a normal thing, in view, is the one that contradicts it — without arguing with it.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

---

Now the last part, and it's what the rest of it was for.

> **GOLD/PAUSE**

You've seen that this came from somewhere. Maybe you saw where. Maybe you only saw that it did. Either way — it wasn't chosen. Something put it there and you've been carrying it since, and nobody asked you first.

> **GOLD/PAUSE** — long

So here's what's actually available.

Not getting rid of it. That isn't on the table, and anyone offering it is lying to you.

> **GOLD/PAUSE**

But you can put something beside it that you did choose.

> **GOLD/PAUSE** — long

Not something to believe about yourself. Those don't hold — you've tried, and this state takes them apart on the spot.

Something you'll do.

> **GOLD/PAUSE**

Small enough that you'll genuinely do it today. Feeling exactly as you do now, not on a better day.

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — two marks side by side. One older and faded. One clear, newly made.

Got it? Say it to yourself once, plainly.

> **GOLD/PAUSE** — long

The old one was put in. This one you picked.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

It won't feel like much, and you'll have to pick it again tomorrow. That's what picking something means.

> **GOLD/PAUSE** — long

---

---

And one last thing before you come back.

> **GOLD/PAUSE**

Something in you brought you here today. Not the part that was hurting — the part that noticed the hurting and sat down with it anyway.

> **GOLD/PAUSE** — long

That was there the whole time, underneath all of it. It's what let you find the state, and name it, and stay while it was uncomfortable, and go one question deeper than was comfortable.

> **GOLD/PAUSE**

Nobody taught you that. It's yours, and it was yours before today.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

So just acknowledge it. Not gratitude for what happened to you — nobody is asking you for that, and anyone who does is wrong.

> **GOLD/PAUSE**

Gratitude for the thing in you that kept looking anyway.

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — an open hand. Nothing held in it, nothing taken from it.

Now put all of it down. The state. The question. The decision.

> **GOLD/PAUSE**

You don't have to carry any of it out of here. It happened, and it stays happened, whether or not you keep hold of it.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE**

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back. Feet on the floor. Shoulders where they are.

The verdict may still be here. It doesn't get overturned by a session, and nothing here was pretending it would be. What's changed is that there's a bit of space between you and it, and space is the thing it's never had.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic. On this protocol it does more than anywhere: *you* is the word that puts space between the person and the verdict.

### Front

**Name it** — *You are unsteady.* A state, not a verdict.
**Breathe it** — Four in, six out. Hand to your chest. Shoulders back a little.
**Drop the case** — Not what's underneath. Ask *what was this for*.
**Step out** — *You are having a bad hour with yourself.*

### Back

**Recognition** — Find it in your body first: heat in the face, sinking chest, shoulders curling, a physical wish to be smaller. Name the state in one word. The word doesn't agree with the verdict — this state arrives with one already attached, presenting itself as simply true. Whatever else it is, it's first a state, running in a body.

**Regulation** — Four in, six out. Attention in the centre of your chest, hand there if it helps — this state pulls the body inward and warmth at the chest is one of the few things it accepts. Let the shoulders come back a little. Not straightening. Less curled.

**Release** — Two things are running. The state, and the case being built against you, gathering old evidence, including things that weren't yours. The case isn't investigating — it's confirming. Set down the case. Keep whatever real thing is underneath; you can look at that later from somewhere steadier. Ask *what was this for*. You already know what the other question returns.

**Rise** — See yourself from across the room. *You are having a bad hour with yourself.* Notice that from out here, the person and the state are two objects. From inside they were one. Then a concrete ordinary scene later today, in view of people. Ordinary is the point.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

This is a state that pulls inward and downward rather than mobilising. In the body: heat in the face and neck, a sinking through the chest, the shoulders drawing forward, reduced eye contact, a lowered voice. The physical wish to be smaller is a real motor pattern, not a metaphor.

It has a social shape rather than a danger shape. The behaviours it produces — hiding, withdrawing, going quiet, appeasing — are the behaviours of avoiding exclusion.

**Why it arrives with a verdict**

The distinguishing feature of this state is fusion. Most states describe a situation. This one describes you — and it presents that description as an observation rather than as a symptom.

That's why arguing with it fails. You cannot reason with a state by producing counter-evidence, because the state generated the evidence in the first place and will generate more.

Recognition doesn't dispute the verdict. It names the state, which does something different and more useful: it puts the verdict inside a category. A verdict that has a category is no longer simply true.

**Why the exhale is longer than the inhale**

You can't decide your way out of a physiological state. You can decide your breathing, and it's the one reachable control. Lengthening the out-breath relative to the in-breath is what shifts the system toward settled. Contact and warmth at the sternum is a related signal and one this state accepts unusually well, because it works below the level the verdict operates at.

Opening the shoulders slightly matters for the same reason — the inward posture is part of the state's machinery, not just a sign of it.

**Why Release targets the case**

There's the state, and there's the prosecution — the accumulating case, drawing on old material, including things that weren't your responsibility.

Two different costs, and the case is the one that keeps going. It feels like being honest with yourself, or like taking responsibility.

But it never looks for anything that might let you off, and it never reaches a verdict. It isn't weighing anything up. It's only collecting.

Setting it down isn't a claim that you've done nothing wrong. Whatever real thing sits underneath stays available, and it's easier to look at from a settled state than from inside a prosecution.

The change of question is the whole of this step's design. *What is wrong with me* is the question this state already asks, constantly, and it has never returned anything usable — it returns more of itself. *What was this for* asks about function. What it tends to surface is that going small and quiet and hidden is a manoeuvre aimed at something, usually at not being cast out. Things aimed at something were built.

**Why Rise rehearses the ordinary**

Distance breaks the fusion mechanically. From outside, there's a person and there's a state, and they're two objects. From inside they were one. That separation is what the fourth step is for here, more than the future scene.

The scene itself is deliberately unremarkable. This state instructs you to be hidden; a scene of being ordinarily in view contradicts the instruction without arguing with the verdict. Rehearsing having resolved something about your worth would be rehearsing a scene you have no route to.

---

### What we rest on

**Compassionate Inquiry — Gabor Maté** · *clinical practice* · supplies Release and the way the question is asked

A response is treated as an adaptation rather than a defect — something that was doing a job, whether or not it's still the right job. The kind of question you ask decides the kind of answer you get. *What is wrong with me* asks what is broken, and comes back with a list of what is broken. *What was this for* asks what it was doing, and comes back with something you can use. Understanding is not endorsement. *Here it is the entire mechanism of the third step, because this state's native question is the defect one.*

*A clinical practice, not a controlled research programme. Used here for the way the question is asked, and nothing wider. It makes no claim about where any pattern came from, and neither does this platform.*

**Shadow & individuation — C. G. Jung** · *interpretive* · informs Release

What you decline to look at keeps running unattended. The usable test is proportion: when a reaction outruns the event that occasioned it, the surplus is carrying information about something other than the event. There's no finish line and nothing to complete. *Here it accounts for why this state attaches to small occasions — the size of the reaction is rarely about the size of the event.*

*Offered as a lens rather than a finding, with no controlled evidence behind it. What it shows you, if anything, is yours to read — this platform will not tell you what your surplus means.*

**Where the reading is yours** — this explains the machinery. What the verdict is about, where it came from, and whether any part of it is warranted are readings that belong to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Long exhale, no ceremony.** Four in, six out, three or four cycles. Available anywhere.

**Hand to sternum.** Flat, light, centre of the chest. This state pulls the body inward and accepts warmth there when it accepts very little else.

**Shoulders back a little, not straight.** Let the collarbones widen slightly. The inward posture is part of the machinery rather than a sign of it, and the correction doesn't need to be dramatic to register.

**Lift your eyes to the horizon of the room.** This state lowers the gaze. Raising it a few degrees — not staring at anyone, just looking further — changes something. Do it in a shop, a corridor, anywhere.

**Be in view, doing nothing.** Sit in a café, a park, a waiting room. No task, no performance, no requirement to speak. The instruction this state gives is *hide*; being ordinarily visible contradicts it without any argument.

**Warm water on the hands.** Slow, at a sink, longer than necessary. Warmth rather than cold on this protocol — the cold version belongs on the agitated states.

*Unclench the jaw when you notice it. It holds here as much as in anger, more quietly.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with a state that arrives with a verdict attached, using breath, attention and observation. It doesn't dispute the verdict and it doesn't confirm it. It puts space between you and it, which is the thing the state has never had.

**Pacing**

Once through is a complete use. Use it when the state is there. If four and six is a stretch, shorten both and keep the ratio uneven — three and five works, two and four works.

**What people commonly notice**

Resistance to starting at all, which is the state doing what it does. Heat in the face increasing before it settles. Tears at Release, which is ordinary. A pull to stop at Rise, because looking at yourself from outside is uncomfortable when the view is unkind — go slowly there, or stay out at the distance without describing anything.

Or very little, which is an ordinary result.

**When to slow down**

If the fourth step turns into an inventory of everything you've done wrong, stop. That's the case restarting inside the step designed to interrupt it. Come back to the breath and end there. You can run three steps.

If Release opens something much larger — something old, something you weren't looking for — you can stop and come back to the breath. Surfacing isn't an instruction to follow it, and on this protocol it will surface things more often than most.

**When a person in the room is the right tool**

Some of what this state attaches to needs another person, and no self-guided practice substitutes for that. Contact someone today — a doctor, a helpline in your country, or a person you trust — if you're having thoughts of harming yourself or punishing yourself in any way, if you can't be around people at all, if you're using something to get through it, or if the verdict is now constant rather than episodic.

If what this attaches to is something that was done to you, that is not a pattern to be managed alone. It needs a person, and it isn't a failure of this practice that it needs one.

**Alongside other support**

If you're with a therapist, doctor or counsellor, this sits alongside that and replaces nothing. This is one of the protocols where having a person is worth a great deal.

---

## 06 · Disclosure & Support
*A script for someone close.*

This is the hardest state to disclose, because disclosure is the exact thing it's built to prevent. You don't have to say much. Saying anything is the move.

**Saying it, minimally**
> "I get into a thing sometimes where I turn on myself pretty hard. I'm not asking you to talk me out of it. I just don't want to be doing it entirely in private."

**Describing what it's actually like**

> "It's physical first — heat in my face, everything sinking, wanting to be smaller. And it doesn't feel like a mood. It feels like finally seeing something true about myself. That's the part that makes it hard to argue with."

> "It usually attaches to something small. The size of the reaction has almost nothing to do with the size of the thing."

**How to tell it's coming**

> "I go quiet and stop looking at people. I start apologising for things that don't need it. I turn down plans with a reason attached."

> "If you notice, the useful thing isn't reassurance — it's just including me. 'Come anyway' does more than 'you're being hard on yourself'."

**What helps**

> "Being around you without having to talk about it. Ordinary company is genuinely the thing."

> "If you can say a specific factual thing — not 'you're great', something like 'you did the thing on Tuesday and it helped' — that lands. Compliments about who I am bounce off. Facts about what happened don't."

**What doesn't**

> "Being told I'm too hard on myself. I know. Being told makes it another thing I'm getting wrong."

> "Being asked what it's about, while it's happening. I usually can't answer that, and trying makes it worse."

**If they ask what you're doing about it**

> "I run a method when it comes. Four steps. First I name it as a state, which sounds small but it's the whole thing — this one arrives disguised as a fact about me, and calling it a state puts it in a category. Then breathing, four in and six out, with a hand on my chest. Then I stop the case I'm building against myself, which is a separate thing from whatever's actually true. Then I look at myself from across the room, and from out there the person and the verdict are two things instead of one."

*Tell one person. It can be a professional rather than a friend. This state's central instruction is to stay hidden, and telling anyone at all is the move that contradicts it.*

---

## 07 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before.

Any of these, or none. Skipping them entirely is a legitimate use of this resource, and on this protocol it's sometimes the right one.

- Where did it sit in your body?
- What was the occasion? Write the actual event, plainly, without the verdict attached.
- What did the case bring in? How old was the oldest thing on the list?
- Was any of it something that wasn't yours?
- *What was this for* — what turned up, without needing to answer it?
- What did you say to yourself from across the room? Was it something you'd say to somebody else?
- What was the ordinary scene? Did you go and be in view?
- What did you write here last time? Read it back — as if someone else wrote it.

That last instruction is deliberate. Reading your own account as though it were someone else's is the same distancing move as the fourth step, and it's usually where people first notice how they're speaking to themselves.

---

## 08 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half exits — and this one exits in a way almost nobody recognises as exiting at all.

**The specific blind spot here** — this state exits as withdrawal, and withdrawal is invisible to the person doing it. Declining the invitation. Not replying. Being present and unreachable. Leaving early. From inside, each of those is protecting other people from you. From outside, it's being shut out, repeatedly, by someone who then seems fine with everyone else.

**The second one** — the pre-emptive apology. Apologising for existing in the room, for taking time, for having asked. From inside it's manners. From outside it asks the other person to keep reassuring you that you're welcome, which is a small ongoing tax they didn't agree to and usually can't name.

**Their earlier information** — people close to you often see the onset before you feel it. Worth asking directly: *what do you see, before I know?*

**Naming the act, not the character** — this is the protocol where that distinction matters most, and where it's hardest. *"I cancelled on you three times and didn't say why"* is ownership. *"I'm a burden"* is not — it's the verdict again, wearing accountability's clothes, and it asks the other person to argue with it.

If your account of yourself is a verdict rather than an act, you haven't done accountability. You've done the state, out loud, at somebody.

**No because.** The state is a real reason and it doesn't belong in the sentence.

**No self-attack.** On every other protocol that's a guideline. Here it's the whole thing — self-attack is this state's native mode, and an apology built out of it hands the other person the job of managing your distress about yourself. Ownership is a statement about an act. It is not a verdict on you, and this protocol is where that distinction is worth the most.

**Describe what was observable, ask about the rest.** *"I've pulled back a lot lately. I'm not going to tell you what that's been like — I'd rather you told me."* Then let them answer without correcting it, and without apologising for the answer.

**The checkable change** — this repairs by showing up rather than by explaining. *"I'm going to come to the thing even when I don't want to, and I'll tell you if I need to leave early"* is small, specific and observable.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. On this protocol especially: this state will take any external information and feed it straight into the case. If that's what's happening, you're not doing this resource — you're doing the thing the third step asked you to set down. Come back to it another day.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Go small. Be unfindable.

Take up less room, say less, don't be the one anyone looks at. If there's less of you visible there's less to be found, and less to be cast out for.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Being seen as what I'm afraid I am. Being put outside. Not being argued with — just quietly set apart.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the rooms I was in and not really in*, or *the things I didn't say that would have been fine.*

---

**What it should be attending to instead**

It isn't performing confidence. That's a bigger version of hiding, and this state takes it apart in seconds.

What's available is a different instruction about **how much room to take**.

The old one contracts. The successor takes up its actual amount — not more, which would be a performance, and not less, which is what's been happening.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *take up the room I'd take up if nobody were assessing it.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *sits back in the chair. Says the thing without the apology in front of it. Stays in the conversation after saying something.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Notices the shoulders coming forward and doesn't correct it. Stays in the room. Doesn't leave early to end the exposure.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
