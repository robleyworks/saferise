# t1-10 · The Powerlessness & Despair Protocol

**Label:** Reclaim · **State:** Numb · **Frameworks:** Porges, Watts · **extras:** `['advisory']`
**Resources: 9**

> **Build note.** Numb-state entry, as t1-07: movement and contact before the count, short Recognition. `META['t1-10'].frameworks` currently reads `['porges','watts','dispenza']`. Authored against Porges and Watts. Data fix tracked as SR-098.

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in late, very low. No turn until the close.
> **VOICE** — honest, level, no brightness whatsoever. The respect is in refusing to pretend. Long pauses. Asks little.

Nothing about your situation is going to be different when we finish.

> **GOLD/PAUSE** — long

I'd rather say that at the start than have you find it out at the end.

> **GOLD/PAUSE** — long

What we can do is smaller, and it's not nothing. There are two things weighing on you, and only one of them is the situation.

---

### Before we start

> **RED/ACTION** — small deliberate movement. Offered, never insisted on.

Move your fingers. One hand. That's all this asks.

> **GOLD/PAUSE** — very long

And your feet, if they'll go. Press them into whatever's underneath.

> **GOLD/PAUSE** — very long

That happened because you decided it would. Small, and real, and yours.

> **GOLD/PAUSE**

We'll come back to it.

---

### Recognition

One word. We're not going looking for it.

> **GOLD/PAUSE**

**Numb.**

> **GOLD/PAUSE** — very long

You don't have to find where it sits. In this state that's often hard, and not finding it is part of what this is rather than a failure to look properly.

> **BLUE/ILLUSTRATION** — a wide flat horizon, one small fixed point on it. The point is not moving.

> **GOLD/PAUSE** — long

Two things are stacked here and they get treated as one thing.

There's what can't be changed.

And there's the state you're in about it.

> **GOLD/PAUSE** — long

Different things. Only one of them is within reach.

---

### Regulation

Contact first. The counting can wait.

> **RED/ACTION** — hand to sternum, or hold the opposite arm. Offered, not instructed.

A hand on your chest, or hold your own arm. Whichever is easier to arrange.

> **GOLD/PAUSE** — very long

Let it stay there. Warmth and pressure is what this state will take when it won't take much else.

> **GOLD/PAUSE** — long

Now breathe, and longer out than in. Count it if you can. Don't if you can't.

> **TEAL/BREATH** — in, slow
> **TEAL/BREATH** — out, longer
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Nothing here to get right.

> **GOLD/PAUSE** — extended

---

### Release

The situation is real. Whatever part of it genuinely can't be moved — that's real, and nobody's going to tell you otherwise, or that you haven't tried, or that there's an angle you've missed.

> **GOLD/PAUSE** — long

And then there's the other thing. The going back over how it should have gone. The version where it was different, run again.

> **GOLD/PAUSE** — long

A quarrel with something that already happened.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

That's the expensive one. And it's the only one of the two you can put down.

> **GOLD/PAUSE** — long

Which isn't the same as calling it acceptable. It probably isn't acceptable. It just happened, and it stays happened, and arguing with that is the costliest thing there is to do with a day.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

The question. Not *what's wrong with me that I can't cope* — the situation may be genuinely unbearable, and that question puts the fault in entirely the wrong place.

**What was this for?**

> **GOLD/PAUSE** — very long

Reducing is what a body does when what's arriving is more than it can meet and there's nothing to push against. It's protective. It costs a great deal, and it's protective.

> **GOLD/PAUSE**

Nothing needs answering today.

---

### Rise

Step back a little, if you can.

Someone sitting there with a hand on their chest, in the middle of something hard.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Say it to them as *you*.

*This is a lot. It isn't your fault. And you're still here.*

> **GOLD/PAUSE** — very long

No correction in that. Nothing being fixed.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now — remember your fingers moving, at the start.

> **GOLD/PAUSE**

That happened because you chose it.

> **GOLD/PAUSE** — long

Almost everything might be outside your reach right now. That was inside it.

> **GOLD/PAUSE** — very long

So — one thing later that's yours to decide. Small enough that you're certain of it. Standing up. A glass of water. A window.

> **GOLD/PAUSE** — long

Not a step toward fixing anything. Just something that's yours.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And before you come back — something in you got you here today. Not the part that's hurting. The part that noticed and sat down with it anyway.

> **GOLD/PAUSE** — long

Nobody taught you that.

> **GOLD/PAUSE**

Now put it all down. You don't have to carry any of this out of here.

> **GOLD/PAUSE**

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back slowly.

Nothing about the situation has changed. You knew that going in.

What you've got is a bit of ground, and one thing that's yours.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

*Before you start — move something. Fingers, feet into the floor. Small, and it happened because you decided it would.*

**Name it** — *You are numb.* Don't go hunting for where.
**Contact, then breath** — Hand on your chest. Longer out than in.
**Put down the quarrel** — Not the situation. Ask *what was this for*.
**One thing that's yours** — Small enough to be certain of.

### Back

**Move first** — Before anything else, move something. Fingers, feet pressed into the floor. It's small and it happened because you decided it would. That matters later.

**Recognition** — One word. *Numb.* Don't search for where it sits; not finding it is part of the state. Two things are stacked here and get treated as one: what you can't change, and the state you're in about it. They're not the same, and the second one is reachable.

**Regulation** — Contact before counting. Hand on your chest, or hold your own arm. Then longer out than in. Count if you can. Don't if you can't.

**Release** — There's what genuinely can't be moved, which is real. And there's arguing with it — going back over how it should have gone, running the version where it was different. The quarrel is the expensive one and the only one you can put down. This isn't calling the situation acceptable. It's stopping an argument with something that already happened.

**Rise** — See yourself from a distance. *This is a lot, it isn't your fault, and you're still here.* Then one thing that's yours to decide, small enough to be certain of. Not a step toward fixing anything. Then one thing that's still here.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

This is a reduced state — the third of the three broad conditions, alongside settled and mobilised. It's what a system does when what's arriving exceeds what it can meet and there's nothing available to push against.

That last part is the distinguishing feature. Mobilised states need a target. Where there isn't one — where the situation genuinely can't be moved — the system doesn't stay mobilised. It reduces.

In the body: heaviness, distance from your own limbs, flattened sensation, slowed thought, and a marked drop in the capacity to begin anything. Sensation is muffled rather than gone, which is why locating it precisely is hard.

**Why movement comes before attention**

Every other protocol opens by asking you to find where the state sits and hold attention there. Here, sustained attention is exactly what has reduced, so opening that way asks for the least available thing and produces a member who has failed at step one.

Small deliberate movement asks nothing of attention. It also does something specific on this protocol: it is a small act with a chosen cause and an immediate result, in a state whose central feature is the sense that nothing you do produces an effect. The fourth step returns to it deliberately.

**Why Recognition separates two things**

Powerlessness arrives as one object: an impossible situation and a flattened state, fused. While they're fused, working on the state looks like pretending the situation is fine, so people won't.

Naming the state separates them. The situation is what it is and this protocol makes no claim about it. The state is a physiological condition, and it answers to different tools than the situation does.

**Why contact comes before the count**

Warmth and pressure at the sternum or the arm is a direct input requiring nothing of you, and it registers when finer inputs don't. The breath follows: lengthening the out-breath relative to the in-breath is what shifts the system toward settled. The count is offered rather than required, because in a reduced state counting can itself become a demand.

**Why Release goes after the quarrel**

There's the situation, including whatever part of it genuinely can't be moved. And there's the arguing with it — going back over how it should have gone, running the version where it was different.

Two different costs. The first isn't optional. The second starts again every day, changes nothing, and is the only one you can put down.

Setting it down is not acceptance in the sense of finding the situation acceptable, and it is not agreement that it's fair. That distinction matters, because people asked to accept something usually hear that they're being asked to approve of it, and refuse — correctly. What's being put down is an argument with a fact, not the feeling about it.

The change of question does related work. *What is wrong with me that I can't cope* puts the fault in the wrong place when the situation may be genuinely unbearable. *What was this for* asks about function, and what it surfaces is that reducing is protective — expensive, and protective.

**Why Rise returns to the movement**

Rehearsing the situation resolving is rehearsing something outside your control, and the system doesn't accept it.

What's available is something small and genuinely yours. The step returns to the fingers moving at the start because that was a chosen act with an observed result — the exact thing this state reports as impossible. It isn't a step toward fixing the situation, and framing it as one would make it another failure.

---

### What we rest on

**Polyvagal Theory — Stephen Porges** · *peer-reviewed* · supplies Recognition and the three state labels

Threat detection runs ahead of thought. The body reads a situation and moves before deliberation catches up. Porges describes three broad conditions: settled and socially available, mobilised for action, and shut down. Agitated, Unsteady and Numb are the member-facing names for those three. *Here it accounts for why an unmovable situation produces reduction rather than mobilisation — mobilising needs something to push against.*

*The anatomical premises are contested: a 2026 evaluation in* Clinical Neuropsychiatry *challenged them, with Porges replying in the same issue. The state distinctions are what this platform uses, and they hold independently of that dispute.*

**Non-resistance — Alan Watts** · *interpretive* · informs why the third step says *accept*

The state is one thing. The fight with the state is a second thing. The fight usually costs more, and it is the only one of the two you can put down. Setting it down isn't passivity, isn't approval, and isn't agreement that the situation is acceptable. *Here it is the distinction the protocol turns on — the situation stays, the quarrel with the fact of it doesn't have to.*

*Watts is an interpreter rather than an originator; the older sources are Laozi and, for the framing used here, D. T. Suzuki. Offered as a lens rather than a finding.*

**Where the reading is yours** — this explains the machinery. What your situation means, what can and can't be changed in it, and what to do next are readings that belong entirely to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

Small, deliberately. Any one of these on its own is a complete use.

**Move one small thing.** Fingers, toes, ankles. A chosen act with an immediate result.

**Feet into the floor.** Press down, feel it push back.

**Hand to sternum, or hold your own arm.** Warmth and pressure. The input this state accepts when it accepts little else.

**Longer out than in.** Three or four breaths. No counting required.

**Stand up.** That's the whole item.

**One decision, any size.** Which mug. Which window. Whether to sit or lie down. The point is not the outcome; it's that you chose and something followed.

**Go outside the door and come back.** Air and light on skin. Nothing further required.

*Saying one sentence out loud, to anyone or nobody, is worth knowing about. Voice goes quiet early in this state.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with a reduced state, using movement, contact, breath and observation. It makes no claim about your situation, doesn't suggest the situation is smaller than it is, and treats getting through this as a complete use.

**Pacing**

Any single part is a complete use. Moving your fingers and stopping there counts. There's no requirement to reach the fourth step.

**What people commonly notice**

Feeling nothing during or after — common here, and it doesn't mean nothing happened. Heaviness increasing before it eases. Emotion arriving suddenly as the state lifts, sometimes tears and sometimes anger, which is what tends to happen when a reduced state comes up. Considerable tiredness.

**When to slow down**

If the practice feels like one more demand, do a single somatic item instead and leave the session. That's a correct decision.

If emotion arrives hard as the state lifts and you're on your own, stop and let it be there, and consider whether there's someone you could be near.

**Where the situation itself is the thing**

A regulation practice helps you meet an unbearable situation with a system that isn't reduced. It doesn't change the situation and was never built to. Where something can be moved — money, housing, legal, medical, work — the useful next steps are outside this platform and they involve other people. The Proximity Guide goes further into that.

**When this needs a person rather than a practice**

Reduced states are the ones people carry alone and longest, because the state removes the impulse to reach for anyone.

Contact someone today — a doctor, a helpline in your country, or a person you trust — if you're having thoughts of harming yourself or of not being here, if you feel there's no point continuing, if you haven't been able to eat, wash or leave the house for days, if you're using something to get through it, or if this has been going on for weeks rather than days.

**If you can't face making the call**

Ask someone else to make it, or send a message rather than speaking. *"I need to see someone and I can't do the phone today"* sent to one person is enough, and it's a legitimate way to do it.

**Alongside other support**

If you're with a therapist, doctor or counsellor, this sits alongside that and replaces nothing. This is one of the protocols where having a person matters most, and the practice is not a substitute for one.

---

## 06 · Proximity Guide
*How close to stay.*

This state usually has a genuine external source — a situation, a system, a person, a set of circumstances. Contact with it is often the one variable available, and often more available than it feels from inside.

Three tiers. Which one yours belongs in is your read, on information nobody here has.

**Worth staying engaged with**

Where something in the situation can still move, even a little, and engaging with it produces some return. Where the difficulty is real but the effort isn't entirely absorbed without effect. Where there's a conversation, a form, a call that hasn't been made yet.

Distance isn't the tool here. Regulation and one specific action is, and the protocol is what makes that action possible on a day like today.

**Worth reducing the surface area of**

Where contact reliably produces the state and nothing you do changes anything. Where you've been engaging for a long time with the same result. Where the situation has become something you monitor rather than something you affect — checking the news about it, rereading the letter, going back over the account.

Reduction here is specific: not checking daily, having a set time for it rather than all day, letting someone else hold a part of it. Putting something down for a period is not giving up on it.

**Past what self-regulation is for**

Where you're without money, housing, safety, care or legal standing. Where you're being harmed. Where the situation is genuinely beyond one person and has been for some time.

That isn't a regulation problem and treating it as one has a real cost — it converts a situation that needs other people and institutions into a private failure of coping. What it needs is a doctor, a lawyer, a debt or housing service, a union, a social worker, or someone who can see the whole picture rather than the version you can bear to describe.

Asking for that kind of help is not a last resort and it is not an admission of anything.

**Using this**

Notice the tier. Then notice whether it's the tier you'd assign if a friend described the same thing. People in this state place their own situation lower than they'd place someone else's, more reliably than anywhere else. Where it goes next is yours.

---

## 07 · Disclosure & Support
*A script for someone close.*

This state removes the impulse to tell anyone. Any of these can be sent as a message rather than said.

**Saying it**
> "Things are hard and I've gone quite flat about it. I'm not looking for solutions. I'd rather you knew where I am than kept guessing."

**Describing what it's actually like**

> "It's physical. Heavy, slowed down, a bit far away from myself. Starting anything is the hard part — not doing it, starting it."

> "The thing people misread is that it isn't only sadness. It's more that everything's turned down, including the parts that would normally make me do something about it."

**How to tell it's coming**

> "I stop replying. I go still. I say I'm fine in a flat voice. I stop suggesting anything or making plans."

> "If you see that, the useful thing is specific — 'I'm coming round at four' rather than 'let me know if you need anything'. I won't let you know. That's the state, not me not wanting to."

**What helps**

> "Turn up. You don't have to do or say anything. Being in the room is most of it."

> "Do a small thing rather than ask what I need. Decisions are the expensive part right now."

> "If you want to help with the actual situation, ask for one specific job rather than offering generally. 'Give me the letter and I'll ring them' is something I can say yes to."

**What doesn't**

> "Silver linings, or being told it'll work out. I can't tell whether it will and neither can you, and hearing it means I've got to manage your optimism as well."

> "Being told about someone who had it worse."

**If they ask what you're doing about it**

> "There's a method I run. It starts small — move something, name the state, hand on my chest before any breathing. Then I stop arguing with the part that can't be changed, which is different from being fine about it. Then one small thing that's actually mine to decide."

> "It doesn't change the situation. It stops me adding to it."

**If you need someone to act**
> "I need to see a doctor and I can't face arranging it. Could you help me do that this week?"

*Tell one person. This is the state that most reliably keeps people silent, and the silence is produced by the state rather than chosen.*

---

## 08 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before.

One line is a complete entry. Writing nothing is a legitimate use.

- What did you manage today? Anything at all.
- What's the part that genuinely can't be moved? Write it plainly.
- Is there any part of it that could move, even slightly? Including no.
- What did the quarrel sound like today? Write the sentence it used.
- *What was this for* — anything, or nothing? Nothing is a real answer.
- What did you say to yourself from across the room?
- What was the one thing that was yours? Did you do it?
- What did you write here last time? Read it back — without comparing today to it.

---

## 09 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half exits as absence, which is the hardest kind to see from inside because from inside it feels like nothing happening at all.

**The specific blind spot here** — this exits as not-doing. Messages unanswered, plans lapsed, things left. From inside each is not a decision but the absence of the capacity to make one. From outside, the difference between *couldn't* and *didn't* is invisible, and what lands is being dropped.

**The second one** — the flatness in the face of other people's news, good or bad. From inside there's nothing available to respond with. From outside it reads as not caring, particularly to the people who've been carrying you.

**The third one** — the people around you are often carrying the situation too, and doing so in a state you can't currently see. Not being able to ask how they are is characteristic. Not knowing that it lands is the blind spot.

**Their earlier information** — people close to you usually see it before you do, because the first signs are things you stop doing.

**Naming the act, not the character** — *"I haven't asked how you are in weeks"* is ownership. *"I'm dead weight"* is not; it names nothing, it's the commentary again, and it asks them to argue with it.

**No because.** On this protocol the because is enormous and everybody already knows it, and it still doesn't belong in the sentence.

**No self-attack.** This is the whole thing here, because the commentary is already running all day. An apology built out of it is the state, out loud, at somebody — and it hands them the job of reassuring you about the thing you did to them.

**Describe what was observable, ask about the rest.** *"I've been gone for a long time. I'm not going to tell you what that's been like for you — I'd rather you told me."*

**The checkable change** — this repairs by sending something rather than by improving. *"When I'm under, I'll send you one line saying so, even if that's all I can manage"* is small, specific, observable, and doesn't ask you to be different.

**Where this stops** — this is not an instruction to be less flattened for other people's convenience, and you don't owe anyone a better performance while you're in the middle of something hard. If today isn't the day for this one, that's a legitimate answer — it's the resource here you can leave for as long as you need to.

---

## 12 · The Decision
*What takes over.*

Short version today. This one asks very little.

---

**What's running now**

Go over it again. Find the version where it went differently.

Run it back. Look for the point it turned, the thing that could have been done, the way out that was there and got missed.

It isn't a fault. It's been doing a job.

---

**What takes over**

It isn't accepting the situation. It may well be unacceptable and nothing here says otherwise.

What's available is stopping the argument with something that already happened.

> **One line. What should it be doing instead?**

Something like: *stop running the other version.*

Yours, if you've got one. If you haven't, leave it and come back — this one keeps.

---

**Who runs the next one**

Not who you are once this lifts. Who's in it while it's happening.

> **One thing they do, in the middle of one.**

*Moves one thing. Decides one small thing that's theirs. Doesn't go back over it.*

---

**Come back to it**

This gets rewritten and nobody arrives at it. On a day like today, having written one line is the whole of it.

*Written on your device and kept there. Nobody else sees it, and it is never measured against anything you wrote before. Because it is only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
