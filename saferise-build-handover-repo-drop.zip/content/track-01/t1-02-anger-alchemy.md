# t1-02 · The Anger Alchemy Protocol

**Label:** Transmute · **State:** Agitated · **Frameworks:** Porges, Maté · **extras:** `['advisory','invitation']`
**Resources: 9** · *reference build at house sizes*

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in late, under the third line. 90 BPM, 3/4. Sits low throughout.

Something got crossed.

> **GOLD/PAUSE**

That's what this is. Not a mood, not a bad day — a line, and something went over it.

> **GOLD/PAUSE**

This one doesn't begin with settling. Anger doesn't settle on request, and asking it to is how these things fail in the first ten seconds. Keep moving if you're moving. Stay still if you're still.

> **GOLD/PAUSE**

Here's what we're doing. Your position stays exactly where you're holding it. Nobody is going to talk you round.

---

### Recognition

Your body registered that before you'd finished deciding what you thought about it.

> **BLUE/ILLUSTRATION** — a line, drawn firm. Something has passed over it.

So — where is it. Jaw. Hands. The back of the neck. Heat across the face.

> **GOLD/PAUSE**

Find it, and then say one word to yourself.

**Agitated.**

> **GOLD/PAUSE** — long

Now notice what that word left out. It left out them. Their name, their face, what they said, and the whole argument you've got assembled and ready.

That isn't because the argument is wrong. You may be completely right, and it will be just as right afterwards, with all of it intact.

> **GOLD/PAUSE**

It's because there are two things in you right now and only one of them can be worked on. The case is going nowhere. The state is here, in your hands and your jaw, and that one moves.

---

### Regulation

Four counts in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six out. Longer out than in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Your breath wants to go short and sharp. Let it want that. Go the other way anyway.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **RED/ACTION** — hands unclench. Offered, not instructed.

Your hands are closed. Open them. Fingers wide, then loose.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the middle of your chest. Not the jaw — the jaw will hold on to it. The chest.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

It'll come up before it goes down. That's normal here and it's not a sign this isn't working.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — extended

---

### Release

Now. The conversation in your head.

> **GOLD/PAUSE**

You know the one. You say the thing, they answer, you answer better. And you've run it — what, four times? Five?

> **GOLD/PAUSE** — long

Notice something about it. You win it. Every single time.

> **GOLD/PAUSE**

That's not you being unfair. The part of you writing that conversation is on your side — that's its entire job — so of course it hands you the better lines. It was never going to do anything else.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And every run puts your body back where it started. You've been re-lighting yourself all afternoon.

> **GOLD/PAUSE** — long

So: the anger stays. It's yours, it's earned, nobody's taking it.

Put down the rerun. Only the rerun.

> **GOLD/PAUSE** — long

And one different question, in place of the one you've been asking.

Not *what's wrong with me.*

**What was this for?**

> **GOLD/PAUSE** — long

Anger goes toward things. That's what makes it different from fear — fear backs away, this walks at it. It turns up where something's being crossed and it gets you upright to meet it.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

On its own terms, it did its job.

Understanding that doesn't let anybody off. It doesn't drop a single thing you're holding.

> **GOLD/PAUSE** — long

One more, and it's the harder one to admit.

> **GOLD/PAUSE**

You might not want to put this down.

> **GOLD/PAUSE** — long

Fair enough. It works. It's the thing that stops you being walked over, and some part of you knows exactly what happens on the days you haven't got it.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

So here's the smaller true thing. It was built with what you had then. What you had then and what you've got now aren't the same — you can see a state while you're standing in it, and you did that a moment ago, at the top of this.

> **GOLD/PAUSE** — long

That part of you doesn't know. Nobody told it. It's working off old information.

> **GOLD/PAUSE**

Nobody's asking you to stand it down. You'd be right to refuse. Only to notice that the person it's guarding isn't the one it started guarding.

> **GOLD/PAUSE** — very long

---

One more thing, if there's room for it. If there isn't, go and have the conversation — you're steadier than you were.

> **GOLD/PAUSE** — long

Still here.

> **GOLD/PAUSE**

Then — the line that got crossed. Why that one?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — a firm line with something over it, and beneath it an older line in the same place.

Because there are things people do to you that you shrug off, and this wasn't one of them.

> **GOLD/PAUSE** — long

What does this particular line have on it?

> **GOLD/PAUSE** — very long

For a lot of people it's some version of being taken for granted. Or spoken over. Or treated as though what they want is the least important thing in the room.

> **GOLD/PAUSE** — very long

And under that, often, the part that puts the heat in it — *it will keep happening, and there's nothing I can do to stop it.*

> **GOLD/PAUSE** — very long

I'm not telling you which is yours. From outside your life nobody knows.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before we move.

> **GOLD/PAUSE**

Something will be arriving behind that — usually *I overreacted*, or its opposite, *no, I was completely justified.*

> **GOLD/PAUSE** — very long

Put both down. If what's underneath is being overlooked and having no say in it, then of course the reaction was that size. That isn't overreacting. It's the weight of what got touched.

> **GOLD/PAUSE** — long

And something in you looked at that while still angry, which is much harder than looking afterwards.

> **GOLD/PAUSE** — very long

One more, simply true rather than comforting. Almost nobody gets to say the thing at the time. That's why so many people are walking around with a version of this, and why so few of them mention it.

> **GOLD/PAUSE** — very long

None of that changes what they did. You're still right. You just know what the size of it is made of now.

> **GOLD/PAUSE**

---

### Rise

Now step back from it.

Somebody across the room. Standing, jaw set, running a conversation for the sixth time.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Say it to them as *you*.

*You are angry. You have a reason.*

> **GOLD/PAUSE** — long

Both halves stay. Neither one takes anything off the other.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now something later today. Not the confrontation where you win — you've already had that one, five times, and it cost you the afternoon.

The one where you're steady and it still matters to you just as much.

> **GOLD/PAUSE**

Where are you standing. What's your voice doing. What are the actual first words — not the gist of them, the words.

> **GOLD/PAUSE** — long

And what do your hands do while you say it.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

One more thing before you come back. Something already true, and small, and nothing to do with any of this. Not gratitude about the situation — that would be a stupid thing to ask of you.

> **GOLD/PAUSE**

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Feet on the floor. Hands open.

The anger may well still be here. If it is, that's right — it was never what we were going after.

What's different is that you've got a decision to make now, instead of a loop to run. And you'll make it from here rather than from where you were standing.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic.

### Front

**Name it** — *You are agitated.* The state, not the case.
**Breathe it** — Four in, six out. Hands open.
**Drop the rerun** — Not the position. Ask *what was this for*.
**Step out** — *You are angry, and you have a reason.*

### Back

**Recognition** — Find it in your body before you find words for it. Jaw, hands, neck, chest. Name the state in one word. Keep who and what they did out of it — you can be entirely right and this step still isn't about that. The case waits. It doesn't spoil.

**Regulation** — Four in, six out. Anger wants short and sharp; go the other way. Attention in the centre of your chest, not the jaw or the hands. Open your hands. If it rises before it settles, keep counting.

**Release** — Two things are running. The anger, which arrived on its own. And the rerun, where you get the line right. The rerun is the expensive one and the one you have a say in. Set down the rerun. Keep the anger. Keep the position. Ask *what was this for* and leave it open.

**Rise** — See yourself from a distance. *You are angry, and you have a reason.* Both. Then one concrete scene: your actual words, your voice, your hands. Not the version where you win.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

Anger is a mobilised state with a feature that distinguishes it from fear: it moves toward rather than away. Fear pulls you back from the thing. Anger sends you at it.

In the body — raised heart rate, blood toward the large muscles and the hands, faster shallower breathing, heat in the face and chest, tension gathering in jaw and grip. Attention narrows onto the source and holds there. That narrowing is the point of the state: it stops you being distracted from what it has identified as needing dealing with.

All of it happens before you have decided anything.

**Why Recognition leaves the person out**

Two things arrive fused — a physiological condition, and an evaluation of what happened. The evaluation may be entirely accurate. But while they are welded, settling the body feels like conceding the position, which is why people stay lit. Splitting them lets you bring the state down without giving up anything, then look at the case with a system that is no longer narrowed.

**Why the exhale is longer than the inhale**

You cannot decide your heart rate down. You can decide your breathing, and it is the one reachable control on a system that otherwise runs without consulting you. Anger pushes toward the opposite pattern — short in, hard out, or held breath entirely. Going deliberately against that pattern is most of this step.

**Why Release targets the rerun**

The anger turned up once. The argument in your head is a different thing — you're running that one, again and again, getting your line better each time.

It feels like getting ready. It isn't. Nothing comes out of it, and every run puts your body back where it started.

**Why Rise uses distance before it uses the future**

Distance does what intensity alone will not. The forward scene then has to be concrete: detail transfers, general intention does not.

---

### What we rest on

**Polyvagal Theory — Stephen Porges** · *peer-reviewed* · supplies Recognition and the three state labels

Threat detection runs ahead of thought. The body reads a situation and moves before deliberation catches up, which is what makes the response fast and also what makes it non-negotiable in the moment. Porges describes three broad conditions: settled and socially available, mobilised for action, and shut down. Agitated, Unsteady and Numb are the member-facing names for those three. *Here it distinguishes anger from fear — both are mobilised, but anger moves toward rather than away.*

*The anatomical premises are contested: a 2026 evaluation in* Clinical Neuropsychiatry *challenged them, with Porges replying in the same issue. The state distinctions are what this platform uses, and they hold independently of that dispute.*

**Compassionate Inquiry — Gabor Maté** · *clinical practice* · supplies Release and the way the question is asked

A response is treated as an adaptation rather than a defect — something that was doing a job, whether or not it is still the right job. The kind of question you ask decides the kind of answer you get. *What is wrong with me* asks what is broken, and comes back with a list of what is broken. *What was this for* asks what it was doing, and comes back with something you can use. Understanding is not endorsement, of the response or of anyone's behaviour. *Here it is what lets you understand what the anger was protecting without dropping the charge.*

*A clinical practice, not a controlled research programme. Used here for the way the question is asked, and nothing wider.*

**Where the reading is yours** — this explains the machinery. What your anger means, and what to do about it, is a reading that belongs to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Open the hands.** Spread the fingers wide, hold, let them go soft. Anger closes the grip constantly, which gives you constant chances.

**Unclench the jaw.** Teeth apart, tongue off the roof of the mouth, lower face heavy. It creeps back quickly. Do it again.

**Push against something immovable.** Palms flat to a wall or the underside of a desk. Steady firm pressure for a slow five, then release completely and let the arms hang.

**Walk it, with a destination.** Anger is an approach state — give it approach. A specific door, a specific corner, brisk. Arrive. Stop. Then breathe.

**Shoulders down and back.** Blades gently together, then sliding down away from the ears. Anger rides high in the shoulders and the position feeds it.

**Say it out loud, once, alone.** The actual thing you want to say. Once is discharge. Twice is rehearsal, which is what the protocol asks you to set down.

*Four in, six out is always available — eyes open, in the room, nobody watching.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with anger while it is present, using breath, attention and observation. Leaves your position, your grievance and your judgement of what happened intact.

**Pacing**

Once through is a complete use. Use it when the state is there. If four and six is a stretch, shorten both and keep the ratio uneven — three and five works, two and four works. The relationship between the counts is the mechanism, not the specific numbers.

**What people commonly notice**

Anger rising rather than falling during the breathing, particularly early on. Heat becoming more noticeable before it becomes less. Tiredness afterwards, sometimes considerable — mobilised states are expensive and the bill arrives when they end. Tears, in some people, which surprises them and means nothing in particular. Or very little, which is also an ordinary result.

**When to slow down**

If Release opens something much larger than today's anger, you can stop there and come back to the breath. Surfacing is not an instruction to follow it.

If working with the anger makes you feel you might act on it, stop and change your physical situation instead. Leave the room. Go outside. The protocol is not the priority in that moment.

**Where violence is anywhere in the picture**

If your anger has become violent — if you have hurt someone, damaged things, or you are worried you might — that needs a person rather than a protocol, and it needs one now. Speak to a doctor, or to a helpline for people concerned about their own behaviour. Most countries have one and it exists for exactly this call. Making it is not an admission of anything and it is the single most effective move available.

If someone is being violent toward you, this protocol is a way to steady yourself in it. It is not a way to manage them, and it is not a substitute for getting out of range. Your safety is a separate question from your regulation and it comes first.

**When a person in the room is the right tool**

Contact someone today — a doctor, a helpline in your country, or a person you trust — if you are frightening yourself with the intensity of it, if anger is arriving with no identifiable trigger and staying for days, if you are using something to manage it, or if you are having thoughts of harming yourself.

**Alongside other support**

If you are with a therapist, doctor or counsellor, this sits alongside that and replaces nothing. Tell them you are using it.

---

## 06 · Proximity Guide
*How close to stay.*

Some anger has a live external source that keeps supplying it. Where that is the case, how much contact you have is a real variable — and one you have more say over than you have over the state.

Three tiers. Which one anything belongs in is your read, on information nobody here has.

**Worth staying engaged with**

The difficulty is real but the relationship can hold it. There is a version of the conversation you have not yet had. Behaviour changes when it is named. Your anger tends to be proportionate to the event and settles once the event is dealt with.

Distance is not the tool here. The conversation is, and the protocol is what makes you fit to have it. The Invitation to Repair on this protocol is written for exactly this tier.

**Worth taking some distance from**

Contact reliably produces the state, and the conversation has been had more than once without changing anything. Your anger consistently exceeds the event.

That surplus is worth attending to — when a reaction outruns its occasion, the excess is carrying information about something other than the event. An interpretive lens rather than a finding, and what it shows you is yours to read.

Distance here is rarely all-or-nothing. More often it is specific: fewer occasions, shorter ones, ones you can leave, ones with other people present, topics you decline. Reducing the surface area is a real option and it is not the same as ending anything.

**Past what self-regulation is for**

Where you are being threatened, intimidated, controlled or harmed. Where you are frightened of someone.

This is not a regulation problem, and treating it as one has a cost. A practice will help you think clearly inside it and will not change it. What this needs is other people — a doctor, a lawyer, a union, a helpline, a friend who knows the whole picture rather than the version you can bear to tell.

**Using this**

Notice the tier. Then notice whether it is the tier you would assign if a friend described the same thing. That is the exercise. Where it goes next is yours — nobody here knows what you would be giving up.

---

## 07 · Disclosure & Support
*A script for someone close.*

Take these exactly, or change every word.

**Saying it**
> "I've been carrying a lot of anger lately. Not at you. I'd rather you knew what you were seeing than guessed at it."

**Describing what it's actually like**

Most people can name the mood and not the body, so the other person hears a complaint rather than a description. The body is the part that makes it land.

> "It's physical before it's anything else. My jaw goes tight, my hands close up, there's heat across my chest and face. My attention narrows down onto one thing and won't move off it. That's all happening before I've decided anything about it."

> "The bit that's hardest to explain is the loop. I end up running the same argument in my head over and over, getting my line better each time. It feels like I'm preparing. I'm not — I'm just putting myself back through it."

**How to tell it's coming**

Worth saying out loud, because the other person often sees the early signs before you feel them.

> "There are signs before it arrives. My replies get shorter. I stop asking you things. I go quiet in a way that isn't relaxed. My jaw sets and I start moving faster than the situation needs."

> "If you spot that and say something simple — not 'what's wrong', just 'you've gone quiet, do you want a minute' — that's usually enough to catch it. Earlier is much easier than later."

**What helps while it's happening**

> "A bit of room, without it becoming a thing. If I go outside for a bit, I'm not storming off — I'm doing something that works. I'll come back."

> "Stay nearby without needing it to be a conversation. Being in the same room, doing something else, is genuinely better than being asked about it."

> "If you want to offer something concrete — a walk, going outside, getting out of the room we're in — say the specific thing rather than asking what I need. I usually can't answer that one while it's happening."

**What doesn't**

> "Being told to calm down does the opposite, every time. And being asked what's wrong while it's still happening — I can't answer that yet, but I can afterwards, and I will."

> "Following me into the other room. If I've taken myself out of the room, that's the method working, not me shutting you out."

**When the anger is about them**
> "I'm angry with you about something. I don't want to get into it while I'm still this lit, because I'll say it badly and then we'll be dealing with how I said it. Can we do it tomorrow? I'm not going anywhere."

**If they ask what you're doing about it**

The honest version is more reassuring than the vague one, because it describes something with parts rather than an intention.

> "I've got a method I run when it starts. Four steps. First I name the state instead of the argument — that separates my body being lit from whether I'm right about the thing. Then a breathing pattern, four counts in and six out, which is the part that actually brings the physical side down. Then I stop replaying the argument, without dropping my position on it. Then I look at the whole thing from a bit of distance and work out what I'm actually going to do."

> "It doesn't make me not angry. It makes me able to decide what to do about being angry. That was the part I was missing."

> "There's more than the session. I've got a card I keep on me with the four steps for when there's no time to think. A few physical things for the days in between — opening my hands, unclenching my jaw, walking somewhere with a purpose. And something I write in afterwards, which is mostly how I've noticed the loop is the same one every time."

**If someone is frightened of you**

No script for this one. Say the true thing plainly, do not explain it, then get a professional involved:
> "I've frightened you. I'm sorry. I'm going to get proper help with this, not just manage it myself."

Then do that, today.

*Tell one person. It can be a professional rather than a friend. Anger kept entirely private finds its own exits, and the exits it finds are worse than the telling.*

---

## 08 · Invitation to Repair
*Reopening it with them.*

Send it from the far side of the protocol, not the middle. An invitation written from inside the state reads as an opening move in a case, and gets answered as one.

**The rule that makes it sendable:** no prosecution of them. Not a soft one either — no *I've been reflecting and I've realised what you did*. The moment it contains a charge it stops being an invitation, and they will read it correctly and defend accordingly. You are not conceding by leaving the charge out. You are declining to open with it.

**Sendable**
> Hi — I've been sitting with what happened and I don't want to leave it where it is.
>
> I'm not writing to relitigate it. I've got my version and I imagine you've got yours, and I don't think trading them gets us anywhere useful.
>
> What I'd like is to talk, without either of us arriving with a position. No rush and no pressure. If you'd rather not, or not yet, I'll take that.

**Shorter**
> I don't want to leave this where it is. Can we talk — not to settle who was right, just to talk?

**Where you did the damage**
> I've been thinking about how I was with you. I'm not going to explain it, because an explanation is a defence and that isn't what I want to hand you. I'd like to hear what it was like on your end, and to say sorry properly rather than in passing.

**Before sending** — read it back for a case in disguise. *Always, never, actually, to be fair, I've realised.* Cut them. Then check what you are expecting back: if a slow reply would anger you, it is early. An invitation with a required answer is not one.

*If they don't take it, you have done the part that was yours. Whether they meet it is theirs, and always was.*

---

## 09 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it is never measured against anything you wrote before.

Reading your own words back is the most direct version of the distance the fourth step trains.

Any of these, or none.

- Where did it sit in your body?
- What was the rerun? Write the line you kept getting right.
- How many times had you run it before you noticed you were running it?
- What was actually crossed? Not who — what.
- *What was this for* — what came up, without needing to answer it?
- What did you say to yourself from across the room?
- Is this the same anger as last time, or a different one wearing the same clothes?
- What did you write here last time? Read it back.

---

## 10 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half exits — into a room, a tone, a silence, something you did or didn't do — and lands somewhere you can't see from where you're standing.

**The specific blind spot here** — anger's exterior is the one people misjudge by the widest margin. Volume feels normal from inside. Your face feels neutral. And the rerun you've been running is silent, so what arrives on the other side has no build-up attached to it. From where you stand it was the sixth round of an argument. From where they stand it was the first, and it was sudden.

**Their earlier information** — people close to you can usually see it coming before you feel it. That makes them a real early-warning instrument, and it's worth asking directly: *what do you see, before I know?*

**Naming the act, not the character** — *"I raised my voice at you on Sunday, in front of the kids"* is ownership. *"I've been a nightmare lately"* is not; it names nothing and quietly asks them to disagree with it. Pick the act they'd name if someone asked them.

> "I said the thing about your job. I knew where it would land and I said it anyway."
> "I walked out mid-conversation and didn't come back."

**No because.** Anger arrives with an unusually complete case attached, and the case is what wants to go into the sentence. You may be entirely right about the underlying thing. It still has no place here. Two conversations, not one.

**No self-attack.** *"I've got a problem, I'm sorry, I'm working on it"* said with enough distress asks them to reassure you about your anger. That's a lot to ask of the person it arrived at.

**Describe what was observable, ask about the rest.** You don't know their interior, and asserting it puts words in their mouth. *"You went very still. I don't want to guess what that was like — I'd rather hear it."* Then let them answer without correcting it.

**The checkable change** — anger repairs by leaving earlier, not by leaving better. *"I'm going to go outside when it starts, before it gets loud"* is small, specific and something they can watch for. *"I'll never do that again"* isn't.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. Someone else's account of you isn't automatically more accurate than your own. And if someone is being violent or controlling toward you, this isn't the resource for that situation — the Proximity Guide's third tier is, and your safety is a separate question from your regulation.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Build the case. Win it before you get there.

That's the instruction. Assemble the examples, run the conversation, have the better line ready. Get to the argument with it already won.

And it works — you are rarely caught without an answer.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Being walked over. Saying nothing and regretting it. Being the reasonable one who gets taken advantage of.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the afternoons*, or *the conversations I won in my head and never actually had.*

---

**What it should be attending to instead**

It isn't the opposite of the case. The opposite is saying nothing, and you've done that, and it's what built the case in the first place.

What's available is a different instruction about **when**.

The old one collects and delivers later. The successor says it at the time, once, without the eleven supporting instances.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *say the thing in the week it happens, badly if necessary.* Or plainer.

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples people write: *raises it the same day. Says one thing rather than the case. Lets a small one go without adding it to anything.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Feels the heat and doesn't open the file. Says the plain sentence. Leaves the room before the rerun starts.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
