# t1-09 · The Insecurity Anchor Protocol

**Label:** Anchor · **State:** Unsteady · **Frameworks:** Jung, Kross · **extras:** `['advisory','invitation']`
**Resources: 10** · all conditionals apply

> **Note:** `META['t1-09'].frameworks` currently reads `['jung','dispenza']`. Authored here against Kross & Ayduk, which is what the fourth step rests on. Data fix tracked as SR-098.

---

## 01 · Guided Meditation
*Do it with me.*

> **PURPLE/MUSIC** — bed in, 90 BPM, 3/4. Five-bar phrase. Turn at four seconds.

It's already running, isn't it. The checking. How you're sitting, whether you're doing this properly, whether it's working yet.

> **GOLD/PAUSE**

That's the thing we're here about. So we'll take it off the table now — there's nothing here to get right, and nobody marking it.

> **GOLD/PAUSE**

This works on the state and puts some ground under you. It leaves the opinion where it is — reassurance is something you'd have argued with anyway, so we're doing something else.

---

### Recognition

Find where it is in your body, before any of the words.

> **GOLD/PAUSE**

Chest, often — something unsteady rather than heavy. The stomach. A tightness in the throat that arrives just before speaking. Hands that want something to do.

> **BLUE/ILLUSTRATION** — a form on an uneven base. Upright. Not falling.

Now name the state. One word. **Unsteady.**

> **GOLD/PAUSE**

That word is doing something precise. It describes how you're standing, not what you're worth.

Because this state has an opinion attached, and the opinion presents itself as a fact you've finally noticed. *Not enough. Not really. Found out eventually.*

> **GOLD/PAUSE** — long

We're not going to argue with it. Arguing gives it something to answer.

> **GOLD/PAUSE**

Instead, notice what just happened. You described a state — and something in you did the describing.

> **GOLD/PAUSE** — long

Those aren't the same thing.

The opinion is in the room. You're the one who noticed it was in the room. That's a different position, and you're already standing in it.

> **GOLD/PAUSE**

That's the whole of this step. Not believing something better about yourself. Just being the one who's looking, for a second, rather than only the thing being looked at.

---

### Regulation

Four counts in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Six counts out. Longer out than in.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Attention into the centre of your chest.

> **RED/ACTION** — feet flat, pressed into the floor. Offered, not instructed.

Press your feet into the floor. Feel the floor push back. This state is unsteady and the floor is not.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six
> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Nothing to be good at here. Nobody's watching this bit.

> **GOLD/PAUSE** — extended

---

### Release

Two things are running.

> **GOLD/PAUSE**

There's the state. And there's the auditing — checking yourself against everyone in the room, replaying what you said, working out how it landed, deciding what it revealed about you.

It feels like being careful. It runs constantly and it never clears you.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Let the state be here. It arrived, it's uncomfortable, it isn't being argued with.

Set down the auditing. Only the auditing.

> **GOLD/PAUSE** — long

And the question. Not *what's wrong with me* — that's the question the auditing is already asking, on repeat, and it has never once returned an answer you could use.

**What was this for?**

> **GOLD/PAUSE** — long

Watching yourself closely in a room is a skill. It was learned somewhere, and it was learned because at some point it was useful to know exactly how you were landing.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

It's still running. It hasn't been told the situation changed.

> **GOLD/PAUSE** — very long

---

One further, while there's room. If there isn't, come back to the count and finish — that's complete.

> **GOLD/PAUSE** — long

Still here.

> **GOLD/PAUSE**

Then — what does the opinion say would happen, if it turned out to be right?

> **GOLD/PAUSE** — very long

> **BLUE/ILLUSTRATION** — an upright form on an uneven base, and beneath the base an older, level one.

Not the practical answer. The one underneath.

> **GOLD/PAUSE** — long

For a lot of people it isn't about being wrong about themselves. It's what follows — being thought less of, quietly, by people whose view of them holds them in place.

> **GOLD/PAUSE** — very long

That's why evidence never settles it. You're not asking whether you're competent. You're checking whether you're still held.

> **GOLD/PAUSE** — very long

I'm not telling you that's yours. From outside your life nobody knows. If something landed, leave it there. If nothing did, that's a real answer.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

And the auditing — what's it protecting?

> **GOLD/PAUSE** — very long

Exactly that. Find the fault first, correct it before anyone sees, stay held. It's been doing that job for years and it has never once been thanked for it.

> **GOLD/PAUSE**

Expensive, and entirely on your side.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

> **GOLD/PAUSE** — long

Two things before we move.

> **GOLD/PAUSE**

Something will arrive behind that — probably *other people just get on with things.*

> **GOLD/PAUSE** — very long

Put it down. If what's underneath is whether you're still held by the people who matter, then of course this takes up so much of you. Struggling with it is the right size of response.

> **GOLD/PAUSE** — long

And something in you looked underneath the opinion instead of arguing with it. Arguing is what you've done for years, and it has never worked.

> **GOLD/PAUSE** — very long

One more, simply true rather than comforting. Whatever you found under there, you're not the only one. Almost nobody says it, which is the only reason it feels like a defect.

---

### Rise

Step outside it.

See yourself from across the room. Someone sitting there, feet on the floor, breathing four and six.

> **BLUE/ILLUSTRATION** — figure at middle distance, room around it, unhurried.

Speak to them as *you*, not *I*.

*You are unsteady today. That's a state, and it's a state you've been in before.*

> **GOLD/PAUSE**

Notice something about being out here. From this distance there's a person, and there's an opinion about the person, and they're two things. From inside, they were one thing.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

Now — here's what being able to see it is actually good for.

> **GOLD/PAUSE**

Not making it stop. You've watched it not stop on request. It's that once you can see where your attention is sitting, you can put it somewhere else on purpose.

> **GOLD/PAUSE** — long

And look at where it's been sitting. A room you were in last week. One you haven't walked into yet. Neither of those has anything in it you can use.

Everything you actually have is here.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

So put it somewhere by choice.

> **GOLD/PAUSE**

Not on the version of you who feels confident — that one isn't available on demand and building him would be a lie.

Not on the version who's already got the thing, either. That one does nothing for you.

> **GOLD/PAUSE** — long

On the one who does the work today. Unsteady, and doing it.

Where are they. What are they about to say. What are their hands doing. What's the first sentence out of their mouth.

> **GOLD/PAUSE** — long

That's not a reward waiting at the end of something. That person is the thing being built. Every time you're the one who does it anyway, that's who gets made.

> **TEAL/BREATH** — in, four
> **TEAL/BREATH** — out, six

And one thing already true. Something you did, not something you are. Small and factual.

> **GOLD/PAUSE**

---

> **PURPLE/MUSIC** — bed lifts, resolves on the turn.

Come back. Feet on the floor.

The opinion may still be here. It doesn't get overturned in one go and nothing here pretended it would. What's changed is that there's a bit of ground under you, and some space between you and it.

Recognition. Regulation. Release. Rise.

---

## 02 · Cue Card
*Do it yourself.*

> Second person throughout — deliberate, not stylistic. On this protocol it carries most of the work: *you* is what puts space between the person and the opinion.

### Front

**Name it** — *You are unsteady.* How you're standing, not what you're worth.
**Breathe it** — Four in, six out. Feet into the floor.
**Stop auditing** — Ask *what was this for*, not *what's wrong with me*.
**Step out** — *Unsteady, and doing it anyway.*

### Back

**Recognition** — Find it in your body first: chest, stomach, a tightness in the throat before speaking. Name the state in one word. That word describes how you're standing, not what you're worth. This state comes with an opinion attached that presents itself as a fact you've finally noticed. Don't argue with it — arguing gives it something to answer.

**Regulation** — Four in, six out. Attention in the centre of your chest. Press your feet into the floor and feel it push back — the state is unsteady and the floor isn't. Nothing to be good at here.

**Release** — Two things are running. The state, and the auditing — checking yourself against the room, replaying what you said, working out what it revealed. It feels like being careful. It runs constantly and it never clears you. Set down the auditing. Ask *what was this for* and leave it open.

**Rise** — See yourself from a distance. From out there, the person and the opinion about the person are two things; from inside they were one. Then one concrete scene: doing the thing anyway, unsteady. Not the scene where you feel confident. Then one thing you did — not something you are.

---

## 03 · How This Works
*Why it works.*

**What the state is doing**

This is an unsettled state rather than a fully mobilised one. In the body: an unsteadiness through the chest, something turning in the stomach, tightness in the throat immediately before speaking, restlessness in the hands, and a raised sensitivity to how a room is responding.

That last part is the distinguishing feature. Attention is turned outward, monitoring, and simultaneously turned inward, evaluating the returns. Both at once, continuously.

**Why the state comes with an opinion**

Like shame, this state doesn't describe a situation — it describes you, and it presents that description as an observation rather than as a symptom. *Not enough. Not really. Found out eventually.*

Arguing with it fails, reliably. Counter-evidence gives the auditing something new to process, and it will find the flaw in it. That's why nothing on this protocol attempts reassurance.

What Recognition does instead is give the opinion a category. Naming the state doesn't dispute the content; it changes the status of the content from fact to symptom. A symptom can be worked on. A fact can only be argued with.

**Why the exhale is longer, and why the feet**

You can't decide a state down. You can decide your breathing, and it's the one reachable control. Lengthening the out-breath relative to the in-breath is what shifts the system toward settled.

The feet do something specific here. This state is characterised by unsteadiness, and pressure against a fixed surface is the most direct available contradiction of that — not as a metaphor, but because the body registers support and stops registering it unless attention is sent there.

**Why Release goes after the auditing**

There's the state, and there's the auditing — checking yourself against the room, replaying what you said, working out how it landed.

Two different costs. The auditing feels like conscientiousness. But it runs whether or not anything happened, it finds something every time, and it never returns a verdict of fine. It doesn't finish, which is the tell.

The change of question is the whole design of this step. *What is wrong with me* is precisely what the auditing already asks, all day. Asking it again inside a protocol would be running the loop with better lighting. *What was this for* asks about function instead — and what tends to surface is that close self-monitoring in a room is a learned skill, learned because knowing exactly how you were landing was once useful information.

It's still running. It hasn't been told the situation changed. Where it was learned is not something this platform will tell you, and working it out is not required for the protocol to do its job.

**Why Rise rehearses doing it anyway**

Observing an experience from outside it lowers distress at the time and reactivity afterwards; distraction does neither. Second-person self-address is one of the reliable ways to produce that shift, which is why the cue card says *you*.

There's a second effect on this protocol specifically. From the outside, there's a person and there's an opinion about the person, and they're two objects. From inside they were one. That separation is most of what the fourth step is for here.

The forward scene has to be concrete, and on this protocol it also has to include the state. Rehearsing feeling confident is rehearsing something you can't produce on demand, and the system doesn't accept it. Rehearsing doing the thing while unsteady is a scene that's actually available, and it's the one that transfers.

---

### What we rest on

**Shadow & individuation — C. G. Jung** · *interpretive* · informs Release

What you decline to look at keeps running unattended. The usable test is proportion: when a reaction outruns the event that occasioned it, the surplus is carrying information about something other than the event. There's no finish line and nothing to complete. *Here it accounts for why an ordinary remark can produce a disproportionate day.*

*Offered as a lens rather than a finding, with no controlled evidence behind it. What it shows you, if anything, is yours to read — this platform will not tell you what your surplus means.*

**Distance & rehearsal — Kross & Ayduk, with King** · *peer-reviewed* · supplies Rise

Observing an experience from outside it, rather than from inside looking out, lowers distress and later reactivity. Distraction does neither. Second-person self-address is one of the reliable ways to produce that shift. Rehearsing a specific future scene in concrete detail lifts outlook; general optimism does not. *Here it is what separates you from the opinion about you — two objects from outside, one from inside.*

*The effect is on the person rehearsing. It acts on your own steadiness and makes no claim to act on anyone else, or on how anything turns out.*

**Where the reading is yours** — this explains the machinery. What the opinion is about, where it was learned, and whether any part of it is warranted are readings that belong to you.

---

## 04 · Somatic Release Activities
*Between sessions.*

**Feet into the floor.** Press both down steadily, feel the floor push back, hold for a slow five. The most direct thing available for a state whose whole signature is unsteadiness. Works sitting, standing, in a meeting.

**Long exhale, no ceremony.** Four in, six out, three or four cycles. Available anywhere.

**Both forearms on the surface in front of you.** Weight through them. This state holds the arms slightly lifted and ready; putting them down changes something.

**Take up your actual amount of room.** Not expanding — just stopping the small contraction. Feet apart rather than tucked, elbows off your sides, back against the chair.

**Say one thing early.** In any room, say something in the first few minutes — a question, an agreement, anything. The auditing gets heavier the longer you go without speaking, and the first contribution is the expensive one regardless of when you make it.

**One horizon.** Look at the furthest thing you can see. This state pulls focus to the faces nearest you.

*Unclench the jaw when you notice it. It holds here quietly.*

---

## 05 · Safe Practice
*When and how to proceed.*

**What this practice does**

Works with a state that arrives with an opinion attached, using breath, attention and observation. It doesn't dispute the opinion and it doesn't confirm it. It puts ground underneath you and space between you and it.

**Pacing**

Once through is a complete use. Use it when the state is there. Before a specific occasion is a legitimate use — this is one of the protocols people run in a car park before going in.

If four and six is a stretch, shorten both and keep the ratio uneven.

**What people commonly notice**

The auditing starting up about the protocol itself — whether you're doing it correctly, whether you're feeling the right things. That's the loop finding a new subject, and it's ordinary. Note it and come back to the count.

Resistance at the fourth step, because looking at yourself from outside is uncomfortable when you expect the view to be unkind.

Relief that's smaller than hoped for. This state doesn't clear in one session and nothing here suggests it should.

**When to slow down**

If the fourth step turns into an inventory of everything you've got wrong, stop. That's the auditing restarting inside the step built to interrupt it. Come back to the breath and end there. Three steps is a complete use.

If Release opens something much larger — something old, something you weren't looking for — you can stop and come back to the breath. Surfacing isn't an instruction to follow it.

**When a person in the room is the right tool**

Contact someone today — a doctor, a helpline in your country, or a person you trust — if you're having thoughts of harming yourself or punishing yourself, if you've stopped going to things entirely, if you're using something to get through occasions, or if the opinion is now constant rather than episodic.

**Alongside other support**

If you're with a therapist, doctor or counsellor, this sits alongside that and replaces nothing. This is one of the protocols where having a person is worth a great deal.

---

## 06 · Proximity Guide
*How close to stay.*

This state often has a live external source — a person, a group, a workplace, a feed — where contact reliably produces it. How much contact you have is a real variable.

Three tiers. Which one yours belongs in is your read, on information nobody here has.

**Worth staying engaged with**

Contact is uncomfortable but the discomfort is about the newness or the stretch, not about how you're treated. You're taken seriously when you speak. Your reaction is roughly proportionate and settles once the occasion is over.

Distance isn't the tool here — it's the thing the state is asking for and it would cost you the room. Regulation before, and going anyway, is the tool.

**Worth reducing the surface area of**

Contact produces the state reliably, and you've noticed you're smaller in that room than in others. Where you're spoken over, or corrected in front of people, or your contributions surface later under someone else's name.

Reduction here is specific: fewer occasions, a channel you leave, a feed you stop opening, conversations you decline to be drawn into. That isn't the same as ending anything.

Also worth attending to at this tier: where the reaction consistently outruns the event, the extra is carrying information about something other than the event. An interpretive lens rather than a finding, and what it shows you is yours to read.

**Past what self-regulation is for**

Where you're being belittled, undermined or humiliated, particularly in front of others. Where someone manages you by keeping you uncertain. Where you're being made unsafe at work.

That isn't a regulation problem, and treating it as one converts a situation needing other people into a private failure of coping. What it needs is a doctor, HR, a union, a lawyer, or a friend who knows the whole picture rather than the version you can bear to tell.

**Using this**

Notice the tier. Then notice whether it's the tier you'd assign if a friend described the same thing. People in this state place their own situation lower than they'd place someone else's, more reliably than on any other protocol. Where it goes next is yours.

---

## 07 · Disclosure & Support
*A script for someone close.*

The obvious response to this one is reassurance, which doesn't work and which everyone offers. Telling someone what does work spares you both.

**Saying it**
> "I get a thing where I'm convinced I'm not up to something and I'm about to be found out. It isn't tied to how things are actually going. I'd rather you knew than kept wondering why I go strange before things."

**Describing what it's actually like**

> "It's physical. Chest goes unsteady, stomach turns, throat tightens just before I speak. That's all happening before I've thought anything."

> "The part that's hard to explain is the auditing. I'm watching how I'm landing in a room the whole time I'm in it, and then replaying it afterwards. It's exhausting and it isn't a choice."

**How to tell it's coming**

> "I go quiet in groups. Or I talk too much and too fast. I start deferring to everyone. I decline things with a reason attached."

> "If you notice, the useful thing is small and specific — 'you should say the thing you told me earlier'. Being handed a concrete opening works. Being told I'm great doesn't."

**What helps**

> "Facts about what happened, not opinions about who I am. 'The thing you did on Tuesday worked' lands. 'You're brilliant' bounces off — the auditing takes it apart in about ten seconds."

> "In a room, bringing me in by name once. That's usually all it takes."

**What doesn't**

> "Reassurance. I know you mean it. It gives the loop something new to argue with, and it always wins."

> "Being told I'm overthinking. I am. Being told adds a second thing I'm getting wrong."

**If they ask what you're doing about it**

> "I run a method when it comes. Four steps. First I name it as a state — this one arrives disguised as a fact I've finally noticed about myself, and calling it a state puts it in a category rather than making it true. Then breathing, four in and six out, with my feet pressed into the floor, because the state is unsteady and the floor isn't. Then I stop the auditing, which is the loop that never clears me. Then I look at myself from across the room — and from out there, me and the opinion about me are two different things."

> "It doesn't make me confident. It gets me into the room anyway."

*Tell one person. It can be a professional rather than a friend. This state's instruction is to keep the doubt hidden in case anyone agrees with it, and telling someone contradicts that directly.*

---

## 08 · Invitation to Repair
*Reopening it with them.*

Send it from the far side of the protocol, not the middle. From inside the state, an invitation becomes a request to be reassured, and it will be answered with reassurance rather than with anything true.

**The rule that makes it sendable:** no prosecution of them, and no fishing. If the message would only be successful if they told you that you're fine, it isn't an invitation.

**Sendable**
> There's something I'd rather say than keep managing quietly.
>
> I've been finding things hard around this and I've been going quiet rather than saying so. That's on me, not on you, and I didn't want it to keep reading as distance.
>
> I'm not looking for reassurance. I just wanted it said out loud.

**Shorter**
> I've been quiet lately and it isn't about you. I'd rather tell you than let you guess.

**Where you've withdrawn from them**
> I've pulled back from you over the last while and I know you'll have noticed. It wasn't about anything you did. I'd rather hear what that's been like than assume it didn't land.

**Where it's about how you were treated**
> Something happened in that meeting that I've been sitting with. I'm not looking for an apology and I'm not making it a thing. I'd rather say it than let it change how I am around you.

**Before sending** — read it back and ask what answer would make it a success. If the only successful answer is *you're fine*, it's fishing. Rewrite it so that no reply at all would still leave it worth having sent.

*If they don't take it, you've done the part that was yours. Whether they meet it is theirs, and always was.*

---

## 09 · Your Record
*What changed, in your words.*

Written on your device and kept there. Your account, in your language, for you to read back — nobody else sees it, and it's never measured against anything you wrote before.

Any of these, or none.

- Where did it sit in your body?
- What was the occasion? Write what actually happened, without the reading attached.
- What did the auditing find? Write the sentence it used.
- Had anything actually gone wrong, or only possibly gone wrong?
- *What was this for* — what turned up, without needing to answer it?
- What did you say to yourself from across the room? Would you say it to someone else?
- What was the scene where you did it anyway? Did you do it?
- What did you write here last time? Read it back — as if someone else wrote it.

That last instruction is deliberate. Reading your own account as though it were someone else's is the same distancing move as the fourth step, and it's usually where people first hear how they talk to themselves.

---

## 10 · Accountability & Empathy
*What it does outside you.*

The protocol trains the interior half of the state. The other half exits — and this one exits in ways that look like modesty from inside and like something else entirely from outside.

**The specific blind spot here** — this state exits as absence. Not putting yourself forward, not saying the thing, not taking the place. From inside that's staying out of the way. From outside it's a person who was capable and didn't show up, and other people had to cover it. They rarely say so, because complaining about someone's self-doubt feels unkind.

**The second one** — the pre-emptive undercut. Getting there first: *this is probably rubbish, don't expect much, I'm not the right person for this.* From inside it's honesty, or managing expectations. From outside it hands them the job of talking you up before they can respond to the actual thing, every time, and it's the version people tire of quietly.

**The third one** — deferring. Agreeing with the room, not saying the objection, going along. From inside it's not being difficult. From outside it's the loss of your actual view, and the people who wanted it are the ones who notice.

**Their earlier information** — people close to you often see it before you feel it. Worth asking directly: *what do you see, before I know?*

**Naming the act, not the character** — *"I didn't say the thing I thought in that meeting, and you ended up making the argument alone"* is ownership. *"I'm useless in meetings"* is not; it names nothing, it's the opinion again, and it asks them to argue with it.

If your account of yourself is a verdict rather than an act, you haven't done accountability. You've done the state, out loud, at somebody.

**No because.** The state is a real reason and it doesn't belong in the sentence.

**No self-attack.** On this protocol that's not a matter of manners. Self-attack is the state's native mode, and an apology built out of it hands the other person the job of reassuring you — which is the whole pattern, repeating inside the apology for the pattern.

**Describe what was observable, ask about the rest.** *"I've been quiet in things where I'd normally have said something. I'm not going to tell you what that's been like — I'd rather you told me."* Then let them answer without correcting it or apologising for the answer.

**The checkable change** — this repairs by saying one thing early rather than by becoming confident. *"I'm going to say something in the first few minutes of things, even when I don't want to"* is small, specific and observable.

**Where this stops** — a reaction is information about the exterior of your state, not a verdict on you. This state will take anything external and feed it straight into the auditing; if that's what's happening, you're not doing this resource, you're doing the thing the third step asked you to put down. Come back another day. And if someone has been belittling you, their account of your conduct isn't a reliable one.

---

## 12 · The Decision
*What takes over.*

Something has been running this for a long time. It has a job, it does it well, and it costs you.

This is where you write what takes over. Not once you're better — who runs the next one.

---

**What's running now**

Audit. Find the fault before anyone else does.

Check how that landed. Replay what you said. Work out what it revealed. Get to the problem first, so at least you're not the last to know.

It isn't a fault and it isn't irrational. Somewhere it was the right answer to something, and it has been carrying it out ever since.

Does that sound like yours? If the wording's off, change it. It should read like your own head, not like something written about you.

**What it's been protecting**

Say it in one line.

*Being found wanting by people whose view of me holds me in place. Being thought less of, quietly, by someone who won't say it.*

Yours may be different. Write the one that's actually true.

**What it's cost**

Two things. Not a list — the list is the old pattern doing its work on this page.

Most people put something like: *the hour after every meeting*, or *the things I didn't say because I'd already run how they'd land.*

---

**What it should be attending to instead**

It isn't believing something better about yourself. Those don't hold and you've tried.

What's available is a different instruction about **who does the assessing**.

The old one assesses continuously, in advance, from inside. The successor does the work and lets it be assessed by the people whose job that actually is.

> **So: what should it be on?**
>
> Not a value. Something concrete. Write it as an instruction, the way the old one is written.

Something like: *do it, let it be seen, and stop marking it myself.*

Yours, in your words.

---

**What that version does**

Three things, small enough to see.

Not qualities — *calm, confident, secure* can't be done and won't survive a bad morning. Behaviour.

> **On an ordinary day, what do they do?**

Examples: *contributes in the first few minutes. Sends it without the third read. Asks what someone thought rather than deciding for them.*

Three. Yours.

---

**Who runs the next one**

This is the part the whole resource is for.

The next time it comes — and it will — this version is who's in it. Not who you become once it's passed. Who's standing there while it's happening, and not going down.

The old one couldn't be in it. It could only try to get ahead of it.

> **So: what do they do in the middle of one?**
>
> During. Not after.

*Feet on the floor. Says the thing unsteady rather than waiting to feel ready. Doesn't replay it on the way home.*

Write yours.

---

**Read it back tomorrow**

This gets rewritten. Nobody arrives at it, and there's no version that's finished.

The old one took years to write and it won't hand over the job because you asked once. What changes is that there's now something to hand it to.

*Written on your device and kept there. Nobody else sees it, and it's never measured against anything you wrote before. Because it's only on this device, clearing your browser or switching device will remove it. The export button is there whenever you want a copy you keep.*
